package com.wevois.vcarebackoffice.Monitoring.VehicleMonitoring;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;

public class ActiveVehiclesFragment extends Fragment {
    DatabaseReference databaseReferencePath;
    VehicleMonitoringAdapter vehicleMonitoringAdapter;
    ArrayList<VehicleMonitoringModel> vehicleList = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    DataSnapshot employeeDataSnap, vehicleDataSnap;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_active_vehicles, container, false);
        ListView monitoringLv = view.findViewById(R.id.vehicle_monitoring_lv);
        databaseReferencePath = common.getDatabasePath(getActivity());
        common.setProgressDialog("Please wait...", "Loading...", getActivity(), getActivity());
        vehicleMonitoringAdapter = new VehicleMonitoringAdapter(getActivity(), vehicleList);
        monitoringLv.setAdapter(vehicleMonitoringAdapter);

        databaseReferencePath.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() == null) {
                    common.closeDialog(getActivity());
                    return;
                }
                employeeDataSnap = dataSnapshot;
                getDataFromFirebase();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return view;
    }

    public void getDataFromFirebase() {
        databaseReferencePath.child("Vehicles").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() == null) {
                    common.closeDialog(getActivity());
                    return;
                }
                vehicleDataSnap = dataSnapshot;
                new vehicleMonitoring().execute();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private class vehicleMonitoring extends AsyncTask<Void, String, JSONArray> {
        @Override
        protected JSONArray doInBackground(Void... voids) {
            for (DataSnapshot dataSnapshot1 : vehicleDataSnap.getChildren()) {
                if (dataSnapshot1.hasChild("status")) {
                    if (dataSnapshot1.child("status").getValue() != null) {
                        String status = dataSnapshot1.child("status").getValue().toString();
                        if (Integer.parseInt(status) == 3) {
                            String vehicleName = "", wardName = "", name = "", helperName = "", driverName = "";
                            vehicleName = dataSnapshot1.getKey();
                            if (dataSnapshot1.hasChild("assigned-task")) {
                                if (dataSnapshot1.child("assigned-task").getValue() != null) {
                                    wardName = dataSnapshot1.child("assigned-task").getValue().toString();
                                }
                            }
                            if (dataSnapshot1.hasChild("assigned-driver")) {
                                if (dataSnapshot1.child("assigned-driver").getValue() != null) {
                                    String driverId = dataSnapshot1.child("assigned-driver").getValue().toString();
                                    if (driverId.length() > 0) {
                                        driverName = getName(driverId) + "[" + driverId + "](D)";
                                    } else {
                                        driverName = "Not Available";
                                    }
                                }
                            }
                            if (dataSnapshot1.hasChild("assigned-helper")) {
                                if (dataSnapshot1.child("assigned-helper").getValue() != null) {
                                    String helperId = dataSnapshot1.child("assigned-helper").getValue().toString();
                                    if (helperId.length() > 0) {
                                        helperName = getName(helperId) + "[" + helperId + "](H)";
                                    } else {
                                        helperName = "Not Available";
                                    }
                                }
                            }
                            name = driverName + "\n" + helperName;
                            vehicleList.add(new VehicleMonitoringModel(vehicleName, wardName, name));
                        }
                    }
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        protected void onPostExecute(JSONArray aVoid) {
            common.closeDialog(getActivity());
            Collections.sort(vehicleList, (obj1, obj2) -> obj1.ward.compareToIgnoreCase(obj2.ward));
            vehicleMonitoringAdapter.notifyDataSetChanged();
            super.onPostExecute(aVoid);
        }
    }

    private String getName(String assignedId) {
        String name = "";
        if (employeeDataSnap.hasChild(assignedId)) {
            if (employeeDataSnap.child(assignedId).hasChild("GeneralDetails")) {
                if (employeeDataSnap.child(assignedId + "/GeneralDetails").hasChild("name")) {
                    if (employeeDataSnap.child(assignedId + "/GeneralDetails").child("name").getValue() != null) {
                        name = employeeDataSnap.child(assignedId + "/GeneralDetails").child("name").getValue().toString();
                    }
                }
            }
        }
        return name;
    }
}