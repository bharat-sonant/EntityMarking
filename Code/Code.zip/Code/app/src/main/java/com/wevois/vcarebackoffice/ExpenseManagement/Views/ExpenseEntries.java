package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.github.drjacky.imagepicker.ImagePicker;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.ExpenseListModel;
import com.wevois.vcarebackoffice.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

public class ExpenseEntries extends AppCompatActivity {
    Spinner vendorSpinner, billTypeSpinner;
    EditText amountEt, billNoEt, purchaseEt;
    ImageView billImage;
    SharedPreferences pathSharedPreferences;
    boolean isBackClick = true;
    TextView backTV;
    Button saveButton, uploadButton;
    ProgressDialog progressDialog;
    ArrayList<ExpenseListModel> arrayListExpense = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<String> billArrayList = new ArrayList<>();
    ArrayList<String> vendorArrayList = new ArrayList<>();
    ArrayList<String> positionArrayList = new ArrayList<>();
    private StorageReference mStorageRef;
    String vendorId, vendorName, dateString = "", loggedInName, type;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_entries);
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait");
        progressDialog.setMessage("Data Uploading...");
        if (getIntent().hasExtra("expenseListData")) {
            arrayListExpense = new Gson().fromJson(getIntent().getStringExtra("expenseListData"), new TypeToken<ArrayList<ExpenseListModel>>() {
            }.getType());
        }
        mStorageRef = FirebaseStorage.getInstance().getReference("Common");
        initMethod();
        setAction();
        getVendorsList();
        getBillType();
    }

    public void initMethod() {
        vendorSpinner = findViewById(R.id.vendorSpinner);
        billTypeSpinner = findViewById(R.id.billTypeSpinner);
        billNoEt = findViewById(R.id.billNoEt);
        amountEt = findViewById(R.id.amountEt);
        billImage = findViewById(R.id.billImage);
        purchaseEt = findViewById(R.id.purchaseEt);
        uploadButton = findViewById(R.id.upload);
        backTV = findViewById(R.id.back_Button);
        saveButton = findViewById(R.id.saveButton);

        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        dateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date().getTime());
    }

    public void setAction() {

        backTV.setOnClickListener(view -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });

        saveButton.setOnClickListener(view -> validationAllDetails());

        uploadButton.setOnClickListener(view -> callCamera());
    }

    private boolean validationAllDetails() {
        boolean isValid = true;
        try {
            if (billTypeSpinner.getSelectedItem().equals("Final Bill")) {
                if (billNoEt.getText().toString().length() == 0) {
                    billNoEt.setError("Please enter bill number ");
                    billNoEt.requestFocus();
                    isValid = false;
                } else if (amountEt.getText().toString().length() == 0) {
                    amountEt.setError("Please enter amount");
                    amountEt.requestFocus();
                    isValid = false;
                } else if (billImage.getDrawable() == null) {
                    common.showAlertDialog("Alert", "Click Picture", false, this);
                    isValid = false;
                } else if (purchaseEt.getText().toString().length() == 0) {
                    purchaseEt.setError("Please enter purchase details");
                    purchaseEt.requestFocus();
                    isValid = false;
                } else {
                    progressDialog.show();
                    CheckExistFile();
                }
            } else {
                if (amountEt.getText().toString().length() == 0) {
                    amountEt.setError("Please enter amount");
                    amountEt.requestFocus();
                    isValid = false;
                } else if (billImage.getDrawable() == null) {
                    common.showAlertDialog("Alert", "Click Picture", false, this);
                    isValid = false;
                } else if (purchaseEt.getText().toString().length() == 0) {
                    purchaseEt.setError("Please enter purchase details");
                    purchaseEt.requestFocus();
                    isValid = false;
                } else {
                    progressDialog.show();
                    CheckExistFile();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isValid;
    }

    public void CheckExistFile() {

        int position = vendorSpinner.getSelectedItemPosition();
        vendorId = positionArrayList.get(position);

        StorageReference storageReference = mStorageRef.child("Expenses").child(vendorId + ".json");
        storageReference.getDownloadUrl().addOnSuccessListener(uri -> checkDataFound()).addOnFailureListener(e -> makeJSONOnStorage());
    }

    public JSONObject makeJSONOnStorage() {
        JSONObject objectMainList = new JSONObject();
        try {
            JSONObject jsonObjectList = new JSONObject();
            String imageName = dateString + ".jpeg";
            int position = vendorSpinner.getSelectedItemPosition();
            vendorId = positionArrayList.get(position);
            vendorName = String.valueOf(vendorSpinner.getSelectedItem());

            pathSharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
            loggedInName = pathSharedPreferences.getString("loggedInName", "");
            type = getSharedPreferences("loginData", MODE_PRIVATE).getString("loginType", "");
            try {
                jsonObjectList.put("uri", imageName);
                jsonObjectList.put("vendorName", vendorName);
                jsonObjectList.put("billType", billTypeSpinner.getSelectedItem().toString());
                jsonObjectList.put("billNo", billNoEt.getText().toString());
                jsonObjectList.put("amount", amountEt.getText().toString());
                jsonObjectList.put("purchase", purchaseEt.getText().toString());
                jsonObjectList.put("expenseBy", loggedInName + "(" + type + ")");
                jsonObjectList.put("Approval","Pending");

                objectMainList.put(dateString, jsonObjectList);

                arrayListExpense.clear();
                arrayListExpense.add(new ExpenseListModel(
                        imageName,
                        vendorName,
                        billTypeSpinner.getSelectedItem().toString(),
                        billNoEt.getText().toString(),
                        amountEt.getText().toString(),
                        purchaseEt.getText().toString(),
                        purchaseEt.getText().toString(),
                        purchaseEt.getText().toString(),
                        vendorId
                ));

                JSONObject ExpenseList = objectMainList;
                try {
                    upLoadToStorage(ExpenseList);
                    imageUpload(imageName);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectMainList;
    }

    public void checkDataFound() {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        firebaseStorage.getReference().child("Common/Expenses").child(vendorId + ".json").getBytes(1000000).addOnSuccessListener(taskSnapshot -> {
            String expensesData = new String(taskSnapshot, StandardCharsets.UTF_8);

            String imageName = dateString + ".jpeg";
            try {
                JSONObject jsonObjectMainList = new JSONObject(expensesData);
                JSONObject jsonObjectList = new JSONObject();
                int position = vendorSpinner.getSelectedItemPosition();
                vendorId = positionArrayList.get(position);
                vendorName = String.valueOf(vendorSpinner.getSelectedItem());

                pathSharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
                loggedInName = pathSharedPreferences.getString("loggedInName", "");
                type = getSharedPreferences("loginData", MODE_PRIVATE).getString("loginType", "");
                try {
                    jsonObjectList.put("uri", imageName);
                    jsonObjectList.put("vendorName", vendorName);
                    jsonObjectList.put("billType", billTypeSpinner.getSelectedItem().toString());
                    jsonObjectList.put("billNo", billNoEt.getText().toString());
                    jsonObjectList.put("amount", amountEt.getText().toString());
                    jsonObjectList.put("purchase", purchaseEt.getText().toString());
                    jsonObjectList.put("expenseBy", loggedInName + "(" + type + ")");
                    jsonObjectList.put("Approval","Pending");
                    jsonObjectMainList.put(dateString, jsonObjectList);

                    arrayListExpense.clear();
                    arrayListExpense.add(new ExpenseListModel(
                            imageName,
                            vendorName,
                            billTypeSpinner.getSelectedItem().toString(),
                            billNoEt.getText().toString(),
                            amountEt.getText().toString(),
                            purchaseEt.getText().toString(),
                            purchaseEt.getText().toString(),
                            purchaseEt.getText().toString(),
                            vendorId

                    ));
                    try {
                        File output = File.createTempFile(vendorId, ".json");
                        try (FileWriter writer = new FileWriter(output)) {
                            writer.write(jsonObjectMainList.toString());
                            Uri uri = Uri.fromFile(output);
                            StorageMetadata metadata = new StorageMetadata.Builder().setContentType("json").build();
                            firebaseStorage.getReference().child("Common/Expenses").child(vendorId + ".json").putFile(uri, metadata).
                                    addOnSuccessListener(task -> {
                                        if (task.getTask().isSuccessful()) {
                                            imageUpload(imageName);
                                            showDialog("Data has been saved successfully.", true);
                                            progressDialog.dismiss();
                                        }
                                    });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    private void upLoadToStorage(JSONObject expenseList) throws IOException {
        File output = File.createTempFile(String.valueOf(vendorId), ".json");
        try (FileWriter writer = new FileWriter(output)) {
            writer.write(expenseList.toString());
            Uri uri = Uri.fromFile(output);
            StorageMetadata metadata = new StorageMetadata.Builder().setContentType("json").build();
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            firebaseStorage.getReference().child("Common/Expenses").child(vendorId + ".json").putFile(uri, metadata).
                    addOnSuccessListener(task -> {
                        if (task.getTask().isSuccessful()) {
                            showDialog("Data has been saved successfully.", true);
                            progressDialog.dismiss();
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void imageUpload(String imageName) {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference uploader = storage.getReference("Common/Images/" + vendorId + "/" + imageName);
        ByteArrayOutputStream toUpload = new ByteArrayOutputStream();
        Bitmap.createScaledBitmap(bitmap, 400, 600, false)
                .compress(Bitmap.CompressFormat.JPEG, 100, toUpload);
        byte[] result = toUpload.toByteArray();
        uploader.putBytes(result).addOnSuccessListener(taskSnapshot -> uploader.getDownloadUrl().addOnSuccessListener(uri -> {
        }));
    }

    ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), (ActivityResult result) -> {
        if (result.getResultCode() == RESULT_OK) {
            String[] file = result.getData().getData().getPath().split("/");
            InputStream inputStream = null;
            try {
                inputStream = getContentResolver().openInputStream(result.getData().getData());
                bitmap = BitmapFactory.decodeStream(inputStream);
                billImage.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    });
    private void callCamera() {
        ImagePicker.Companion.with(ExpenseEntries.this)
                .crop()
                .cropFreeStyle()
                .createIntentFromDialog(new Function1() {
                    public Object invoke(Object var1) {
                        this.invoke((Intent) var1);
                        return Unit.INSTANCE;
                    }

                    public final void invoke(@NotNull Intent it) {
                        Intrinsics.checkNotNullParameter(it, "it");
                        launcher.launch(it);
                    }
                });
    }

    public void getBillType() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("Common/BillTypes.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("BillTypeDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("Common/BillTypes.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String billTypeJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("BillTypeList", billTypeJsonData).apply();
                        pathSharedPreferences.edit().putLong("BillTypeDownloadTime", fileCreationTime).apply();
                        setBillType();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                setBillType();
            }
        });
        progressDialog.dismiss();
    }

    public void setBillType() {
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("BillTypeList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String billType = jsonObject.getString("billType");
                    billArrayList.add(billType);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            common.closeDialog(ExpenseEntries.this);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> billSpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, billArrayList);
        billSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        billTypeSpinner.setAdapter(billSpinnerAdapter);
    }

    public void getVendorsList() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("Common/VendorList.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("VendorListDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("Common/VendorList.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String vendorJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("VendorList", vendorJsonData).apply();
                        pathSharedPreferences.edit().putLong("VendorListDownloadTime", fileCreationTime).apply();
                        setVendorsList();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                setVendorsList();
            }
        });
        progressDialog.dismiss();
    }

    public void setVendorsList() {
        try {
            JSONObject vendorJsonData = new JSONObject(pathSharedPreferences.getString("VendorList", ""));
            Iterator<String> vendorKeys = vendorJsonData.keys();
            while (vendorKeys.hasNext()) {
                String key = vendorKeys.next();
                try {
                    if (key != "lastVendorId") {
                        JSONObject values = vendorJsonData.getJSONObject(key);
                        String name = values.getString("name");
                        vendorArrayList.add(name);
                        positionArrayList.add(key);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            common.closeDialog(ExpenseEntries.this);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> vendorSpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, vendorArrayList);
        vendorSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        vendorSpinner.setAdapter(vendorSpinnerAdapter);
        progressDialog.dismiss();
    }

    public void showDialog(String message, Boolean isFinish) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton("Ok", (dialog, id) -> {
            dialog.dismiss();
            if (isFinish) {
                finish();
                Intent i = new Intent(ExpenseEntries.this, ExpenseList.class);
                i.putExtra("expenseListData1", new Gson().toJson(arrayListExpense));
                startActivityForResult(i, 100);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(ExpenseEntries.this, ExpenseList.class);
        startActivity(intent);
    }
}