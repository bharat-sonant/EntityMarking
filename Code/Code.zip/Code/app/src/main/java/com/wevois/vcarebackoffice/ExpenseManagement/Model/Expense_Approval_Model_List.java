package com.wevois.vcarebackoffice.ExpenseManagement.Model;

public class Expense_Approval_Model_List {
    String Name;
    String Date;
    String Amount;
    String Purchase;
    String ExpenseBy;
    String Approval;
    String Approved;

    public String getApproval() {
        return Approval;
    }

    public void setApproval(String approval) {
        Approval = approval;
    }

    public Expense_Approval_Model_List(String name, String date, String amount, String purchase, String expenseBy, String approval, String approved) {
        Name = name;
        Date = date;
        Amount = amount;
        Purchase = purchase;
        ExpenseBy = expenseBy;
        Approval = approval;
        Approved = approved;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getPurchase() {
        return Purchase;
    }

    public void setPurchase(String purchase) {
        Purchase = purchase;
    }

    public String getExpenseBy() {
        return ExpenseBy;
    }

    public void setExpenseBy(String expenseBy) {
        ExpenseBy = expenseBy;
    }


    public String getApproved() {
        return Approved;
    }

    public void setApproved(String approved) {
        Approved = approved;
    }

    @Override
    public String toString() {
        return "Expense_Approval_Model_List{" +
                "Name='" + Name + '\'' +
                ", Date='" + Date + '\'' +
                ", Amount='" + Amount + '\'' +
                ", Purchase='" + Purchase + '\'' +
                ", ExpenseBy='" + ExpenseBy + '\'' +
                ", Approval='" + Approval + '\'' +
                ", Approved='" + Approved + '\'' +
                '}';
    }
}


