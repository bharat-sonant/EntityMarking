package com.wevois.vcarebackoffice.employeeattendance.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevois.vcarebackoffice.databinding.UserSummaryListBinding;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;

import java.util.ArrayList;

public class DutyOffAdapter extends RecyclerView.Adapter<DutyOffAdapter.ParentViewHolder> {

    ArrayList<ParentRecyclerviewModel> models;
    Context context;

    public DutyOffAdapter(ArrayList<ParentRecyclerviewModel> models, Context context){
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        UserSummaryListBinding parentLvLayoutBinding = UserSummaryListBinding.inflate(layoutInflater,parent,false);

        return new ParentViewHolder(parentLvLayoutBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
        ParentRecyclerviewModel model = models.get(position);
        holder.parentLvLayoutBinding.setParent(model);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    class ParentViewHolder extends RecyclerView.ViewHolder{
        UserSummaryListBinding parentLvLayoutBinding;

        public ParentViewHolder(UserSummaryListBinding itemVeiw){
            super(itemVeiw.getRoot());
            this.parentLvLayoutBinding = itemVeiw;
        }
    }
}

