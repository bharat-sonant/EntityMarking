package com.wevois.vcarebackoffice.DustbinImageCheck;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import uk.co.senab.photoview.PhotoViewAttacher;

public class ImageCheckActivity extends AppCompatActivity {

    Spinner wardSpinner;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> zoneList = new ArrayList<>();
    TextView selectDateTv;
    ProgressDialog progressDialog;
    DatabaseReference databaseReference;
    SharedPreferences preferences;
    String today = "";
    CommonUtils commonUtils;
    RadioGroup radioGroupFillPercentage,radioGroupOkay;
    ImageButton nextBtn;
    RadioButton radioButton;
    Button nextImageBtn;
    ImageView imageView;
    ArrayList<String> filledImgNameList = new ArrayList<>();
    ArrayList<String> emptyImgNameList = new ArrayList<>();
    ArrayList<String> filledImgUrlList = new ArrayList<>();
    ArrayList<String> emptyImgUrlList = new ArrayList<>();
    ArrayList<String> dateList = new ArrayList<>();
    ArrayList<String> keyList = new ArrayList<>();
    int currentImageNo = 0, currentDatePos = 0;
    StorageReference mStorage;
    String ward = "";
    boolean imgDelBool = false, setFPPHBool = false;
    private DataSnapshot wardSnap;
    private static int X = 1;
    private String fillPercent = "100";
    CommonFunctions common = CommonFunctions.getInstance();
    private ArrayList<String> pickDateTimeList  = new ArrayList<>();
    String fakeUrl = "https://firebasestorage.googleapis.com/v0/b/dtdnavigator.appspot.com/o/" +
            "DustbinImage%2F06%3A08%3A2019%2FA%2F6.filled_dustbin.jpg?alt=media&token=598b89fb-" +
            "04b8-477a-99b7-4df87a7d29e4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_check);

        preferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        String storagePathRef = preferences.getString("storagePathRef","");
        mStorage = FirebaseStorage.getInstance().getReferenceFromUrl(
                storagePathRef+"/DustbinImage");
        wardSpinner = findViewById(R.id.zoneNoSpinner);
        selectDateTv = findViewById(R.id.selectDateTv);
        radioGroupFillPercentage = findViewById(R.id.radioGroup);
        nextBtn = findViewById(R.id.nxtBtn);
        radioGroupOkay = findViewById(R.id.okayRadioGroup);
        nextImageBtn = findViewById(R.id.nextImage);
        imageView = findViewById(R.id.imageView);

        commonUtils = new CommonUtils(this);

        if (getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        progressDialog = new ProgressDialog(ImageCheckActivity.this);
        progressDialog.setTitle("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.create();


        zoneList.add("-- Select Zone --");
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,zoneList);
        wardSpinner.setAdapter(arrayAdapter);

        wardSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position>0){
                    String selectedZone = wardSpinner.getSelectedItem().toString();
                    getDustbinPickedDates(selectedZone);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        nextBtn.setOnClickListener((View.OnClickListener) v -> {
            int selectedId = radioGroupFillPercentage.getCheckedRadioButtonId();
            radioButton = (RadioButton) findViewById(selectedId);
            if (radioButton != null) {
                fillPercent = radioButton.getText().toString();
                if (fillPercent.contains("Higher OverFlow")) {
                    fillPercent = "150";
                } else if (fillPercent.contains("OverFlow")) {
                    fillPercent = "125";
                }
            }
            setFillPercent();
        });

        nextImageBtn.setOnClickListener(v -> {
            showProgressDialog();
            deleteImage();
        });

        imageView.setOnClickListener(view -> {
            Display display = getWindowManager().getDefaultDisplay();
            int width = display.getWidth();
            int height = display.getHeight();
            final Dialog dialog = new Dialog(ImageCheckActivity.this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.custom_fullimage_dialog,
                    (ViewGroup) findViewById(R.id.layout_root));
            ImageView image = (ImageView) layout.findViewById(R.id.fullimage);
            LinearLayout linearLayout = layout.findViewById(R.id.closeBtn);
            image.setImageDrawable(imageView.getDrawable());
            image.getLayoutParams().height = height;
            image.getLayoutParams().width = width;
            new PhotoViewAttacher(image);
            image.requestLayout();
            linearLayout.setOnClickListener(view1 -> dialog.dismiss());
            dialog.setContentView(layout);
            dialog.show();
        });
        getZone();
    }

    private void getDustbinPickedDates(String selectedZone) {
        showProgressDialog();
        databaseReference.child("DustbinPickedDates/"+selectedZone).orderByChild("checked_status")
                .equalTo("UnChecked").addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()==null){
                            dismissProgressDialog();
                            commonUtils.showAlertDialog("No unchecked dustbin date is available in our database");
                            return;
                        }
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                            dateList.add(dataSnapshot1.getKey());
                        }
                        today = dateList.get(currentDatePos);
                        selectDateTv.setText(today);
                       // dialog will dismiss in getImages()
                        getImages();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                }
        );
    }

    private void getZone() {
        showProgressDialog();
        databaseReference.child("DustbinImages").addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()==null){
                            dismissProgressDialog();
                            commonUtils.showAlertDialog( "No ward in our database");
                            return;
                        }
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                            zoneList.add(dataSnapshot1.getKey());
                        }
                        arrayAdapter.notifyDataSetChanged();
                        dismissProgressDialog();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                }
        );
    }

    private void getImages() {
        if (wardSpinner.getSelectedItemPosition()>0){
            ward = wardSpinner.getSelectedItem().toString();
            databaseReference.child("DustbinImages/"+ward).child(today)
                    .orderByChild("checked_status").equalTo("UnChecked").addListenerForSingleValueEvent(
                    new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.getValue()==null){
                                dismissProgressDialog();
                                currentDatePos++;
                                setDustbinPickedChecked();
                                commonUtils.showAlertDialog("No unchecked image available");
                                return;
                            }
                            for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                                keyList.add(dataSnapshot1.getKey());
                                if (dataSnapshot1.hasChild("filled_dustbin")){
                                    filledImgNameList.add(dataSnapshot1.child("filled_dustbin").getValue().toString());
                                }else{
                                    filledImgNameList.add("ImageNotFound");
                                }
                                if (dataSnapshot1.hasChild("empty_dustbin")){
                                    emptyImgNameList.add(dataSnapshot1.child("empty_dustbin").getValue().toString());
                                }else{
                                    emptyImgNameList.add("ImageNotFound");
                                }
                                if (dataSnapshot1.hasChild("filled_dustbin_url")){
                                    filledImgUrlList.add(dataSnapshot1.child("filled_dustbin_url").getValue().toString());
                                }else{
                                    filledImgUrlList.add(fakeUrl);
                                }
                                if (dataSnapshot1.hasChild("empty_dustbin_url")){
                                    emptyImgUrlList.add(dataSnapshot1.child("empty_dustbin_url").getValue().toString());
                                }else{
                                    emptyImgUrlList.add(fakeUrl);
                                }
                                if (dataSnapshot1.hasChild("pick_date_time")){
                                    pickDateTimeList.add(dataSnapshot1.child("pick_date_time").getValue().toString());
                                }
                                // we already get from spinner
//                                if (dataSnapshot1.hasChild("ward")){
//                                    ward = dataSnapshot1.child("ward").getValue().toString();
//                                }
                            }
                            getDII(); // this method is to get all dustbin important information from DII
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    }
            );

        }else{
            commonUtils.showAlertDialog("Select Vehicle from List");
        }
    }

    private void setDustbinPickedChecked() {
        databaseReference.child("DustbinPickedDates/"+ward).child(today).child("checked_status")
                .setValue("Checked");
        if (dateList.size()>currentDatePos) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Information");
            builder.setMessage("Do you want to check images for next date for this ward " + ward);
            builder.setCancelable(false);
            builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    filledImgNameList.clear();
                    filledImgUrlList.clear();
                    emptyImgNameList.clear();
                    emptyImgUrlList.clear();
                    pickDateTimeList.clear();
                    keyList.clear();
                    currentImageNo = 0;

                    today = dateList.get(currentDatePos);
                    selectDateTv.setText(today);
                    getImages();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.create();
            builder.show();
        }else{
            dismissProgressDialog();
            commonUtils.showAlertDialog(
                    "We have checked all images for all dates in this ward");
        }
    }

    private void getDII() {
        if (ward.length()>0){
            databaseReference.child("DII/"+ward).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue()==null){
                        dismissProgressDialog();
                        commonUtils.showAlertDialog(
                                "No data found in database for ward "+ward);
                        return;
                    }
                    wardSnap = dataSnapshot;
                    dismissProgressDialog();
                    showFilledImage();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }else{
            dismissProgressDialog();
            commonUtils.showAlertDialog( "Ward no is not proper");
        }
    }

    private void showFilledImage() {
        showProgressDialog();
        if (filledImgUrlList.size()>0){
            if (filledImgUrlList.size()>currentImageNo) {
                Log.d("tag", "showFilledImage: check "+filledImgUrlList.get(currentImageNo));
                Picasso.get().load(filledImgUrlList.get(currentImageNo))
                        .placeholder(R.drawable.ic_launcher_background)
                        .error(R.drawable.imagenotfound).into(imageView);
                dismissProgressDialog();
            }else{
                dismissProgressDialog();
                currentDatePos++; // for getting next date from dateList
                setDustbinPickedChecked(); // it means all images are checked

                imageView.setImageResource(R.drawable.ic_launcher_background);
                commonUtils.showAlertDialog("No more image in our database");
            }
        }else{
            dismissProgressDialog();
            commonUtils.showAlertDialog( "No more image in our database");
        }
    }

    private void showEmptyImage() {
        showProgressDialog();
        if (emptyImgUrlList.size()>0){
            if (emptyImgUrlList.size()>currentImageNo) {
                Picasso.get().load(emptyImgUrlList.get(currentImageNo))
                        .placeholder(R.drawable.ic_launcher_background)
                        .error(R.drawable.imagenotfound).into(imageView);
                dismissProgressDialog();
            }else{
                dismissProgressDialog();
                imageView.setImageResource(R.drawable.ic_launcher_background);
                commonUtils.showAlertDialog("No more image in our database");
            }
        }else{
            dismissProgressDialog();
            commonUtils.showAlertDialog("No more image in our database");
        }
    }

    private void deleteImage() {
        if (filledImgNameList.size()>currentImageNo) {
            mStorage.child(today + "/" + ward + "/" +filledImgNameList.get(currentImageNo)).delete();
        }
        if (emptyImgNameList.size()>currentImageNo) {
            mStorage.child(today + "/" + ward + "/" +emptyImgNameList.get(currentImageNo)).delete();
        }
        if (keyList.size()>currentImageNo) {
            databaseReference.child("DustbinImages/" + ward).child(today).child(keyList.get(currentImageNo))
                    .child("checked_status").setValue("Checked");
        }
        showNextImage();
    }

    private void setFillPercent() {
        String dustbin = "1";
        if (keyList.size()>currentImageNo) {
            dustbin = keyList.get(currentImageNo);
        }
        if (wardSnap==null){
            dismissProgressDialog();
            commonUtils.showAlertDialog("Ops this is not expected -> Ward Data is not available in our local");
            return;
        }
        if (wardSnap.hasChild(dustbin)){
            if (wardSnap.child(dustbin).hasChild("DbPickTimes")){
                String pick  = wardSnap.child(dustbin).child("DbPickTimes").getValue().toString();
                if (wardSnap.child(dustbin).hasChild("FPPH")){
                    String fpph = wardSnap.child(dustbin).child("FPPH").getValue().toString();
                    calTimeDiff(dustbin, pick, fpph);
                }else{
                    dismissProgressDialog();
                    commonUtils.showAlertDialog("No fpph");
                }
            }else{
                dismissProgressDialog();
                commonUtils.showAlertDialog("No DbPickTimes");
            }
        }
    }

    private void calTimeDiff(String dustbin, String pick, String fpph){
        if (pickDateTimeList.size()<=currentImageNo){
            dismissProgressDialog();
            commonUtils.showAlertDialog("Insufficient data");
            return;
        }
        databaseReference.child("LastPickDate").child(ward).child(dustbin)
                .child("last_picked_date").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()==null){

                            String pickDate = pickDateTimeList.get(currentImageNo);
                            dataSnapshot.getRef().setValue(pickDate);

                            showEmptyImage();

                            radioGroupFillPercentage.setVisibility(View.GONE);
                            nextBtn.setVisibility(View.GONE);
                            radioGroupOkay.setVisibility(View.VISIBLE);
                            nextImageBtn.setVisibility(View.VISIBLE);

                        }
                        else{
                            String lastPickDate = dataSnapshot.getValue().toString();
                            Log.i("tag", "onDataChange: calTimeDiff "+lastPickDate);
                            calculateNewFPPH(pick,fpph,lastPickDate);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }
    
    private void calculateNewFPPH(String pick, String fpph, String lastPickDate) {

        String latestPickDate = pickDateTimeList.get(currentImageNo);
        Log.i("tag", "onDataChange: calculateNewFPPH: "+latestPickDate+" list "+pickDateTimeList);
        double totalHours = formattedDate(lastPickDate, latestPickDate);


        double d_pick = Double.parseDouble(pick); // d for database fetched value
        double d_fpph = Double.parseDouble(fpph);

        double p_fillPercent = Double.parseDouble(fillPercent); // this is selected value by checking manager
        double p_fpph = d_fpph;// we forcefully setting this because it will be infinite if total hours is 0
                               // this will not happen in real case
        if (totalHours!=0){
            p_fpph = p_fillPercent / totalHours;
        }

        double newFPPH = (d_pick*d_fpph + X*p_fpph)/(d_pick+X); // X is here for weigh value for calculating next fpph


        // change last pick date
        databaseReference.child("LastPickDate").child(ward).child(keyList.get(currentImageNo))
                .child("last_picked_date").setValue(latestPickDate);

        // set newFpph and pickTime to DII
        databaseReference.child("DII/"+ward).child(keyList.get(currentImageNo)).child("DbPickTimes")
                .setValue(String.valueOf(d_pick+X));
        databaseReference.child("DII/"+ward).child(keyList.get(currentImageNo)).child("FPPH")
                .setValue(String.valueOf(newFPPH));

        showEmptyImage();

        radioGroupFillPercentage.setVisibility(View.GONE);
        nextBtn.setVisibility(View.GONE);
        radioGroupOkay.setVisibility(View.VISIBLE);
        nextImageBtn.setVisibility(View.VISIBLE);
    }

    private void showNextImage() {
        dismissProgressDialog();
        currentImageNo++;
        showFilledImage();
        radioGroupFillPercentage.setVisibility(View.VISIBLE);
        nextBtn.setVisibility(View.VISIBLE);
        radioGroupOkay.setVisibility(View.GONE);
        nextImageBtn.setVisibility(View.GONE);
    }

    public double formattedDate(String pre, String current){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/M/yyyy HH:mm:ss");
        double totalHours = 0;
        try {
            Date date1 = simpleDateFormat.parse(pre);
            Date date2 = simpleDateFormat.parse(current);

            totalHours = printDifference(date1, date2);
            Log.i("tag", "formattedDate: previous "+totalHours);


        } catch (ParseException e) {
            e.printStackTrace();
        }
        return totalHours;
    }

    public double printDifference(Date startDate, Date endDate) {
        //milliseconds
        long different = endDate.getTime() - startDate.getTime();

        System.out.println("startDate : " + startDate);
        System.out.println("endDate : "+ endDate);
        System.out.println("different : " + different);

        Log.i("tag", "printDifference: "+startDate +" end "+endDate+" diff "+different);

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        System.out.printf("%d days, %d hours, %d minutes, %d seconds%n",
                elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);

        Log.i("tag", "printDifference: "+elapsedDays +" hour "+elapsedHours+" min "+elapsedMinutes);

        double totalTime = Double.valueOf(elapsedDays*24+elapsedHours+(elapsedMinutes/60));
        Log.i("abcd", "printDifference: "+totalTime);

        return totalTime;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    private void showProgressDialog() {
        if (progressDialog!=null){
            if (!progressDialog.isShowing()&&!isFinishing()){
                progressDialog.show();
            }
        }
    }

    private void dismissProgressDialog(){
        if(progressDialog!=null){
            if (progressDialog.isShowing()&&!isFinishing()){
                progressDialog.dismiss();
            }
        }
    }
//    private void datePicker(){
//
//        // Get Current Date
//        final Calendar c = Calendar.getInstance();
//        mYear = c.get(Calendar.YEAR);
//        mMonth = c.get(Calendar.MONTH);
//        mDay = c.get(Calendar.DAY_OF_MONTH);
//
//        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
//                new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//
//                        if (monthOfYear+1<=9) {
//                            if (dayOfMonth<=9) {
//                                date_time = "0" + dayOfMonth + ":0" + (monthOfYear + 1) + ":" + year;
////                                date_time = year + ":0" + (monthOfYear + 1) + ":" + "0" + dayOfMonth ;
//                            }else{
//                                date_time = dayOfMonth + ":0" + (monthOfYear + 1) + ":" + year;
////                                date_time = year + ":0" + (monthOfYear + 1) + ":" + dayOfMonth ;
//                            }
//                        }else{
//                            if (dayOfMonth<=9) {
//                                date_time = "0" + dayOfMonth + ":" + (monthOfYear + 1) + ":" + year;
////                                date_time = year + ":" + (monthOfYear + 1) + ":" + "0" + dayOfMonth;
//                            }else {
//                                date_time = dayOfMonth + ":" + (monthOfYear + 1) + ":" + year;
////                                date_time = year + ":" + (monthOfYear + 1) + ":" + dayOfMonth;
//                            }
//                        }
//                        selectDateTv.setText(date_time);
//
//                        today = date_time;
//
//                        getImages(); // getImages
//                    }
//                }, mYear, mMonth, mDay);
//        datePickerDialog.show();
//    }

}
