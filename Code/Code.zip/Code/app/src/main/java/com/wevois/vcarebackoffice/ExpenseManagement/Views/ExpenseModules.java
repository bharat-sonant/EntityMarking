package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.ExpenseManagement.Adapter.HomeAdapterForVendors;
import com.wevois.vcarebackoffice.R;

public class ExpenseModules extends AppCompatActivity {
    private Boolean isActivityClick = true;
    private Boolean isBackPress = true;
    GridView gridView;
    TextView backPress;
    String[] wordPositionTv = {"Vendors", "Expense", "Expense Approval"};
    int[] positionIv = {R.drawable.ic_vendor, R.drawable.add_item, R.drawable.ic_expenseapproval};
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        common.setProgressDialog("", "Please Wait", this, ExpenseModules.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendors);
        initMethod();
        setAction();
    }

    private void initMethod() {
        backPress = findViewById(R.id.backPress);
        gridView = findViewById(R.id.gridView);
        HomeAdapterForVendors adapter = new HomeAdapterForVendors(ExpenseModules.this, wordPositionTv, positionIv);
        common.closeDialog(ExpenseModules.this);
        gridView.setAdapter(adapter);
    }

    private void setAction() {
        backPress.setOnClickListener(v -> {
            if (isBackPress) {
                isBackPress = false;
                onBackPressed();
            }
        });
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            if (position == 0) {
                if (isActivityClick) {
                    isActivityClick = false;
                    Intent i = new Intent(ExpenseModules.this, VendorsList.class);
                    startActivity(i);
                }
            } else if (position == 1) {
                if (isActivityClick) {
                    isActivityClick = false;
                    Intent i = new Intent(ExpenseModules.this, ExpenseList.class);
                    startActivity(i);
                }
            } else if (position == 2) {
                if (isActivityClick) {
                    isActivityClick = false;
                    Intent i = new Intent(ExpenseModules.this, ExpenseApproval.class);
                    startActivity(i);
                }
            }
        });
    }

    protected void onResume() {
        super.onResume();
        isActivityClick = true;
        isBackPress = true;
    }
}