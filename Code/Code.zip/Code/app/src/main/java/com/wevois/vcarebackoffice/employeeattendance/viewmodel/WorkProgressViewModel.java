package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.maps.android.data.kml.KmlLayer;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.repository.WorkProgressRepository;
import com.wevois.vcarebackoffice.employeeattendance.views.HaltMap;
import com.wevois.vcarebackoffice.employeeattendance.views.HaltPage;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class WorkProgressViewModel extends ViewModel {

    Activity activity;
    String outTime;
    SupportMapFragment fragment;
    GoogleMap mMap;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences preferences;
    LatLngBounds.Builder builder;
    WorkProgressRepository repository = new WorkProgressRepository();
    ArrayList<String> wards;
    ArrayList<OtherDetails> otherDetails = new ArrayList<>();
    ArrayList<ParentRecyclerviewModel> userModel = new ArrayList<>();
    ArrayList<LatLng> directionPositionList = new ArrayList<>();
    ArrayList<String> dustbinList = new ArrayList<>();
    ArrayList<JSONObject> wardJson = new ArrayList<>();
    ArrayList<String> offLineData = new ArrayList<>();
    ArrayList<byte[]> wardKml = new ArrayList<>();
    ArrayList<Integer> totalHousesCount = new ArrayList<>(), totalSurveyHousesCount = new ArrayList<>();
    ArrayList<ArrayList<Integer>> lineStatusLists = new ArrayList<>(), lineCompletedLists = new ArrayList<>();
    int currentPosition = 0, count = 0, pos;
    boolean first = true, isMoved = true;
    HashMap<Integer, Polyline> hashLineMarker = new HashMap<>();
    HashMap<Integer, KmlLayer> hashKmlMarker = new HashMap<>();
    public ObservableField<String> title = new ObservableField<>(), houseCount = new ObservableField<>(), currentWard = new ObservableField<>();
    public ObservableField<Boolean> isPreviousVisible = new ObservableField<>(false);
    String helperId,TimeInEntries,tasks;
    HashMap<String, Object> hashMap = new HashMap<>();


    public WorkProgressViewModel(Activity activity, SupportMapFragment fragment) {

        this.activity = activity;
        this.fragment = fragment;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        builder = new LatLngBounds.Builder();
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {
        }.getType());
        userModel = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {
        }.getType());
        wards = otherDetails.get(0).getWards();
        helperId = userModel.get(1).getId();
        common.setProgressDialog("Please wait.....", "", activity, activity);
        setMap();
    }

    public void setMap() {

        fragment.getMapAsync(googleMap -> {
            if (googleMap != null) {
                mMap = googleMap;
            }
            mMap.getUiSettings().setCompassEnabled(false);
            mMap.getUiSettings().setMapToolbarEnabled(false);
            if (wards.get(0).contains("BinLifting")) {
                repository.getBins(activity, common, otherDetails).observe((LifecycleOwner) activity, response -> {
                    if (response.equalsIgnoreCase("fail")) {
                        common.closeDialog(activity);
                    } else {
                        setBins(response);
                    }
                });
            } else {
                count = 0;
                for (String ward : wards) {
                    JSONObject jsonObject = common.getJsonData(ward, preferences);
                    wardJson.add(jsonObject);
                    int totalLine = 0;
                    for (int lineNo = 1; lineNo <= jsonObject.length(); lineNo++) {
                        try {
                            totalLine = totalLine + jsonObject.getJSONObject(String.valueOf(lineNo)).getJSONArray("Houses").length();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    activity.runOnUiThread(() -> {
                        Log.e("kml path value"," value "+ward);
                        new DownloadKmlFile(common.getKmlFilePath(ward, activity)).execute();
                    });
                    totalHousesCount.add(totalLine);
                    getScannedHouses(ward);
                }
            }
        });
    }

    public void getScannedHouses(String ward) {

        count = count + 1;
        activity.runOnUiThread(() -> {
            int counts = count;
            common.getDatabasePath(activity).child("HousesCollectionInfo/" + ward + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot1) {
                    Log.d("TAG", "onDataChange: check " + counts + "   " + count + "   " + dataSnapshot1);
                    common.getDatabasePath(activity).child("WasteCollectionInfo/" + ward + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/LineStatus").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            int scannedHouse = 0;
                            if (dataSnapshot1.getValue() != null) {
                                for (DataSnapshot snapshot : dataSnapshot1.getChildren()) {
                                    if (snapshot.getKey().contains("SIKA") || snapshot.getKey().contains("SHAH") || snapshot.getKey().contains("RENC") || snapshot.getKey().contains("RENA") || snapshot.getKey().contains("KISH")) {
                                        if (snapshot.hasChild("scanBy")) {
                                            if (!snapshot.child("scanBy").getValue().toString().equalsIgnoreCase("-1")) {
                                                scannedHouse++;
                                            }
                                        }
                                    }
                                }
                                if (dataSnapshot1.hasChild("ImagesData/totalCount")) {
                                    scannedHouse = scannedHouse + Integer.parseInt(dataSnapshot1.child("ImagesData/totalCount").getValue().toString());
                                }
                            }
                            ArrayList<Integer> statusList = new ArrayList<>(), completedList = new ArrayList<>();
                            if (dataSnapshot.getValue() != null) {
                                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                    String status = dataSnapshot1.getValue().toString();
                                    if (status.contains("Skipped")) {
                                        statusList.add(0);
                                    } else if (status.contains("PartialLineCompleted")) {
                                        statusList.add(2);
                                    } else {
                                        statusList.add(1);
                                    }
                                    completedList.add(Integer.parseInt(dataSnapshot1.getKey())); // line name
                                }
                            }
                            Log.d("TAG", "onDataChange: check A " + counts + "   " + count + "   " + wards.size());
                            totalSurveyHousesCount.add(scannedHouse);
                            lineStatusLists.add(statusList);
                            lineCompletedLists.add(completedList);
                            if (wards.size() == counts) {
                                Log.d("TAG", "onDataChange: check A " + counts + "   " + count);
                                setWard();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        });
    }

    public void setBins(String bins) {
        dustbinList.clear();
        String[] dustbins = bins.split(",");
        for (int i = 0; i < dustbins.length; i++) {
            dustbinList.add(dustbins[i].trim());
        }
        repository.getDustbinList(activity, common).observe((LifecycleOwner) activity, dataSnapshot1 -> {
            if (dataSnapshot1 != null) {
                repository.getPickHistoryList(activity, common).observe((LifecycleOwner) activity, dataSnapshot -> {
                    int totalPickDustbins = 0;
                    if (dataSnapshot.getValue() != null) {
                        LatLng latLng;
                        for (int i = 0; i < dustbinList.size(); i++) {
                            Boolean isCompleted = false;
                            if (dataSnapshot.hasChild(dustbinList.get(i))) {
                                isCompleted = true;
                                totalPickDustbins = totalPickDustbins + 1;
                            }
                            if (dataSnapshot1.hasChild(dustbinList.get(i))) {
                                latLng = new LatLng(Double.parseDouble(dataSnapshot1.child(dustbinList.get(i)).child("lat").getValue().toString()), Double.parseDouble(dataSnapshot1.child(dustbinList.get(i)).child("lng").getValue().toString()));
                                setMarker(latLng, dataSnapshot1.child(dustbinList.get(i)).child("type").getValue().toString(), isCompleted);
                            }
                        }
                    } else {
                        LatLng latLng = null;
                        for (int i = 0; i < dustbinList.size(); i++) {
                            if (dataSnapshot1.hasChild(dustbinList.get(i))) {
                                latLng = new LatLng(Double.parseDouble(dataSnapshot1.child(dustbinList.get(i)).child("lat").getValue().toString()), Double.parseDouble(dataSnapshot1.child(dustbinList.get(i)).child("lng").getValue().toString()));
                                setMarker(latLng, dataSnapshot1.child(dustbinList.get(i)).child("type").getValue().toString(), false);
                            }
                        }
                    }
                    title.set("BinLifting");
                    currentWard.set("Task : " + (currentPosition + 1) + "/" + wards.size());
                    //totalHouseTv.setText(""+dustbinList.size());
                    houseCount.set("" + totalPickDustbins + "/" + dustbinList.size());
                    common.closeDialog(activity);
                });
            } else {
                common.closeDialog(activity);
            }
        });
    }

    public void setMarker(LatLng currentDustbinLatLng, String type, Boolean isCompleted) {
        if (type.equalsIgnoreCase("Rectangular")) {
            if (isCompleted) {
                mMap.addMarker(new MarkerOptions().position(currentDustbinLatLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.small_rect_green_dustbin)));
            } else {
                mMap.addMarker(new MarkerOptions().position(currentDustbinLatLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.small_rect_red_dustbin)));
            }
        } else {
            if (isCompleted) {
                mMap.addMarker(new MarkerOptions().position(currentDustbinLatLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.small_circle_green_dustbin)));
            } else {
                mMap.addMarker(new MarkerOptions().position(currentDustbinLatLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.small_circle_red_dustbin)));
            }
        }
        builder.include(currentDustbinLatLng);
        LatLngBounds bounds = builder.build();
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 50);
        mMap.animateCamera(cu);
    }

    private void setWard() {
        if (wards.get(currentPosition).contains("Market") || wards.get(currentPosition).contains("mkt")) {
            title.set(wards.get(currentPosition));
        } else {
            title.set("Ward : " + wards.get(currentPosition));
        }
        currentWard.set("Task : " + (currentPosition + 1) + "/" + wards.size());
        houseCount.set("" + totalSurveyHousesCount.get(currentPosition) + "/" + totalHousesCount.get(currentPosition));
        showLine(lineStatusLists.get(currentPosition), lineCompletedLists.get(currentPosition), wardJson.get(currentPosition));
        callKml();
        common.closeDialog(activity);
    }

    private void callKml() {

        try {
            try {
                int size = hashKmlMarker.size();
                for (int i = 0; i < size; i++) {
                    try {
                        KmlLayer marker = hashKmlMarker.get((hashKmlMarker.keySet().toArray())[0]);
                        marker.removeLayerFromMap();
                        hashKmlMarker.remove((hashKmlMarker.keySet().toArray())[0]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
            }
//            Log.e("current pos", new ByteArrayInputStream(wardKml.get(currentPosition))+"");
            if (wardKml.get(currentPosition) != null) {
                KmlLayer kmlLayer = new KmlLayer(mMap, new ByteArrayInputStream(wardKml.get(currentPosition)), activity);
                kmlLayer.addLayerToMap();
                hashKmlMarker.put(currentPosition, kmlLayer);
            }
        } catch (Exception e) {
            Log.e("kml exception",e.getMessage());
        }
    }

    public void showLine(ArrayList<Integer> lineStatusLists, ArrayList<Integer> lineCompletedLists, JSONObject jsonObject) {
        try {
            directionPositionList.clear();
            try {
                int size = hashLineMarker.size();
                for (int i = 0; i < size; i++) {
                    try {
                        Polyline marker = hashLineMarker.get((hashLineMarker.keySet().toArray())[0]);
                        marker.remove();
                        hashLineMarker.remove((hashLineMarker.keySet().toArray())[0]);
                        Log.d("TAG", "getTotalHouses: check ward DDDD A A " + hashLineMarker.size());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
            }
            if (jsonObject == null || jsonObject.length() == 0) {
                return;
            }
            int count = 0;
            for (int lineNo = 1; lineNo <= jsonObject.length(); lineNo++) {
                int color = Color.parseColor("#0C9EF1");
                JSONArray jsonArray = jsonObject.getJSONObject(String.valueOf(lineNo)).getJSONArray("points");
                if (lineCompletedLists.contains(lineNo)) {
                    int line = lineStatusLists.get(lineCompletedLists.indexOf(lineNo));
                    if (line == 1) {
                        color = Color.GREEN;
                    } else if (line == 2) {
                        color = Color.parseColor("#FFA500");
                    } else {
                        color = Color.RED;
                    }
                }
                for (int i = 0; i < jsonArray.length(); i++) {
                    directionPositionList.add(new LatLng(jsonArray.getJSONArray(i).getDouble(0), jsonArray.getJSONArray(i).getDouble(1)));
                    if (i >= jsonArray.length() - 1) {
                        if (directionPositionList.size() > 0) {
                            for (int a = 0; a < directionPositionList.size(); a++) {
                                builder.include(directionPositionList.get(a));
                            }
                        }
                        Polyline polyline = mMap.addPolyline(new PolylineOptions().addAll((directionPositionList)).color(color).width(4.0f));
                        LatLngBounds bounds = builder.build();
                        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 50);
                        mMap.animateCamera(cu);
                        directionPositionList.clear();
                        hashLineMarker.put(count, polyline);
                        count++;
                    }
                }
            }
        } catch (Exception e) {
            Log.e("TAG", "getTotalHouses: check ward DDDD " + e.toString());
        }
        common.closeDialog(activity);
    }

    private class DownloadKmlFile extends AsyncTask<String, Void, byte[]> {
        private final String mUrl;

        public DownloadKmlFile(String url) {
            mUrl = url;
        }

        protected byte[] doInBackground(String... params) {
            try {
                Log.e("DownloadKmlFile",mUrl+"");
                InputStream is = new URL(mUrl).openStream();
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                int nRead;
                byte[] data = new byte[16836];
                while ((nRead = is.read(data, 0, data.length)) != -1) {
                    buffer.write(data, 0, nRead);
                }
                buffer.flush();
                return buffer.toByteArray();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("Input exception",e.getMessage());            }
            return null;
        }

        protected void onPostExecute(byte[] byteArr) {
            wardKml.add(byteArr);
            if (first) {
                first = false;
                callKml();
            }
        }
    }

    public void previousOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if (currentPosition != 0) {
            currentPosition = currentPosition - 1;
            if (currentPosition == 0) {
                isPreviousVisible.set(false);
            }
            setWard();
        }
    }

    public void nextOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if ((wards.size() - 1) > currentPosition) {
            if (currentPosition == 0) {
                isPreviousVisible.set(true);
            }
            currentPosition = currentPosition + 1;
            setWard();
        } else {
            if (isMoved) {
                isMoved = true;
                common.setProgressDialog("", "Please wait...", activity, activity);
                common.getRealTime().observe((LifecycleOwner) activity, response -> {
                    if (response.equalsIgnoreCase("fail")) {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "आपके मोबाइल का Time सही नहीं है |", false, activity);
                    } else {
                        common.closeDialog(activity);
                        Intent i = new Intent(activity, HaltPage.class);
                        i.putExtra("otherDetails", new Gson().toJson(otherDetails));
                        i.putExtra("userModel", new Gson().toJson(userModel));
                        activity.startActivity(i);
//                        saveLocatData();
                        isMoved = true;
                    }
                });
            }
        }
    }

    public void saveLocatData() {

        offLineData.add("emp");
        offLineData.add("vehicle");
        offLineData.add("taskDetails");
        offLineData.add("WasteCollectionInfo");
        offLineData.add("DailyWorkDetail");
        outTime = new SimpleDateFormat("HH:mm:ss").format(new Date());

        getEmpdata();
        getDailyWorkDetail();
        sendVehicleData();
        sendTaskDetailData();
        sendWasteCollectionInfoDetailData();

    }

    private void getDailyWorkDetail() {

        common.getDatabasePath(activity).child("DailyWorkDetail").child(common.year()).child(common.monthName()).child(common.date()).child(helperId).child("card-swap-entries").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d("dailyKey", snapshot.getKey());
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Log.d("TimeInEntriesValue", dataSnapshot.getValue().toString());

                    if (!dataSnapshot.getValue().toString().equals("Out")) {
                        TimeInEntries = dataSnapshot.getKey();
                        Log.d("TimeInEntries", TimeInEntries);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        common.getDatabasePath(activity).child("DailyWorkDetail").child(common.year()).child(common.monthName()).child(common.date()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d("driverId", userModel.get(0).getId());
                Log.d("helperId", helperId);
                for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                    Log.d("DRIVEN", dataSnapshot1.getKey());
                    if (dataSnapshot1.getKey().equals(helperId)) {
                        for (DataSnapshot dataSnapshot : dataSnapshot1.getChildren()) {
                            Log.d("key",dataSnapshot.getKey());
                            if (dataSnapshot.child("in-out").getChildrenCount()<2){

                                for (DataSnapshot dataSnapshot2:dataSnapshot.child("in-out").getChildren()){
                                    tasks = dataSnapshot.getKey();
                                    Log.d("option",dataSnapshot.getKey());
                                    Log.d("dataa",dataSnapshot2.getValue().toString());

                                    if (dataSnapshot2.getValue().toString().equals("In")) {
                                        hashMap.put(TimeInEntries, "In");
                                        hashMap.put("20:00:00", "Out");
                                        common.getDatabasePath(activity).child("DailyWorkDetail").child(common.year()).child(common.monthName()).child(common.date()).child(helperId).child(tasks).child("in-out").setValue(hashMap);
                                        removedLocal("DailyWorkDetail");
                                    }else {
                                        common.closeDialog(activity);
                                    }


                                }
                            }
                        }
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                common.closeDialog(activity);
            }
        });
    }

    private void getDeviceData() {

        for (int i = 0; i< userModel.size(); i++){

            if (!userModel.get(pos).getDevice().equals("NotApplicable")) {
                Log.e("key value", userModel.get(i).getDevice()+" ");
                common.getDatabasePath(activity).child("Devices/"+preferences.getString("city", "")).orderByChild("name").equalTo(userModel.get(i).getDevice()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            common.closeDialog(activity);
                            for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                String key = dataSnapshot1.getKey();
                                Log.e("key value", key+" ");
                                common.getDatabasePath(activity).child("Devices/" + preferences.getString("city", "")).child(key+"/status").setValue("1");
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        }
    }

    private void sendWasteCollectionInfoDetailData() {
        common.setProgressDialog("","Please Wait..",activity,activity);
        common.getDatabasePath(activity).child("WasteCollectionInfo/"+wards.get(0)+"/"+common.year()+"/"+common.monthName()+"/"+common.date()+"/Summary/dutyOutTime").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String dutyInTime = "";
                if (dataSnapshot.getValue() != null) {
                    dutyInTime = dataSnapshot.getValue().toString() + ",";
                }
                dutyInTime += outTime.substring(0, outTime.length() - 3);
                common.getDatabasePath(activity).child("WasteCollectionInfo/" + wards.get(0) + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary/dutyOutTime").setValue(dutyInTime).addOnCompleteListener( task32 ->{
                    if (task32.isSuccessful()) {
                        common.closeDialog(activity);
                        removedLocal("WasteCollectionInfo");
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void sendTaskDetailData() {
        common.setProgressDialog("","Please Wait..",activity,activity);
        common.getDatabasePath(activity).child("Tasks/" + wards.get(0)).setValue("Available").addOnCompleteListener ( task2  ->{
            if (task2.isSuccessful()) {
                common.closeDialog(activity);
                removedLocal("taskDetails");
            }
        });
    }

    private void sendVehicleData() {

        HashMap<String,String> vehicleData = new HashMap<>();
        vehicleData.put("assigned-driver","");
        vehicleData.put("assigned-helper","");
        vehicleData.put("assigned-task","");
        vehicleData.put("status","1");
        common.setProgressDialog("","Please Wait..",activity,activity);
        common.getDatabasePath(activity).child("Vehicles/"+otherDetails.get(0).getVehicle()).setValue(vehicleData).addOnCompleteListener(task -> {
            if (task.isSuccessful()){
                common.closeDialog(activity);
                removedLocal("vehicle");
            }
        });
    }

    public void getEmpdata(){

        Log.e("Size value"," = "+userModel.size());
        for (int i = 0; i< userModel.size(); i++){
            Log.e("Size value"," = "+userModel.size() +" "+ i);
            HashMap<String,String> workAssignmentData = new HashMap<>();
            workAssignmentData.put("current-assignment","");
            workAssignmentData.put("device","");
            workAssignmentData.put("vehicle","");
            common.setProgressDialog("","Please Wait..",activity,activity);
            pos = i;
            common.getDatabasePath(activity).child("WorkAssignment/"+userModel.get(i).getId()).setValue(workAssignmentData).addOnCompleteListener(task -> {
                if (task.isSuccessful()){
                    Log.e("pos value",pos+" pos value");
                    removedLocal("emp");
                    getDeviceData();
                }
            });

        }
    }

    private void removedLocal(String removeData) {
        try {
            if (offLineData.contains(removeData)){
                offLineData.remove(removeData);
            }
            Log.d("TAG", "removedLocal: check A "+offLineData+"   "+offLineData.size());
//            otherDetails[0].offlineSave = offLineData;
            Log.d("TAG", "removedLocal: check B "+otherDetails);
            preferences.edit().putString("dutyOffUserDetails", new Gson().toJson(userModel)).apply();
            preferences.edit().putString("dutyOffOtherDetails", new Gson().toJson(otherDetails)).apply();
            if(offLineData.size() == 0)
                moveActivity();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void moveActivity() {
        common.closeDialog(activity);
        preferences.edit().putString("dutyOffUserDetails", "").apply();
        preferences.edit().putString("dutyOffOtherDetails", "").apply();
        Intent intent = new Intent(activity, WardSelectKotlin.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(intent);
        activity.finish();
    }

    public void onBack() {
        activity.finish();
    }
}
