package com.wevois.vcarebackoffice.employeeattendance.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.*

class WardSelectKotlinRepository {
    fun getDustbinPlan(databasePath: DatabaseReference): LiveData<DataSnapshot> {
        val response = MutableLiveData<DataSnapshot>()
        databasePath.child("DustbinData/DustbinPickingPlans/" + SimpleDateFormat("yyyy-MM-dd").format(Date())).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                response.value = dataSnapshot
            }

            override fun onCancelled(databaseError: DatabaseError) {}
        })
        return response
    }
}