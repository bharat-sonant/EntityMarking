package com.wevois.vcarebackoffice.ExpenseManagement.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.ExpenseListModel;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class ExpenseListAdapter extends BaseAdapter {
    Context context;
    ArrayList<ExpenseListModel> arrayListExpense;

    public ExpenseListAdapter(Context context, ArrayList<ExpenseListModel> arrayListExpense) {
        this.context = context;
        this.arrayListExpense = arrayListExpense;
    }

    @Override
    public int getCount() {
        return arrayListExpense.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.display_expense_list, null, true);
        }
        ExpenseListModel expenseListModel = arrayListExpense.get(i);
        ImageView imageView = convertView.findViewById(R.id.billImageView);
        TextView vendorName = convertView.findViewById(R.id.vendorTv);
        TextView billType = convertView.findViewById(R.id.billTypeTv);
        TextView billNo = convertView.findViewById(R.id.billNoTv);
        TextView amount = convertView.findViewById(R.id.amountTv);
        TextView purchase = convertView.findViewById(R.id.purchaseTv);
        TextView expenseBy = convertView.findViewById(R.id.expenseByTv);
        TextView date = convertView.findViewById(R.id.dateTv);

        FirebaseStorage.getInstance().getReferenceFromUrl("gs://dtdnavigator.appspot.com/Common/").child("Images/" + expenseListModel.getVendorId() + "/" + expenseListModel.getDate() + ".jpeg").
                getDownloadUrl().addOnSuccessListener(uri -> {
                    imageView.setImageResource(R.drawable.imageavailable);
                    imageView.setEnabled(true);
                    imageView.setOnClickListener(view1 -> {
                        final View dialogView = LayoutInflater.from(context).inflate(R.layout.display_expense_image, null);
                        ImageView billImageView = dialogView.findViewById(R.id.bill_Image_View);
                        final AlertDialog detailsDialog = new AlertDialog.Builder(context).create();
                        detailsDialog.setView(dialogView);
                        Glide.with(context)
                                .load(uri)
                                .placeholder(R.drawable.plzwaiticon)
                                .into(billImageView);
                        detailsDialog.show();
                    });
                });
        vendorName.setText(expenseListModel.getVendorName());
        billType.setText(expenseListModel.getBillType());
        billNo.setText(expenseListModel.getBillNo());
        amount.setText(expenseListModel.getAmount());
        purchase.setText(expenseListModel.getPurchase());
        expenseBy.setText(expenseListModel.getExpenseBy());
        date.setText(expenseListModel.getDate());
        return convertView;
    }
}
