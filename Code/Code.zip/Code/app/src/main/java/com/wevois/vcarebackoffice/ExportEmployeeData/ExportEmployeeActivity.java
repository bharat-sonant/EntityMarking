package com.wevois.vcarebackoffice.ExportEmployeeData;

import static android.os.Environment.getExternalStorageDirectory;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ExportEmployeeActivity extends AppCompatActivity {

    ArrayList<ModelClass> modelClasses = new ArrayList<>();
    DatabaseReference databaseReference;
    CommonFunctions common = CommonFunctions.getInstance();
    DataSnapshot designationSnapshot=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export_employee);
        databaseReference = common.getDatabasePath(this);
        findViewById(R.id.employeeExport).setOnClickListener(view -> {
            common.setProgressDialog("Please wait...","",ExportEmployeeActivity.this,ExportEmployeeActivity.this);
            getWardHousesData();
        });
    }

    private void getWardHousesData() {
        databaseReference.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot1) {
                if (snapshot1.getValue()!=null){
                    for (DataSnapshot dataSnapshot:snapshot1.getChildren() ) {
                        String empId="",empName = "", fatherName = "", mobile = "", email = "", designation = "", gender = "", dob = "", doj = "", status = "",profileImageUrl="";
                        String actNumber = "", ifsc = "", familyMembers = "", nName = "", nAddress = "", nMobile = "", nEmail = "", nRelation = "", nUidNumber = "",
                                ppdCompanyName = "", ppdCompanyAddress = "", ppdCompanyEmail = "", ppdCompanyEmployeeCode = "", ppdCompanyInsuranceNumber = "", UANNumber = "";
                        String aadharNumber = "", panNumber = "";
                        String cCity = "", cHouseName = "", cLocality = "", cPinCode = "", cState = "", cSubLocality = "", pCity = "", pHouseName = "", pLocality = "", pPinCode = "", pState = "", pSubLocality = "";
                        String isHandicap = "", isInternational = "", isLocomotive = "", isVisual = "", maritalStatus = "", nationality = "", originCountry = "", passportNumber = "", passportValidFrom = "",
                                passportValidTill = "", qualification = "";
                        String familyName="",familyDateOfBirth="",familyRelation="",familyResiding="",familyIncome="",familyDisability="";
                        if (dataSnapshot.hasChild("GeneralDetails")) {
                            DataSnapshot snapshot = dataSnapshot.child("GeneralDetails");
                            if (snapshot.hasChild("name")) {
                                empName = snapshot.child("name").getValue().toString();
                            }
                            if (snapshot.hasChild("fatherName")) {
                                fatherName = snapshot.child("fatherName").getValue().toString();
                            }
                            if (snapshot.hasChild("mobile")) {
                                mobile = snapshot.child("mobile").getValue().toString();
                            }
                            if (snapshot.hasChild("email")) {
                                email = snapshot.child("email").getValue().toString();
                            }
                            if (snapshot.hasChild("designationId")) {
                                designation = snapshot.child("designationId").getValue().toString();
                                if (designationSnapshot!=null){
                                    if (designationSnapshot.hasChild(designation)){
                                        designation = designationSnapshot.child(designation+"/name").getValue().toString();
                                    }
                                }
                            }
                            if (snapshot.hasChild("gender")) {
                                gender = snapshot.child("gender").getValue().toString();
                            }
                            if (snapshot.hasChild("dateOfBirth")) {
                                dob = snapshot.child("dateOfBirth").getValue().toString();
                            }
                            if (snapshot.hasChild("dateOfJoining")) {
                                doj = snapshot.child("dateOfJoining").getValue().toString();
                            }
                            if (snapshot.hasChild("profilePhotoURL")) {
                                profileImageUrl = snapshot.child("profilePhotoURL").getValue().toString();
                            }
                            if (snapshot.hasChild("status")) {
                                status = snapshot.child("status").getValue().toString();
                                if (status.equalsIgnoreCase("1")){
                                    status = "Active";
                                }else {
                                    status = "InActive";
                                }
                            }
                        }
                        if (dataSnapshot.hasChild("BankDetails")) {
                            if (dataSnapshot.hasChild("BankDetails/AccountDetails")) {
                                DataSnapshot snapshot = dataSnapshot.child("BankDetails/AccountDetails");

                                if (snapshot.hasChild("accountNumber")) {
                                    actNumber = snapshot.child("accountNumber").getValue().toString();
                                }
                                if (snapshot.hasChild("ifsc")) {
                                    ifsc = snapshot.child("ifsc").getValue().toString();
                                }
                                if (snapshot.hasChild("familyMembers")) {
                                    familyMembers = snapshot.child("familyMembers").getValue().toString();
                                }
                            }
                            if (dataSnapshot.hasChild("BankDetails/NomineeDetails")) {
                                DataSnapshot snapshot = dataSnapshot.child("BankDetails/NomineeDetails");
                                if (snapshot.hasChild("name")) {
                                    nName = snapshot.child("name").getValue().toString();
                                }
                                if (snapshot.hasChild("mobile")) {
                                    nMobile = snapshot.child("mobile").getValue().toString();
                                }
                                if (snapshot.hasChild("email")) {
                                    nEmail = snapshot.child("email").getValue().toString();
                                }
                                if (snapshot.hasChild("address")) {
                                    nAddress = snapshot.child("address").getValue().toString();
                                }
                                if (snapshot.hasChild("relation")) {
                                    nRelation = snapshot.child("relation").getValue().toString();
                                }
                                if (snapshot.hasChild("uidNumber")) {
                                    nUidNumber = snapshot.child("uidNumber").getValue().toString();
                                }
                            }
                            if (dataSnapshot.hasChild("BankDetails/FamilyMemberDetails")) {
                                for (DataSnapshot snapshot2:dataSnapshot.child("BankDetails/FamilyMemberDetails").getChildren()){
                                    if (snapshot2.hasChild("name")) {
                                        if (familyName.length()>0){
                                            familyName = familyName+"/"+snapshot2.child("name").getValue().toString();
                                        }else {
                                            familyName = snapshot2.child("name").getValue().toString();
                                        }
                                    }if (snapshot2.hasChild("dateOfBirth")) {
                                        if (familyDateOfBirth.length()>0){
                                            familyDateOfBirth = familyDateOfBirth+"/"+snapshot2.child("dateOfBirth").getValue().toString();
                                        }else {
                                            familyDateOfBirth = snapshot2.child("dateOfBirth").getValue().toString();
                                        }
                                    }if (snapshot2.hasChild("relation")) {
                                        if (familyRelation.length()>0){
                                            familyRelation = familyRelation+"/"+snapshot2.child("relation").getValue().toString();
                                        }else {
                                            familyRelation = snapshot2.child("relation").getValue().toString();
                                        }
                                    }if (snapshot2.hasChild("residing")) {
                                        if (familyResiding.length()>0){
                                            familyResiding = familyResiding+"/"+snapshot2.child("residing").getValue().toString();
                                        }else {
                                            familyResiding = snapshot2.child("residing").getValue().toString();
                                        }
                                    }if (snapshot2.hasChild("income")) {
                                        if (familyIncome.length()>0){
                                            familyIncome = familyIncome+"/"+snapshot2.child("income").getValue().toString();
                                        }else {
                                            familyIncome = snapshot2.child("income").getValue().toString();
                                        }
                                    }if (snapshot2.hasChild("disability")) {
                                        if (familyDisability.length()>0){
                                            familyDisability = familyDisability+"/"+snapshot2.child("disability").getValue().toString();
                                        }else {
                                            familyDisability = snapshot2.child("disability").getValue().toString();
                                        }
                                    }
                                }
                            }
                            if (dataSnapshot.hasChild("BankDetails/ProvidentFundDetails/PreviousPFDetails")) {
                                DataSnapshot snapshot = dataSnapshot.child("BankDetails/ProvidentFundDetails/PreviousPFDetails");
                                if (snapshot.hasChild("companyName")) {
                                    ppdCompanyName = snapshot.child("companyName").getValue().toString();
                                }
                                if (snapshot.hasChild("companyAddress")) {
                                    ppdCompanyAddress = snapshot.child("companyAddress").getValue().toString();
                                }
                                if (snapshot.hasChild("companyEmail")) {
                                    ppdCompanyEmail = snapshot.child("companyEmail").getValue().toString();
                                }
                                if (snapshot.hasChild("employeeCode")) {
                                    ppdCompanyEmployeeCode = snapshot.child("employeeCode").getValue().toString();
                                }
                                if (snapshot.hasChild("insuranceNumber")) {
                                    ppdCompanyInsuranceNumber = snapshot.child("insuranceNumber").getValue().toString();
                                }
                            }
                            if (dataSnapshot.hasChild("BankDetails/ProvidentFundDetails/uanNumber")) {
                                UANNumber = dataSnapshot.child("BankDetails/ProvidentFundDetails/uanNumber").getValue().toString();
                            }
                        }
                        if (dataSnapshot.hasChild("IdentificationDetails")) {
                            if (dataSnapshot.hasChild("IdentificationDetails/AadharCardDetails/aadharNumber")) {
                                aadharNumber = dataSnapshot.child("IdentificationDetails/AadharCardDetails/aadharNumber").getValue().toString();
                            }
                            if (dataSnapshot.hasChild("IdentificationDetails/PanCardDetails/panNumber")) {
                                panNumber = dataSnapshot.child("IdentificationDetails/PanCardDetails/panNumber").getValue().toString();
                            }
                        }
                        if (dataSnapshot.hasChild("AddressDetails")) {
                            if (dataSnapshot.hasChild("AddressDetails/CurrentAddress")) {
                                DataSnapshot snapshot = dataSnapshot.child("AddressDetails/CurrentAddress");
                                if (snapshot.hasChild("city")) {
                                    cCity = snapshot.child("city").getValue().toString();
                                }
                                if (snapshot.hasChild("houseName")) {
                                    cHouseName = snapshot.child("houseName").getValue().toString();
                                }
                                if (snapshot.hasChild("locality")) {
                                    cLocality = snapshot.child("locality").getValue().toString();
                                }
                                if (snapshot.hasChild("pinCode")) {
                                    cPinCode = snapshot.child("pinCode").getValue().toString();
                                }
                                if (snapshot.hasChild("state")) {
                                    cState = snapshot.child("state").getValue().toString();
                                }
                                if (snapshot.hasChild("subLocality")) {
                                    cSubLocality = snapshot.child("subLocality").getValue().toString();
                                }
                            }
                            if (dataSnapshot.hasChild("AddressDetails/PermanentAddress")) {
                                DataSnapshot snapshot = dataSnapshot.child("AddressDetails/PermanentAddress");
                                if (snapshot.hasChild("city")) {
                                    pCity = snapshot.child("city").getValue().toString();
                                }
                                if (snapshot.hasChild("houseName")) {
                                    pHouseName = snapshot.child("houseName").getValue().toString();
                                }
                                if (snapshot.hasChild("locality")) {
                                    pLocality = snapshot.child("locality").getValue().toString();
                                }
                                if (snapshot.hasChild("pinCode")) {
                                    pPinCode = snapshot.child("pinCode").getValue().toString();
                                }
                                if (snapshot.hasChild("state")) {
                                    pState = snapshot.child("state").getValue().toString();
                                }
                                if (snapshot.hasChild("subLocality")) {
                                    pSubLocality = snapshot.child("subLocality").getValue().toString();
                                }
                            }
                        }
                        if (dataSnapshot.hasChild("OtherDetails")) {
                            DataSnapshot snapshot = dataSnapshot.child("OtherDetails");
                            if (snapshot.hasChild("isHandicap")) {
                                isHandicap = snapshot.child("isHandicap").getValue().toString();
                            }
                            if (snapshot.hasChild("isInternational")) {
                                isInternational = snapshot.child("isInternational").getValue().toString();
                            }
                            if (snapshot.hasChild("isLocomotive")) {
                                isLocomotive = snapshot.child("isLocomotive").getValue().toString();
                            }
                            if (snapshot.hasChild("isVisual")) {
                                isVisual = snapshot.child("isVisual").getValue().toString();
                            }
                            if (snapshot.hasChild("maritalStatus")) {
                                maritalStatus = snapshot.child("maritalStatus").getValue().toString();
                            }
                            if (snapshot.hasChild("nationality")) {
                                nationality = snapshot.child("nationality").getValue().toString();
                            }
                            if (snapshot.hasChild("originCountry")) {
                                originCountry = snapshot.child("originCountry").getValue().toString();
                            }
                            if (snapshot.hasChild("passportNumber")) {
                                passportNumber = snapshot.child("passportNumber").getValue().toString();
                            }
                            if (snapshot.hasChild("passportValidFrom")) {
                                passportValidFrom = snapshot.child("passportValidFrom").getValue().toString();
                            }
                            if (snapshot.hasChild("passportValidTill")) {
                                passportValidTill = snapshot.child("passportValidTill").getValue().toString();
                            }
                            if (snapshot.hasChild("qualification")) {
                                qualification = snapshot.child("qualification").getValue().toString();
                            }
                        }
                        if (empName.length()>0) {
                            modelClasses.add(new ModelClass(dataSnapshot.getKey(), empName, fatherName, mobile, email, designation, gender, dob, doj, status,
                                    actNumber, ifsc, familyMembers, nName, nAddress, nMobile, nEmail, nRelation, nUidNumber,
                                    ppdCompanyName, ppdCompanyAddress, ppdCompanyEmail, ppdCompanyEmployeeCode, ppdCompanyInsuranceNumber, UANNumber,
                                    aadharNumber, panNumber, cCity, cHouseName, cLocality, cPinCode, cState, cSubLocality, pCity, pHouseName,
                                    pLocality, pPinCode, pState, pSubLocality, isHandicap, isInternational, isLocomotive, isVisual, maritalStatus, nationality,
                                    originCountry, passportNumber, passportValidFrom, passportValidTill, qualification, familyName, familyDateOfBirth,
                                    familyRelation, familyResiding, familyIncome, familyDisability,profileImageUrl));
                        }
                    }
                    templateFileDownload();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private static class ModelClass {
        String empId="",empName="",fatherName="",mobile="",email="",designation="",gender="",dob="",doj="",status=""
                ,actNumber="",ifsc="",familyMembers="",nName="",nAddress="",nMobile="",nEmail="",nRelation="",nUidNumber="",
                ppdCompanyName="",ppdCompanyAddress="",ppdCompanyEmail="",ppdCompanyEmployeeCode="",ppdCompanyInsuranceNumber=""
                ,UANNumber="",aadharNumber="",panNumber="",cCity="",cHouseName="",cLocality="",cPinCode="",cState="",cSubLocality=""
                ,pCity="",pHouseName="",pLocality="",pPinCode="",pState="",pSubLocality="",isHandicap="",isInternational="",
                    isLocomotive="",isVisual="",maritalStatus="",nationality="",originCountry="",passportNumber="",passportValidFrom="",
                passportValidTill= "",qualification="",familyName="",familyDateOfBirth="",familyRelation="",familyResiding="",familyIncome="",familyDisability="",profileImageUrl;

        public ModelClass(String empId, String empName, String fatherName, String mobile, String email, String designation, String gender, String dob, String doj, String status, String actNumber, String ifsc, String familyMembers, String nName, String nAddress, String nMobile, String nEmail, String nRelation, String nUidNumber, String ppdCompanyName, String ppdCompanyAddress, String ppdCompanyEmail, String ppdCompanyEmployeeCode, String ppdCompanyInsuranceNumber, String UANNumber, String aadharNumber, String panNumber, String cCity, String cHouseName, String cLocality, String cPinCode, String cState, String cSubLocality, String pCity, String pHouseName, String pLocality, String pPinCode, String pState, String pSubLocality, String isHandicap, String isInternational, String isLocomotive, String isVisual, String maritalStatus, String nationality, String originCountry, String passportNumber, String passportValidFrom, String passportValidTill, String qualification, String familyName, String familyDateOfBirth, String familyRelation, String familyResiding, String familyIncome, String familyDisability, String profileImageUrl) {
            this.empId = empId;
            this.empName = empName;
            this.fatherName = fatherName;
            this.mobile = mobile;
            this.email = email;
            this.designation = designation;
            this.gender = gender;
            this.dob = dob;
            this.doj = doj;
            this.status = status;
            this.actNumber = actNumber;
            this.ifsc = ifsc;
            this.familyMembers = familyMembers;
            this.nName = nName;
            this.nAddress = nAddress;
            this.nMobile = nMobile;
            this.nEmail = nEmail;
            this.nRelation = nRelation;
            this.nUidNumber = nUidNumber;
            this.ppdCompanyName = ppdCompanyName;
            this.ppdCompanyAddress = ppdCompanyAddress;
            this.ppdCompanyEmail = ppdCompanyEmail;
            this.ppdCompanyEmployeeCode = ppdCompanyEmployeeCode;
            this.ppdCompanyInsuranceNumber = ppdCompanyInsuranceNumber;
            this.UANNumber = UANNumber;
            this.aadharNumber = aadharNumber;
            this.panNumber = panNumber;
            this.cCity = cCity;
            this.cHouseName = cHouseName;
            this.cLocality = cLocality;
            this.cPinCode = cPinCode;
            this.cState = cState;
            this.cSubLocality = cSubLocality;
            this.pCity = pCity;
            this.pHouseName = pHouseName;
            this.pLocality = pLocality;
            this.pPinCode = pPinCode;
            this.pState = pState;
            this.pSubLocality = pSubLocality;
            this.isHandicap = isHandicap;
            this.isInternational = isInternational;
            this.isLocomotive = isLocomotive;
            this.isVisual = isVisual;
            this.maritalStatus = maritalStatus;
            this.nationality = nationality;
            this.originCountry = originCountry;
            this.passportNumber = passportNumber;
            this.passportValidFrom = passportValidFrom;
            this.passportValidTill = passportValidTill;
            this.qualification = qualification;
            this.familyName = familyName;
            this.familyDateOfBirth = familyDateOfBirth;
            this.familyRelation = familyRelation;
            this.familyResiding = familyResiding;
            this.familyIncome = familyIncome;
            this.familyDisability = familyDisability;
            this.profileImageUrl = profileImageUrl;
        }

        public String getEmpId() {
            return empId;
        }

        public String getEmpName() {
            return empName;
        }

        public String getFatherName() {
            return fatherName;
        }

        public String getMobile() {
            return mobile;
        }

        public String getEmail() {
            return email;
        }

        public String getDesignation() {
            return designation;
        }

        public String getGender() {
            return gender;
        }

        public String getDob() {
            return dob;
        }

        public String getDoj() {
            return doj;
        }

        public String getStatus() {
            return status;
        }

        public String getActNumber() {
            return actNumber;
        }

        public String getIfsc() {
            return ifsc;
        }

        public String getFamilyMembers() {
            return familyMembers;
        }

        public String getnName() {
            return nName;
        }

        public String getnAddress() {
            return nAddress;
        }

        public String getnMobile() {
            return nMobile;
        }

        public String getnEmail() {
            return nEmail;
        }

        public String getnRelation() {
            return nRelation;
        }

        public String getnUidNumber() {
            return nUidNumber;
        }

        public String getPpdCompanyName() {
            return ppdCompanyName;
        }

        public String getPpdCompanyAddress() {
            return ppdCompanyAddress;
        }

        public String getPpdCompanyEmail() {
            return ppdCompanyEmail;
        }

        public String getPpdCompanyEmployeeCode() {
            return ppdCompanyEmployeeCode;
        }

        public String getPpdCompanyInsuranceNumber() {
            return ppdCompanyInsuranceNumber;
        }

        public String getUANNumber() {
            return UANNumber;
        }

        public String getAadharNumber() {
            return aadharNumber;
        }

        public String getPanNumber() {
            return panNumber;
        }

        public String getcCity() {
            return cCity;
        }

        public String getcHouseName() {
            return cHouseName;
        }

        public String getcLocality() {
            return cLocality;
        }

        public String getcPinCode() {
            return cPinCode;
        }

        public String getcState() {
            return cState;
        }

        public String getcSubLocality() {
            return cSubLocality;
        }

        public String getpCity() {
            return pCity;
        }

        public String getpHouseName() {
            return pHouseName;
        }

        public String getpLocality() {
            return pLocality;
        }

        public String getpPinCode() {
            return pPinCode;
        }

        public String getpState() {
            return pState;
        }

        public String getpSubLocality() {
            return pSubLocality;
        }

        public String getIsHandicap() {
            return isHandicap;
        }

        public String getIsInternational() {
            return isInternational;
        }

        public String getIsLocomotive() {
            return isLocomotive;
        }

        public String getIsVisual() {
            return isVisual;
        }

        public String getMaritalStatus() {
            return maritalStatus;
        }

        public String getNationality() {
            return nationality;
        }

        public String getOriginCountry() {
            return originCountry;
        }

        public String getPassportNumber() {
            return passportNumber;
        }

        public String getPassportValidFrom() {
            return passportValidFrom;
        }

        public String getPassportValidTill() {
            return passportValidTill;
        }

        public String getQualification() {
            return qualification;
        }

        public String getFamilyName() {
            return familyName;
        }

        public String getFamilyDateOfBirth() {
            return familyDateOfBirth;
        }

        public String getFamilyRelation() {
            return familyRelation;
        }

        public String getFamilyResiding() {
            return familyResiding;
        }

        public String getFamilyIncome() {
            return familyIncome;
        }

        public String getFamilyDisability() {
            return familyDisability;
        }

        public String getProfileImageUrl() {
            return profileImageUrl;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void templateFileDownload() {
        System.setProperty("org.apache.poi.javax.xml.stream.XMLInputFactory", "com.fasterxml.aalto.stax.InputFactoryImpl");
        System.setProperty("org.apache.poi.javax.xml.stream.XMLOutputFactory", "com.fasterxml.aalto.stax.OutputFactoryImpl");
        System.setProperty("org.apache.poi.javax.xml.stream.XMLEventFactory", "com.fasterxml.aalto.stax.EventFactoryImpl");
        SharedPreferences sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        File root = new File(Environment.getExternalStorageDirectory(), "TemplateFile");
        if (!root.exists()) {
            root.mkdirs();
        }
        final File file = new File(Environment.getExternalStorageDirectory(), "TemplateFile/EmployeeExportTemplate.xlsx");
        file.delete();
        StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(sharedPreferences.getString("storagePathRef", "") + "/TemplateFile").child("EmployeeExportTemplate.xlsx");
        storageReference.getFile(file).addOnSuccessListener(taskSnapshot -> {
            exportPenalty();
        }).addOnFailureListener(exception -> {
            Log.d("TAG", "templateFileDownload: check data " + exception.toString());
            common.closeDialog(ExportEmployeeActivity.this);
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void exportPenalty() {
        String fileName = " Employee Details";
        try {
            FileInputStream file = new FileInputStream(new File(getExternalStorageDirectory(), "TemplateFile/EmployeeExportTemplate.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheetAt(0);

            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setFontHeightInPoints((short) 14);
            headerFont.setColor(IndexedColors.BLACK.getIndex());

            Font noteFont = workbook.createFont();
            noteFont.setBold(true);
            noteFont.setFontHeightInPoints((short) 11);
            noteFont.setColor(IndexedColors.WHITE.getIndex());

            // Create a CellStyle for total
            CellStyle totalCellStyle = workbook.createCellStyle();
            totalCellStyle.setFont(headerFont);
            totalCellStyle.setAlignment(HorizontalAlignment.RIGHT);

            // amount style
            CellStyle amountStyle = workbook.createCellStyle();
            amountStyle.setFont(headerFont);
            amountStyle.setAlignment(HorizontalAlignment.LEFT);

            int rowNum = 1;
            for (ModelClass data : modelClasses) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(data.getEmpId());
                row.createCell(1).setCellValue(data.getStatus());
                row.createCell(2).setCellValue("");
                row.createCell(3).setCellValue("");
                row.createCell(4).setCellValue(data.getUANNumber());
                row.createCell(5).setCellValue(data.getPpdCompanyEmployeeCode());
                row.createCell(6).setCellValue(data.getEmpName());
                row.createCell(7).setCellValue(data.getDob());
                row.createCell(8).setCellValue(data.getDoj());
                row.createCell(9).setCellValue(data.getGender());
                row.createCell(10).setCellValue(data.getFatherName());
                row.createCell(11).setCellValue("");
                row.createCell(12).setCellValue(data.getMobile());
                row.createCell(13).setCellValue(data.getEmail());
                row.createCell(14).setCellValue(data.getNationality());
                row.createCell(15).setCellValue("");
                row.createCell(16).setCellValue(data.getQualification());
                row.createCell(17).setCellValue(data.getMaritalStatus());
                row.createCell(18).setCellValue(data.getIsInternational());
                row.createCell(19).setCellValue(data.getPassportNumber());
                row.createCell(20).setCellValue(data.getPassportValidFrom());
                row.createCell(21).setCellValue(data.getPassportValidTill());
                row.createCell(22).setCellValue(data.getIsHandicap());
                row.createCell(23).setCellValue(data.getIsLocomotive());
                row.createCell(24).setCellValue(data.getActNumber());
                row.createCell(25).setCellValue(data.getIfsc());
                row.createCell(26).setCellValue("");
                row.createCell(27).setCellValue(data.getPanNumber());
                row.createCell(28).setCellValue("");
                row.createCell(29).setCellValue(data.getAadharNumber());
                row.createCell(30).setCellValue("");
                row.createCell(31).setCellValue("");
                row.createCell(32).setCellValue(data.getnName());
                row.createCell(33).setCellValue(data.getnAddress());
                row.createCell(34).setCellValue(data.getnRelation());
                row.createCell(35).setCellValue(data.getnMobile());
                row.createCell(36).setCellValue("");
                row.createCell(37).setCellValue(data.getcHouseName());
                row.createCell(38).setCellValue(data.getcSubLocality());
                row.createCell(39).setCellValue(data.getcPinCode());
                row.createCell(40).setCellValue(data.getcState());
                row.createCell(41).setCellValue(data.getcCity());
                row.createCell(42).setCellValue("");
                row.createCell(43).setCellValue(data.getpHouseName());
                row.createCell(44).setCellValue(data.getpSubLocality());
                row.createCell(45).setCellValue(data.getpPinCode());
                row.createCell(46).setCellValue(data.getpState());
                row.createCell(47).setCellValue(data.getpCity());
                row.createCell(48).setCellValue("");
                row.createCell(49).setCellValue(data.getFatherName());
                row.createCell(50).setCellValue(data.getFamilyDateOfBirth());
                row.createCell(51).setCellValue(data.getFamilyRelation());
                row.createCell(52).setCellValue(data.getFamilyResiding());
                row.createCell(53).setCellValue(data.getFamilyIncome());
                row.createCell(54).setCellValue(data.getFamilyDisability());
                row.createCell(55).setCellValue(data.getProfileImageUrl());
                Log.d("TAG", "exportPenalty: check "+data.getEmpName());
            }

            File files = new File(Environment.getExternalStorageDirectory(), fileName + ".xlsx");
            FileOutputStream fileOut = null;
            try {
                fileOut = new FileOutputStream(files);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                workbook.write(fileOut);
            } catch (IOException e) {
                e.printStackTrace();
            }
            assert fileOut != null;
            fileOut.close();

            workbook.close();
            Toast.makeText(ExportEmployeeActivity.this, "Report Downloaded", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(() -> shareReport(files.getPath()), 200);
        } catch (Exception e) {
            common.closeDialog(ExportEmployeeActivity.this);
        }
    }

    private void shareReport(String path) {
        common.closeDialog(ExportEmployeeActivity.this);
        try {
            File outputFile = new File(path);
            Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", outputFile);
            Intent share = new Intent();
            share.setAction(Intent.ACTION_SEND);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setType("application/pdf|application/x-excel");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setPackage("com.whatsapp");
            startActivity(share);
        } catch (Exception e) {
            Log.d("TAG", "exportPenalty: check "+e.toString());
        }
    }
}