package com.wevois.vcarebackoffice.ExpenseManagement.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.wevois.vcarebackoffice.ExpenseManagement.Model.Expense_Approval_Model_List;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class Expense_Approval_List_Adapter extends BaseAdapter {
    Context context;
    public static Object OnClickView;
    OnClickView onClickView;
    ArrayList<Expense_Approval_Model_List> expenseArrayList;

    public Expense_Approval_List_Adapter(Context context, ArrayList<Expense_Approval_Model_List> vendorArrayList, OnClickView onClickView) {
        this.context = context;
        this.expenseArrayList = vendorArrayList;
        this.onClickView = onClickView;

    }

    @Override
    public int getCount() {
        return expenseArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.activity_expense_approval_list, null, true);
        }
        Expense_Approval_Model_List vendorsListModel = expenseArrayList.get(i);
        TextView name = convertView.findViewById(R.id.vNameE1);
        name.setText(vendorsListModel.getName());
        TextView Bill = convertView.findViewById(R.id.vDateE1);
        Bill.setText(vendorsListModel.getDate());
        TextView Amount = convertView.findViewById(R.id.vAmountE1);
        Amount.setText(vendorsListModel.getAmount());
        TextView Purchase = convertView.findViewById(R.id.vPurchaseE1);
        Purchase.setText(vendorsListModel.getPurchase());
        TextView ExpenseBy = convertView.findViewById(R.id.vExpenseByE1);
        ExpenseBy.setText(vendorsListModel.getExpenseBy());
        ImageButton approval = convertView.findViewById(R.id.approval);
        approval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onClickView.onClick(i,vendorsListModel.getAmount(),vendorsListModel.getApproval(),vendorsListModel.getApproved());
            }
        });
        TextView Approved = convertView.findViewById(R.id.vApproved);
        Approved.setText(vendorsListModel.getApproved());
        return convertView;
    }
    public interface OnClickView{
        public void onClick(int i, String Amount,String Approved,String Approval);
    }
}
