package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory;

import android.app.Activity;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.employeeattendance.viewmodel.LogBookViewModel;

public class LogBookViewModelFactory implements ViewModelProvider.Factory {
    Activity activity;
    Spinner spinner;

    public LogBookViewModelFactory(Activity activity,Spinner spinner) {
        this.activity = activity;
        this.spinner = spinner;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new LogBookViewModel(activity,spinner);
    }
}