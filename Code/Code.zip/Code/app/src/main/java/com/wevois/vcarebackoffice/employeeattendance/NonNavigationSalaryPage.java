package com.wevois.vcarebackoffice.employeeattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

public class NonNavigationSalaryPage extends AppCompatActivity {
    String outTime="",ward = "", empName = "", empId = "", designationId = "", vehicle = "", year = "", month = "", date = "", timeInMillis = "", startTimes = "", salary = "";
    TextView totalTimeTv, totalHaltTimeTv, totalWorkTimeTv, todaySalaryTv, employeeName;
    DateFormat dateFormat;
    Long finalApprovedTimes;
    int totalEmpSalary=0;
    private ListView salaryListView;
    private ArrayList<SalaryDetails> salaryDetailsList = new ArrayList<>();
    SharedPreferences preferences;
    DatabaseReference databaseReference;
    CommonFunctions common = CommonFunctions.getInstance();
    SalaryAdapter salaryAdapter;
    boolean isMoved = true;
    int currentPosition = 0;
    DateFormat timeFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_navigation_salary_page);
        initPage();
        getEmployeeSalaryList(empId, designationId);
        setAction();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        totalHaltTimeTv = findViewById(R.id.employeeSalaryTotalHaltTimeTvNonNavigation);
        totalTimeTv = findViewById(R.id.employeeSalaryTotalTimeTvNonNavigation);
        totalWorkTimeTv = findViewById(R.id.employeeSalaryTotalWorkTimeTvNonNavigation);
        todaySalaryTv = findViewById(R.id.totalSalaryNonNavigation);
        salaryListView = findViewById(R.id.employeeSalaryListViewNonNavigation);
        salaryListView.setNestedScrollingEnabled(true);
        employeeName = findViewById(R.id.employeeSalaryNameNonNavigation);
        preferences = this.getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        ward = getIntent().getStringExtra("ward");
        vehicle = getIntent().getStringExtra("vehicle");
        empName = getIntent().getStringExtra("empName");
        empId = getIntent().getStringExtra("empId");
        designationId = getIntent().getStringExtra("designationId");
        employeeName.setText(empName);
        year = new SimpleDateFormat("yyyy").format(new Date());
        month = new SimpleDateFormat("MMMM", Locale.US).format(new Date());
        dateFormat = new SimpleDateFormat("HH:mm");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        date = dateFormat.format(new Date());
        DateFormat dateFormat1 = new SimpleDateFormat("HH:mm:ss");
        outTime = dateFormat1.format(new Date());

        salaryAdapter = new SalaryAdapter();
        salaryListView.setAdapter(salaryAdapter);
    }

    private void setAction() {
        findViewById(R.id.btnDutyOffNonNavigation).setOnClickListener(view -> {
            if (isMoved) {
                isMoved = false;
                employeeDutyOff();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMoved = true;
    }

    private void getEmployeeSalaryList(String empId, String designId) {
        currentPosition = 0;
        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date).child(empId).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null) {
                            salaryListView.setVisibility(View.GONE);
                            return;
                        }
                        long previousTime = 0, compactorPreviousTime = 0;
                        double tempTime = 0;
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            String key = dataSnapshot1.getKey();
                            if (key.contains("task")) {
                                if (dataSnapshot1.hasChild("task-wages")) {
                                    String duration = "0", vehicle = "";
                                    vehicle = dataSnapshot1.child("vehicle").getValue().toString();
                                    String salary = dataSnapshot1.child("task-wages").getValue().toString();
                                    if (dataSnapshot1.hasChild("final-approved-time")) {
                                        String time = dataSnapshot1.child("final-approved-time").getValue().toString();
                                        tempTime = Long.parseLong(time);
                                        duration = convertMilli2String(time);
                                    }
                                    if (dataSnapshot1.hasChild("task")) {
                                        String ward = dataSnapshot1.child("task").getValue().toString();
                                        if (!ward.equals("Compactor")) {
                                            String basic = calculateBasicTime(tempTime, previousTime, ward);
                                            String[] basicAndExtra = basic.split("-");
                                            previousTime += Long.parseLong(dataSnapshot1.child("final-approved-time").getValue().toString());
                                            String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                            String[] basicAndExtraSalary = basicSalary.split("-");
                                            salaryDetailsList.add(new SalaryDetails(ward, duration, salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                            salaryAdapter.notifyDataSetChanged();
                                        } else {
                                            String basic = calculateBasicTime(tempTime, compactorPreviousTime, ward);
                                            String[] basicAndExtra = basic.split("-");
                                            compactorPreviousTime += Long.parseLong(dataSnapshot1.child("final-approved-time").getValue().toString());
                                            String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                            String[] basicAndExtraSalary = basicSalary.split("-");
                                            salaryDetailsList.add(new SalaryDetails(ward, duration, salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                            salaryAdapter.notifyDataSetChanged();
                                        }
                                    }
                                } else {
                                    if (dataSnapshot1.hasChild("in-out")) {
                                        long difference = 0;
                                        String startTime = "", endTime = "";
                                        for (DataSnapshot snapshot1 : dataSnapshot1.child("in-out").getChildren()) {
                                            if (snapshot1.getValue().toString().equalsIgnoreCase("In")) {
                                                startTime = snapshot1.getKey();
                                                startTimes = startTime;
                                            }
                                        }
                                        endTime =  new SimpleDateFormat("HH:mm:ss").format(new Date());
                                        Date date1;
                                        try {
                                            date1 = dateFormat.parse(startTime);
                                            Date date2 = dateFormat.parse(endTime);
                                            difference += date2.getTime() - date1.getTime();
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                                        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                                        final String dateString = sdf.format(new Date(difference));
                                        final String finalDiff = String.valueOf(difference);
                                        if (dataSnapshot1.hasChild("task")) {
                                            timeInMillis = finalDiff;
                                            finalApprovedTimes = Long.parseLong(finalDiff, 10);
                                            if (ward.equals("Compactor")) {
                                                salary = "" + compactorSalaryCalculation(dateString, compactorPreviousTime);
                                                String basic = calculateBasicTime(tempTime, compactorPreviousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(new SalaryDetails(ward, timeFormat.format(new Date(finalApprovedTimes)), salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                                salaryAdapter.notifyDataSetChanged();
                                            } else if (ward.equals("GarageWork") || ward.equals("OfficeWork") || ward.equals("SegregationWork")) {
                                                int basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
                                                long basicTime = basicMinimumHour * 60 * 60000;
                                                if (finalApprovedTimes > basicTime) {
                                                    final String dateStrings = sdf.format(new Date(basicTime));
                                                    timeInMillis = String.valueOf(basicTime);
                                                    finalApprovedTimes = Long.parseLong(timeInMillis, 10);
                                                    salary = "" + salaryCalculation(dateStrings, previousTime);
                                                } else {
                                                    salary = "" + salaryCalculation(dateString, previousTime);
                                                }
                                                String basic = calculateBasicTime(tempTime, previousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(new SalaryDetails(ward, timeFormat.format(new Date(finalApprovedTimes)), salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                                salaryAdapter.notifyDataSetChanged();
                                            } else if (ward.equals("FixedWages")) {
                                                salary = "0";
                                                String basic = calculateBasicTime(tempTime, previousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(new SalaryDetails(ward, timeFormat.format(new Date(finalApprovedTimes)), salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                                salaryAdapter.notifyDataSetChanged();
                                            } else {
                                                salary = "" + salaryCalculation(dateString, previousTime);
                                                String basic = calculateBasicTime(tempTime, previousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, designId);
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(new SalaryDetails(ward, timeFormat.format(new Date(finalApprovedTimes)), salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], empName));
                                                salaryAdapter.notifyDataSetChanged();
                                            }
                                            totalTimeTv.setText(timeFormat.format(new Date(Long.parseLong(timeInMillis, 10))));
                                            totalHaltTimeTv.setText(timeFormat.format(new Date(0)));
                                            totalWorkTimeTv.setText(timeFormat.format(new Date(finalApprovedTimes)));
                                            totalEmpSalary = Integer.parseInt(salary);
                                            if (dataSnapshot.hasChild("today-wages")){
                                                totalEmpSalary = Integer.parseInt(dataSnapshot.child("today-wages").getValue().toString())+Integer.parseInt(salary);
                                            }
                                            todaySalaryTv.setText("₹ " + totalEmpSalary);
                                        }
                                    }
                                }
                            }
                        }
                        salaryAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                }
        );
    }

    private String calculateBasicSalary(int basicTime, String vehicle, int salary, String ward, String designId) {
        String basicSalary;
        double basicSalaryDriver = preferences.getLong("driverSalaryPerHour", 0) / 60.0;
        double basicSalaryHelper = preferences.getLong("helperSalaryPerHour", 0) / 60.0;
        double tractorDriver = preferences.getLong("tractorDriverSalary", 0) / 60.0;
        double compactorBasicSalaryDriver = preferences.getLong("compactorDriverSalaryPerHour", 0) / 60.0;

        if (designId.equals("5")) {
            if (!ward.equals("Compactor")) {
                if (vehicle.contains("TRACTOR")) {
                    int basicSalaryInt = (int) (basicTime * tractorDriver);
                    basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
                } else {
                    int basicSalaryInt = (int) (basicTime * basicSalaryDriver);
                    basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
                }
            } else {
                int basicSalaryInt = (int) (basicTime * compactorBasicSalaryDriver);
                basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
            }
        } else {
            int basicSalaryInt = (int) (basicTime * basicSalaryHelper);
            basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
        }
        return basicSalary;
    }

    private String calculateBasicTime(double duration, long previousTime, String task) {
        int previousTotalTime = (int) (previousTime / 60000);
        int currentTime = (int) (duration / 60000);
        int basicMinimumHour = 0;
        if (task.equals("Compactor")) {
            basicMinimumHour = preferences.getInt("compactorBasicMinimumHour", 0);
        } else {
            basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
        }
        int basicTime = basicMinimumHour * 60;
        int extraTime = 0;
        if (previousTotalTime > basicTime) {
            basicTime = 0;
            extraTime = currentTime;
        } else if (previousTotalTime == 0) {
            if (basicTime < currentTime) {
                extraTime = currentTime - basicTime;
            } else {
                basicTime = currentTime;
            }
        } else {
            basicTime = basicTime - previousTotalTime;
            if (basicTime < currentTime) {
                extraTime = currentTime - basicTime;
            }
        }
        return basicTime + "-" + extraTime;
    }

    private String convertMilli2String(String time) {
        String duration;
        long timeLong = Long.parseLong(time, 10);
        duration = dateFormat.format(new Date(timeLong));
        return duration;
    }

    public class SalaryAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return salaryDetailsList.size();
        }

        @Override
        public Object getItem(int position) {
            return salaryDetailsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getItemViewType(int position) {
            return super.getItemViewType(position);
        }

        @Override
        public int getViewTypeCount() {
            return super.getViewTypeCount();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView wardTv, durationTv, salaryTv, messageTv, wardStatic;
            View view;
            convertView = LayoutInflater.from(NonNavigationSalaryPage.this).inflate(R.layout.salary_item_row, parent, false);
            wardTv = convertView.findViewById(R.id.wardNo);
            wardStatic = convertView.findViewById(R.id.wardStatic);
            durationTv = convertView.findViewById(R.id.duration);
            salaryTv = convertView.findViewById(R.id.salaryTotal);
            messageTv = convertView.findViewById(R.id.messageForManager);
            view = convertView.findViewById(R.id.view);

            SalaryDetails salaryDetails = salaryDetailsList.get(position);
            wardStatic.setVisibility(View.VISIBLE);
            if (salaryDetails.getWard().contains("BinLifting")) {
                wardTv.setText("BinLifting");
            } else {
                wardTv.setText(salaryDetails.getWard());
            }
            if (!salaryDetails.getExtraTime().equals("00:00")) {
                if (!salaryDetails.getBasicTime().equals("00:00")) {
                    view.setVisibility(View.VISIBLE);
                    messageTv.setVisibility(View.VISIBLE);
                    SimpleDateFormat f = new SimpleDateFormat("HH:mm");
                    f.setTimeZone(TimeZone.getTimeZone("UTC"));
                    Date d = null;
                    try {
                        d = f.parse(salaryDetails.getBasicTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    int basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
                    long basicTime = (basicMinimumHour * 60 * 60000) - d.getTime();
                    String duration = f.format(new Date(basicTime));
                    String message;
                    if (position == 0) {
                        message = salaryDetails.getName() + " ने " + salaryDetails.getBasicTime() + " (Hrs) Basic OR " + salaryDetails.getBasicTime() + " (Hrs) Extra Work किया हैं | ";
                    } else {
                        message = salaryDetails.getName() + " " + duration + " (Hrs) अन्य task में कर चूका है | इसलिए इस task में " + salaryDetails.getBasicTime() + " (Hrs) Basic Hrs व अन्य Extra Hrs लिये जायेंगे। ";
                    }
                    messageTv.setText(message);
                    String basicString = salaryDetails.getBasicTime() + " (Basic Hrs)";
                    SpannableString ss1 = new SpannableString(basicString);
                    ss1.setSpan(new RelativeSizeSpan(.8f), 5, ss1.length(), 0); // set size
                    ss1.setSpan(new ForegroundColorSpan(Color.RED), 5, ss1.length(), 0);// set color
                    String extraString = salaryDetails.getExtraTime() + " (Extra Hrs)";
                    SpannableString ss2 = new SpannableString(extraString);
                    ss2.setSpan(new RelativeSizeSpan(.8f), 5, ss2.length(), 0); // set size
                    ss2.setSpan(new ForegroundColorSpan(Color.RED), 5, ss2.length(), 0);// set color

                    CharSequence finalText = TextUtils.concat(ss1, " \n", ss2);

                    durationTv.setText(finalText);
                    salaryTv.setText(salaryDetails.getBasicSalary() + "\n" + salaryDetails.getExtraSalary() + "\n---------\n₹ " + salaryDetails.getSalary());
                } else {
                    view.setVisibility(View.GONE);
                    messageTv.setVisibility(View.GONE);
                    String extraString = salaryDetails.getDuration() + " (Hrs)";
                    SpannableString ss2 = new SpannableString(extraString);
                    ss2.setSpan(new RelativeSizeSpan(.8f), 5, ss2.length(), 0); // set size
                    ss2.setSpan(new ForegroundColorSpan(Color.RED), 5, ss2.length(), 0);// set color
                    durationTv.setText(ss2);
                    salaryTv.setText("₹ " + salaryDetails.getSalary());
                }
            } else {
                view.setVisibility(View.GONE);
                messageTv.setVisibility(View.GONE);
                String extraString = salaryDetails.getDuration() + " (Hrs)";
                SpannableString ss2 = new SpannableString(extraString);
                ss2.setSpan(new RelativeSizeSpan(.8f), 5, ss2.length(), 0); // set size
                ss2.setSpan(new ForegroundColorSpan(Color.RED), 5, ss2.length(), 0);// set color
                durationTv.setText(ss2);
                salaryTv.setText("₹ " + salaryDetails.getSalary());
            }
            return convertView;
        }
    }

    private int salaryCalculation(String dateString, long tempTotalTime) {
        double actualSalary;
        actualSalary = calculateSalary(dateString);
        if (tempTotalTime > 0) {
            String totalSalary = timeFormat.format(new Date(tempTotalTime + finalApprovedTimes));
            String removeSalary = timeFormat.format(new Date(tempTotalTime));
            double totalActualSalary = calculateSalary(totalSalary);
            double totalRemoveSalary = calculateSalary(removeSalary);
            actualSalary = totalActualSalary - totalRemoveSalary;
        }
        return (int) actualSalary;
    }

    private int compactorSalaryCalculation(String dateString, long compactorPreviousTime) {
        double actualSalary;
        actualSalary = calculateSalary(dateString);
        if (compactorPreviousTime > 0) {
            String totalSalary = timeFormat.format(new Date(compactorPreviousTime + finalApprovedTimes));
            String removeSalary = timeFormat.format(new Date(compactorPreviousTime));
            double totalActualSalary = calculateSalary(totalSalary);
            double totalRemoveSalary = calculateSalary(removeSalary);
            actualSalary = totalActualSalary - totalRemoveSalary;
        }
        return (int) actualSalary;
    }

    public int calculateSalary(String time) {
        double salary = 0.0;
        if (preferences.getLong("driverIncPerHour", 0) > 1 && preferences.getLong("helperIncPerHour", 0) > 1) {
            double basicSalaryDriver = preferences.getLong("driverSalaryPerHour", 0);
            double basicSalaryHelper = preferences.getLong("helperSalaryPerHour", 0);
            double driverIncPerHour = preferences.getLong("driverIncPerHour", 0);
            double helperIncPerHour = preferences.getLong("helperIncPerHour", 0);
            double compactorDriverIncPerHour = preferences.getLong("compactorDriverIncentivePerHour", 0);
            double compactorBasicSalaryDriver = preferences.getLong("compactorDriverSalaryPerHour", 0);
            int compactorBasicHour = preferences.getInt("compactorBasicMinimumHour", 0);
            double tractorDriverMonthlyIncentive = preferences.getLong("tractorDriverSalary", 0);
            int basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
            double tractorDriver = tractorDriverMonthlyIncentive / 60;
            String text = time;
            String[] arr = text.split(":");
            if (arr.length >= 2) {
                if (designationId.equals("5")) {
                    if (!ward.equals("Compactor")) {
                        if (vehicle.contains("TRACTOR")) {
                            salary = Integer.parseInt(arr[0]) * tractorDriverMonthlyIncentive + Integer.parseInt(arr[1]) * tractorDriver;
                        } else {
                            if (Integer.parseInt(arr[0]) < basicMinimumHour) {
                                salary = Integer.parseInt(arr[0]) * basicSalaryDriver + Integer.parseInt(arr[1]) * (basicSalaryDriver / 60);
                            } else {
                                salary = (basicSalaryDriver * basicMinimumHour) + (Integer.parseInt(arr[0]) - basicMinimumHour) * driverIncPerHour + Integer.parseInt(arr[1]) * (driverIncPerHour / 60);
                            }
                        }
                    } else {
                        if (Integer.parseInt(arr[0]) < compactorBasicHour) {
                            salary = Integer.parseInt(arr[0]) * compactorBasicSalaryDriver + Integer.parseInt(arr[1]) * (compactorBasicSalaryDriver / 60);
                        } else {
                            salary = (compactorBasicSalaryDriver * compactorBasicHour) + (Integer.parseInt(arr[0]) - compactorBasicHour) * compactorDriverIncPerHour + Integer.parseInt(arr[1]) * (compactorDriverIncPerHour / 60);
                        }
                    }
                } else if (designationId.contains("6")) {
                    if (Integer.parseInt(arr[0]) < basicMinimumHour) {
                        salary = Integer.parseInt(arr[0]) * basicSalaryHelper + Integer.parseInt(arr[1]) * (basicSalaryHelper / 60);
                    } else {
                        salary = (basicSalaryHelper * basicMinimumHour) + (Integer.parseInt(arr[0]) - basicMinimumHour) * helperIncPerHour + Integer.parseInt(arr[1]) * (helperIncPerHour / 60);
                    }
                }
            }
        }
        return (int) salary;
    }

    private void employeeDutyOff() {
        common.setProgressDialog("Please wait...", "Employee का data सेव हो रहा है |", NonNavigationSalaryPage.this, NonNavigationSalaryPage.this);
        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.getKey().contains("task")) {
                            if (!snapshot.hasChild("task-wages")) {
                                HashMap<String, Object> data = new HashMap<>();
                                data.put("status", "1");
                                data.put("task-wages", salary);
                                data.put("final-approved-time", finalApprovedTimes);
                                data.put("final-approved-time-in-minute", "" + finalApprovedTimes / 60000);
                                data.put("total-halt-time", 0);
                                data.put("total-halt-time-in-minute", "" + 0);
                                data.put("approved-halt-time", 0);
                                data.put("final-halt-after-remove-time-in-minute", "" + 0);
                                data.put("total-remove-halt-time-in-minute", "" + 0);
                                data.put("total-time-spent", timeInMillis);
                                data.put("work-percent", 0);
                                data.put("vehicle", vehicle);
                                data.put("total-time-spent-in-minute", "" + Long.valueOf(timeInMillis) / 60000);
                                databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId + "/" + "card-swap-entries/" + outTime).setValue("Out");
                                databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId + "/" + "today-wages").setValue(totalEmpSalary);
                                databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId + "/" + snapshot.getKey()).updateChildren(data).addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId + "/" + snapshot.getKey() + "/in-out/" + outTime).setValue("Out").addOnCompleteListener(task12 -> {
                                            if (task12.isSuccessful()) {
                                                HashMap<String, String> workAssignmentData = new HashMap<>();
                                                workAssignmentData.put("current-assignment", "");
                                                workAssignmentData.put("device", "");
                                                workAssignmentData.put("vehicle", "");
                                                databaseReference.child("WorkAssignment/" + empId).setValue(workAssignmentData).addOnCompleteListener(task1 -> {
                                                    if (task1.isSuccessful()) {
                                                        databaseReference.child("RealTimeDetails/peopleOnWork").addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                int activeEmp = 0;
                                                                if (dataSnapshot.getValue() != null) {
                                                                    if (Integer.parseInt(dataSnapshot.getValue().toString()) != 0) {
                                                                        activeEmp = Integer.parseInt(dataSnapshot.getValue().toString()) - 1;
                                                                    }
                                                                }
                                                                databaseReference.child("RealTimeDetails/peopleOnWork").setValue("" + (activeEmp)).addOnCompleteListener(task1 -> {
                                                                    if (task1.isSuccessful()) {
                                                                        if (!vehicle.equalsIgnoreCase("NotApplicable")) {
                                                                            databaseReference.child("Vehicles/" + vehicle).addListenerForSingleValueEvent(new ValueEventListener() {
                                                                                @Override
                                                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                                    if (dataSnapshot.getValue() != null) {
                                                                                        String status = "3", idString = "";
                                                                                        if (designationId.equalsIgnoreCase("5")) {
                                                                                            idString = "assigned-driver";
                                                                                            if (dataSnapshot.hasChild("assigned-helper")) {
                                                                                                if (dataSnapshot.child("assigned-helper").getValue().toString().equalsIgnoreCase("")) {
                                                                                                    status = "1";
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            idString = "assigned-helper";
                                                                                            if (dataSnapshot.hasChild("assigned-driver")) {
                                                                                                if (dataSnapshot.child("assigned-driver").getValue().toString().equalsIgnoreCase("")) {
                                                                                                    status = "1";
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        HashMap<String, Object> dataMapVehicles = new HashMap<>();
                                                                                        dataMapVehicles.put(idString, "");
                                                                                        if (status.equalsIgnoreCase("1")) {
                                                                                            dataMapVehicles.put("assigned-task", "");
                                                                                        }
                                                                                        dataMapVehicles.put("status", status);
                                                                                        databaseReference.child("Vehicles/" + vehicle).updateChildren(dataMapVehicles).addOnCompleteListener(task2 -> {
                                                                                            if (task2.isSuccessful()) {
                                                                                                moveActivity();
                                                                                            }
                                                                                        });
                                                                                    } else {
                                                                                        isMoved = true;
                                                                                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationSalaryPage.this);
                                                                                    }
                                                                                }

                                                                                @Override
                                                                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                                }
                                                                            });
                                                                        }else {
                                                                            moveActivity();
                                                                        }
                                                                    } else {
                                                                        isMoved = true;
                                                                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationSalaryPage.this);
                                                                    }
                                                                });
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                                            }
                                                        });
                                                    } else {
                                                        isMoved = true;
                                                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationSalaryPage.this);
                                                    }
                                                });
                                            } else {
                                                isMoved = true;
                                                common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationSalaryPage.this);
                                            }
                                        });
                                    } else {
                                        isMoved = true;
                                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationSalaryPage.this);
                                    }
                                });
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void moveActivity() {
        common.closeDialog(this);
        Toast.makeText(NonNavigationSalaryPage.this, "Duty Off", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(NonNavigationSalaryPage.this, WardSelectKotlin.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        Bundle options = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        startActivity(intent, options);
        finish();
    }
}