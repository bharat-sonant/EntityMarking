package com.wevois.vcarebackoffice.employeeattendance.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivityHaltReviewBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.HaltReviewViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.HaltReviewViewModelFactory;

public class HaltReview extends AppCompatActivity {
    ActivityHaltReviewBinding binding;
    HaltReviewViewModel viewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_halt_review);
        viewModel = new ViewModelProvider(this,new HaltReviewViewModelFactory(this)).get(HaltReviewViewModel.class);
        binding.setHaltreviewviewmodel(viewModel);
    }

    @Override
    public void onBackPressed() {
        viewModel.onBack();
    }
}