package com.wevois.vcarebackoffice.Monitoring;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class HouseDetailActivity extends AppCompatActivity {

    //    ActivitySubFormPageBinding binding;
    String str1,str2;
    String latlng, name, line_no, mobile, address, ward_no;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences preferences;
    List<String> houseTypeList = new ArrayList<>();
    JSONArray jsonArrayHouseType = new JSONArray();
    AlertDialog saveAlertBox;
    String markingKey, cardNumber;
    TextView tvName,tvAddress,tvWard,tvLine;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.house_detail_activity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        preferences = getSharedPreferences("LoginDetails", MODE_PRIVATE);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {

            if (bundle.containsKey("mobile")) {
                mobile = bundle.getString("mobile");
            }
            if (bundle.containsKey("address")) {
                address = bundle.getString("address");
            }

            if (bundle.containsKey("name")) {
                name = bundle.getString("name");
            }
            if (bundle.containsKey("ward")) {
                ward_no = bundle.getString("ward");
            }
            if (bundle.containsKey("line")) {
                line_no = bundle.getString("line");
            }

            if (bundle.containsKey("latlng")) {
                latlng = bundle.getString("latlng");
                String[] parts = latlng.split(",");
                str1 = parts[0]; // 004
                str2 = parts[1]; // 034556
                str1 = str1.replace("(","");
                str2 = str2.replace(")","");
                Log.e("LatLng",str1+" "+str2);

            }


        }


        findViewById(R.id.btnSaveDetails).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri gmmIntentUri = Uri.parse("google.navigation:q=" + str1 + "," + str2);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });


        findViewById(R.id.BackBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tvName = findViewById(R.id.tvName);
        tvAddress = findViewById(R.id.tvAddress);
        tvWard = findViewById(R.id.tvWard);
        tvLine = findViewById(R.id.tvLine);
        tvName.setText(name);
        tvAddress.setText(address);
        tvWard.setText(ward_no);
        tvLine.setText(line_no);
//        binding.houseTypeSpinner.setSelection(0);
//        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        binding.houseTypeSpinner.setAdapter(spinnerArrayAdapter);

    }

}