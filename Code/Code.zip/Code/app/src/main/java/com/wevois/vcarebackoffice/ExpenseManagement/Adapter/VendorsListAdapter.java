package com.wevois.vcarebackoffice.ExpenseManagement.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.VendorsListModel;
import com.wevois.vcarebackoffice.ExpenseManagement.Views.VendorDetails;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class VendorsListAdapter extends BaseAdapter {
    Context context;
    ArrayList<VendorsListModel> arrayListVendors;

    public VendorsListAdapter(Context context, ArrayList<VendorsListModel> arrayListVendors) {
        this.context = context;
        this.arrayListVendors = arrayListVendors;
    }

    @Override
    public int getCount() {
        return arrayListVendors.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.display_vendor_entries_list, null, true);
        }
        VendorsListModel vendorsListModel = arrayListVendors.get(i);
        TextView name = convertView.findViewById(R.id.vName);
        name.setText(vendorsListModel.getName() + " (" + vendorsListModel.getMobileNumber() + ") ");
        convertView.findViewById(R.id.vName).setOnClickListener((View v) -> {
            Intent intent = new Intent(context, VendorDetails.class);
            intent.putExtra("vendorName", vendorsListModel.getName());
            intent.putExtra("vendorMobile", vendorsListModel.getMobileNumber());
            intent.putExtra("vendorAddress", vendorsListModel.getAddress());
            intent.putExtra("vendorBank", vendorsListModel.getBankName());
            intent.putExtra("vendorAccount", vendorsListModel.getAccountNumber());
            intent.putExtra("vendorBranch", vendorsListModel.getBranch());
            intent.putExtra("vendorIFSC", vendorsListModel.getIfsc());
            context.startActivity(intent);
            ((Activity)context).finish();
        });
        return convertView;
    }
}
