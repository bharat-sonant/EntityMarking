package com.wevois.vcarebackoffice.EmployeeData;

public class EmployeePOJO {
    private String mNo, name, designation, image, username;
    private boolean bankDetails,Approved;

    EmployeePOJO(String mNo, String name, String designation, String image, boolean bankDetails,String username,boolean Approved) {
        this.mNo = mNo;
        this.name = name;
        this.designation = designation;
        this.image = image;
        this.bankDetails = bankDetails;
        this.username = username;
        this.Approved = Approved;
    }

    public String getId() {
        return mNo;
    }

    public void setId(String mNo) {
        this.mNo = mNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    String getImage() {
        return image;
    }

    boolean getBankDetails() {
        return bankDetails;
    }

    String getUsername() {
        return username;
    }

    boolean getApproved() { return Approved; }
}
