package com.wevois.vcarebackoffice.Monitoring;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.wevois.vcarebackoffice.Monitoring.VehicleMonitoring.VehicleMonitoringActivity;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.WorkMonitoringData;

public class MonitoringOptionsActivity extends AppCompatActivity {
    SharedPreferences sharedPrefLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoring_options);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        sharedPrefLogin = getSharedPreferences("loginData", MODE_PRIVATE);
        if (sharedPrefLogin.getBoolean("isSIAdmin", false)) {
            findViewById(R.id.linearLayoutTwo).setVisibility(View.GONE);
            findViewById(R.id.linearLayoutThree).setVisibility(View.GONE);
            findViewById(R.id.viewTwo).setVisibility(View.GONE);
            findViewById(R.id.versionMonitoring).setVisibility(View.GONE);
        }

        findViewById(R.id.vehicleMonitoringBtn).setOnClickListener(v ->
                startActivity(new Intent(MonitoringOptionsActivity.this, VehicleMonitoringActivity.class)));

        findViewById(R.id.salaryMangementBtn).setOnClickListener(v ->
                startActivity(new Intent(MonitoringOptionsActivity.this, WorkMonitoringActivity.class)));

        findViewById(R.id.resetLines).setOnClickListener(v ->
                startActivity(new Intent(MonitoringOptionsActivity.this, ResetLineActivity.class)));
        findViewById(R.id.runningOnMap).setOnClickListener(v ->
                startActivity(new Intent(MonitoringOptionsActivity.this, WardSelectActivity.class)));

        findViewById(R.id.versionMonitoring).setOnClickListener(v ->
                startActivity(new Intent(MonitoringOptionsActivity.this, VersionMonitoringActivity.class)));

        findViewById(R.id.workmonitoringactivity).setOnClickListener(v->{
            startActivity(new Intent(MonitoringOptionsActivity.this, WorkMonitoringData.class));
        });

        findViewById(R.id.cardDetailsBtn).setOnClickListener(v->{
            startActivity(new Intent(MonitoringOptionsActivity.this, CardDetailActivity.class));
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}
