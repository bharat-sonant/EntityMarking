package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

import static androidx.constraintlayout.widget.Constraints.TAG;


public class LeaveAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> dNameList;
    private ArrayList<String> dateList;
    private ArrayList<String> statusList;
    private buttonClickListener mClickListener;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> actionList = new ArrayList<>();

    void setClickListener(buttonClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }


    public static interface buttonClickListener {
        void onMethodCallback(String status, int pos);
    }

    public LeaveAdapter(Context context, ArrayList<String> date, ArrayList<String> name,  ArrayList<String> status) {

        this.context = context;
        this.actionList.add("Action");
        this.actionList.add("Approved");
        this.actionList.add("Rejected");
        if (adapter==null){
            adapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,actionList);
        }
        this.dNameList = name;
        this.dateList = date;
        this.statusList = status;
    }

    @Override
    public int getViewTypeCount() {
        if(getCount() > 0){
            return getCount();
        }else{
            return super.getViewTypeCount();
        }
    }
    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public int getCount() {
        return dateList.size();
    }

    @Override
    public Object getItem(int position) {
        return dateList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.leave_list_row, null, true);


            holder.date = (TextView) convertView.findViewById(R.id.date);
            holder.name = (TextView) convertView.findViewById(R.id.name);
            holder.action = (TextView)convertView.findViewById(R.id.action);
            holder.spinner = (Spinner)convertView.findViewById(R.id.spinner);
            holder.imageButton = (ImageButton)convertView.findViewById(R.id.imageBtn);
            convertView.setTag(holder);
        }else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (ViewHolder)convertView.getTag();
        }

        holder.date.setText(dateList.get(position));
        holder.name.setText(dNameList.get(position));
        if (statusList.size()>position) {
            Log.i(TAG, "getView: "+statusList);
            if (statusList.get(position).contains("2")) {
                holder.action.setText("Approved");
//                convertView.setBackgroundColor(Color.parseColor("#A3E4D7"));
                holder.action.setBackgroundColor(Color.parseColor("#A3E4D7"));
//                holder.date.setBackgroundColor(Color.parseColor("#A3E4D7"));
//                holder.name.setBackgroundColor(Color.parseColor("#A3E4D7"));
                // #F1948A
//                holder.action.setImageResource(R.drawable.ic_done);
            }else if (statusList.get(position).contains("3")) {
                holder.action.setText("Rejected");
//                convertView.setBackgroundColor(Color.parseColor("#F1948A"));
                holder.action.setBackgroundColor(Color.parseColor("#F1948A"));
//                holder.date.setBackgroundColor(Color.parseColor("#F1948A"));
//                holder.name.setBackgroundColor(Color.parseColor("#F1948A"));
                // #F1948A
//                holder.action.setImageResource(R.drawable.ic_cancel);
            }else {
                holder.action.setText("Applied");
//                convertView.setBackgroundColor(Color.TRANSPARENT);
                holder.action.setBackgroundColor(Color.TRANSPARENT);
//                holder.date.setBackgroundColor(Color.TRANSPARENT);
//                holder.name.setBackgroundColor(Color.TRANSPARENT);
//                holder.action.setImageResource(R.drawable.ic_pending_alert);
            }
        }
        if (adapter!=null) {
            holder.spinner.setAdapter(adapter);
        }
        View finalConvertView = convertView;

        holder.imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context wrapper = new ContextThemeWrapper(context, R.style.popup);
                PopupMenu popup = new PopupMenu(wrapper, holder.imageButton);
                //inflating menu from xml resource
                popup.inflate(R.menu.leave_context_menu);
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.approve:
                                mClickListener.onMethodCallback("2", position);
                                holder.action.setText("Approved");
                                holder.action.setBackgroundColor(Color.parseColor("#A3E4D7"));
                                break;
                            case R.id.reject:
                                mClickListener.onMethodCallback("3", position);
                                holder.action.setText("Rejected");
                                item.setEnabled(false);
                                holder.action.setBackgroundColor(Color.parseColor("#F1948A"));
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();
            }
        });
//        holder.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
//                if (pos>0) {
//                    if (pos == 1) {
//                        mClickListener.onMethodCallback("2", position);
//                        holder.action.setText("Approved");
//                        finalConvertView.setBackgroundColor(Color.parseColor("#A3E4D7"));
//
////                        holder.action.setImageResource(R.drawable.ic_done);
//                    } else if (pos == 2) {
//                        mClickListener.onMethodCallback("3", position);
//                        holder.action.setText("Rejected");
//                        finalConvertView.setBackgroundColor(Color.parseColor("#F1948A"));
////                        holder.action.setImageResource(R.drawable.ic_cancel);
//                    }
////                else{
////                    mClickListener.onMethodCallback("1", position);
////                    holder.action.setImageResource(R.drawable.ic_pending_alert);
////                }
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

        return convertView;
    }

    private class ViewHolder {
        private TextView date, name;
        TextView action;
        ImageButton imageButton;
        Spinner spinner;

    }

}