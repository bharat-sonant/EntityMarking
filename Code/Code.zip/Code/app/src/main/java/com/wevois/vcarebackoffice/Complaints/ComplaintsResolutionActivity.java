package com.wevois.vcarebackoffice.Complaints;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Complaints.Model.ResolveModel;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Arrays;

public class ComplaintsResolutionActivity extends AppCompatActivity {
    ListView resolveRV;
    CommonFunctions common = CommonFunctions.getInstance();
    DatabaseReference ref;
    ArrayList<ResolveModel> models = new ArrayList<>();
    ResolveAdapterNew resolveAdapterNew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_resolution);
        resolveAdapterNew = new ResolveAdapterNew();
        resolveRV = findViewById(R.id.resolveRV);
        ref = common.getDatabasePath(this);
        getWardListandCount();
        setPageTitle();
    }

    private void getWardListandCount() {
        ref.child("Complaints").child("WardListCount").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snap : dataSnapshot.getChildren()) {
                        String ward = snap.getKey();
                        String count = snap.getValue() + "";
                        models.add(new ResolveModel(ward, count));
                    }
                    resolveRV.setAdapter(resolveAdapterNew);
                    resolveAdapterNew.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public class ResolveAdapterNew extends BaseAdapter {

        @Override
        public int getCount() {
            return models.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            TextView wardDetails;
            TextView complaintsNumber;
            LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.resolverecyclerview,null,true);
            complaintsNumber = view.findViewById(R.id.complaintsNumber);
            wardDetails = view.findViewById(R.id.wardDetails);
            ResolveModel resolveModel = models.get(i);
            wardDetails.setText(resolveModel.getWard());
            complaintsNumber.setText(resolveModel.getCount());

            wardDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(ComplaintsResolutionActivity.this,ShowWardComplaintsList.class);
                    startActivity(i);
                }
            });

            return view;
        }
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Complaints Resolutuion");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            ComplaintsResolutionActivity.super.onBackPressed();
        });
    }

}