package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.widget.LinearLayout;

import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.adapter.ParentRecyclerViewAdapter;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.repository.DutyOffReviewRepository;
import com.wevois.vcarebackoffice.employeeattendance.views.Swipe;
import com.wevois.vcarebackoffice.employeeattendance.views.WorkProgressMap;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DutyOffReviewViewModel extends ViewModel {

    Activity activity;
    SharedPreferences preferences;
    public ObservableField<String> wardName = new ObservableField<>(),vehicleName = new ObservableField<>(),planName = new ObservableField<>();
    public ObservableField<ParentRecyclerViewAdapter> parentRecyclerViewAdapter = new ObservableField<>();
    public ObservableField<Boolean> isSwipeDisplay = new ObservableField<>(true),isViewDisplay = new ObservableField<>(true),isPlanDisplay = new ObservableField<>(false);
    String storageReference="",ward="",planId="";
    CommonFunctions common = CommonFunctions.getInstance();
    DatabaseReference databaseReference;
    DutyOffReviewRepository repository = new DutyOffReviewRepository();
    boolean isMoved=true,isProgressDialog = true,isSwipe=false;
    ArrayList<String> wards = new ArrayList<>();
    ArrayList<OtherDetails> otherDetails;
    ArrayList<ParentRecyclerviewModel> userModel = new ArrayList<>();
    Handler handler;
    long fileCreationTime;

    public DutyOffReviewViewModel(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        storageReference = preferences.getString("storagePathRef","");
        databaseReference = common.getDatabasePath(activity);
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {}.getType());
        ward = otherDetails.get(0).getWards().get(0);
        if (ward.contains("Market") || ward.contains("mkt")) {
            wardName.set(ward);
        } else if (ward.contains("BinLifting")){
            if (!otherDetails.get(0).getPlanName().equalsIgnoreCase("")) {
                isPlanDisplay.set(true);
                planName.set(otherDetails.get(0).getPlanName());
            }
            isSwipeDisplay.set(false);
            isViewDisplay.set(false);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
            params.weight = 100;
            activity.findViewById(R.id.btnContinueForDutyOffReviewPage).setLayoutParams(params);
            wardName.set("BinLifting");
        } else {
            wardName.set("Ward : " + ward);
        }
        common.setProgressDialog("Please wait.....", "", activity, activity);
        repository.getEmployeeDetails(databaseReference,ward,common,otherDetails).observe((LifecycleOwner) activity, response->{
            if (!response.equalsIgnoreCase("fail")){
                String[] result = response.split("~");
                userModel = new Gson().fromJson(result[0], new TypeToken<ArrayList<ParentRecyclerviewModel>>() {}.getType());
                parentRecyclerViewAdapter.set(new ParentRecyclerViewAdapter(userModel, activity));
                otherDetails = new Gson().fromJson(result[1], new TypeToken<ArrayList<OtherDetails>>() {}.getType());
                wards = otherDetails.get(0).getWards();
                vehicleName.set(otherDetails.get(0).getVehicle());
                common.closeDialog(activity);
            }
        });
    }

    private void downloadWardJson(int i) {
        Log.e("file download","ward json");
        common.checkNetWork(activity).observe((LifecycleOwner) activity,result->{
            if (result) {
                if (wards.get(i).contains("BinLifting")){
                    moveToMapActivity();
                }else {
//                    initiateFileDownload(i);
                    getStatus(i);
                }
            } else {
                if (wards.get(i).contains("BinLifting")){
                    moveToMapActivity();
                }else {
                    Log.e("file downloaded","ward json");
                    File sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                    File file = new File(sdcard, "WardJson");
                    File checkFile = new File(file, wards.get(i)+".json");
                    if (!checkFile.exists()) {
                        if (isProgressDialog) {
                            isProgressDialog = false;
                            common.setProgressDialog("", "Check your internet connection.", activity, activity);
                        }
                        handler = new Handler();
                        handler.postDelayed(runnable(i), 1000);
                    } else {
                        if ((wards.size()-1)<=i) {
                            moveToMapActivity();
                        }else {
                            downloadWardJson(i+1);
                        }
                    }
                }
            }
        });
    }

    private Runnable runnable(int i) {
        return () -> downloadWardJson(i);
    }

//    public void initiateFileDownload(int i) {
//        FirebaseStorage.getInstance().getReferenceFromUrl(storageReference + "/WardJson").child(wards.get(i)+".json").getMetadata().addOnSuccessListener(storageMetadata -> {
//            File file = new File(Environment.getExternalStorageDirectory(), "WardJson/" + wards.get(i)+".json");
//            fileCreationTime = storageMetadata.getCreationTimeMillis();
//            long fileDownloadTime = preferences.getLong("fileDownloadTime"+wards.get(i), 0);
//            if (fileDownloadTime == fileCreationTime && file.exists()) {
//                if ((wards.size()-1)<=i) {
//                    moveToMapActivity();
//                }else {
//                    downloadWardJson(i+1);
//                }
//            } else {
//                fileDownload(i);
//            }
//        }).addOnFailureListener(e -> {
//            common.setProgressDialog("","File not found ",activity,activity);
//        });
//    }
//
//    public void fileDownload(int i) {
//        File root = new File(Environment.getExternalStorageDirectory(), "WardJson");
//        if (!root.exists()) {
//            root.mkdirs();
//        }
//        final File file = new File(Environment.getExternalStorageDirectory(), "WardJson/" + wards.get(i)+".json");
//        file.delete();
//        FirebaseStorage.getInstance().getReferenceFromUrl(storageReference + "/WardJson").child(wards.get(i)+".json").getFile(file).addOnSuccessListener(taskSnapshot -> {
//            preferences.edit().putLong("fileDownloadTime"+wards.get(i), fileCreationTime).apply();
//            if ((wards.size()-1)<=i) {
//                moveToMapActivity();
//            }else {
//                downloadWardJson(i+1);
//            }
//        }).addOnFailureListener(exception -> {
//        });
//    }


    public void getStatus(int i) {
        Log.d("TAG", "getStatus: check calling file download "+wards.get(i));
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(preferences.getString("city","")+"/WardLinesHouseJson/"+wards.get(i)+"/mapUpdateHistoryJson.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = preferences.getLong(preferences.getString("city","")+""+wards.get(i)+"mapUpdateHistoryJsonDownloadTime", 0);
            Log.d("TAG", "getStatus: check calling file download "+wards.get(i)+"   "+fileCreationTime+"   "+fileDownloadTime);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(preferences.getString("city","")+"/WardLinesHouseJson/"+wards.get(i)+"/mapUpdateHistoryJson.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        preferences.edit().putString(preferences.getString("city","")+wards.get(i)+"mapUpdateHistoryJson", str).apply();
                        preferences.edit().putLong(preferences.getString("city","")+""+wards.get(i)+"mapUpdateHistoryJsonDownloadTime", fileCreationTime).apply();
                        checkDate(i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }else {
                checkDate(i);
            }
        });
    }

    private void checkDate(int j) {
        try {
            Log.d("TAG", "getStatus: check calling file download B "+wards.get(j));
            JSONArray jsonArray = new JSONArray(preferences.getString(preferences.getString("city","")+wards.get(j)+"mapUpdateHistoryJson",""));
            for (int i=jsonArray.length()-1;i>=0;i--){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date date1 = format.parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                    Date date2 = format.parse(jsonArray.getString(i));
                    if (date1.after(date2)){
                        fileMetaDownload(String.valueOf(jsonArray.getString(i)),j);
                        break;
                    }else if (date1.equals(date2)){
                        fileMetaDownload(String.valueOf(jsonArray.getString(i)),j);
                        break;
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void fileMetaDownload(String dates,int i) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        Log.d("TAG", "getStatus: check calling file download C "+wards.get(i));
        storageReference.child(preferences.getString("city","")+"/WardLinesHouseJson/"+wards.get(i)+"/"+dates+".json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = preferences.getLong(preferences.getString("city","")+wards.get(i)+dates+"DownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                getFileDownload(dates,i);
                preferences.edit().putLong(preferences.getString("city","")+wards.get(i)+dates+"DownloadTime", fileCreationTime).apply();
            }else {
                try {
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "WardJson/"+
                            preferences.getString("city","")+"/"+wards.get(i)+"/"+dates + ".json");
                    if (file.exists()) {
                        if ((wards.size()-1)<=i) {
                            moveToMapActivity();
                        }else {
                            downloadWardJson(i+1);
                        }
                    }else {
                        getFileDownload(dates,i);
                    }
                }catch (Exception e){

                }
            }
        });
    }

    private void getFileDownload(String dates,int i) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(preferences.getString("city","")+"/WardLinesHouseJson/"+wards.get(i)+"/"+dates+".json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
            try {
                String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                File root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "WardJson/"+
                        preferences.getString("city","")+"/"+wards.get(i));
                if (!root.exists()) {
                    root.mkdirs();
                }
                File wardFile = new File(root, dates + ".json");
                FileWriter writer = new FileWriter(wardFile, true);
                writer.append(str);
                writer.flush();
                writer.close();
                if ((wards.size()-1)<=i) {
                    moveToMapActivity();
                }else {
                    downloadWardJson(i+1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void moveToMapActivity() {
        common.closeDialog(activity);
        Intent i;
        if (!isSwipe) {
            i = new Intent(activity, WorkProgressMap.class);
        }else {
            i = new Intent(activity, Swipe.class);
        }
        i.putExtra("otherDetails", new Gson().toJson(otherDetails));
        i.putExtra("userModel", new Gson().toJson(userModel));
        activity.startActivity(i);
        isMoved=true;
    }

    public void onContinueClick(){
        checkResponse();
        isSwipe = false;
    }

    private void checkResponse() {
        if (isMoved) {
            isMoved=false;
            String pathString=ward,message = "Navigator application";
            if (ward.contains("BinLifting")){
                pathString = "BinLifting/"+vehicleName.get();
                message = "DustbinRouting application";
            }
            common.setProgressDialog("", message + " offline तो नहीं है चेक कर रहे है |...", activity, activity);
            common.checkResponse(activity,pathString,message,userModel.get(0).getName(),userModel.get(0).getId()).observe((LifecycleOwner) activity, response->{
                Log.e("response value 1",response+" value");
                if (response.equals("success")){
                    Log.e("path value", "Suceess");
                    downloadWardJson(0);
                }else {
                    Log.e("response value 2",response+"");
                    isMoved=true;
                }
            });
        }
    }

    public void onSkipClick(){
        checkResponse();
        isSwipe = true;
    }

    public void onBack() {
        activity.finish();
    }
}