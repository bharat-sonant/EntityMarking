package com.wevois.vcarebackoffice.VehicleManagement.Views;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.VehicleManagement.Adapter.AllDataRetrieveAdapter;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class NewVehicles extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinnerFilter;
    TextView backTV, vehicleName;
    private Boolean isButtonClick = true;
    private Boolean isBackClick = true;
    private Boolean isFirstTime = true;
    ImageView noDataFound;
    SharedPreferences pathSharedPreferences;
    RecyclerView recyclerView;
    CommonFunctions common = CommonFunctions.getInstance();
    AllDataRetrieveAdapter allDataRetrieveAdapter;
    ArrayList<User> actualList = new ArrayList<>();
    ArrayList<User> list = new ArrayList<>();
    ArrayList<String> oilTypeList = new ArrayList<>();
    String vName = "", dateString = "";
    Button button, dateFilter;
    DatabaseReference databaseReference;
    ValueEventListener valueEventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_vehicles);

        initMethod();
        setAction();
        getOilTypeData();
    }

    private void initMethod() {
        vehicleName = findViewById(R.id.vehiclesinfo);
        spinnerFilter = findViewById(R.id.spinnerFilter);

        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        vName = getIntent().getStringExtra("vehicleName");
        vehicleName.setText(vName);
        button = findViewById(R.id.button);
        backTV = findViewById(R.id.back);
        dateFilter = findViewById(R.id.dateFilter);
        recyclerView = findViewById(R.id.userlist);

        noDataFound = findViewById(R.id.noDataFound);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dateString = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
    }

    protected void setAction() {

        backTV.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });

        button.setOnClickListener(v -> {
            if (isButtonClick) {
                isButtonClick = false;
                Intent i = new Intent(NewVehicles.this, RegisterCustomer.class);
                i.putExtra("vehicleName", vName);
                startActivity(i);
            }
        });
    }

    public void getOilTypeData() {

        oilTypeList.add("All");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("oilTypeList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        oilTypeList.add(values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        setSpinner();
        downloadDataFromFirebase();
    }

    private void setSpinner() {
        spinnerFilter.setOnItemSelectedListener(this);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, oilTypeList) {
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(arrayAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (isFirstTime) {
            isFirstTime = false;
        } else {
            spinnerFilter(spinnerFilter.getSelectedItem().toString());
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void spinnerFilter(String text) {
        list = new ArrayList<>();
        if (text.equalsIgnoreCase("All")) {
            list = actualList;
            notifyList();
        } else {
            for (User oilTypeList : actualList) {
                String fullName = oilTypeList.getType();
                if (fullName.trim().equalsIgnoreCase(text.trim())) {
                    list.add(oilTypeList);
                }
            }
            notifyList();
        }
    }

    public void downloadDataFromFirebase() {
        common.setProgressDialog("Please Wait...", "Downloading Data...", this, this);
        databaseReference = common.getDatabasePath(this).child("OilEntry").child(vName);

        valueEventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                actualList.clear();
                notifyList();
                if (snapshot.getValue() != null) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        list.add(new User(dataSnapshot.child("createdBy").getValue().toString(),
                                dataSnapshot.child("createdDate").getValue().toString(),
                                dataSnapshot.child("oilFillDate").getValue().toString(),
                                dataSnapshot.child("oilType").getValue().toString()));
                    }
                    recyclerView.setVisibility(View.VISIBLE);
                    noDataFound.setVisibility(View.GONE);
                } else {
                    recyclerView.setVisibility(View.GONE);
                    noDataFound.setVisibility(View.VISIBLE);
                }
                actualList = list;
                spinnerFilter(spinnerFilter.getSelectedItem().toString());
                common.closeDialog(NewVehicles.this);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void notifyList() {
        allDataRetrieveAdapter = new AllDataRetrieveAdapter(NewVehicles.this, list);
        recyclerView.setAdapter(allDataRetrieveAdapter);
        allDataRetrieveAdapter.notifyDataSetChanged();
    }

    protected void onResume() {
        super.onResume();
        isButtonClick = true;
        isBackClick = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseReference.removeEventListener(valueEventListener);
    }
}
