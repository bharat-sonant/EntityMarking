package com.wevois.vcarebackoffice.VehicleManagement.Views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.VehicleManagement.Adapter.MainActivityHomeAdapter;

public class ActivityHome extends AppCompatActivity {
    private Boolean isActivityClick = true;
    private Boolean isBackPress = true;
    GridView gridView;
    TextView backPress;
    String[] wordPositionTv = {"Oil Tracking"};
    int[] positionIv = {R.drawable.ic_oil2};
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        common.setProgressDialog("", "Please Wait...", this, ActivityHome.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);

        initMethod();
        setAction();
    }

    private void initMethod() {
        backPress = findViewById(R.id.backPress);
        gridView = findViewById(R.id.gridView);
        MainActivityHomeAdapter adapter = new MainActivityHomeAdapter(ActivityHome.this, wordPositionTv, positionIv);

        common.closeDialog(ActivityHome.this);
        gridView.setAdapter(adapter);
    }

    private void setAction() {

        backPress.setOnClickListener(v -> {
            if (isBackPress) {
                isBackPress = false;
                onBackPressed();
            }
        });

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            if (position == 0) {

                if (isActivityClick) {
                    isActivityClick = false;
                    Intent i = new Intent(ActivityHome.this, TotalVehicles.class);
                    startActivity(i);
                }
            }
        });
    }

    protected void onResume() {
        super.onResume();
        isActivityClick = true;
        isBackPress = true;
    }
}
