package com.wevois.vcarebackoffice.Common;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.R;
import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import static android.content.Context.MODE_PRIVATE;

public class CommonFunctions {
    ProgressDialog dialog;
    AlertDialog.Builder builder;
    AlertDialog alertDialog;
    String TIME_SERVER = "ntp.xs4all.nl";
    public static final int LOCATION_REQUEST = 500;
    public String[] monthArray = {"Select Month", "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};
    DatabaseReference databaseRef;
    ChildEventListener valueEventListener;
    private SurfaceView surfaceView;
    SurfaceHolder.Callback surfaceViewCallBack;
    Camera.PictureCallback pictureCallback;
    static boolean isCameraClosed = true;
    AlertDialog captureDialog;
    private Camera mCamera;
    private static final int FOCUS_AREA_SIZE = 300;

    private static CommonFunctions single_instance = null;

    private CommonFunctions() {
    }

    public static CommonFunctions getInstance() {
        if (single_instance == null)
            single_instance = new CommonFunctions();
        return single_instance;
    }

    @SuppressLint("SimpleDateFormat")
    public String year() {
        return new SimpleDateFormat("yyyy").format(new Date());
    }

    @SuppressLint("SimpleDateFormat")
    public String monthName() {
        return new SimpleDateFormat("MMMM").format(new Date());
    }

    @SuppressLint("SimpleDateFormat")
    public String monthInNumber() {
        return new SimpleDateFormat("MM").format(new Date());
    }

    @SuppressLint("SimpleDateFormat")
    public String date() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }

    public boolean locationPermission(Activity context) {
        boolean st = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                context.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
                st = false;
            } else {
                st = true;
            }
        }
        return st;
    }

    public boolean internetIsConnected() {
        try {
            String command = "ping -c 1 google.com";
            return (Runtime.getRuntime().exec(command).waitFor() == 0);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean network(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnected() && internetIsConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public LiveData<String> getWardTotalLines(SharedPreferences sharedPreferences) {
        MutableLiveData<String> response = new MutableLiveData<>();
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(sharedPreferences.getString("city", "") + "/WardLinesHouseJson/wardSummary.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = sharedPreferences.getLong(sharedPreferences.getString("city", "") + "wardSummaryDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(sharedPreferences.getString("city", "") + "/WardLinesHouseJson/wardSummary.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        sharedPreferences.edit().putString(sharedPreferences.getString("city", "") + "wardSummary", str).apply();
                        sharedPreferences.edit().putLong(sharedPreferences.getString("city", "") + "wardSummaryDownloadTime", fileCreationTime).apply();
                        response.setValue("success");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                response.setValue("success");
            }
        });
        return response;
    }

    public DatabaseReference getDatabasePath(Context context) {
        DatabaseReference databaseReferencePath = FirebaseDatabase.getInstance(getSp(context).getString("pathRef", "")).getReference();
        return databaseReferencePath;
    }

    public String getDatabaseStorage(Context context) {
        String storagePath = getSp(context).getString("storagePathRef", "");
        return storagePath;
    }

    private SharedPreferences getSp(Context context) {
        SharedPreferences sp = context.getSharedPreferences("path", MODE_PRIVATE);
        return sp;
    }

    public void showAlertDialog(String title, String message, boolean check, Context context) {
        closeDialog((Activity) context);
        if (alertDialog != null) {
            try {
                alertDialog.dismiss();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        builder = new AlertDialog.Builder(context);
        builder.setCancelable(check);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("Ok", (dialog, which) -> dialog.dismiss());
        alertDialog = builder.create();
        alertDialog.cancel();
        alertDialog.show();
    }

    public void setProgressDialog(String title, String message, Context context, Activity activity) {
        closeDialog(activity);
        dialog = new ProgressDialog(context);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.create();
        dialog.setCancelable(false);
        dialog.setProgressStyle(dialog.STYLE_SPINNER);
        if (!dialog.isShowing() && !activity.isFinishing()) {
            try {
                dialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void closeDialog(Activity activity) {
        if (dialog != null) {
            if (dialog.isShowing() && !activity.isFinishing()) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public JSONObject getJsonData(String wardNo, SharedPreferences preferences) {
        JSONObject jsonObject = new JSONObject();
        try {
            JSONArray jsonArray = new JSONArray(preferences.getString(preferences.getString("city", "") + wardNo + "mapUpdateHistoryJson", ""));
            for (int i = jsonArray.length() - 1; i >= 0; i--) {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date date1 = format.parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                    Date date2 = format.parse(jsonArray.getString(i));
                    if (date1.after(date2)) {
                        try {
                            File fileWardPath = new File(Environment.getExternalStorageDirectory(), "WardJson/" +
                                    preferences.getString("city", "") + "/" + wardNo + "/" + String.valueOf(jsonArray.getString(i)) + ".json");
                            BufferedReader br = new BufferedReader(new FileReader(fileWardPath));
                            StringBuilder result = new StringBuilder();
                            String str;
                            while ((str = br.readLine()) != null) {
                                result.append(str);
                            }
                            jsonObject = new JSONObject(String.valueOf(result));
                        } catch (Exception ignored) {
                        }
                        break;
                    } else if (date1.equals(date2)) {
                        try {
                            File fileWardPath = new File(Environment.getExternalStorageDirectory(), "WardJson/" +
                                    preferences.getString("city", "") + "/" + wardNo + "/" + String.valueOf(jsonArray.getString(i)) + ".json");
                            BufferedReader br = new BufferedReader(new FileReader(fileWardPath));
                            StringBuilder result = new StringBuilder();
                            String str;
                            while ((str = br.readLine()) != null) {
                                result.append(str);
                            }
                            jsonObject = new JSONObject(String.valueOf(result));
                        } catch (Exception ignored) {
                        }
                        break;
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public void getCommonFileForMetaData(String path, String downloadKey, String key, Activity activity) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        String selectedCityForMetadata = getSp(activity).getString("city", "");
        storageReference.child(selectedCityForMetadata + path).getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = getSp(activity).getLong(downloadKey, 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(selectedCityForMetadata + path).getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        getSp(activity).edit().putString(key, str).apply();
                        getSp(activity).edit().putLong(downloadKey, fileCreationTime).apply();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }

    public void getCommonFileForMetaData1(String path, String downloadKey, String key, Activity activity) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(path).getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = getSp(activity).getLong(downloadKey, 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(path).getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        getSp(activity).edit().putString(key, str).apply();
                        getSp(activity).edit().putLong(downloadKey, fileCreationTime).apply();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }

    public void getSortedMarkWardList(Context context){

        Log.d("getDatabaseStorage",getDatabaseStorage(context));
        FirebaseStorage.getInstance().getReferenceFromUrl(getDatabaseStorage(context) + "/Defaults/SortedWardList.json").getBytes(10000000).addOnSuccessListener(storageMetadata -> {

            try {
                String wardListStr = new String(storageMetadata, StandardCharsets.UTF_8);
//                Log.e("sortedWardListStr",wardListStr);
                ArrayList<String> wardList = new ArrayList<>();
//                HashMap<String,String> wardList = new HashMap<>();
                JSONArray jsonArray = new JSONArray(String.valueOf(wardListStr));
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                            JSONObject obj = jsonArray.getJSONObject(i);
//                            Log.e("wardNo",obj.get("displayIndex")+" "+obj.get("wardNo"));
                            wardList.add(obj.toString());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                getSp(context).edit().putString("sortedWardList", wardList.toString()).commit();
            }catch (Exception e){
                e.printStackTrace();
            }

        }).addOnFailureListener(e -> {
            Log.e("sortedWardList","not found");
            getSp(context).edit().putString("sortedWardList", "").commit();
        });
    }
    public void wardName(Context context) {
        FirebaseStorage.getInstance().getReferenceFromUrl(getDatabaseStorage(context) + "/Defaults/AvailableWard.json").getBytes(10000000).addOnSuccessListener(storageMetadata -> {


            try {
                String wardListStr = new String(storageMetadata, StandardCharsets.UTF_8);
                ArrayList<String> wardList = new ArrayList<>();
                JSONArray jsonArray = new JSONArray(String.valueOf(wardListStr));
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                            wardList.add(jsonArray.get(i).toString());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                getSp(context).edit().putString("wardList", wardList.toString()).commit();
            }catch (Exception e){
                e.printStackTrace();
            }
//            File file;
//            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//
//                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "NavigatorApp/Defaults/AvailableWard.json");
//            }else {
//                file = new File(Environment.getExternalStorageDirectory(), "NavigatorApp/Defaults/AvailableWard.json");
//            }
//
//
//            long fileCreationTime = storageMetadata.getCreationTimeMillis();
//            long fileDownloadTime = getSp(context).getLong("availableWardDownloadTime", 0);
            /*if (fileDownloadTime == fileCreationTime && file.exists()) {
                try {
                    String str;
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    StringBuilder result = new StringBuilder();
                    while ((str = br.readLine()) != null) {
                        result.append(str);
                    }
                    ArrayList<String> wardList = new ArrayList<>();
                    JSONArray jsonArray = new JSONArray(String.valueOf(result));
                    for (int i = 0; i < jsonArray.length(); i++) {
                        try {
                            if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                                wardList.add(jsonArray.get(i).toString());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    getSp(context).edit().putString("wardList", wardList.toString()).commit();
                } catch (Exception ignored) {
                }
            } else {
                if (!file.exists()) {
                    file.mkdirs();
                }
//                file.delete();
                FirebaseStorage.getInstance().getReferenceFromUrl(getDatabaseStorage(context) + "/Defaults/AvailableWard.json").getFile(file).addOnSuccessListener(taskSnapshot -> {
                    try {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                        StringBuilder builder = new StringBuilder();
                        String str;
                        while ((str = reader.readLine()) != null) {
                            builder.append(str);
                        }
                        File root;
                        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                            root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "NavigatorApp/Defaults");
                        }else {
                            root = new File(Environment.getExternalStorageDirectory(), "NavigatorApp/Defaults");
                        }
                        if (!root.exists()) {
                            root.mkdirs();
                        }
                        File wardFile = new File(root, "AvailableWard.json");
                        FileWriter writer = new FileWriter(wardFile, true);
                        writer.append(builder.toString());
                        ArrayList<String> wardList = new ArrayList<>();
                        JSONArray jsonArray = new JSONArray(builder.toString());
                        for (int i = 0; i < jsonArray.length(); i++) {
                            try {
                                if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                                    wardList.add(jsonArray.get(i).toString());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        getSp(context).edit().putString("wardList", wardList.toString()).commit();
                        writer.flush();
                        writer.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    getSp(context).edit().putLong("availableWardDownloadTime", fileCreationTime).apply();
                }).addOnFailureListener(exception -> {
                });
            }*/
        }).addOnFailureListener(e -> {
        });

        FirebaseStorage.getInstance().getReferenceFromUrl(getDatabaseStorage(context) + "/Defaults/NonNavigationTask.json").getBytes(10000000).addOnSuccessListener(storageMetadata -> {

            try {
                String wardListStr = new String(storageMetadata, StandardCharsets.UTF_8);
                ArrayList<String> wardList = new ArrayList<>();
                JSONArray jsonArray = new JSONArray(String.valueOf(wardListStr));
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                            wardList.add(jsonArray.get(i).toString());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                getSp(context).edit().putString("nonNavigationTaskList", wardList.toString()).commit();
            }catch (Exception e){
                e.printStackTrace();
            }

            /*File file;
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q){
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "NavigatorApp/Defaults/NonNavigationTask.json");
            }else {
                file = new File(Environment.getExternalStorageDirectory(), "NavigatorApp/Defaults/NonNavigationTask.json");
            }

            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = getSp(context).getLong("nonNavigationTaskDownloadTime", 0);
            if (fileDownloadTime == fileCreationTime && file.exists()) {
                try {
                    String str;
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    StringBuilder result = new StringBuilder();
                    while ((str = br.readLine()) != null) {
                        result.append(str);
                    }
                    ArrayList<String> wardList = new ArrayList<>();
                    JSONArray jsonArray = new JSONArray(String.valueOf(result));
                    for (int i = 0; i < jsonArray.length(); i++) {
                        try {
                            if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                                wardList.add(jsonArray.get(i).toString());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    getSp(context).edit().putString("nonNavigationTaskList", wardList.toString()).commit();
                } catch (Exception ignored) {
                }
            } else {
                if (!file.exists()) {
                    file.mkdirs();
                }
//                file.delete();
                FirebaseStorage.getInstance().getReferenceFromUrl(getDatabaseStorage(context) + "/Defaults/NonNavigationTask.json").getFile(file).addOnSuccessListener(taskSnapshot -> {
                    try {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                        StringBuilder builder = new StringBuilder();
                        String str;
                        while ((str = reader.readLine()) != null) {
                            builder.append(str);
                        }
                        File root;
                        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q){
                            root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "NavigatorApp/Defaults");
                        }else {
                            root = new File(Environment.getExternalStorageDirectory(), "NavigatorApp/Defaults");
                        }

                        if (!root.exists()) {
                            root.mkdirs();
                        }
                        File wardFile = new File(root, "NonNavigationTask.json");
                        FileWriter writer = new FileWriter(wardFile, true);
                        writer.append(builder.toString());
                        ArrayList<String> wardList = new ArrayList<>();
                        JSONArray jsonArray = new JSONArray(builder.toString());
                        for (int i = 0; i < jsonArray.length(); i++) {
                            try {
                                if (!jsonArray.get(i).toString().equalsIgnoreCase("null")) {
                                    wardList.add(jsonArray.get(i).toString());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        getSp(context).edit().putString("nonNavigationTaskList", wardList.toString()).commit();
                        writer.flush();
                        writer.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    getSp(context).edit().putLong("nonNavigationTaskDownloadTime", fileCreationTime).apply();
                }).addOnFailureListener(exception -> {
                });
            }*/
        }).addOnFailureListener(e -> {
        });
        try {
            FirebaseStorage.getInstance().getReference().child("Common/EmployeeCreationPermission.json").getMetadata()
                    .addOnSuccessListener(storageMetadata -> {
                        long fileCreationTime = storageMetadata.getCreationTimeMillis();
                        long fileDownloadTime = getSp(context).getLong("EmployeeCreationPermissionDownloadTime", 0);
                        if (fileDownloadTime != fileCreationTime) {
                            try {
                                FirebaseStorage.getInstance().getReference().child("Common/EmployeeCreationPermission.json")
                                        .getBytes(10000000)
                                        .addOnSuccessListener(taskSnapshot -> {
                                            String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                                            getSp(context).edit().putString("EmployeeCreationPermission", str.trim()).apply();
                                            getSp(context).edit().putLong("EmployeeCreationPermissionDownloadTime", fileCreationTime).apply();
                                        }).addOnFailureListener(exception -> {
                                        });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }).addOnFailureListener(e -> {
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }

        JSONObject jsonObject;
        try {
            JSONObject jsonKmlBoundary = new JSONObject();
            jsonObject = new JSONObject(getSp(context).getString("kmlBoundaryList", ""));
            Iterator<String> iter = jsonObject.keys();
            while (iter.hasNext()) {
                String key = iter.next();
                try {
                    Object values = jsonObject.get(key);
                    jsonKmlBoundary.put(key, values);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getKmlFilePath(String wardNo, Context context) {
        String kmlFilepath = "";
        JSONObject jsonObject;
        try {
            Log.e("kml boundary list"," list "+getSp(context).getString("kmlBoundaryList", ""));
            jsonObject = new JSONObject(String.valueOf(getSp(context).getString("kmlBoundaryList", "")));
            Log.e("ward no",wardNo+"");
            kmlFilepath = jsonObject.getString(wardNo);
            Log.e("kml path",kmlFilepath);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("kml error",e.getMessage());
        }
        return kmlFilepath;
    }

    public void getIncentive(Context context) {
        getDatabasePath(context).child("Settings/Salary").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("driver_salary_per_hour")) {
                        String driverSal = Objects.requireNonNull(dataSnapshot.child("driver_salary_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("driverSalaryPerHour", Long.parseLong(driverSal)).commit();
                    }
                    if (dataSnapshot.hasChild("helper_salary_per_hour")) {
                        String helperSal = Objects.requireNonNull(dataSnapshot.child("helper_salary_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("helperSalaryPerHour", Long.parseLong(helperSal)).commit();
                    }
                    if (dataSnapshot.hasChild("driver_incentive_per_hour")) {
                        String driverIncentive = Objects.requireNonNull(dataSnapshot.child("driver_incentive_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("driverIncPerHour", Long.parseLong(driverIncentive)).commit();
                    }
                    if (dataSnapshot.hasChild("helper_incentive_per_hour")) {
                        String helperIncentive = Objects.requireNonNull(dataSnapshot.child("helper_incentive_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("helperIncPerHour", Long.parseLong(helperIncentive)).commit();
                    }
                    if (dataSnapshot.hasChild("tractor_driver_salary")) {
                        String tractorDriver = Objects.requireNonNull(dataSnapshot.child("tractor_driver_salary").getValue()).toString();
                        getSp(context).edit().putLong("tractorDriverSalary", Long.parseLong(tractorDriver)).commit();
                    }
                    if (dataSnapshot.hasChild("basic_minimum_hour")) {
                        String basic_minimum_hour = Objects.requireNonNull(dataSnapshot.child("basic_minimum_hour").getValue()).toString();
                        getSp(context).edit().putInt("basicMinimumHour", Integer.parseInt(basic_minimum_hour)).commit();
                    }
                    if (dataSnapshot.hasChild("compactor_driver_incentive_per_hour")) {
                        String compactor_driver_incentive_per_hour = Objects.requireNonNull(dataSnapshot.child("compactor_driver_incentive_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("compactorDriverIncentivePerHour", Integer.parseInt(compactor_driver_incentive_per_hour)).commit();
                    }
                    if (dataSnapshot.hasChild("compactor_basic_hour")) {
                        String compactor_basic_hour = Objects.requireNonNull(dataSnapshot.child("compactor_basic_hour").getValue()).toString();
                        getSp(context).edit().putInt("compactorBasicMinimumHour", Integer.parseInt(compactor_basic_hour)).commit();
                    }
                    if (dataSnapshot.hasChild("compactor_driver_salary_per_hour")) {
                        String compactor_driver_salary_per_hour = Objects.requireNonNull(dataSnapshot.child("compactor_driver_salary_per_hour").getValue()).toString();
                        getSp(context).edit().putLong("compactorDriverSalaryPerHour", Integer.parseInt(compactor_driver_salary_per_hour)).commit();
                    }
                    if (dataSnapshot.hasChild("tractor_reward_amount")) {
                        String tractor_reward_amount = Objects.requireNonNull(dataSnapshot.child("tractor_reward_amount").getValue()).toString();
                        getSp(context).edit().putInt("tractorRewardAmount", Integer.parseInt(tractor_reward_amount)).commit();
                    }
                    if (dataSnapshot.hasChild("tractor_reward_days")) {
                        String tractor_reward_days = Objects.requireNonNull(dataSnapshot.child("tractor_reward_days").getValue()).toString();
                        getSp(context).edit().putInt("tractorRewardDays", Integer.parseInt(tractor_reward_days)).commit();
                    }
                    if (dataSnapshot.hasChild("driver_reward_amount")) {
                        String driver_reward_amount = Objects.requireNonNull(dataSnapshot.child("driver_reward_amount").getValue()).toString();
                        getSp(context).edit().putInt("driverRewardAmount", Integer.parseInt(driver_reward_amount)).commit();
                    }
                    if (dataSnapshot.hasChild("helper_reward_amount")) {
                        String helper_reward_amount = Objects.requireNonNull(dataSnapshot.child("helper_reward_amount").getValue()).toString();
                        getSp(context).edit().putInt("helperRewardAmount", Integer.parseInt(helper_reward_amount)).commit();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void getSettingsData(Context context) {
        getDatabasePath(context).child("Settings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("HaltSettings")) {
                        if (dataSnapshot.child("HaltSettings").hasChild("minimum-time-for-green")) {
                            getSp(context).edit().putInt("minimumTimeForGreen", Integer.parseInt(dataSnapshot.child("HaltSettings/minimum-time-for-green").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("HaltSettings").hasChild("minimum-time-for-orange")) {
                            getSp(context).edit().putInt("minimumTimeForOrange", Integer.parseInt(dataSnapshot.child("HaltSettings/minimum-time-for-orange").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("HaltSettings").hasChild("minimum-time-for-red")) {
                            getSp(context).edit().putInt("minimumTimeForRed", Integer.parseInt(dataSnapshot.child("HaltSettings/minimum-time-for-red").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("HaltSettings").hasChild("minimum-halt-show")) {
                            getSp(context).edit().putInt("minimumHaltShow", Integer.parseInt(dataSnapshot.child("HaltSettings/minimum-halt-show").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("HaltSettings").hasChild("mobile-off-halt-allowed-in-minutes")) {
                            getSp(context).edit().putInt("mobileOffHaltAllowed", Integer.parseInt(dataSnapshot.child("HaltSettings/mobile-off-halt-allowed-in-minutes").getValue().toString())).apply();
                        }
                    }
                    if (dataSnapshot.hasChild("AttendanceSettings")) {
                        if (dataSnapshot.child("AttendanceSettings").hasChild("assignment-review-wait-time")) {
                            getSp(context).edit().putInt("assignmentReviewWaitTime", Integer.parseInt(dataSnapshot.child("AttendanceSettings/assignment-review-wait-time").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("AttendanceSettings").hasChild("halt-review-wait-time")) {
                            getSp(context).edit().putInt("haltReviewWaitTime", Integer.parseInt(dataSnapshot.child("AttendanceSettings/halt-review-wait-time").getValue().toString())).apply();
                        }
                    }
                    if (dataSnapshot.hasChild("BackOfficeApplicationSettings")) {
                        if (dataSnapshot.child("BackOfficeApplicationSettings").hasChild("assignmentWarningMessage")) {
                            getSp(context).edit().putString("assignmentWarningMessage", dataSnapshot.child("BackOfficeApplicationSettings/assignmentWarningMessage").getValue().toString()).apply();
                        }
                        if (dataSnapshot.child("BackOfficeApplicationSettings").hasChild("maximumDayToEditPenalty")) {
                            getSp(context).edit().putInt("maximumDayToEditPenalty", Integer.parseInt(dataSnapshot.child("BackOfficeApplicationSettings/maximumDayToEditPenalty").getValue().toString())).apply();
                        }
                        if (dataSnapshot.child("BackOfficeApplicationSettings").hasChild("logBookNote")) {
                            getSp(context).edit().putString("logBookNote", dataSnapshot.child("BackOfficeApplicationSettings/logBookNote").getValue().toString()).apply();
                        }
                    }
                    if (dataSnapshot.hasChild("NavigatorApplicationSettings/salaryApprovedMaximumDay")) {
                        getSp(context).edit().putInt("salaryApprovedMaximumDay", Integer.parseInt(dataSnapshot.child("NavigatorApplicationSettings/salaryApprovedMaximumDay").getValue().toString())).apply();
                    }
                    if (dataSnapshot.hasChild("WasteCollectionVehicleCapacity")) {
                        JSONObject vehicleWasteWeight = new JSONObject();
                        for (DataSnapshot snapshot : dataSnapshot.child("WasteCollectionVehicleCapacity").getChildren()) {
                            try {
                                vehicleWasteWeight.put(snapshot.getKey(), snapshot.getValue().toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        getSp(context).edit().putString("vehicleWasteWeight", vehicleWasteWeight.toString()).apply();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        JSONObject jsonHousesType = new JSONObject();
        try {
            JSONArray jsonArray = new JSONArray(getSp(context).getString("removeReasonList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        jsonHousesType.put(String.valueOf(i), values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int formatDate(String pre, String current) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        int totalHours = 0;
        try {
            Date date1 = simpleDateFormat.parse(pre);
            Date date2 = simpleDateFormat.parse(current);
            totalHours = TimeDifference(date1, date2);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return totalHours;
    }

    public Long timeDiff(SimpleDateFormat simpleDateFormat, String pre, String current) {
        long difference = 0;
        Date date1;
        try {
            date1 = simpleDateFormat.parse(pre);
            Date date2 = simpleDateFormat.parse(current);
            difference += date2.getTime() - date1.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return difference;
    }

    public int TimeDifference(Date startDate, Date endDate) {
        long different = endDate.getTime() - startDate.getTime();
        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long elapsedMinutes = different / minutesInMilli;
        return (int) elapsedMinutes;
    }

    public String getCurrentMapReference(String ward, String date, String wardSummary) {
        String response = "";
        try {
            JSONObject jsonObject = new JSONObject(wardSummary);
            if (jsonObject.has(ward)) {
                JSONObject jsonObject1 = jsonObject.getJSONObject(ward);
                long previous = -1;
                Iterator<?> keys = jsonObject1.keys();
                while (keys.hasNext()) {
                    String key = (String) keys.next();
                    SimpleDateFormat dates = new SimpleDateFormat("yyyy-MM-dd");
                    long difference = -1;
                    try {
                        difference = dates.parse(date).getTime() - dates.parse(key).getTime();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (difference / (24 * 60 * 60 * 1000) >= 0) {
                        if (previous == -1) {
                            previous = difference / (24 * 60 * 60 * 1000);
                        }

                        if (difference / (24 * 60 * 60 * 1000) <= previous) {
                            response = key;
                        }
                    }
                    Log.d("TAG", "getCurrentMapReference: check " + response + "   " + difference / (24 * 60 * 60 * 1000));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getAddress(Geocoder geocoder, double lat, double lng) {
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(lat, lng, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses != null && !addresses.isEmpty()) {
            return addresses.get(0).getAddressLine(0);
        } else {
            return "Not Found";
        }
    }
    public String encrypt(String password, String userName) throws Exception {
        SecretKeySpec key = generateKey(userName);
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(password.getBytes());
        String encryptedValue = Base64.encodeToString(encVal, Base64.DEFAULT);
        return encryptedValue;
    }

    private SecretKeySpec generateKey(String userName) throws Exception {
        final MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = userName.getBytes("UTF-8");
        digest.update(bytes, 0, bytes.length);
        byte[] key = digest.digest();
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
        return secretKeySpec;
    }

    public String decrypt(String password, String encKey) throws Exception {
        SecretKeySpec key = generateKey(encKey);
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.DECRYPT_MODE, key);
        byte[] decodeValue = Base64.decode(password, Base64.DEFAULT);
        byte[] decVal = c.doFinal(decodeValue);
        return new String(decVal);
    }

    public void getEmployeeList(Context context) {
        getDatabasePath(context).child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    StringBuilder sb = new StringBuilder();
                    StringBuilder sbForInactiveUser = new StringBuilder();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.hasChild("GeneralDetails")) {
                            if (snapshot.child("GeneralDetails").child("status").getValue().toString().equals("1")) {
                                if (!snapshot.child("GeneralDetails").child("designationId").getValue().toString().equals("5") &&
                                        !snapshot.child("GeneralDetails").child("designationId").getValue().toString().equals("6")) {
                                    sb.append(String.valueOf(snapshot.child("GeneralDetails").child("userName").getValue()) + ":" +
                                            snapshot.child("GeneralDetails").child("name").getValue().toString().toUpperCase() + "~");

                                }
                            } else {
                                if (!snapshot.child("GeneralDetails").child("designationId").getValue().toString().equals("5") &&
                                        !snapshot.child("GeneralDetails").child("designationId").getValue().toString().equals("6")) {
                                    sbForInactiveUser.append(String.valueOf(snapshot.child("GeneralDetails").child("userName").getValue()) + ":" +
                                            snapshot.child("GeneralDetails").child("name").getValue().toString().toUpperCase() + "~");

                                }
                            }
                        }
                    }
                    if (sb.length() > 2) {
                        sb.deleteCharAt(sb.length() - 1);
                    }
                    if (sbForInactiveUser.length() > 2) {
                        sbForInactiveUser.deleteCharAt(sbForInactiveUser.length() - 1);
                    }
                    getSp(context).edit().putString("employeeList", sb.toString()).commit();
                    getSp(context).edit().putString("inactiveEmployeeList", sbForInactiveUser.toString()).commit();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public int getMonthDays(String year, int months) {
        Calendar calendar = Calendar.getInstance();
        int date = 1;
        calendar.set(Integer.parseInt(year), months, date);
        int maxDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        System.out.println("Max Day: " + maxDay);
        return maxDay;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> openHaltDialog(Activity activity, boolean isSpinner) {
        MutableLiveData<String> response = new MutableLiveData<>();
        Dialog dialogs = new Dialog(activity);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.halt_reason_layout);
        TextView alertMessage = dialogs.findViewById(R.id.messageTv);
        Button cancel = dialogs.findViewById(R.id.cancelBtn);
        Button remove = dialogs.findViewById(R.id.removeTimeBtn);
        Spinner spinner = dialogs.findViewById(R.id.selectReason);
        if (isSpinner) {
            remove.setText("Remove Halt");
            List<String> reasonList = new ArrayList<>();
            reasonList.add("Select Halt Reason");
            try {
                JSONArray jsonArray = new JSONArray(getSp(activity).getString("removeReasonList", ""));
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        String values = jsonArray.getString(i);
                        if (!values.equalsIgnoreCase("null")) {
                            reasonList.add(values);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            spinner.setVisibility(View.VISIBLE);
            final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(activity, android.R.layout.simple_spinner_dropdown_item, reasonList) {
                @Override
                public boolean isEnabled(int position) {
                    return !(position == 0);
                }

                @Override
                public View getDropDownView(int position, View convertView, ViewGroup parent) {
                    View view = super.getDropDownView(position, convertView, parent);
                    TextView tv = (TextView) view;
                    tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                    return view;
                }
            };
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerArrayAdapter);
        } else {
            alertMessage.setVisibility(View.VISIBLE);
            remove.setText("Undo Halt");
        }
        cancel.setOnClickListener(v -> dialogs.dismiss());
        remove.setOnClickListener(v -> {
            if (isSpinner) {
                if (spinner.getSelectedItem().toString().equals("Select Halt Reason")) {
                    View selectedView = spinner.getSelectedView();
                    if (selectedView != null && selectedView instanceof TextView) {
                        spinner.requestFocus();
                        TextView selectedTextView = (TextView) selectedView;
                        selectedTextView.setError("error");
                        selectedTextView.setTextColor(Color.RED);
                        selectedTextView.setText("please select type");
                        spinner.performClick();
                    }
                } else {
                    response.setValue(spinner.getSelectedItem().toString());
                }
            } else {
                response.setValue("success");
            }
            dialogs.dismiss();
        });
        dialogs.create();
        dialogs.show();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> getRealTime() {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Long>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Long doInBackground(Void... p) {
                long returnTime = 0;

                NTPUDPClient timeClient = new NTPUDPClient();
                timeClient.setDefaultTimeout(1000);
                for (int retries = 7; retries >= 0; retries--) {
                    try {
                        InetAddress inetAddress = InetAddress.getByName(TIME_SERVER);
                        TimeInfo timeInfo = timeClient.getTime(inetAddress);
                        returnTime = timeInfo.getMessage().getTransmitTimeStamp().getTime();
                        return returnTime;
                    } catch (IOException e) {
                        Log.i("RTCTestActivity", "Unable to connect. Retries left: " + (retries - 1));
                    }
                }
                return returnTime;
            }

            @Override
            protected void onPostExecute(Long result) {
                if (result != 0) {
                    final Date date = new Date(result);
                    final Date dates = new Date(new Date().getTime());
                    int timeGap = TimeDifference(date, dates);
                    if (String.valueOf(timeGap).contains("-")) {
                        timeGap = Integer.parseInt(String.valueOf(timeGap).substring(1));
                    }
                    if (timeGap < 5) {
                        response.setValue("success");
                    } else {
                        response.setValue("fail");
                    }
                } else {
                    response.setValue("success");
                }
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> checkResponse(Activity activity, String path, String message, String driverName, String driverId) {
        MutableLiveData<String> response = new MutableLiveData<>();
        Log.e("path value", path+"");
        getDatabasePath(activity).child("CheckPoints/NavigatorOffline/Wards/" + path + "/isOnline").setValue(new SimpleDateFormat("HH:mm:ss").format(new Date()));
        CountDownTimer countDownTimer = new CountDownTimer(getSp(activity).getInt("checkNavigatorOfflineTimeInSecond", 20000), 1000) {
            @SuppressLint("SimpleDateFormat")
            public void onTick(long millisUntilFinished) {

            }

            @SuppressLint("SimpleDateFormat")
            public void onFinish() {
                response.setValue("fail");
                databaseRef.removeEventListener(valueEventListener);
                getDatabasePath(activity).child("CheckPoints/NavigatorOffline/OfflineCountEmployeeWise/" + driverId + "/totalOfflineFound").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int activeCount = 0;
                        if (dataSnapshot.getValue() != null) {
                            activeCount = Integer.parseInt(dataSnapshot.getValue().toString());
                        }
                        showAlertDialog("", message + " offline पायी  गई है. Duty off नहीं कर सक्ते | \n\nWarning : " + driverName + " ने " + message + " करके अब तक " + activeCount + " बार Duty Off करवायी है |", true, activity);
                        getDatabasePath(activity).child("CheckPoints/NavigatorOffline/OfflineCountEmployeeWise/" + driverId + "/totalOfflineFound").setValue("" + (activeCount + 1));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        }.start();
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... p) {
                databaseRef = getDatabasePath(activity).child("CheckPoints/NavigatorOffline/Wards/" + path);
                valueEventListener = databaseRef.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        Log.e("isOnline",dataSnapshot.toString());
                        if (dataSnapshot.getKey().equals("isOnline")) {
                            if (dataSnapshot.getValue().toString().equalsIgnoreCase("yes")) {
                                response.setValue("success");
                                Log.e("isResult",dataSnapshot.getValue().toString());
                                databaseRef.removeEventListener(valueEventListener);
                                if (countDownTimer != null) {
                                    countDownTimer.cancel();
                                }
                            }
                        }
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<Boolean> checkNetWork(Activity activity) {
        MutableLiveData<Boolean> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Boolean doInBackground(Void... p) {
                return network(activity);
            }

            @Override
            protected void onPostExecute(Boolean result) {
                response.setValue(result);
            }
        }.execute();
        return response;
    }

    private void focusOnTouch(MotionEvent event) {
        if (mCamera != null) {
            Camera.Parameters parameters = mCamera.getParameters();
            if (parameters.getMaxNumMeteringAreas() > 0) {
                Rect rect = calculateFocusArea(event.getX(), event.getY());

                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
                meteringAreas.add(new Camera.Area(rect, 800));
                parameters.setFocusAreas(meteringAreas);

                mCamera.setParameters(parameters);
                mCamera.autoFocus(mAutoFocusTakePictureCallback);
            } else {
                mCamera.autoFocus(mAutoFocusTakePictureCallback);
            }
        }
    }

    private Camera.AutoFocusCallback mAutoFocusTakePictureCallback = (success, camera) -> {
        if (success) {
        } else {
        }
    };

    private Rect calculateFocusArea(float x, float y) {
        int left = clamp(Float.valueOf((x / surfaceView.getWidth()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        int top = clamp(Float.valueOf((y / surfaceView.getHeight()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);

        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private int clamp(int touchCoordinateInCameraReper, int focusAreaSize) {
        int result;
        if (Math.abs(touchCoordinateInCameraReper) + focusAreaSize / 2 > 1000) {
            if (touchCoordinateInCameraReper > 0) {
                result = 1000 - focusAreaSize / 2;
            } else {
                result = -1000 + focusAreaSize / 2;
            }
        } else {
            result = touchCoordinateInCameraReper - focusAreaSize / 2;
        }
        return result;
    }

    public static void setCameraDisplayOrientation(Activity activity, int cameraId, android.hardware.Camera camera) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = activity.getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;
        } else {
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    public Bitmap returnScaledBitmap(byte[] bytes) {
        Bitmap b = bytesTOBitmap(bytes);
        Matrix matrix = new Matrix();
        matrix.postRotate(90F);
        b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), matrix, true);
        return Bitmap.createScaledBitmap(b, 512,
                (int) (b.getHeight() * (512.0 / b.getWidth())), false);
    }

    public Bitmap bytesTOBitmap(byte[] bytes) {
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    }

    @SuppressLint({"StaticFieldLeak", "ClickableViewAccessibility"})
    public LiveData<Bitmap> captureDialog(Activity activity) {
        MutableLiveData<Bitmap> response = new MutableLiveData<>();
        try {
            closeDialog(activity);
            if (captureDialog != null) {
                captureDialog.dismiss();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        isCameraClosed = true;
        View dialogLayout = activity.getLayoutInflater().inflate(R.layout.custom_camera_alertbox, null);
        captureDialog = new AlertDialog.Builder(activity).setView(dialogLayout).setCancelable(false).create();
        surfaceView = (SurfaceView) dialogLayout.findViewById(R.id.surfaceViews);
        SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_HARDWARE);
        surfaceViewCallBack = new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    mCamera = Camera.open();
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
                Camera.Parameters parameters;
                parameters = mCamera.getParameters();
                List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
                parameters.setPictureSize(sizes.get(0).width, sizes.get(0).height);
                mCamera.setParameters(parameters);
                setCameraDisplayOrientation(activity, 0, mCamera);
                try {
                    mCamera.setPreviewDisplay(surfaceHolder);
                    mCamera.startPreview();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

            }
        };
        surfaceHolder.addCallback(surfaceViewCallBack);
        Button btn = dialogLayout.findViewById(R.id.capture_image_btn);
        btn.setOnClickListener(v -> {
            try {
                if (isCameraClosed) {
                    isCameraClosed = false;
                    setProgressDialog("", "Uploading...", activity, activity);
                    new AsyncTask<Void, Void, Boolean>() {

                        @Override
                        protected void onPreExecute() {
                            super.onPreExecute();
                        }


                        @Override
                        protected Boolean doInBackground(Void... p) {
                            mCamera.takePicture(null, null, null, pictureCallback);
                            return null;
                        }
                    }.execute();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        Button closeBtn = dialogLayout.findViewById(R.id.close_image_btn);
        captureDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        closeBtn.setOnClickListener(v -> {
            closeDialog(activity);
            response.setValue(null);
            try {
                if (captureDialog != null) {
                    captureDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        if (!activity.isFinishing()) {
            captureDialog.show();
        }

        pictureCallback = (bytes, camera) -> {
            Bitmap thumbnail = returnScaledBitmap(bytes);
            camera.stopPreview();
            if (camera != null) {
                camera.release();
                mCamera = null;
            }
            try {
                if (captureDialog != null) {
                    captureDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            closeDialog(activity);
            response.setValue(thumbnail);
        };

        surfaceView.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                focusOnTouch(motionEvent);
            }
            return false;
        });
        return response;
    }
}