package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class VersionMonitoringAdapter extends BaseAdapter {
    private Context context;

    ArrayList<VersionMonitoringModel> versionMonitoringList;
    public VersionMonitoringAdapter(Context context, ArrayList<VersionMonitoringModel> versionMonitoringList) {
        this.context = context;
        this.versionMonitoringList = versionMonitoringList;
    }

    @Override
    public int getCount() {
        return versionMonitoringList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.version_layout, null, true);

            holder.serialNoTv = (TextView) convertView.findViewById(R.id.sno);
            holder.deviceTv = (TextView) convertView.findViewById(R.id.deviceId);
            holder.versionTv = (TextView) convertView.findViewById(R.id.versionName);
            holder.statusIv = (ImageView) convertView.findViewById(R.id.status);


            convertView.setTag(holder);
        }else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (VersionMonitoringAdapter.ViewHolder)convertView.getTag();
        }
        VersionMonitoringModel sList = versionMonitoringList.get(position);
        holder.serialNoTv.setText(sList.getSerialno());
        holder.deviceTv.setText(sList.getDevice());
        holder.versionTv.setText(sList.getVersion());
        if (sList.getStatus().equals("1")){
            holder.statusIv.setImageResource(R.drawable.ic_close_black_24dp);
        }else {
            holder.statusIv.setImageResource(R.drawable.ic_check_black_24dp);
        }

        return convertView;
    }

    private class ViewHolder {
        private TextView deviceTv,versionTv,serialNoTv;
        private ImageView statusIv;
    }
}
