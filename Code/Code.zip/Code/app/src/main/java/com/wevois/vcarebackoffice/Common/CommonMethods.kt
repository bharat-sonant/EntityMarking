package com.wevois.vcarebackoffice.Common

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

    class CommonMethods {
        var builder: AlertDialog.Builder? = null
        var alertDialog: AlertDialog? = null

        fun showAlertDialog(title: String?, message: String?, check: Boolean, context: Context?):LiveData<String> {
            CommonFunctions.getInstance().closeDialog(context as Activity?)
            val response = MutableLiveData<String>()
            if (alertDialog != null) {
                alertDialog!!.dismiss()
            }
            builder = AlertDialog.Builder(context)
            builder!!.setCancelable(check)
            builder!!.setTitle(title)
            builder!!.setMessage(message)
            builder!!.setPositiveButton("Ok") { dialog: DialogInterface, which: Int ->
                run {
                    dialog.dismiss()
                    response.value = "success"
                }
            }
            alertDialog = builder!!.create()
            alertDialog!!.cancel()
            alertDialog!!.show()
            return response
        }
    }