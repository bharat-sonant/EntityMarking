package com.wevois.vcarebackoffice.employeeattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class EmployeeAssignmentActivity extends AppCompatActivity {

    SharedPreferences preferences;
    DatabaseReference databaseReferencePath;
    DataSnapshot employeeSnapShot = null;
    Spinner selectVehicle;
    ArrayAdapter<String> vehicleNoAdapter;
    EditText driverID, driverDeviceId, helperId, helperDeviceId, helperOneId, helperTwoId, helperThreeId;
    TextView driverDeviceName, helperDeviceName,mainHelperTV;
    LinearLayout helperLayout, helperTwoLayout, helperThreeLayout,mainHelperLayout;
    String wardName = "",planName="",planId="",driver = "", driverDevice = "", helper = "", helperDevice = "", helperOne = "",helperOneDevice="", helperTwo = "",helperTwoDevice="", helperThree = "",helperThreeDevice="";
    int showHelperLayoutCount = 0;
    ArrayList<String> vehicleNoList = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    boolean isMoved = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_assignment);
        initPage();
        getEmployeeDetails();
        getAvailableVehicles();
        setAction();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        TextView title = findViewById(R.id.toolbar_title);
        backButton.setOnClickListener(view -> onBackPressed());
        preferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReferencePath = common.getDatabasePath(this);
        driverID = findViewById(R.id.driverIdForAssignment);
        driverDeviceId = findViewById(R.id.driverDeviceIdForAssignment);
        driverDeviceName = findViewById(R.id.driverDeviceName);
        helperId = findViewById(R.id.helperIdForAssignment);
        helperDeviceId = findViewById(R.id.helperDeviceIdForAssignment);
        helperDeviceName = findViewById(R.id.helperDeviceName);
        helperOneId = findViewById(R.id.helperOneIdForAssignment);
        helperTwoId = findViewById(R.id.helperTwoIdForAssignment);
        helperThreeId = findViewById(R.id.helperThreeIdForAssignment);
        selectVehicle = findViewById(R.id.spinnerVehicleForAssignment);
        mainHelperLayout = findViewById(R.id.mainHelperLayout);
        mainHelperTV = findViewById(R.id.mainHelperTV);
        vehicleNoList.add("Select vehicle");
        vehicleNoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, vehicleNoList);
        selectVehicle.setAdapter(vehicleNoAdapter);
        driverDeviceName.setText(preferences.getString("city", "").substring(0, 3).toUpperCase());
        helperDeviceName.setText(preferences.getString("city", "").substring(0, 3).toUpperCase());
        if (getIntent().getStringExtra("ward").contains("Market") || getIntent().getStringExtra("ward").contains("mkt")) {
            wardName = getIntent().getStringExtra("ward");
            title.setText("" + wardName);
        } else if (getIntent().getStringExtra("ward").contains("BinLifting")){
            mainHelperLayout.setVisibility(View.GONE);
            mainHelperTV.setVisibility(View.VISIBLE);
            if (getIntent().hasExtra("planName")) {
                planName = getIntent().getStringExtra("planName");
                planId = getIntent().getStringExtra("planId");
                TextView planTV = findViewById(R.id.planForAssignment);
                planTV.setVisibility(View.VISIBLE);
                planTV.setText(planName);
            }
            wardName = "BinLifting";
            title.setText(wardName);
        } else {
            wardName = getIntent().getStringExtra("ward");
            title.setText("Ward " + wardName);
        }
        helperLayout = findViewById(R.id.helperLayout);
        helperTwoLayout = findViewById(R.id.helperTwoLayout);
        helperThreeLayout = findViewById(R.id.helperThreeLayout);
        TextView addHelperLayout = findViewById(R.id.addHelperForAssignment);
        TextView removeHelperLayout = findViewById(R.id.removeHelperForAssignment);
        addHelperLayout.setOnClickListener(view -> {
            if (showHelperLayoutCount == 0) {
                removeHelperLayout.setVisibility(View.VISIBLE);
                showHelperLayoutCount = showHelperLayoutCount + 1;
                helperLayout.setVisibility(View.VISIBLE);
            } else if (showHelperLayoutCount == 1) {
                showHelperLayoutCount = showHelperLayoutCount + 1;
                helperTwoLayout.setVisibility(View.VISIBLE);
            } else if (showHelperLayoutCount == 2) {
                showHelperLayoutCount = showHelperLayoutCount + 1;
                helperThreeLayout.setVisibility(View.VISIBLE);
            }
        });
        removeHelperLayout.setOnClickListener(view -> {
            if (showHelperLayoutCount == 1) {
                removeHelperLayout.setVisibility(View.GONE);
                showHelperLayoutCount = showHelperLayoutCount - 1;
                helperLayout.setVisibility(View.GONE);
            } else if (showHelperLayoutCount == 2) {
                showHelperLayoutCount = showHelperLayoutCount - 1;
                helperTwoLayout.setVisibility(View.GONE);
            } else if (showHelperLayoutCount == 3) {
                showHelperLayoutCount = showHelperLayoutCount - 1;
                helperThreeLayout.setVisibility(View.GONE);
            }
        });
    }

    private void setAction() {
        findViewById(R.id.btnContinueForAssignment).setOnClickListener(view -> {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Please wait...", this, this);
                if (selectVehicle.getSelectedItem().toString().equals("Select vehicle")) {
                    View selectedView = selectVehicle.getSelectedView();
                    if (selectedView != null && selectedView instanceof TextView) {
                        selectVehicle.requestFocus();
                        TextView selectedTextView = (TextView) selectedView;
                        selectedTextView.setError("error");
                        selectedTextView.setTextColor(Color.RED);
                        selectedTextView.setText("Please select vehicle");
                        selectVehicle.performClick();
                    }
                    common.closeDialog(EmployeeAssignmentActivity.this);
                    isMoved = true;
                }else {
                    String helperDeviceIdString = helperDeviceId.getText().toString();
                    if (planName.length()>0) {
                        helperDeviceIdString = "NotApplicable";
                    }
                    if (driverID.getText().toString().length() >= 1) {
                        if (checkEmployeeDetails(driverID.getText().toString(), 5, "Driver")) {
                            if (driverDeviceId.getText().toString().length() >= 1) {
                                if (helperId.getText().toString().length() >= 1) {
                                    if (checkEmployeeDetails(helperId.getText().toString(), 6, "Helper")) {
                                        if (helperDeviceIdString.length() >= 1) {
                                            if (helperLayout.getVisibility() == View.VISIBLE) {
                                                if (helperOneId.getText().toString().length() >= 1) {
                                                    if (checkEmployeeDetails(helperOneId.getText().toString(), 6, "Second helper")) {
                                                        if (helperTwoLayout.getVisibility() == View.VISIBLE) {
                                                            if (helperTwoId.getText().toString().length() >= 1) {
                                                                if (checkEmployeeDetails(helperTwoId.getText().toString(), 6, "Third helper")) {
                                                                    if (helperThreeLayout.getVisibility() == View.VISIBLE) {
                                                                        if (helperThreeId.getText().toString().length() >= 1) {
                                                                            if (checkEmployeeDetails(helperThreeId.getText().toString(), 6, "Fourth helper")) {
                                                                                driver = driverID.getText().toString();
                                                                                driverDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + driverDeviceId.getText().toString();
                                                                                helper = helperId.getText().toString();
                                                                                if (planName.length()>0) {
                                                                                    helperDevice = "NotApplicable";
                                                                                }else {
                                                                                    helperDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + helperDeviceId.getText().toString();
                                                                                }
                                                                                helperOne = helperOneId.getText().toString();
                                                                                helperOneDevice = "NotApplicable";
                                                                                helperTwo = helperTwoId.getText().toString();
                                                                                helperTwoDevice = "NotApplicable";
                                                                                helperThree = helperThreeId.getText().toString();
                                                                                helperThreeDevice = "NotApplicable";
                                                                                checkDetails(driver, driverDevice, "1", "Driver");
                                                                            }
                                                                        } else {
                                                                            isMoved = true;
                                                                            common.showAlertDialog("Wrong Assignment!", "कृपया चौथे Helper की ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                                                                        }
                                                                    } else {
                                                                        driver = driverID.getText().toString();
                                                                        driverDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + driverDeviceId.getText().toString();
                                                                        helper = helperId.getText().toString();
                                                                        if (planName.length()>0) {
                                                                            helperDevice = "NotApplicable";
                                                                        }else {
                                                                            helperDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + helperDeviceId.getText().toString();
                                                                        }
                                                                        helperOne = helperOneId.getText().toString();
                                                                        helperOneDevice = "NotApplicable";
                                                                        helperTwo = helperTwoId.getText().toString();
                                                                        helperTwoDevice = "NotApplicable";
                                                                        checkDetails(driver, driverDevice, "1", "Driver");
                                                                    }
                                                                }
                                                            } else {
                                                                isMoved = true;
                                                                common.showAlertDialog("Wrong Assignment!", "कृपया तीसरे Helper की ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                                                            }
                                                        } else {
                                                            driver = driverID.getText().toString();
                                                            driverDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + driverDeviceId.getText().toString();
                                                            helper = helperId.getText().toString();
                                                            if (planName.length()>0) {
                                                                helperDevice = "NotApplicable";
                                                            }else {
                                                                helperDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + helperDeviceId.getText().toString();
                                                            }
                                                            helperOne = helperOneId.getText().toString();
                                                            helperOneDevice = "NotApplicable";
                                                            checkDetails(driver, driverDevice, "1", "Driver");
                                                        }
                                                    }
                                                } else {
                                                    isMoved = true;
                                                    common.showAlertDialog("Wrong Assignment!", "कृपया दूसरे Helper की ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                                                }
                                            } else {
                                                driver = driverID.getText().toString();
                                                driverDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + driverDeviceId.getText().toString();
                                                helper = helperId.getText().toString();
                                                if (planName.length()>0) {
                                                    helperDevice = "NotApplicable";
                                                }else {
                                                    helperDevice = preferences.getString("city", "").substring(0, 3).toUpperCase() + "-" + helperDeviceId.getText().toString();
                                                }
                                                checkDetails(driver, driverDevice, "1", "Driver");
                                            }
                                        } else {
                                            isMoved = true;
                                            common.showAlertDialog("Wrong Assignment!", "कृपया Helper की Device ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                                        }
                                    }
                                } else {
                                    isMoved = true;
                                    common.showAlertDialog("Wrong Assignment!", "कृपया Helper की ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                                }
                            } else {
                                isMoved = true;
                                common.showAlertDialog("Wrong Assignment!", "कृपया Driver की Device ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                            }
                        }
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Wrong Assignment!", "कृपया Driver की ID दर्ज करे |", false, EmployeeAssignmentActivity.this);
                    }
                }
            }
        });
    }

    private boolean checkEmployeeDetails(String toString, int i, String message) {
        if (employeeSnapShot != null) {
            if (employeeSnapShot.getValue() != null) {
                if (employeeSnapShot.hasChild(toString + "/GeneralDetails/status")) {
                    if (employeeSnapShot.child(toString + "/GeneralDetails/status").getValue().toString().equalsIgnoreCase("1")) {
                        if (employeeSnapShot.hasChild(toString + "/GeneralDetails/designationId")) {
                            if (employeeSnapShot.child(toString + "/GeneralDetails/designationId").getValue().toString().equalsIgnoreCase("" + i)) {
                                return true;
                            } else {
                                isMoved = true;
                                if (i == 5) {
                                    common.showAlertDialog("Wrong Assignment!", message + " id गलत है | ", false, EmployeeAssignmentActivity.this);
                                } else {
                                    common.showAlertDialog("Wrong Assignment!", message + " id गलत है | ", false, EmployeeAssignmentActivity.this);
                                }
                                return false;
                            }
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Wrong Assignment!", message + " id गलत है | ", false, EmployeeAssignmentActivity.this);
                            return false;
                        }
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Wrong Assignment!", message + " id गलत है | ", false, EmployeeAssignmentActivity.this);
                        return false;
                    }
                } else {
                    isMoved = true;
                    common.showAlertDialog("Wrong Assignment!", message + " id गलत है | ", false, EmployeeAssignmentActivity.this);
                    return false;
                }
            } else {
                isMoved = true;
                common.showAlertDialog("Error!", " Database error.", false, EmployeeAssignmentActivity.this);
                return false;
            }
        } else {
            isMoved = true;
            common.showAlertDialog("Error!", "Database error.", false, EmployeeAssignmentActivity.this);
            return false;
        }
    }

    private void checkDetails(String id, String deviceId, String isDriver, String message) {
        databaseReferencePath.child("WorkAssignment/" + id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("current-assignment")) {
                        if (dataSnapshot.child("current-assignment").getValue().toString().equalsIgnoreCase("")) {
                            checkDeviceDetails(deviceId,isDriver,message);
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Wrong Assignment!", message + " को already "+dataSnapshot.child("current-assignment").getValue().toString()+" assign है |", false, EmployeeAssignmentActivity.this);
                        }
                    } else {
                        checkDeviceDetails(deviceId,isDriver,message);
                    }
                } else {
                    checkDeviceDetails(deviceId,isDriver,message);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkDeviceDetails(String deviceId, String isDriver, String message) {
        if (isDriver.equalsIgnoreCase("1") || isDriver.equalsIgnoreCase("2")) {
            if (planName.length()>0&&isDriver.equalsIgnoreCase("2")) {
                if (helperLayout.getVisibility() == View.VISIBLE) {
                    checkDetails(helperOne, helperOneDevice, "3", "Second helper");
                } else {
                    common.closeDialog(EmployeeAssignmentActivity.this);
                    moveActivity();
                }
            }else {
                databaseReferencePath.child("Devices/" + preferences.getString("city", "")).orderByChild("name").equalTo(deviceId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                if (snapshot.hasChild("status")&&snapshot.hasChild("appType")) {
                                    if (snapshot.child("status").getValue().toString().equalsIgnoreCase("1")) {
                                        if (isDriver.equalsIgnoreCase("1")) {
                                            if (planName.length() > 0){
                                                if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("3")) {
                                                    checkDetails(helper, helperDevice, "2", "Helper");
                                                }else {
                                                    isMoved = true;
                                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeAssignmentActivity.this);
                                                }
                                            }else {
                                                if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("1")) {
                                                    checkDetails(helper, helperDevice, "2", "Helper");
                                                } else {
                                                    isMoved = true;
                                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeAssignmentActivity.this);
                                                }
                                            }
                                        } else if (isDriver.equalsIgnoreCase("2")) {
                                            if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("2")) {
                                                if (helperLayout.getVisibility() == View.VISIBLE) {
                                                    checkDetails(helperOne, helperOneDevice, "3", "Second helper");
                                                } else {
                                                    common.closeDialog(EmployeeAssignmentActivity.this);
                                                    moveActivity();
                                                }
                                            }else {
                                                isMoved = true;
                                                common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeAssignmentActivity.this);
                                            }
                                        }
                                    } else {
                                        isMoved = true;
                                        common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeAssignmentActivity.this);
                                    }
                                } else {
                                    isMoved = true;
                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeAssignmentActivity.this);
                                }
                            }
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Error!", message + " device id गलत है |", false, EmployeeAssignmentActivity.this);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        } else {
            if (isDriver.equalsIgnoreCase("3")) {
                if (helperTwoLayout.getVisibility() == View.VISIBLE) {
                    checkDetails(helperTwo, helperTwoDevice, "4", "Third helper");
                } else {
                    common.closeDialog(EmployeeAssignmentActivity.this);
                    moveActivity();
                }
            } else if (isDriver.equalsIgnoreCase("4")) {
                if (helperThreeLayout.getVisibility() == View.VISIBLE) {
                    checkDetails(helperThree, helperThreeDevice, "5", "Fourth helper");
                } else {
                    common.closeDialog(EmployeeAssignmentActivity.this);
                    moveActivity();
                }
            } else {
                common.closeDialog(EmployeeAssignmentActivity.this);
                moveActivity();
            }
        }
    }

    private void moveActivity() {
        Intent i = new Intent(EmployeeAssignmentActivity.this, EmployeeReviewAssignment.class);
        i.putExtra("ward", wardName);
        i.putExtra("vehicle", selectVehicle.getSelectedItem().toString());
        i.putExtra("driver", driver);
        i.putExtra("driverDevice", driverDevice);
        i.putExtra("driverName", getEmployeeName(driver));
        i.putExtra("helper", helper);
        i.putExtra("helperDevice", helperDevice);
        i.putExtra("helperName", getEmployeeName(helper));
        if (helperLayout.getVisibility() == View.VISIBLE) {
            i.putExtra("helperOne", helperOne);
            i.putExtra("helperOneDevice", helperOneDevice);
            i.putExtra("helperOneName", getEmployeeName(helperOne));
        }
        if (helperTwoLayout.getVisibility() == View.VISIBLE) {
            i.putExtra("helperTwo", helperTwo);
            i.putExtra("helperTwoDevice", helperTwoDevice);
            i.putExtra("helperTwoName", getEmployeeName(helperTwo));
        }
        if (helperThreeLayout.getVisibility() == View.VISIBLE) {
            i.putExtra("helperThree", helperThree);
            i.putExtra("helperThreeDevice", helperThreeDevice);
            i.putExtra("helperThreeName", getEmployeeName(helperThree));
        }
        if (planName.length()>0) {
            i.putExtra("planName", planName);
            i.putExtra("planId", planId);
        }
        startActivity(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMoved = true;
    }

    private String getEmployeeName(String driver) {
        String name="";
        if (employeeSnapShot.hasChild(driver + "/GeneralDetails/name")){
            name = employeeSnapShot.child(driver + "/GeneralDetails/name").getValue().toString();
        }
        return name;
    }

    private void getEmployeeDetails() {
        databaseReferencePath.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    employeeSnapShot = dataSnapshot;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getAvailableVehicles() {
        databaseReferencePath.child("Vehicles").orderByChild("status").equalTo("1").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        vehicleNoList.add(snapshot.getKey());
                    }
                    vehicleNoAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}