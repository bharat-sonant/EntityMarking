package com.wevois.vcarebackoffice.Complaints;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.wevois.vcarebackoffice.AccessManagement.AccessManagementActivity;
import com.wevois.vcarebackoffice.Monitoring.MonitoringOptionsActivity;
import com.wevois.vcarebackoffice.Monitoring.ResetLineActivity;
import com.wevois.vcarebackoffice.Monitoring.VehicleMonitoring.VehicleMonitoringActivity;
import com.wevois.vcarebackoffice.Monitoring.VersionMonitoringActivity;
import com.wevois.vcarebackoffice.Monitoring.WardSelectActivity;
import com.wevois.vcarebackoffice.Monitoring.WorkMonitoringActivity;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.WorkMonitoringData;

public class ComplaintsPage extends AppCompatActivity {
    SharedPreferences sharedPrefLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_page);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sharedPrefLogin = getSharedPreferences("loginData", MODE_PRIVATE);
//        if (sharedPrefLogin.getBoolean("isSIAdmin", false)) {
//            findViewById(R.id.ComplaintLinearLayoutTwo).setVisibility(View.GONE);
//            findViewById(R.id.ComplaintsViewTwo).setVisibility(View.GONE);
//        }
        findViewById(R.id.ComplaintsSummaryBtn).setOnClickListener(v ->
                startActivity(new Intent(ComplaintsPage.this, ComplaintsSummaryActivity.class)));
        findViewById(R.id.ComplaintsResolutionBtn).setOnClickListener(v ->
                startActivity(new Intent(ComplaintsPage.this, ComplaintsResolutionActivity.class)));
        findViewById(R.id.ComplaintsApprovalBtn).setOnClickListener(v ->
                startActivity(new Intent(ComplaintsPage.this, ComplaintsApprovalActivity.class)));
        findViewById(R.id.ComplaintsRegisterBtn).setOnClickListener(v ->
                startActivity(new Intent(ComplaintsPage.this, ComplaintsRegisterActivity.class)));
    setPageTitle();
    }
    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Complaints Page");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            ComplaintsPage.super.onBackPressed();
        });
    }
}