package com.wevois.vcarebackoffice.Vehicle;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.R;

public class CompactorAssignment extends AppCompatActivity {
    Spinner selectLocation,selectCompactor;
    Button setLocation;
    DatabaseReference databaseReference;
    static String [] locations = {"Select Location","Beed","AmbedkarBhawan","OtherLocation"};
    static String [] compactors = {"Select Compactors","C1","C2","C3"};
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);

        if (getSupportActionBar()!=null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        selectLocation = findViewById(R.id.selectLocation);
        selectCompactor = findViewById(R.id.selectCompator);
        setLocation = findViewById(R.id.setLocation);
        ArrayAdapter<String> locationsAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked,locations);
        selectLocation.setAdapter(locationsAdapter);
        final ArrayAdapter<String> compactorAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_checked,compactors);
        selectCompactor.setAdapter(compactorAdapter);

        sharedPreferences = getSharedPreferences("path",MODE_PRIVATE);

        getPath();

        setLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(CompactorAssignment.this);
                builder.setCancelable(false);
                builder.setTitle("Alert!!!");
                builder.setMessage("लोकेशन  "+selectLocation.getSelectedItem().toString()+"\nकॉम्पेक्टर  "+
                        selectCompactor.getSelectedItem().toString()+
                        "\nआप इन चुनावों के साथ सहमत कर रहे हैं ?");
                builder.setPositiveButton("हाँ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String child = "Beed", value = "10";
                        if (selectLocation.getSelectedItem().toString().equals(locations[1])){
                            if (selectCompactor.getSelectedItem().toString().equals(compactors[1])){
                                child = "Beed";
                                value = "10";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[2])){
                                child = "Beed";
                                value = "15";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[3])){
                                child = "Beed";
                                value = "20";
                            }
                        }else if (selectLocation.getSelectedItem().toString().equals(locations[2])){
                            if (selectCompactor.getSelectedItem().toString().equals(compactors[1])){
                                child = "AmbedkarBhawan";
                                value = "10";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[2])){
                                child = "AmbedkarBhawan";
                                value = "15";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[3])){
                                child = "AmbedkarBhawan";
                                value = "20";
                            }
                        }else if (selectLocation.getSelectedItem().toString().equals(locations[3])){
                            if (selectCompactor.getSelectedItem().toString().equals(compactors[1])){
                                child = "DefaultLocation";
                                value = "10";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[2])){
                                child = "DefaultLocation";
                                value = "20";
                            }else if (selectCompactor.getSelectedItem().toString().equals(compactors[3])){
                                child = "DefaultLocation";
                                value = "20";
                            }
                        }


                        databaseReference.child("CompactorCapacity").child(child).setValue(value);
                        selectCompactor.setSelection(0);
                        selectLocation.setSelection(0);
                    }
                });
                builder.setNegativeButton("नहीं", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
    private void getPath() {
        String pathRef = sharedPreferences.getString("pathRef","");
        if (pathRef.length()>2){
            databaseReference = FirebaseDatabase.getInstance(pathRef).getReference();
        } else{
            databaseReference = FirebaseDatabase.getInstance().getReference();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        databaseReference.child("CompactorCapacity").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot: dataSnapshot.getChildren()) {
                    if (snapshot.getValue().toString().equals("0")) {
                        databaseReference.child("CompactorCapacity").child(""+snapshot.getKey()).removeValue();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}
