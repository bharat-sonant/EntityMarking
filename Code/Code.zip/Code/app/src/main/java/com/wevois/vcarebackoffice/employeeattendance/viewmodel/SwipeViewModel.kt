package com.wevois.vcarebackoffice.employeeattendance.viewmodel

import android.R
import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.wevois.vcarebackoffice.Common.CommonFunctions
import com.wevois.vcarebackoffice.Common.CommonMethods
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel
import com.wevois.vcarebackoffice.employeeattendance.repository.DutyOffKotlinRepository
import com.wevois.vcarebackoffice.employeeattendance.repository.SwipeRepository
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin
import java.text.SimpleDateFormat
import java.util.*

class SwipeViewModel(val activity: Activity, val spinner: Spinner) : ViewModel() {
    var common = CommonFunctions.getInstance()
    var preferences: SharedPreferences = activity.getSharedPreferences("path", Context.MODE_PRIVATE)
    var otherDetails: ArrayList<OtherDetails> = Gson().fromJson(activity.intent.getStringExtra("otherDetails"), object : TypeToken<ArrayList<OtherDetails?>?>() {}.type)
    private var userModels: ArrayList<ParentRecyclerviewModel> = Gson().fromJson(activity.intent.getStringExtra("userModel"), object : TypeToken<ArrayList<ParentRecyclerviewModel?>?>() {}.type)
    var wards: ArrayList<String> = otherDetails[0].wards
    var repository = DutyOffKotlinRepository()
    var repositorySwipe = SwipeRepository()
    var isMoved = true
    var outTime = ""
    var loginId = ""
    var currentMapReference = ""
    var workPercent = 0
    var wardList: ArrayList<String> = ArrayList()
    var nonNavigationList: ArrayList<String> = ArrayList()
    var offLineData: ArrayList<String>

    init {
        repository.getWorkPercentage(activity, common, otherDetails[0].wards[otherDetails[0].wards.size - 1])?.observe((activity as LifecycleOwner), { response: Int -> workPercent = response })
        offLineData = ArrayList()
        getNonNavigationTask()
    }

    private fun getNonNavigationTask() {
        val listAsStringNon = preferences.getString("nonNavigationTaskList", null)
        val nonNavigationString = listAsStringNon?.substring(1, listAsStringNon?.length - 1)?.split(",")?.toTypedArray()
        for (i in nonNavigationString!!.indices) {
            nonNavigationList.add(nonNavigationString[i].replace(" ", "").trim { it <= ' ' })
        }
        wardList.add("Select Ward")
        val listAsString = preferences.getString("wardList", null)
        val reasonString = listAsString?.substring(1, listAsString.length - 1)?.split(",")?.toTypedArray()
        for (i in reasonString!!.indices) {
            val reasonType = reasonString[i].replace(" ", "").trim { it <= ' ' }
            if (reasonType.equals("BinLifting", true) || nonNavigationList.contains(reasonType)) {
            } else {
                wardList.add(reasonType)
            }
        }
        bindWardToSpinner()
    }

    private fun bindWardToSpinner() {
        val spinnerArrayAdapter = ArrayAdapter(activity, R.layout.simple_spinner_item, wardList)
        spinnerArrayAdapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
        spinner!!.setAdapter(spinnerArrayAdapter)
    }

    fun onContinueClick() {
        if (isMoved) {
            isMoved = false
            if (spinner.selectedItem.toString() == "Select Ward") {
                val selectedView: View = spinner.getSelectedView()
                if (selectedView != null && selectedView is TextView) {
                    spinner.requestFocus()
                    val selectedTextView = selectedView
                    selectedTextView.error = "error"
                    selectedTextView.setTextColor(Color.RED)
                    selectedTextView.text = "please select ward"
                    spinner.performClick()
                }
                isMoved = true
            } else {
                common.setProgressDialog("", "Assignment चेक हो रहा है |", activity, activity)
                repositorySwipe.checkTask(activity, spinner.selectedItem.toString())?.observe((activity as LifecycleOwner)) { response: String ->
                    run {
                        if (response.equals("success", true)) {
                            saveLocalData()
                        } else {
                            isMoved = true
                            common.showAlertDialog("", "Ward available नहीं है |", false, activity)
                        }
                    }
                }
            }
        }
    }

    private fun saveLocalData() {
        common.setProgressDialog("Please wait...","Swiping...",activity,activity)
        loginId =
            activity.getSharedPreferences("loginData", Context.MODE_PRIVATE).getString("loginId", "101")
                .toString()
        repositorySwipe.getMapReference(activity, spinner.selectedItem.toString())?.observe((activity as LifecycleOwner)) { response: String ->
            run {
                if (!response.equals("fail", true)) {
                    currentMapReference = response
                }
                outTime = SimpleDateFormat("HH:mm:ss").format(Date())
                otherDetails[0].time = outTime
                otherDetails[0].newWard = spinner.selectedItem.toString()
                otherDetails[0].commonReference = currentMapReference
                offLineData.add("wasteCollectionInfoDutyOff")
                offLineData.add("wasteCollectionInfoDutyOnWorker")
                offLineData.add("wasteCollectionInfoDutyOnSummary")
                offLineData.add("empOff")
                offLineData.add("empOn")
                offLineData.add("vehicle")
                offLineData.add("realTimeDetailsOff")
                offLineData.add("realTimeDetailsOn")
                offLineData.add("taskDetailsOff")
                offLineData.add("taskDetailsOn")
                offLineData.add("whoAssignWork")
                offLineData.add("locationHistory")
                offLineData.add("TripWasteCollectionInfo")
                otherDetails[0].offlineSave = offLineData
                preferences.edit().putString("swipeUserDetails", Gson().toJson(userModels)).apply()
                preferences.edit().putString("swipeOtherDetails", Gson().toJson(otherDetails))
                    .apply()
                repository.sendWasteCollectionInfoDetailData(activity, common, wards, outTime)
                    ?.observe((activity as LifecycleOwner)) { response: String ->
                        removedLocal("wasteCollectionInfoDutyOff")
                    }
                repository.setWasteCollectionInfoDutyOnWorker(
                    activity,
                    common,
                    otherDetails,
                    userModels
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("wasteCollectionInfoDutyOnWorker")
                }
                repository.setWasteCollectionInfoDutyOnSummary(
                    activity,
                    common,
                    otherDetails,
                    userModels
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("wasteCollectionInfoDutyOnSummary")
                }
                repository.setEmployeeSkipDutyOff(
                    activity,
                    common,
                    userModels,
                    loginId,
                    outTime,
                    wards
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("empOff")
                }
                repository.setEmployeeDutyOn(
                    activity,
                    common,
                    otherDetails,
                    userModels,
                    loginId,
                    outTime
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("empOn")
                }
                repository.sendVehicleData(
                    activity,
                    common,
                    otherDetails,
                    userModels[0].id,
                    userModels[1].id,
                    otherDetails[0].newWard,
                    "3"
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("vehicle")
                }
                repository.sendRealTimeDetailData(
                    activity,
                    common,
                    otherDetails,
                    wards[wards.size - 1],
                    "no",
                    "completed",
                    "notActive"
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("realTimeDetailsOff")
                }
                repository.sendRealTimeDetailData(
                    activity,
                    common,
                    otherDetails,
                    otherDetails[0].newWard,
                    "yes",
                    "active",
                    "notActive"
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    removedLocal("realTimeDetailsOn")
                }
                repository.sendTaskDetailData(activity, common, wards[wards.size - 1], "Available")
                    ?.observe((activity as LifecycleOwner)) { response: String ->
                        removedLocal("taskDetailsOff")
                    }
                repository.sendTaskDetailData(activity, common, otherDetails[0].newWard, "Assigned")
                    ?.observe((activity as LifecycleOwner)) { response: String ->
                        removedLocal("taskDetailsOn")
                    }
                repository.saveWhoAssignWork(activity, common, otherDetails, "")
                    ?.observe((activity as LifecycleOwner)) {
                        removedLocal("whoAssignWork")
                    }
                repository.saveLocationHistory(
                    activity,
                    common,
                    otherDetails[0].newWard,
                    otherDetails[0].time
                )?.observe((activity as LifecycleOwner)) {
                    removedLocal("locationHistory")
                }
                repository.checkTripWasteCollectionInfoComplete(
                    activity,
                    common,
                    otherDetails,
                    preferences,
                    wards
                )?.observe((activity as LifecycleOwner)) { response: String ->
                    if (response == "success") {
                        offLineData.add("setTripWards")
                        offLineData.add("setTripRealTimeWardsDetails")
                        removedLocal("TripWasteCollectionInfo")
                        repository.setTripWards(activity, common, otherDetails, preferences)
                            ?.observe((activity as LifecycleOwner)) { response: String ->
                                removedLocal("setTripWards")
                            }
                        repository.setTripRealTimeWardsDetails(activity, common, wards)
                            ?.observe((activity as LifecycleOwner)) { response: String ->
                                removedLocal("setTripRealTimeWardsDetails")
                            }
                    } else {
                        removedLocal("TripWasteCollectionInfo")
                    }
                }
            }
        }
    }

    private fun removedLocal(removeData: String) {
        try {
            Log.d("TAG", "removedLocal: check "+offLineData)
            if (offLineData.contains(removeData)){
                offLineData.remove(removeData)
            }
            Log.d("TAG", "removedLocal: check A "+offLineData+"   "+offLineData.size)
            otherDetails[0].offlineSave = offLineData
            Log.d("TAG", "removedLocal: check B "+otherDetails)
            preferences.edit().putString("swipeUserDetails", Gson().toJson(userModels)).apply()
            preferences.edit().putString("swipeOtherDetails", Gson().toJson(otherDetails)).apply()
            if(offLineData.size==0)
                moveActivity()
        } catch (e: Exception) {
        }
    }

    private fun moveActivity() {
        common.closeDialog(activity)
        preferences.edit().putString("swipeUserDetails", "").apply()
        preferences.edit().putString("swipeOtherDetails", "").apply()
        CommonMethods().showAlertDialog("Info!!!","सफलतापूर्वक assignment हो चूका है |",false,activity).observe((activity as LifecycleOwner)) {
            val intent = Intent(activity, WardSelectKotlin::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            val options = ActivityOptions.makeSceneTransitionAnimation(activity).toBundle()
            activity.startActivity(intent, options)
            activity.finish()
        }
    }

    fun onBack() {
        activity.finish()
    }
}