package com.wevois.vcarebackoffice.employeeattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

public class NonNavigationDutyOffPage extends AppCompatActivity {
    SharedPreferences preferences,sharedPreferences;
    DatabaseReference databaseReferencePath;
    TextView empName, empId, empDeviceName,vehiclesTv,ward;
    String designationId = "", name = "", id = "", wardName = "",loginId,vehicle="";
    CommonFunctions common = CommonFunctions.getInstance();
    boolean isMoved = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_navigation_duty_off_page);
        initPage();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        loginId = sharedPreferences.getString("loginId", "101");
        preferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReferencePath = common.getDatabasePath(this);
        empName = findViewById(R.id.empNameNonNavigationDutyOffReviewPage);
        empId = findViewById(R.id.empIdNonNavigationDutyOffReviewPage);
        empDeviceName = findViewById(R.id.empDeviceNameNonNavigationDutyOffReviewPage);
        vehiclesTv = findViewById(R.id.vehicleForNonNavigationDutyOffReviewPage);
        ward = findViewById(R.id.wardForNonNavigationDutyOffReviewPage);
        wardName = getIntent().getStringExtra("ward");
        name = getIntent().getStringExtra("empName");
        id = getIntent().getStringExtra("empId");
        vehicle = getIntent().getStringExtra("vehicle");
        designationId = getIntent().getStringExtra("designationId");
        ward.setText(wardName);
        empName.setText(name);
        empId.setText(id);
        vehiclesTv.setText(vehicle);
        empDeviceName.setText("NotApplicable");
        findViewById(R.id.btnNonNavigationDutyOffReviewPage).setOnClickListener(view -> {
            if (isMoved){
                isMoved=false;
                Intent i = new Intent(NonNavigationDutyOffPage.this,NonNavigationSalaryPage.class);
                i.putExtra("ward",wardName);
                i.putExtra("empName", name);
                i.putExtra("empId", id);
                i.putExtra("vehicle", vehicle);
                i.putExtra("designationId", designationId);
                common.closeDialog(NonNavigationDutyOffPage.this);
                startActivity(i);
            }
        });
    }
}