package com.wevois.vcarebackoffice.EmployeeData;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AddItemsActivity extends AppCompatActivity implements ItemAdapter.buttonClickListener {

    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;
    ListView itemList;
    Button addMoreItemsBtn, addItemBtn;
    LinearLayout newItemLayout;
    TextInputEditText itemNameEt;
    ItemAdapter itemAdapter;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<String> nameList = new ArrayList<>();
    ArrayList<String> dateList = new ArrayList<>();
    String empId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        initPage();
        setDefault();
        setAction();
    }

    private void initPage() {
        itemList = findViewById(R.id.itemList);
        addMoreItemsBtn = findViewById(R.id.addMoreBtn);
        addItemBtn = findViewById(R.id.addItem);
        newItemLayout = findViewById(R.id.newItemLayout);
        itemNameEt = findViewById(R.id.itemName);
    }

    private void setDefault() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        empId = getIntent().getStringExtra("id");
        Log.d("TAG", "setDefault: ");
        itemAdapter = new ItemAdapter(this, nameList, dateList);
        itemAdapter.setOnClickListener(this);
        itemList.setAdapter(itemAdapter);
    }

    private void setAction() {
        addMoreItemsBtn.setOnClickListener(v -> {
            addMoreItemsBtn.setVisibility(View.GONE);
            newItemLayout.setVisibility(View.VISIBLE);
        });

        addItemBtn.setOnClickListener(v -> {
            String item = itemNameEt.getText().toString();
            if (item.length() > 1) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
                String today = simpleDateFormat.format(new Date());
                databaseReference.child("Inventory/" + empId + "/" + today).child(item).setValue("1");
                getIssuedItems();
                itemNameEt.getText().clear();
            } else {
                itemNameEt.setError("Enter item");
                itemNameEt.requestFocus();
                new CommonUtils(AddItemsActivity.this).showAlertDialog("Enter Item Name");
            }
        });
        getIssuedItems();
    }

    private void getIssuedItems() {
        common.setProgressDialog("Wait","Loading...",this,this);
        dateList.clear();
        nameList.clear();
        databaseReference.child("Inventory/" + empId).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null) {
                            Toast.makeText(AddItemsActivity.this, "No item issued", Toast.LENGTH_SHORT).show();
                            common.closeDialog(AddItemsActivity.this);
                            return;
                        }
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            for (DataSnapshot dataSnapshot2 : dataSnapshot1.getChildren()) {
                                if (dataSnapshot2.getValue() != null) {
                                    if (dataSnapshot2.getValue().equals("1")) {
                                        nameList.add(dataSnapshot2.getKey());
                                        dateList.add(dataSnapshot1.getKey());
                                    }
                                }
                            }
                        }
                        common.closeDialog(AddItemsActivity.this);
                        itemAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                }
        );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(AddItemsActivity.this, Employee.class));
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public void onMethodCallBack(int position) {
        databaseReference.child("Inventory/" + empId + "/" + dateList.get(position)).child(nameList.get(position)).setValue("2");
        nameList.remove(position);
        dateList.remove(position);
        itemAdapter.notifyDataSetChanged();
    }
}
