package com.wevois.vcarebackoffice.Login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Launcher;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.SelectCityActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class LoginSignUp extends AppCompatActivity {
    TextInputEditText userIdEt, passwordEt;
    SharedPreferences sharedPreferences;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences pathSharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sign_up);
        initPage();
        getSpecialUsers();
        findViewById(R.id.loginBtn).setOnClickListener(view -> doLogin());
    }

    public void getSpecialUsers() {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        String selectedCity = pathSharedPreferences.getString("city", "");
        storageReference.child(selectedCity + "/Settings/SpecialUsers.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("SpecialUserDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(selectedCity + "/Settings/SpecialUsers.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    String specialUsersData = new String(taskSnapshot, StandardCharsets.UTF_8);
                    pathSharedPreferences.edit().putString("SpecialUsersList", specialUsersData).apply();
                    pathSharedPreferences.edit().putLong("SpecialUserDownloadTime", fileCreationTime).apply();
                });
            }
        });
        storageReference.child(selectedCity + "/Settings/SpecialUsers.json").getMetadata().addOnFailureListener(e -> common.closeDialog(LoginSignUp.this));
    }

    private void doLogin() {
        try {
            Boolean isSpecialUser = false;
            common.setProgressDialog("Please Wait", " ", this, this);
            String userId = userIdEt.getText().toString().trim();
            String userPassword = passwordEt.getText().toString().trim();
            JSONObject specialUsersData = new JSONObject(pathSharedPreferences.getString("SpecialUsersList", ""));
            Iterator<String> specialUsersKeys = specialUsersData.keys();
            while (specialUsersKeys.hasNext()) {
                String key = specialUsersKeys.next();
                try {
                    if (key != "lastKey") {
                        JSONObject values = specialUsersData.getJSONObject(key);
                        String username = values.getString("username");
                        String password = values.getString("password");
                        if (username.equals(userId)) {
                            isSpecialUser = true;
                            if (password.equals(userPassword)) {
                                String type = String.valueOf(values.getString("type"));
                                switch (type) {
                                    case "SIAdmin":
                                        sharedPreferences.edit().putBoolean("isSIAdmin", true).apply();
                                        break;
                                    case "SuperAdmin": {
                                        sharedPreferences.edit().putBoolean("isSuperAdmin", true).apply();
                                        break;
                                    }
                                }
                                sharedPreferences.edit().putString("loginId", type).apply();
                                sharedPreferences.edit().putString("loginType", type).apply();
                                sharedPreferences.edit().putString("loggedInUsername", String.valueOf(values.getString("username"))).apply();
                                sharedPreferences.edit().putString("loggedInName", String.valueOf(values.getString("username"))).apply();
                                common.closeDialog(LoginSignUp.this);
                                startActivity(new Intent(LoginSignUp.this, Launcher.class));
                                finish();
                            } else {
                                common.closeDialog(LoginSignUp.this);
                                userIdEt.setError("Invalid user or password");
                                userIdEt.requestFocus();
                                break;
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            if(!isSpecialUser){
                if (userId.contains(".")) {
                    common.closeDialog(LoginSignUp.this);
                    userIdEt.setError("Invalid user or password");
                    userIdEt.requestFocus();
                } else {
                    String encyPassword = common.encrypt(userPassword, userId);
                    common.getDatabasePath(LoginSignUp.this).child("Employees").child(userId).child("GeneralDetails")
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild("status") && dataSnapshot.hasChild("password")) {
                                        if (dataSnapshot.child("status").getValue().equals("1") && dataSnapshot.child("password").getValue().equals(encyPassword)) {
                                            sharedPreferences.edit().putString("loginId", userId).apply();
                                            sharedPreferences.edit().putString("loginType", userId).apply();
                                            sharedPreferences.edit().putString("loggedInUsername", dataSnapshot.child("userName").getValue().toString()).apply();
                                            sharedPreferences.edit().putString("designationId", dataSnapshot.child("designationId").getValue().toString()).apply();
                                            sharedPreferences.edit().putString("loggedInName", dataSnapshot.child("name").getValue().toString()).apply();
                                            common.closeDialog(LoginSignUp.this);
                                            startActivity(new Intent(LoginSignUp.this, Launcher.class));
                                            finish();
                                        } else {
                                            common.closeDialog(LoginSignUp.this);
                                            userIdEt.setError("Invalid user or password");
                                            userIdEt.requestFocus();
                                        }
                                    } else {
                                        common.closeDialog(LoginSignUp.this);
                                        common.showAlertDialog("Alert", "You are not authorized to use", false, LoginSignUp.this);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initPage() {
        userIdEt = findViewById(R.id.userId);
        passwordEt = findViewById(R.id.password);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        sharedPreferences.edit().putBoolean("isAccountant", false).apply();
        sharedPreferences.edit().putBoolean("isSIAdmin", false).apply();
        sharedPreferences.edit().putBoolean("isSuperAdmin", false).apply();
        findViewById(R.id.toolbarback).setOnClickListener(view -> onBackPressed());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(LoginSignUp.this, SelectCityActivity.class));
        finish();
    }
}