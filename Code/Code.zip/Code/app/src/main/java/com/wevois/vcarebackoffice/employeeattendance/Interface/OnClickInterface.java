package com.wevois.vcarebackoffice.employeeattendance.Interface;

public interface OnClickInterface {
    void onItemClick(int position);
}
