package com.wevois.vcarebackoffice.AccessManagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Collections;

public class AccessManagementActivity extends AppCompatActivity {
    ArrayList<Model> list = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access_management);
        setPageTitle();
        mFetchAndShowData();
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Access Management");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            AccessManagementActivity.super.onBackPressed();
        });
    }

    private void mFetchAndShowData() {
        Adapter adapter = new Adapter();
        ListView listView = findViewById(R.id.permissions_emp_lv);
        listView.setAdapter(adapter);
        common.setProgressDialog("Please wait", "Fetching data...", this, this);
        String empData = getSharedPreferences("path", MODE_PRIVATE).getString("employeeList", "");
        list.clear();
        list.add(new Model("Account Admin", "AccountAdmin"));
        list.add(new Model("Admin", "Admin"));
        list.add(new Model("SI Admin", "SIAdmin"));
        list.add(new Model("Local Admin", "CityAdmin"));
        list.add(new Model("Support Team", "SupportTeam"));
        list.add(new Model("Human Resources", "HR"));
        for (String pair : empData.split("~")) {
            String[] userIdAndName = pair.split(":");
            list.add(new Model(userIdAndName[1], userIdAndName[0]));
        }
        Collections.sort(list, (obj1, obj2) -> obj1.empName.compareToIgnoreCase(obj2.empName));
        adapter.notifyDataSetChanged();
        common.closeDialog(AccessManagementActivity.this);
    }

    private class Adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.total_emp_lv_layout, null, true);
            Model model = list.get(i);
            TextView empName = view.findViewById(R.id.emp_name);
            String[] strArray = model.getEmpName().split(" ");
            StringBuilder builder = new StringBuilder();
            try {
                for (String s : strArray) {
                    String cap = s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
                    builder.append(cap + " ");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            empName.setText(builder.toString());
            view.findViewById(R.id.clickable).setOnClickListener(view1 -> {
                Intent intent = new Intent(AccessManagementActivity.this, AccessList.class);
                intent.putExtra("empName", builder.toString());
                intent.putExtra("empId", model.getEmpId());
                startActivity(intent);
            });
            return view;
        }
    }

    private class Model {
        private String empName;
        private String empId;

        public String getEmpName() {
            return empName;
        }

        public String getEmpId() {
            return empId;
        }

        public Model(String empName, String empId) {
            this.empName = empName;
            this.empId = empId;
        }

    }

}