package com.wevois.vcarebackoffice.employeeattendance.repository

import android.annotation.SuppressLint
import android.app.Activity
import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.tasks.Task
import com.google.firebase.database.*
import com.wevois.vcarebackoffice.Common.CommonFunctions
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class DutyOffKotlinRepository() {

    @SuppressLint("StaticFieldLeak")
    fun getWorkPercentage(activity: Activity?, common: CommonFunctions, ward: String): LiveData<Int>? {
        val response = MutableLiveData<Int>()
        common.getDatabasePath(activity).child("WasteCollectionInfo/" + ward + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary/workPercentage").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.value != null) {
                    response.setValue(dataSnapshot.value.toString().toInt())
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {}
        })
        return response
    }

    fun setEmployeeData(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, userModels: ArrayList<ParentRecyclerviewModel>, preferences: SharedPreferences, outTime: String, wards: ArrayList<String>, workPercent: Int): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            val userModel = userModels
            for (i in userModel.indices) {
                val workAssignmentData = HashMap<String, String>()
                workAssignmentData["current-assignment"] = ""
                workAssignmentData["device"] = ""
                workAssignmentData["vehicle"] = ""
                common.getDatabasePath(activity).child("WorkAssignment/" + userModel[i].id).setValue(workAssignmentData).addOnCompleteListener { task1: Task<Void?> ->
                    if (task1.isSuccessful) {
                        if (!userModel[i].device.equals("NotApplicable", ignoreCase = true)) {
                            common.getDatabasePath(activity).child("Devices/" + preferences.getString("city", "")).orderByChild("name").equalTo(userModel[i].device).addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                    if (dataSnapshot.value != null) {
                                        for (dataSnapshot1 in dataSnapshot.children) {
                                            val key = dataSnapshot1.key
                                            common.getDatabasePath(activity).child("Devices/" + preferences.getString("city", "")).child("$key/status").setValue("1")
                                        }
                                    }
                                }

                                override fun onCancelled(databaseError: DatabaseError) {}
                            })
                        }
                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id).addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                if (dataSnapshot.value != null) {
                                    var currentPosition = 0
                                    var isCover = true
                                    for (snapshot in dataSnapshot.children) {
                                        if (snapshot.key!!.contains("task")) {
                                            if (!snapshot.hasChild("task-wages")) {
                                                isCover = false
                                                val finalCurrentPosition1 = currentPosition
                                                val data = HashMap<String, Any>()
                                                data["status"] = "1"
                                                data["task-wages"] = userModel[i].taskSalary[finalCurrentPosition1]
                                                data["final-approved-time"] = otherDetails[0].approvedTime[finalCurrentPosition1]
                                                data["final-approved-time-in-minute"] = "" + otherDetails[0].approvedTime[finalCurrentPosition1] / 60000
                                                data["total-halt-time"] = otherDetails[0].totalHaltTime[finalCurrentPosition1]
                                                data["total-halt-time-in-minute"] = "" + otherDetails[0].totalHaltTime[finalCurrentPosition1] / 60000
                                                data["approved-halt-time"] = otherDetails[0].approvedHaltTime[finalCurrentPosition1]
                                                data["final-halt-after-remove-time-in-minute"] = "" + (otherDetails[0].approvedHaltTime[finalCurrentPosition1] / 60000).toInt()
                                                data["total-remove-halt-time-in-minute"] = "" + (otherDetails[0].totalHaltTime[finalCurrentPosition1] - otherDetails[0].approvedHaltTime[finalCurrentPosition1]).toInt() / 60000
                                                data["total-time-spent"] = otherDetails[0].totalTimes[finalCurrentPosition1]
                                                data["work-percent"] = workPercent
                                                data["vehicle"] = otherDetails[0].vehicle
                                                data["total-time-spent-in-minute"] = "" + java.lang.Long.valueOf(otherDetails[0].totalTimes[finalCurrentPosition1]) / 60000
                                                common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + "card-swap-entries/" + outTime).setValue("Out")
                                                common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + "today-wages").setValue(userModel[i].totalSalary)
                                                if (wards.size - 1 == finalCurrentPosition1) {
                                                    common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + snapshot.key + "/in-out/" + outTime).setValue("Out")
                                                }
                                                common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + snapshot.key).updateChildren(data).addOnCompleteListener { task: Task<Void?> ->
                                                    if (task.isSuccessful) {
                                                        if (wards.size - 1 == finalCurrentPosition1) {
                                                            if (i == userModel.size - 1) {
                                                                Log.d("TAG", "onDataChange: save all data $userModel")
                                                                response.value = "success"
                                                            }
                                                        }
                                                    }
                                                }
                                                currentPosition++
                                            }
                                        }
                                    }
                                    if (isCover) {
                                        if (i == userModel.size - 1) {
                                            response.value = "success"
                                        }
                                    }
                                }
                            }

                            override fun onCancelled(databaseError: DatabaseError) {}
                        })
                    } else {
                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, activity)
                    }
                }
            }
        }
        return response
    }

    fun realTimeCountDetails(activity: Activity, common: CommonFunctions, userModels: ArrayList<ParentRecyclerviewModel>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("RealTimeDetails/peopleOnWork").runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    if (currentData.value != null) {
                        try {
                            currentData.value = (currentData.value.toString().toInt() - userModels.size).toString()
                        } catch (e: Exception) {
                            currentData.value = 0
                        }
                    }
                    return Transaction.success(currentData)
                }

                override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                    if (error == null) {
                        response.value = "success"
                    }
                }
            })
        }
        return response
    }

    fun sendVehicleData(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, driver: String, helper: String, task: String, status: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        val vehicleData = HashMap<String, String>()
        vehicleData["assigned-driver"] = driver
        vehicleData["assigned-helper"] = helper
        vehicleData["assigned-task"] = task
        vehicleData["status"] = status
        GlobalScope.launch {
            common.getDatabasePath(activity).child("Vehicles/" + otherDetails[0].vehicle).setValue(vehicleData).addOnCompleteListener { task: Task<Void?> ->
                if (task.isSuccessful) {
                    response.value = "success"
                }
            }
        }
        return response
    }

    fun sendRealTimeDetailData(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, wards: String, isDutyOn: String, status: String, micStatus: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            var path = wards
            if (path.contains("BinLifting")) {
                path = "BinLifting/" + otherDetails[0].vehicle
            }
            val realTimeData = HashMap<String, Any>()
            realTimeData["isOnDuty"] = isDutyOn
            realTimeData["activityStatus"] = status
            realTimeData["micStatus"] = micStatus
            common.getDatabasePath(activity).child("RealTimeDetails/WardDetails/$path").updateChildren(realTimeData).addOnCompleteListener { task1: Task<Void?> ->
                if (task1.isSuccessful) {
                    response.value = "success"
                }
            }
        }
        return response
    }

    fun sendTaskDetailData(activity: Activity, common: CommonFunctions, ward: String, status: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("Tasks/" + ward).setValue(status).addOnCompleteListener { task2: Task<Void?> ->
                if (task2.isSuccessful) {
                    response.value = "success"
                }
            }
        }
        return response
    }

    fun sendWasteCollectionInfoDetailData(activity: Activity, common: CommonFunctions, wards: ArrayList<String>, outTime: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("WasteCollectionInfo/" + wards[wards.size - 1] + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary/dutyOutTime").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    var dutyInTime = ""
                    if (dataSnapshot.value != null) {
                        dutyInTime = dataSnapshot.value.toString() + ","
                    }
                    dutyInTime += outTime.substring(0, outTime.length - 3)
                    common.getDatabasePath(activity).child("WasteCollectionInfo/" + wards[wards.size - 1] + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary/dutyOutTime").setValue(dutyInTime).addOnCompleteListener { task32: Task<Void?> ->
                        if (task32.isSuccessful) {
                            response.value = "success"
                        }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun planFree(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("DustbinData/DustbinPickingPlans/" + common.date() + "/" + otherDetails[0].planId).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.value != null) {
                        val data = HashMap<String?, Any>()
                        for (snapshot1 in snapshot.children) {
                            if (snapshot1.key.equals("bins", ignoreCase = true)) {
                                val bins = snapshot1.value.toString().split(",").toTypedArray()
                                for (i in bins.indices) {
                                    common.getDatabasePath(activity).child("DustbinData/DustbinDetails/" + bins[i].trim { it <= ' ' } + "/isAssigned").setValue("false")
                                }
                            }
                            data[snapshot1.key] = snapshot1.value.toString()
                        }
                        data["doneDate"] = common.date()
                        common.getDatabasePath(activity).child("DustbinData/DustbinPickingPlanHistory/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + otherDetails[0].planId).setValue(data).addOnCompleteListener { task: Task<Void?> ->
                            if (task.isSuccessful) {
                                common.getDatabasePath(activity).child("DustbinData/DustbinPickingPlans/" + common.date() + "/" + otherDetails[0].planId).removeValue().addOnCompleteListener { task1: Task<Void?> ->
                                    if (task1.isSuccessful) {
                                        response.value = "success"
                                    }
                                }
                            }
                        }
                    } else {
                        response.value = "success"
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun checkTripWasteCollectionInfoComplete(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, preferences: SharedPreferences, wards: ArrayList<String>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("RealTimeDetails/WardDetails/" + wards[wards.size - 1] + "/isTripComplete").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value != null) {
                        if (dataSnapshot.value.toString().equals("no", ignoreCase = true)) {
                            common.getDatabasePath(activity).child("WasteCollectionInfo/" + wards[wards.size - 1] + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary").addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(snapshot5: DataSnapshot) {
                                    var i = 1
                                    var totalWasteCollection = 0
                                    try {
                                        val vehicles = otherDetails[0].vehicle.split("-").toTypedArray()
                                        val vehicleWasteWeightJsonObject = JSONObject(preferences.getString("vehicleWasteWeight", ""))
                                        if (vehicleWasteWeightJsonObject.has(vehicles[0])) {
                                            totalWasteCollection = vehicleWasteWeightJsonObject.getString(vehicles[0]).toInt()
                                        }
                                    } catch (e: JSONException) {
                                        e.printStackTrace()
                                    }
                                    if (snapshot5.hasChild("trip")) {
                                        i = snapshot5.child("trip").value.toString().toInt() + 1
                                    }
                                    if (snapshot5.hasChild("totalWardWasteCollection")) {
                                        totalWasteCollection = snapshot5.child("totalWardWasteCollection").value.toString().toInt() + totalWasteCollection
                                    }
                                    val data = HashMap<String, Any>()
                                    data["trip"] = "" + i
                                    data["totalWardWasteCollection"] = "" + totalWasteCollection
                                    common.getDatabasePath(activity).child("WasteCollectionInfo/" + wards[wards.size - 1] + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary").updateChildren(data).addOnCompleteListener { task: Task<Void?> ->
                                        if (task.isSuccessful) {
                                            response.value = "success"
                                        }
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {}
                            })
                        } else {
                            response.value = "success1"
                        }
                    } else {
                        response.value = "success1"
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun setTripWards(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, preferences: SharedPreferences): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("WardTrips/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/totalWasteCollection").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot5: DataSnapshot) {
                    var vehicleWaste = 0
                    try {
                        val vehicles = otherDetails[0].vehicle.split("-").toTypedArray()
                        val vehicleWasteWeightJsonObject = JSONObject(preferences.getString("vehicleWasteWeight", ""))
                        if (vehicleWasteWeightJsonObject.has(vehicles[0])) {
                            vehicleWaste = vehicleWasteWeightJsonObject.getString(vehicles[0]).toInt()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                    if (snapshot5.value != null) {
                        vehicleWaste = snapshot5.value.toString().toInt() + vehicleWaste
                    }
                    common.getDatabasePath(activity).child("WardTrips/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/totalWasteCollection").setValue("" + vehicleWaste).addOnCompleteListener { task: Task<Void?> ->
                        if (task.isSuccessful) {
                            response.value = "success"
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
        return response
    }

    fun setTripRealTimeWardsDetails(activity: Activity, common: CommonFunctions, wards: ArrayList<String>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("RealTimeDetails/WardDetails/" + wards[wards.size - 1] + "/isTripComplete").setValue("yes").addOnCompleteListener { task1: Task<Void?> ->
                if (task1.isSuccessful) {
                    response.value = "success"
                }
            }
        }
        return response
    }

    //

    fun setWasteCollectionInfoDutyOnWorker(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, userModels: ArrayList<ParentRecyclerviewModel>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("WasteCollectionInfo/" + otherDetails[0].newWard + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/WorkerDetails").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val wasteCollectionInfoData = HashMap<String, String>()
                    var driverIds: String = userModels[0].id
                    var driverNames: String = userModels[0].name
                    var helperIds: String = userModels[1].id
                    var helperNames: String = userModels[1].name
                    var vehicles: String = otherDetails[0].vehicle
                    var secondHelperIds = ""
                    var secondHelperNames = ""
                    var thirdHelperIds = ""
                    var thirdHelperNames = ""
                    var fourthHelperIds = ""
                    var fourthHelperNames = ""
                    if (userModels.size > 2) {
                        secondHelperIds = userModels[2].id
                        secondHelperNames = userModels[2].name
                    }
                    if (userModels.size > 3) {
                        thirdHelperIds = userModels[3].id
                        thirdHelperNames = userModels[3].name
                    }
                    if (userModels.size > 4) {
                        fourthHelperIds = userModels[4].id
                        fourthHelperNames = userModels[4].name
                    }

                    if (dataSnapshot.value != null) {
                        if (dataSnapshot.hasChild("driver")) {
                            driverIds = dataSnapshot.child("driver").value.toString() + "," + driverIds
                        }
                        if (dataSnapshot.hasChild("driverName")) {
                            driverNames = dataSnapshot.child("driverName").value.toString() + "," + driverNames
                        }
                        if (dataSnapshot.hasChild("helper")) {
                            helperIds = dataSnapshot.child("helper").value.toString() + "," + helperIds
                        }
                        if (dataSnapshot.hasChild("helperName")) {
                            helperNames = dataSnapshot.child("helperName").value.toString() + "," + helperNames
                        }
                        if (dataSnapshot.hasChild("vehicle")) {
                            vehicles = dataSnapshot.child("vehicle").value.toString() + "," + vehicles
                        }
                        if (dataSnapshot.hasChild("secondHelper")) {
                            secondHelperIds = if (secondHelperIds.equals("", ignoreCase = true)) {
                                dataSnapshot.child("secondHelper").value.toString()
                            } else {
                                dataSnapshot.child("secondHelper").value.toString() + "," + secondHelperIds
                            }
                        }
                        if (dataSnapshot.hasChild("thirdHelper")) {
                            thirdHelperIds = if (thirdHelperIds.equals("", ignoreCase = true)) {
                                dataSnapshot.child("thirdHelper").value.toString()
                            } else {
                                dataSnapshot.child("thirdHelper").value.toString() + "," + thirdHelperIds
                            }
                        }
                        if (dataSnapshot.hasChild("fourthHelper")) {
                            fourthHelperIds = if (fourthHelperIds.equals("", ignoreCase = true)) {
                                dataSnapshot.child("fourthHelper").value.toString()
                            } else {
                                dataSnapshot.child("fourthHelper").value.toString() + "," + fourthHelperIds
                            }
                        }
                        if (dataSnapshot.hasChild("secondHelperName")) {
                            secondHelperNames = if (secondHelperNames.equals("", ignoreCase = true)) {
                                dataSnapshot.child("secondHelperName").value.toString()
                            } else {
                                dataSnapshot.child("secondHelperName").value.toString() + "," + secondHelperNames
                            }
                        }
                        if (dataSnapshot.hasChild("thirdHelperName")) {
                            thirdHelperNames = if (thirdHelperNames.equals("", ignoreCase = true)) {
                                dataSnapshot.child("thirdHelperName").value.toString()
                            } else {
                                dataSnapshot.child("thirdHelperName").value.toString() + "," + thirdHelperNames
                            }
                        }
                        if (dataSnapshot.hasChild("fourthHelperName")) {
                            fourthHelperNames = if (fourthHelperNames.equals("", ignoreCase = true)) {
                                dataSnapshot.child("fourthHelperName").value.toString()
                            } else {
                                dataSnapshot.child("fourthHelperName").value.toString() + "," + fourthHelperNames
                            }
                        }
                    }
                    wasteCollectionInfoData["driver"] = driverIds
                    wasteCollectionInfoData["driverName"] = driverNames
                    wasteCollectionInfoData["helper"] = helperIds
                    wasteCollectionInfoData["helperName"] = helperNames
                    if (!secondHelperIds.equals("", ignoreCase = true)) {
                        wasteCollectionInfoData["secondHelper"] = secondHelperIds
                        wasteCollectionInfoData["secondHelperName"] = secondHelperNames
                    }
                    if (!thirdHelperIds.equals("", ignoreCase = true)) {
                        wasteCollectionInfoData["thirdHelper"] = thirdHelperIds
                        wasteCollectionInfoData["thirdHelperName"] = thirdHelperNames
                    }
                    if (!fourthHelperIds.equals("", ignoreCase = true)) {
                        wasteCollectionInfoData["fourthHelper"] = fourthHelperIds
                        wasteCollectionInfoData["fourthHelperName"] = fourthHelperNames
                    }
                    wasteCollectionInfoData["vehicle"] = vehicles
                    common.getDatabasePath(activity).child("WasteCollectionInfo/" + otherDetails[0].newWard + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/WorkerDetails").setValue(wasteCollectionInfoData).addOnCompleteListener { task: Task<Void?> ->
                        if (task.isSuccessful) {
                            response.value = "success"
                        }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun setWasteCollectionInfoDutyOnSummary(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, userModels: ArrayList<ParentRecyclerviewModel>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("WasteCollectionInfo/" + otherDetails[0].newWard + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary/dutyInTime").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    var dutyInTime = ""
                    if (dataSnapshot.value != null) {
                        dutyInTime = dataSnapshot.value.toString() + ","
                    }
                    dutyInTime = dutyInTime + otherDetails[0].time.substring(0, otherDetails[0].time.length - 3)
                    val wasteData = HashMap<String, Any>()
                    wasteData["dutyInTime"] = dutyInTime
                    if (!otherDetails[0].commonReference.equals("", ignoreCase = true)) {
                        wasteData["mapReference"] = otherDetails[0].commonReference
                    }
                    common.getDatabasePath(activity).child("WasteCollectionInfo/" + otherDetails[0].newWard + "/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/Summary").updateChildren(wasteData).addOnCompleteListener { task1: Task<Void?> ->
                        if (task1.isSuccessful) {
                            response.value = "success"
                        }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun saveWhoAssignWork(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, loginId: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("WhoAssignWork/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + loginId).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    var count = 1
                    if (dataSnapshot.value != null) {
                        count = dataSnapshot.childrenCount.toInt() + 1
                    }
                    val data = HashMap<String, Any>()
                    data["task"] = otherDetails[0].newWard
                    data["time"] = otherDetails[0].time
                    common.getDatabasePath(activity).child("WhoAssignWork/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + loginId + "/$count").setValue(data).addOnCompleteListener { task22: Task<Void?> ->
                        if (task22.isSuccessful) {
                            response.value = "success"
                        }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun saveLocationHistory(activity: Activity, common: CommonFunctions, ward: String, time: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            common.getDatabasePath(activity).child("LocationHistory/" + ward + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).child("/last-update-time").setValue(time.substring(0, time.length - 3)).addOnCompleteListener { task22: Task<Void?> ->
                if (task22.isSuccessful) {
                    response.value = "success"
                }
            }
        }
        return response
    }

    fun setEmployeeSkipDutyOff(activity: Activity, common: CommonFunctions, userModels: ArrayList<ParentRecyclerviewModel>, loginId: String, outTime: String, wards: ArrayList<String>): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            val userModel = userModels
            for (i in userModel.indices) {
                common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id).orderByChild("task").equalTo(wards[wards.size - 1]).addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.value != null) {
                            val totalChildren = dataSnapshot.childrenCount
                            var counter: Long = 1
                            for (snapshot in dataSnapshot.children) {
                                if (counter >= totalChildren) {
                                    if (snapshot.child("status").value.toString().equals("2")) {
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/card-swap-entries/" + SimpleDateFormat("HH:mm:ss").format(Date())).setValue("Out")
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + snapshot.key + "/status").setValue("1")
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/" + snapshot.key + "/in-out/" + outTime).setValue("Out").addOnCompleteListener {
                                            if (i == userModel.size - 1) {
                                                Log.d("TAG", "onDataChange: save all data $userModel")
                                                response.value = "success"
                                            }
                                        }
                                    }else {
                                        if (i == userModel.size - 1) {
                                            Log.d("TAG", "onDataChange: save all data $userModel")
                                            response.value = "success"
                                        }
                                    }
                                }
                                counter++
                            }
                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {}
                })
            }
        }
        return response
    }

    fun setEmployeeDutyOn(activity: Activity, common: CommonFunctions, otherDetails: ArrayList<OtherDetails>, userModels: ArrayList<ParentRecyclerviewModel>, loginId: String, outTime: String): LiveData<String>? {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            val userModel = userModels
            for (i in userModel.indices) {
                val datas = HashMap<String, String>()
                datas["current-assignment"] = otherDetails[0].newWard
                datas["vehicle"] = otherDetails[0].vehicle
                datas["device"] = userModel[i].device
                common.getDatabasePath(activity).child("WorkAssignment/" + userModel[i].id).setValue(datas).addOnCompleteListener { tasks: Task<Void?> ->
                    if (tasks.isSuccessful) {
                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id).addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                if (dataSnapshot.value != null) {
                                    var currentKey = 1
                                    var isAllReadyAssignment = false
                                    for (snapshot in dataSnapshot.children) {
                                        if (snapshot.key!!.contains("task")) {
                                            currentKey++
                                        }
                                    }
                                    for (snapshot in dataSnapshot.children) {
                                        if (snapshot.hasChild("task")) {
                                            if (snapshot.child("task").value.toString().equals(otherDetails[0].newWard)) {
                                                if (snapshot.hasChild("status")) {
                                                    if (snapshot.child("status").value.toString().equals("2")) {
                                                        isAllReadyAssignment = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (!isAllReadyAssignment){
                                        val dataMaps = HashMap<String, Any>()
                                        dataMaps["device"] = userModel[i].device
                                        dataMaps["task"] = otherDetails[0].newWard
                                        dataMaps["status"] = "2"
                                        dataMaps["task-assigned-by"] = loginId
                                        dataMaps["vehicle"] = otherDetails[0].vehicle
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/card-swap-entries/" + SimpleDateFormat("HH:mm:ss").format(Date())).setValue("In")
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/task$currentKey").child("in-out/$outTime").setValue("In")
                                        common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + userModel[i].id + "/task$currentKey").updateChildren(dataMaps).addOnCompleteListener { task1: Task<Void?> ->
                                            if (task1.isSuccessful) {
                                                if (i == userModel.size - 1) {
                                                    Log.d("TAG", "onDataChange: save all data $userModel")
                                                    response.value = "success"
                                                }
                                            }
                                        }
                                    }else{
                                        if (i == userModel.size - 1) {
                                            Log.d("TAG", "onDataChange: save all data A $userModel")
                                            response.value = "success"
                                        }
                                    }
                                }
                            }

                            override fun onCancelled(databaseError: DatabaseError) {}
                        })
                    }
                }
            }
        }
        return response
    }
}