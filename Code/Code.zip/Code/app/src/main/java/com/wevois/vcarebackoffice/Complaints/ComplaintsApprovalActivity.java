package com.wevois.vcarebackoffice.Complaints;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Complaints.Model.ComplaintsModel;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class ComplaintsApprovalActivity extends AppCompatActivity {
    DatabaseReference databaseReferencePath;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<ComplaintsModel> ArrayWardList = new ArrayList<>();
    ListView wardListView;
    ComplaintsApprovalAdapter complaintsApprovalAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_approval);
        databaseReferencePath = common.getDatabasePath(this);
        complaintsApprovalAdapter = new ComplaintsApprovalAdapter();
        wardListView = findViewById(R.id.approvalListView);
        setPageTitle();
//        setWardName();
        setWardNameFromTasks();
    }

    private void setWardNameFromTasks() {
        databaseReferencePath.child("Complaints/").child("WardListCount/").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    String allWard = dataSnapshot1.getKey();
                    ArrayWardList.add(new ComplaintsModel(allWard));

                }
                wardListView.setAdapter(complaintsApprovalAdapter);
                complaintsApprovalAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void setWardName() {
        databaseReferencePath.child("CardWardMapping/").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    String allWard = dataSnapshot1.child("ward").getValue().toString();
                    ArrayWardList.add(new ComplaintsModel(allWard));

                }
                wardListView.setAdapter(complaintsApprovalAdapter);
                complaintsApprovalAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public class ComplaintsApprovalAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return ArrayWardList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }


        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView wardList;
            LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.complainapprovallayout,null,true);
            wardList = convertView.findViewById(R.id.ComplaintsApprovalWardList);
            ComplaintsModel modelList = ArrayWardList.get(position);
            wardList.setText(modelList.getWard());
            wardList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ComplaintsApprovalActivity.this,ApprovalActivity.class);
                    startActivity(intent);
                }
            });
            return convertView;
        }
    }
    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Complaints Approval");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            ComplaintsApprovalActivity.super.onBackPressed();
        });
    }
}