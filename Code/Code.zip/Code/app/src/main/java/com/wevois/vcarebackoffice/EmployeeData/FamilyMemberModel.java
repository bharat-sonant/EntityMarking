package com.wevois.vcarebackoffice.EmployeeData;

public class FamilyMemberModel {
    String name;
    String age;
    String relation;
    String residing;
    String familyMemberTown;
    String familyMemberState;
    String income;
    String disability;
    String id;
    int serialNo;

    public FamilyMemberModel(String name, String age, String relation, String residing, String familyMemberTown, String familyMemberState, String income, String disability, String id, int serialNo) {
        this.name = name;
        this.age = age;
        this.relation = relation;
        this.residing = residing;
        this.familyMemberTown = familyMemberTown;
        this.familyMemberState = familyMemberState;
        this.income = income;
        this.disability = disability;
        this.id = id;
        this.serialNo = serialNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getResiding() {
        return residing;
    }

    public void setResiding(String residing) {
        this.residing = residing;
    }

    public String getFamilyMemberTown() {
        return familyMemberTown;
    }

    public void setFamilyMemberTown(String familyMemberTown) {
        this.familyMemberTown = familyMemberTown;
    }

    public String getFamilyMemberState() {
        return familyMemberState;
    }

    public void setFamilyMemberState(String familyMemberState) {
        this.familyMemberState = familyMemberState;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getDisability() {
        return disability;
    }

    public void setDisability(String disability) {
        this.disability = disability;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(int serialNo) {
        this.serialNo = serialNo;
    }
}
