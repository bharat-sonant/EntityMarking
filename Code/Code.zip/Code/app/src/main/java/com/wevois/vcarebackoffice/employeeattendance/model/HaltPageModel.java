package com.wevois.vcarebackoffice.employeeattendance.model;

import com.google.android.gms.maps.model.LatLng;

public class HaltPageModel {
    String sno;
    String duration;
    String startTime;
    String endTime;
    String locality;
    String haltType;
    String key;
    String activeHalt;
    String canRemove;
    int textColor;
    int layoutColor;
    LatLng latLng;

    public HaltPageModel(String sno, String duration, String startTime, String endTime, String locality, String haltType, String key, String activeHalt, String canRemove, int textColor, int layoutColor, LatLng latLng) {
        this.sno = sno;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
        this.locality = locality;
        this.haltType = haltType;
        this.key = key;
        this.activeHalt = activeHalt;
        this.canRemove = canRemove;
        this.textColor = textColor;
        this.layoutColor = layoutColor;
        this.latLng = latLng;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getHaltType() {
        return haltType;
    }

    public void setHaltType(String haltType) {
        this.haltType = haltType;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getActiveHalt() {
        return activeHalt;
    }

    public void setActiveHalt(String activeHalt) {
        this.activeHalt = activeHalt;
    }

    public String getCanRemove() {
        return canRemove;
    }

    public void setCanRemove(String canRemove) {
        this.canRemove = canRemove;
    }

    public int getTextColor() {
        return textColor;
    }

    public void setTextColor(int textColor) {
        this.textColor = textColor;
    }

    public int getLayoutColor() {
        return layoutColor;
    }

    public void setLayoutColor(int layoutColor) {
        this.layoutColor = layoutColor;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public void setLatLng(LatLng latLng) {
        this.latLng = latLng;
    }

    @Override
    public String toString() {
        return "HaltPageModel{" +
                "sno='" + sno + '\'' +
                ", duration='" + duration + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", locality='" + locality + '\'' +
                ", haltType='" + haltType + '\'' +
                ", key='" + key + '\'' +
                ", activeHalt='" + activeHalt + '\'' +
                ", canRemove='" + canRemove + '\'' +
                ", textColor=" + textColor +
                ", layoutColor=" + layoutColor +
                ", latLng=" + latLng +
                '}';
    }
}
