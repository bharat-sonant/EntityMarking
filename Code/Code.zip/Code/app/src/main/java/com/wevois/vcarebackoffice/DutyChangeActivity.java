package com.wevois.vcarebackoffice;

import static com.wevois.vcarebackoffice.WorkMonitoringData.MONTHS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class DutyChangeActivity extends AppCompatActivity {
    Spinner vehiclespinner;
    ArrayList<dutychangeModel> dutychangeModels = new ArrayList<>();
    DatabaseReference databaseReferencePath;
    DutyChangeAdapter dutyChangeAdapter;
    String[] driveridmodel, helperidmodel, driverdevicemodel, helperdevicemodel, vehiclemodel;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayAdapter<String> vehicleNoAdapter;
    RecyclerView dutychangerecyclerview;
    String vehicleNumberList;
    String presentDate;
    String driverId,helperId,driverName,helperName,vehicleName;
    String wardNumber, yesterdayAsString,monthname,presentYear;
    TextView driveridforwork, helperidforwork, driverdevice, helperdevice;
    ArrayList<String> vehicleNoList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duty_change);
        dutychangerecyclerview = findViewById(R.id.dutychangerecyclerview);
        dutychangerecyclerview.setHasFixedSize(true);
        dutychangerecyclerview.setLayoutManager(new LinearLayoutManager(this));
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        presentYear = new SimpleDateFormat("yyyy").format(new Date());
        calendar.add(Calendar.DATE, -1);

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        presentDate = dateFormat.format(new Date());
        Log.d("localdate",presentDate);
        yesterdayAsString = dateFormat.format(calendar.getTime());
        String monthpreno = yesterdayAsString.substring(5, 7);
        monthname = String.valueOf(MONTHS[Integer.parseInt(monthpreno)]);
        common.setProgressDialog("Please Wait", "Getting Data", getApplicationContext(), this);
        Intent i = getIntent();
        wardNumber = i.getStringExtra("ward");
        Log.d("heyward",wardNumber);
        Log.d("alldatedetails",dateFormat+"  "+yesterdayAsString+"  "+monthpreno+"  "+monthname);
        driveridmodel = i.getStringExtra("driverid").split(",");
        helperidmodel = i.getStringExtra("helperid").split(",");
        driverdevicemodel = i.getStringExtra("driverDevice").split(",");
        helperdevicemodel = i.getStringExtra("helperdevice").split(",");
        vehiclemodel = i.getStringExtra("vehiclename").split(",");
        for (int k = 0; k < driveridmodel.length - 1; k++) {
            vehicleNoList.add(driverdevicemodel[k]);
//            dutychangeModels.add(new dutychangeModel(i.getStringExtra("ward"), vehiclemodel[k],
//                    driveridmodel[k], helperidmodel[k], driverdevicemodel[k], helperdevicemodel[k]));

        }
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        databaseReferencePath = common.getDatabasePath(this);
        databaseReferencePath.child("Vehicles").orderByChild("status").equalTo("1").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                        vehicleNoList.add(snapshot.getKey());
                        vehicleNumberList = snapshot.getKey();
                        dutychangeModels.add(new dutychangeModel("",vehicleNumberList,"","","",""));

                    }
                    common.closeDialog(DutyChangeActivity.this);
                    dutyChangeAdapter = new DutyChangeAdapter();
                    dutyChangeAdapter.notifyDataSetChanged();
                    dutychangerecyclerview.setAdapter(dutyChangeAdapter);
//                    vehicleNoAdapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        databaseReferencePath.child("WasteCollectionInfo/").child(wardNumber).child(presentYear).child(monthname).child(presentDate).child("WorkerDetails").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                driverId = dataSnapshot.child("driver").getValue().toString();
                helperId = dataSnapshot.child("helper").getValue().toString();
                driverName = dataSnapshot.child("driverName").getValue().toString();
                helperName = dataSnapshot.child("helperName").getValue().toString();
                vehicleName = dataSnapshot.child("helperName").getValue().toString();
//                dutychangeModels.add(new dutychangeModel(driverId,helperId,driverName,helperName,vehicleName,vehicleNumberList));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public class DutyChangeAdapter extends RecyclerView.Adapter<DutyChangeAdapter.ViewHolder> {

        @NonNull
        @Override
        public DutyChangeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.dutychangelayout, parent, false);
            return new ViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull DutyChangeAdapter.ViewHolder holder, int position) {
            dutychangeModel dutychangeModel = dutychangeModels.get(position);
            vehicleNoAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, driverdevicemodel);
            holder.vehicleSpinner.setSelection(position);
            holder.driveridforwork.setText(dutychangeModel.getDriverid());
            holder.driverdevice.setText(dutychangeModel.getDriverdevice());
            holder.helperidforwork.setText(dutychangeModel.getHelperid());
            holder.helperdevice.setText(dutychangeModel.getHelperdevice());
            holder.vehicleSpinner.setAdapter(vehicleNoAdapter);
            if (dutychangeModel.getVehicle()!=null){
                holder.helperdevice.setText(vehicleNumberList);
            }
            if (dutychangeModel.getDriverid()!=null){
                holder.driveridforwork.setText(vehicleNumberList);
            }
        }


        @Override
        public int getItemCount() {
            return dutychangeModels.size();
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            Spinner vehicleSpinner;
            TextView driveridforwork,driverdevice,helperidforwork,helperdevice;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                vehicleSpinner = itemView.findViewById(R.id.vehiclechange);
                driveridforwork = itemView.findViewById(R.id.driveridforwork);
                driverdevice = itemView.findViewById(R.id.driverdevice);
                helperidforwork = itemView.findViewById(R.id.helperidforwork);
                helperdevice = itemView.findViewById(R.id.helperdevice);
            }
        }
    }

    public class dutychangeModel {
        String ward, vehicle, driverid, helperid, driverdevice, helperdevice;

        public dutychangeModel(String ward, String vehicle, String driverid, String helperid, String driverdevice, String helperdevice) {
            this.ward = ward;
            this.vehicle = vehicle;
            this.driverid = driverid;
            this.helperid = helperid;
            this.driverdevice = driverdevice;
            this.helperdevice = helperdevice;
        }

        public String getWard() {
            return ward;
        }

        public void setWard(String ward) {
            this.ward = ward;
        }

        public String getVehicle() {
            return vehicle;
        }

        public void setVehicle(String vehicle) {
            this.vehicle = vehicle;
        }

        public String getDriverid() {
            return driverid;
        }

        public void setDriverid(String driverid) {
            this.driverid = driverid;
        }

        public String getHelperid() {
            return helperid;
        }

        public void setHelperid(String helperid) {
            this.helperid = helperid;
        }

        public String getDriverdevice() {
            return driverdevice;
        }

        public void setDriverdevice(String driverdevice) {
            this.driverdevice = driverdevice;
        }

        public String getHelperdevice() {
            return helperdevice;
        }

        public void setHelperdevice(String helperdevice) {
            this.helperdevice = helperdevice;
        }
    }
}