package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.DutyOffKotlinViewModel

class DutyOffKotlinViewModelFactory(var activity: Activity) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return DutyOffKotlinViewModel(activity) as T
    }
}