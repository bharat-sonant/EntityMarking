package com.wevois.vcarebackoffice.employeeattendance.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.maps.SupportMapFragment;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivityWorkProgressMapBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.WorkProgressViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.WorkProgressViewModelFactory;

public class WorkProgressMap extends AppCompatActivity {

    ActivityWorkProgressMapBinding binding;
    WorkProgressViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_work_progress_map);
        viewModel = new ViewModelProvider(this, new WorkProgressViewModelFactory(this,(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))).get(WorkProgressViewModel.class);
        binding.setWorkprogressviewmodel(viewModel);
    }
}