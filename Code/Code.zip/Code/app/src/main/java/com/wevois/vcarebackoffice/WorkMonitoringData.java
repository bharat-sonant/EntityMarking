package com.wevois.vcarebackoffice;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;

import org.apache.poi.sl.usermodel.Line;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class WorkMonitoringData extends AppCompatActivity {
    RecyclerView workdata;
    String driverdevices, helperdevices;
    DataSnapshot devicesnapshot, dataSnapshotnew, differentsnapshot;
    SharedPreferences preferences, sharedPreferences;
    DatabaseReference reference;
    String ward;
    String html,html1;
    String driverid, yearSpinner, monthname, yesterdayAsString;
    String helpername;
    String helperid;
    String driver;
    String vehiclename;
    CommonFunctions common = CommonFunctions.getInstance();
    public static final String[] MONTHS = {"Monthes", "Janaury", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    WorkMonitoringNewAdapterNEW workMonitoringData;
//    ArrayList<WorkmonitoringModel> workdatalist = new ArrayList<>();
    List<Model> listn = new ArrayList<>();
    ArrayList<WasteCollectionInfoModel> wasteCollectionlist = new ArrayList<>();
    Map<String, String> hashMap = new HashMap<>();
    Map<String, String> sorting;
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wok_monitoring_data);
        common.setProgressDialog("Please wait...", "Loading...", this, this);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        workdata = findViewById(R.id.workdata);
        workdata.setHasFixedSize(true);
        workdata.setLayoutManager(new LinearLayoutManager(this));
        preferences = this.getSharedPreferences("loginData", MODE_PRIVATE);
        sharedPreferences = this.getSharedPreferences("path", MODE_PRIVATE);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        yearSpinner = new SimpleDateFormat("yyyy").format(new Date());
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        yesterdayAsString = dateFormat.format(calendar.getTime());
        String monthpreno = yesterdayAsString.substring(5, 7);
        monthname = String.valueOf(MONTHS[Integer.parseInt(monthpreno)]);
        reference = common.getDatabasePath(this);
        reference.child("DailyWorkDetail").child(yearSpinner).child(monthname).child(yesterdayAsString).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("yesterdayfirst",yesterdayAsString);
                listn.clear();
                for (DataSnapshot a : dataSnapshot.getChildren()) {
                    String b = a.getKey();
                    Log.d("balldata",b);
                    for (int k = 0; k <= a.getChildrenCount(); k++) {
                        if (dataSnapshot.child(b).hasChild("task" + k)) {
                            String wardnumber = dataSnapshot.child(b).child("task" + k).child("task").getValue().toString();
                            hashMap.put(wardnumber, "ward");
                        }

                    }
                }
                sorting = new TreeMap<>(hashMap);
                wasteCollectionlist.clear();
                getWasteCollectionInfo(0, yearSpinner, monthname, yesterdayAsString);
                devicesnapshot = dataSnapshot;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        reference.child("Tasks").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dataSnapshotnew = dataSnapshot;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    public class Model {
        String empcode, device;

        public Model(String empcode, String device) {
            this.empcode = empcode;
            this.device = device;
        }

        public String getEmpcode() {
            return empcode;
        }

        public void setEmpcode(String empcode) {
            this.empcode = empcode;
        }

        public String getDevice() {
            return device;
        }

        public void setDevice(String device) {
            this.device = device;
        }
    }

    public class WasteCollectionInfoModel {
        String driver, driverName, helper, helperName, vehicle, key, driverdevice, helperdevice;

        public WasteCollectionInfoModel() {

        }

        public WasteCollectionInfoModel(String driver, String driverName, String helper, String helperName, String vehicle, String key, String driverdevice, String helperdevice) {
            this.driver = driver;
            this.driverName = driverName;
            this.helper = helper;
            this.helperName = helperName;
            this.vehicle = vehicle;
            this.key = key;
            this.driverdevice = driverdevice;
            this.helperdevice = helperdevice;
        }

        public String getDriver() {
            return driver;
        }

        public void setDriver(String driver) {
            this.driver = driver;
        }

        public String getDriverName() {
            return driverName;
        }

        public void setDriverName(String driverName) {
            this.driverName = driverName;
        }

        public String getHelper() {
            return helper;
        }

        public void setHelper(String helper) {
            this.helper = helper;
        }

        public String getHelperName() {
            return helperName;
        }

        public void setHelperName(String helperName) {
            this.helperName = helperName;
        }

        public String getVehicle() {
            return vehicle;
        }

        public void setVehicle(String vehicle) {
            this.vehicle = vehicle;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getDriverdevice() {
            return driverdevice;
        }

        public void setDriverdevice(String driverdevice) {
            this.driverdevice = driverdevice;
        }

        public String getHelperdevice() {
            return helperdevice;
        }

        public void setHelperdevice(String helperdevice) {
            this.helperdevice = helperdevice;
        }
    }

    private void getWasteCollectionInfo(int i, String yearSpinner, String monthname, String yesterdayAsString) {
        try {
            Set<String> se = sorting.keySet();
            for (String key : se) {
                common.getDatabasePath(WorkMonitoringData.this).child("WasteCollectionInfo/" + key + "/" + yearSpinner + "/" + monthname + "/" + yesterdayAsString).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Log.d("yesterday",yesterdayAsString+"--"+key);
                        driverid = snapshot.child("WorkerDetails").child("driver").getValue().toString();
                        helperid = snapshot.child("WorkerDetails").child("helper").getValue().toString();
                        Log.d("helperid", helperid + driverid + key);
                        if (!driverid.contains(",")) {
                            Log.d("devicesnapshot",devicesnapshot+"");
                            for (int j = 1; j < devicesnapshot.child(driverid).getChildrenCount(); j++) {
                                if (devicesnapshot.child(driverid).hasChild("task" + j)) {
                                    if (devicesnapshot.child(driverid).child("task" + j).child("task").getValue().toString().equals(key)) {
                                        driverdevices = devicesnapshot.child(driverid).child("task" + j).child("device").getValue().toString();
                                        Log.d("driverdevuc", devicesnapshot.child(driverid).child("task" + j).child("device").getValue().toString());
                                    }

                                }
                            }

                        } else {
                            Log.d("gegegeg", "hello");
                            String[] driverdevicemultiple = driverid.split(",");
                            for (int i = 0; i < driverdevicemultiple.length; i++) {
                                for (int j = 1; j < devicesnapshot.child(driverdevicemultiple[i]).getChildrenCount(); j++) {
                                    if (devicesnapshot.child(driverdevicemultiple[i]).hasChild("task" + j)) {
                                        if (devicesnapshot.child(driverdevicemultiple[i]).child("task" + j).child("task").getValue().toString().equals(key)) {
                                            if (i == 0) {
                                                driverdevices = devicesnapshot.child(driverdevicemultiple[i]).child("task" + j).child("device").getValue().toString();
                                                Log.d("splitdreiver",driverdevices);
                                            } else {
                                                driverdevices = driverdevices + "," + devicesnapshot.child(driverdevicemultiple[i]).child("task" + j).child("device").getValue().toString();
                                                Log.d("splitdreiver2",driverdevices);
                                            }
                                        }

                                    }
                                }
                            }
                        }
                        if (!helperid.contains(",")) {
                            for (int j = 1; j < devicesnapshot.child(helperid).getChildrenCount(); j++) {
                                if (devicesnapshot.child(helperid).hasChild("task" + j)) {
                                    if (devicesnapshot.child(helperid).child("task" + j).child("task").getValue().toString().equals(key)) {
                                        helperdevices = devicesnapshot.child(helperid).child("task" + j).child("device").getValue().toString();
                                    }

                                }
                            }

                        } else {
                            Log.d("gegegeg", "hello");
                            String[] helperdevicemultiple = helperid.split(",");
                            for (int i = 0; i < helperdevicemultiple.length; i++) {
                                for (int j = 1; j < devicesnapshot.child(helperdevicemultiple[i]).getChildrenCount(); j++) {
                                    if (devicesnapshot.child(helperdevicemultiple[i]).hasChild("task" + j)) {
                                        if (devicesnapshot.child(helperdevicemultiple[i]).child("task" + j).child("task").getValue().toString().equals(key)) {
                                            if (i == 0) {
                                                helperdevices = devicesnapshot.child(helperdevicemultiple[i]).child("task" + j).child("device").getValue().toString();
                                            } else {
                                                helperdevices = helperdevices + "," + devicesnapshot.child(helperdevicemultiple[i]).child("task" + j).child("device").getValue().toString();
                                            }
                                        }

                                    }
                                }
                            }
                        }
                        driver = snapshot.child("WorkerDetails").child("driverName").getValue().toString();
                        helpername = snapshot.child("WorkerDetails").child("helperName").getValue().toString();
                        vehiclename = snapshot.child("WorkerDetails").child("vehicle").getValue().toString();
                        wasteCollectionlist.add(new WasteCollectionInfoModel(driverid, driver, helperid, helpername, vehiclename, key, driverdevices, helperdevices));
                        workMonitoringData.notifyDataSetChanged();
//                        getWasteCollectionInfo(i, yearSpinner, monthname, yesterdayAsString);
                    }

                    ;

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }

                });
                workMonitoringData = new WorkMonitoringNewAdapterNEW();
                workMonitoringData.notifyDataSetChanged();
                workdata.setAdapter(workMonitoringData);
            }


        } catch (Exception e) {

        }
        common.closeDialog(WorkMonitoringData.this);
    }


    public class WorkMonitoringNewAdapterNEW extends RecyclerView.Adapter<WorkMonitoringNewAdapterNEW.ViewHolder> {
        @NonNull
        @Override
        public WorkMonitoringNewAdapterNEW.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.workdatashoweasyway, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull WorkMonitoringNewAdapterNEW.ViewHolder holder, int position) {
            WasteCollectionInfoModel wasteCollectionInfoModel = wasteCollectionlist.get(position);
            holder.wardname.setText("#" + wasteCollectionInfoModel.getKey());
            if (wasteCollectionInfoModel.getDriver().contains(",")) {
                String[] drivername = wasteCollectionInfoModel.getDriverName().split(",");
                String[] helpername = wasteCollectionInfoModel.getHelperName().split(",");
                String[] driverdevices = wasteCollectionInfoModel.getDriverdevice().split(",");
                String[] helperdevices = wasteCollectionInfoModel.getHelperdevice().split(",");
                String[] driverides = wasteCollectionInfoModel.getDriver().split(",");
                String[] helperides = wasteCollectionInfoModel.getHelper().split(",");
                for (int k = 0; k < driverides.length; k++) {
                    if (k == 0){
                        html = "<b> D : </b>" + drivername[k] + "(" + driverides[k] + ")" + "[" + driverdevices[k] + "]";
                        html1 = "<b> H : </b>" + helpername[k] + "(" + helperides[k] + ")" + "[" + helperdevices[k] + "]";

                    }else {
                        int j = k+1;
                        html = html +"<br></br>"+"<b> D"+j+" : </b>" + drivername[k] + "(" + driverides[k] + ")" + "[" + driverdevices[k] + "]";
                        html1 = html1 +"<br></br>"+"<b> H"+j+" : </b>" + helpername[k] + "(" + helperides[k] + ")" + "[" + helperdevices[k] + "]";
                    }
                }
                holder.drivername.setText(Html.fromHtml(html));
                holder.helpername.setText(Html.fromHtml(html1));
            } else {
                String html = "<b> D : </b>" + wasteCollectionInfoModel.getDriverName() + "(" + wasteCollectionInfoModel.getDriver() + ")" + "[" + wasteCollectionInfoModel.getDriverdevice() + "]";
                String html2 = "<b>H :</b> " + wasteCollectionInfoModel.getHelperName() + "(" + wasteCollectionInfoModel.getHelper() + ")" + "[" + wasteCollectionInfoModel.getHelperdevice() + "]";
                holder.drivername.setText(Html.fromHtml(html));
                holder.helpername.setText(Html.fromHtml(html2));
            }
            holder.vehicle.setText(wasteCollectionInfoModel.getVehicle());
//            holder.startDutyonsame.setVisibility(View.VISIBLE);
            holder.editbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getApplicationContext(), DutyChangeActivity.class);
                    i.putExtra("ward", wasteCollectionInfoModel.getKey());
                    i.putExtra("vehiclename", wasteCollectionInfoModel.getVehicle()+",null");
                    i.putExtra("driverid", wasteCollectionInfoModel.getDriver()+",null");
                    i.putExtra("helperid", wasteCollectionInfoModel.getHelper()+",null");
                    i.putExtra("driverDevice", wasteCollectionInfoModel.getDriverdevice()+",null");
                    i.putExtra("helperdevice", wasteCollectionInfoModel.getHelperdevice()+",null");
                    startActivity(i);
                }
            });

            holder.startDutyonsame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(WorkMonitoringData.this);
                    builder.setMessage("Do You Want To Start Duty?");
                    builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (wasteCollectionInfoModel.getDriver().contains(",")) {
                                if (wasteCollectionInfoModel.getHelper().contains(",")) {
                                    if (wasteCollectionInfoModel.getDriverdevice().contains(",")) {
                                        if (wasteCollectionInfoModel.getHelperdevice().contains(",")) {
                                            if (wasteCollectionInfoModel.getVehicle().contains(",")) {
                                                Calendar cal = Calendar.getInstance();
                                                reference.child("Tasks").child(wasteCollectionInfoModel.getKey()).setValue("Assigned");
                                                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                                                SimpleDateFormat presentyear = new SimpleDateFormat("yyyy");
                                                SimpleDateFormat month_date = new SimpleDateFormat("MMMM");
                                                SimpleDateFormat presentdate = new SimpleDateFormat("yyyy-MM-dd");
                                                String month_namepresent = month_date.format(cal.getTime());
                                                String yearpresent = presentyear.format(new Date());
                                                String presentdatenew = presentdate.format(new Date());
                                                Log.d("presetndatenew",presentdatenew);
                                                String time = dateFormat.format(new Date());
                                                String[] driverids = wasteCollectionInfoModel.getDriver().split(",");
                                                String[] helperids = wasteCollectionInfoModel.getHelper().split(",");
                                                String[] devicedriver = wasteCollectionInfoModel.getDriverdevice().split(",");
                                                String[] devicehelper = wasteCollectionInfoModel.getHelperdevice().split(",");
                                                String[] vehiclenames = wasteCollectionInfoModel.getVehicle().split(",");
                                                HashMap<String, Object> hashMapdailyhelerinout = new HashMap<>();
                                                hashMapdailyhelerinout.put(time, "In");
                                                for (int i = 0; i < driverids.length; i++) {
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(driverids[i])
                                                            .child("card-swap-entries").setValue(hashMapdailyhelerinout);
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(helperids[i])
                                                            .child("card-swap-entries").setValue(hashMapdailyhelerinout);
                                                }
                                                HashMap<String, Object> hashMapdailyhelertasks = new HashMap<>();
                                                hashMapdailyhelertasks.put("status", "2");
                                                hashMapdailyhelertasks.put("task", wasteCollectionInfoModel.getKey());
                                                hashMapdailyhelertasks.put("task-assigned-by", preferences.getString("loginId", ""));
                                                HashMap<String, Object> hashMapdailydrivertasks = new HashMap<>();
                                                HashMap<String, Object> hashMapdailydriverinout = new HashMap<>();
                                                hashMapdailydrivertasks.put("status", "2");
                                                hashMapdailydrivertasks.put("task", wasteCollectionInfoModel.getKey());
                                                hashMapdailydrivertasks.put("task-assigned-by", preferences.getString("loginId", ""));
                                                reference.child("DailyWorkDetail").child(yearpresent)
                                                        .child(month_namepresent).child(presentdatenew).addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                String[] driveridsupdater = wasteCollectionInfoModel.getDriver().split(",");
                                                                String[] helperidsupdater = wasteCollectionInfoModel.getHelper().split(",");

                                                                for (int i = 0; i < driveridsupdater.length; i++) {
                                                                    hashMapdailyhelertasks.put("device", devicehelper[i]);
                                                                    hashMapdailydrivertasks.put("device", devicedriver[i]);
                                                                    hashMapdailyhelertasks.put("vehicle", vehiclenames[i]);
                                                                    int data = (int) dataSnapshot.child(driveridsupdater[i]).getChildrenCount();
                                                                    if (!dataSnapshot.child(driveridsupdater[i]).hasChild("task" + data)) {
                                                                        reference.child("DailyWorkDetail").child(yearpresent)
                                                                                .child(month_namepresent).child(presentdatenew).child(driveridsupdater[i])
                                                                                .child("task" + data).setValue(hashMapdailydrivertasks);
                                                                        hashMapdailydriverinout.clear();
                                                                        hashMapdailydriverinout.put(time, "In");
                                                                        reference.child("DailyWorkDetail").child(yearpresent)
                                                                                .child(month_namepresent).child(presentdatenew).child(driveridsupdater[i])
                                                                                .child("task" + data).child("in-out").setValue(hashMapdailydriverinout);
                                                                    }
                                                                    if (!dataSnapshot.child(helperidsupdater[i]).hasChild("task" + data)) {
                                                                        reference.child("DailyWorkDetail").child(yearpresent)
                                                                                .child(month_namepresent).child(presentdatenew).child(helperidsupdater[i])
                                                                                .child("task" + data).setValue(hashMapdailyhelertasks);
                                                                        reference.child("DailyWorkDetail").child(yearpresent)
                                                                                .child(month_namepresent).child(presentdatenew).child(helperidsupdater[i])
                                                                                .child("task" + data).child("in-out").setValue(hashMapdailyhelerinout);

                                                                    }
                                                                    String deviceddrivd = devicedriver[i];
                                                                    String devicehelpernew = devicehelper[i];
                                                                    HashMap<String, Object> hashmapvvehicle = new HashMap<>();
                                                                    hashmapvvehicle.put("assigned-driver", driverids[i]);
                                                                    hashmapvvehicle.put("assigned-helper", helperids[i]);
                                                                    hashmapvvehicle.put("assigned-task", wasteCollectionInfoModel.getKey());
                                                                    hashmapvvehicle.put("status", 3);
                                                                    Log.d("devicenamesd", driverids[i] + helperids[i]);
                                                                    reference.child("Vehicles").child(vehiclenames[i]).setValue(hashmapvvehicle);
                                                                    HashMap<String, Object> wastecollectioninfo = new HashMap<>();
                                                                    wastecollectioninfo.put("driver", wasteCollectionInfoModel.getDriver());
                                                                    wastecollectioninfo.put("driverName", wasteCollectionInfoModel.getDriverName());
                                                                    wastecollectioninfo.put("helper", wasteCollectionInfoModel.getHelper());
                                                                    wastecollectioninfo.put("helperName", wasteCollectionInfoModel.getHelperName());
                                                                    wastecollectioninfo.put("vehicle", wasteCollectionInfoModel.getVehicle());
                                                                    reference.child("WasteCollectionInfo").child(wasteCollectionInfoModel.getKey())
                                                                            .child(yearpresent).child(month_namepresent).child(presentdatenew)
                                                                            .child("Summary").child("dutyInTime").setValue(time);
                                                                    reference.child("WasteCollectionInfo").child(wasteCollectionInfoModel.getKey())
                                                                            .child(yearpresent).child(month_namepresent).child(presentdatenew)
                                                                            .child("WorkerDetails").setValue(wastecollectioninfo);
                                                                    String cityname = sharedPreferences.getString("city", "");
                                                                    reference.child("Devices").child(cityname).addValueEventListener(new ValueEventListener() {
                                                                        @Override
                                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                            for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                                                                String devicecheck = dataSnapshot1.child("name").getValue().toString();
                                                                                if (devicecheck.equals(deviceddrivd)) {
                                                                                    reference.child("Devices").child(cityname).child(dataSnapshot1.getKey()).child("status").setValue("3");
                                                                                }
                                                                                if (devicecheck.equals(devicehelpernew)) {
                                                                                    reference.child("Devices").child(cityname).child(dataSnapshot1.getKey()).child("status").setValue("3");
                                                                                    Toast.makeText(WorkMonitoringData.this, "Duty Started Successfully", Toast.LENGTH_SHORT).show();
                                                                                }


                                                                            }
                                                                        }

                                                                        @Override
                                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                        }
                                                                    });

                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                                            }
                                                        });
                                            }
                                        }
                                    }
                                }
                            } else {
                                common.setProgressDialog("", "Please wait...", getApplicationContext(), WorkMonitoringData.this);
                                Calendar cal = Calendar.getInstance();
                                reference.child("Tasks").child(wasteCollectionInfoModel.getKey()).setValue("Assigned");
                                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                                SimpleDateFormat presentyear = new SimpleDateFormat("yyyy");
                                SimpleDateFormat month_date = new SimpleDateFormat("MMMM");
                                SimpleDateFormat presentdate = new SimpleDateFormat("yyyy-MM-dd");
                                String month_namepresent = month_date.format(cal.getTime());
                                String yearpresent = presentyear.format(new Date());
                                String presentdatenew = presentdate.format(new Date());
                                String time = dateFormat.format(new Date());
                                Log.d("presetndatenew2",presentdatenew);

                                HashMap<String, Object> hashMapdailyhelerinout = new HashMap<>();
                                hashMapdailyhelerinout.put(time, "In");
                                reference.child("DailyWorkDetail").child(yearpresent)
                                        .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getDriver())
                                        .child("card-swap-entries").setValue(hashMapdailyhelerinout);
                                reference.child("DailyWorkDetail").child(yearpresent)
                                        .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getHelper())
                                        .child("card-swap-entries").setValue(hashMapdailyhelerinout);
                                HashMap<String, Object> hashMapdailyhelertasks = new HashMap<>();
                                hashMapdailyhelertasks.put("status", "2");
                                hashMapdailyhelertasks.put("task", wasteCollectionInfoModel.getKey());
                                hashMapdailyhelertasks.put("task-assigned-by", preferences.getString("loginId", ""));

                                HashMap<String, Object> hashMapdailydrivertasks = new HashMap<>();
                                HashMap<String, Object> hashMapdailydriverinout = new HashMap<>();
                                hashMapdailydrivertasks.put("status", "2");
                                hashMapdailydrivertasks.put("task", wasteCollectionInfoModel.getKey());
                                hashMapdailydrivertasks.put("task-assigned-by", preferences.getString("loginId", ""));
                                reference.child("DailyWorkDetail").child(yearpresent)
                                        .child(month_namepresent).child(presentdatenew).addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                hashMapdailyhelertasks.put("device", wasteCollectionInfoModel.getDriver());
                                                hashMapdailydrivertasks.put("device", wasteCollectionInfoModel.getDriverdevice());
                                                hashMapdailyhelertasks.put("vehicle", wasteCollectionInfoModel.getVehicle());
                                                int data = (int) dataSnapshot.child(wasteCollectionInfoModel.getDriver()).getChildrenCount();
                                                if (!dataSnapshot.child(wasteCollectionInfoModel.getDriver()).hasChild("task" + data)) {
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getDriver())
                                                            .child("task" + data).setValue(hashMapdailydrivertasks);
                                                    hashMapdailydriverinout.clear();
                                                    hashMapdailydriverinout.put(time, "In");
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getDriver())
                                                            .child("task" + data).child("in-out").setValue(hashMapdailydriverinout);
                                                }
                                                if (!dataSnapshot.child(wasteCollectionInfoModel.getHelper()).hasChild("task" + data)) {
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getHelper())
                                                            .child("task" + data).setValue(hashMapdailyhelertasks);
                                                    reference.child("DailyWorkDetail").child(yearpresent)
                                                            .child(month_namepresent).child(presentdatenew).child(wasteCollectionInfoModel.getHelper())
                                                            .child("task" + data).child("in-out").setValue(hashMapdailyhelerinout);

                                                }


                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                HashMap<String, Object> hashmapvvehicle = new HashMap<>();
                                hashmapvvehicle.put("assigned-driver", wasteCollectionInfoModel.getDriver());
                                hashmapvvehicle.put("assigned-helper", wasteCollectionInfoModel.getHelper());
                                hashmapvvehicle.put("assigned-task", wasteCollectionInfoModel.getKey());
                                hashmapvvehicle.put("status", 3);
                                reference.child("Vehicles").child(wasteCollectionInfoModel.getVehicle()).setValue(hashmapvvehicle);
                                HashMap<String, Object> wastecollectioninfo = new HashMap<>();
                                wastecollectioninfo.put("driver", wasteCollectionInfoModel.getDriver());
                                wastecollectioninfo.put("driverName", wasteCollectionInfoModel.getDriverName());
                                wastecollectioninfo.put("helper", wasteCollectionInfoModel.getHelper());
                                wastecollectioninfo.put("helperName", wasteCollectionInfoModel.getHelperName());
                                wastecollectioninfo.put("vehicle", wasteCollectionInfoModel.getVehicle());
                                reference.child("WasteCollectionInfo").child(wasteCollectionInfoModel.getKey())
                                        .child(yearpresent).child(month_namepresent).child(presentdatenew)
                                        .child("Summary").child("dutyInTime").setValue(time);
                                reference.child("WasteCollectionInfo").child(wasteCollectionInfoModel.getKey())
                                        .child(yearpresent).child(month_namepresent).child(presentdatenew)
                                        .child("WorkerDetails").setValue(wastecollectioninfo);
                                String cityname = sharedPreferences.getString("city", "");
                                reference.child("Devices").child(cityname).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                            String devicecheck = dataSnapshot1.child("name").getValue().toString();
                                            if (devicecheck.equals(wasteCollectionInfoModel.getDriverdevice())) {
                                                reference.child("Devices").child(cityname).child(dataSnapshot1.getKey()).child("status").setValue("3");
                                            }
                                            if (devicecheck.equals(wasteCollectionInfoModel.getHelperdevice())) {
                                                reference.child("Devices").child(cityname).child(dataSnapshot1.getKey()).child("status").setValue("3");
                                                Toast.makeText(WorkMonitoringData.this, "Duty Started Successfully", Toast.LENGTH_SHORT).show();
                                            }


                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });


                            }
//
//
                        }

                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });

        }

        @Override
        public int getItemCount() {
            return wasteCollectionlist.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView wardname, drivername, helpername, vehicle;
            Button startDutyonsame;
            ImageView editbutton;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                wardname = itemView.findViewById(R.id.wardnameeasy);
                drivername = itemView.findViewById(R.id.drivernameduty);
                helpername = itemView.findViewById(R.id.helpernameduty);
                vehicle = itemView.findViewById(R.id.vehiclenamenew);
                editbutton = itemView.findViewById(R.id.editbutton);
                startDutyonsame = itemView.findViewById(R.id.startDutyonsame);

            }
        }
    }


}