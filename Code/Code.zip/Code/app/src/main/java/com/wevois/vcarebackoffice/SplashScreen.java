package com.wevois.vcarebackoffice;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Monitoring.WorkMonitoringActivity;

import java.util.Calendar;

public class SplashScreen extends AppCompatActivity {
    CommonFunctions common = CommonFunctions.getInstance();
    private Calendar calendar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        new Handler().postDelayed(this::checkAlreadyLogin, 3000);
    }

    private void checkAlreadyLogin() {
        SharedPreferences sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        if (sharedPreferences.getString("loginId", "") != "") {
            common.getDatabasePath(SplashScreen.this).child("Employees/" + sharedPreferences.getString("loginType", "")
                    + "/GeneralDetails/status").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue() != null) {
                        if(String.valueOf(dataSnapshot.getValue()).equals("1")){
                            startActivity(new Intent(SplashScreen.this, Launcher.class));
                        } else {
                            Toast.makeText(SplashScreen.this, "You are not authorized to use", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    } else {
                        startActivity(new Intent(SplashScreen.this, Launcher.class));
                        finish();
                    }
                    finish();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } else {
            startActivity(new Intent(SplashScreen.this, SelectCityActivity.class));
            finish();
        }
    }
}