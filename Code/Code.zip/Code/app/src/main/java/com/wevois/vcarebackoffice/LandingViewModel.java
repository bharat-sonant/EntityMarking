package com.wevois.vcarebackoffice;

public class LandingViewModel {
    int pageId;
    String pageName,iconUrl;
    boolean isVisible;

    public int getPageId() {
        return pageId;
    }

    public String getPageName() {
        return pageName;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    public LandingViewModel(int pageId, String pageName, String iconUrl, boolean isVisible) {
        this.pageId = pageId;
        this.pageName = pageName;
        this.iconUrl = iconUrl;
        this.isVisible = isVisible;
    }
}
