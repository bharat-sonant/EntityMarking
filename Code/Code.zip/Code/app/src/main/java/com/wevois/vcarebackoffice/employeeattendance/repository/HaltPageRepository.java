package com.wevois.vcarebackoffice.employeeattendance.repository;


public class HaltPageRepository {


}
