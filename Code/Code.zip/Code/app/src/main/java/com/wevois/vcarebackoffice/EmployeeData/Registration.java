package com.wevois.vcarebackoffice.EmployeeData;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.Objects;

public class Registration extends AppCompatActivity {
    Bundle basic;
    DatabaseReference rootRef;
    boolean value = false;
    private View addressBadge, bankBadge, identificationBadge, otherBadge;
    String from, empId, empCode;
    SharedPreferences sharedPreferences;
    BottomNavigationView bottomNavigationView;
    CommonFunctions cmn = CommonFunctions.getInstance();
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_registration);
        PreviousActivityBundle();
        setPageTitle();
        InIt();
    }

    private void PreviousActivityBundle() {
        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        from = bundle.getString("from");
        empId = bundle.getString("empId");
        empCode = bundle.getString("empCode");
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Employee Detail");
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            Intent j = new Intent(Registration.this, Employee.class);
            startActivity(j);
            finish();
            Registration.super.onBackPressed();

        });
    }

    private void InIt() {

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        rootRef = cmn.getDatabasePath(this);
        Action();
    }

    @Override
    public void onStart() {
        try {
            FirebaseUser user = mAuth.getCurrentUser();
            if (user != null) {
            } else {
                mAuth.signInAnonymously().addOnCompleteListener(task -> {
                });
            }
        }catch (Exception e){
            Log.d("TAG", "onActivityResult: check 16"+e.toString());
        }
        super.onStart();
    }

    public void BnbForAdd() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment fragment = null;
            if (bottomNavigationView.getSelectedItemId() != item.getItemId()) {
                switch (item.getItemId()) {
                    case R.id.general_deatail:
                        fragment = GeneralDetailFragment.newInstance();
                        value = true;
                        break;

                    case R.id.address_deatails:
                        if (sharedPreferences.getBoolean("General", false)) {
                            fragment = AddressDetailFragment.newInstance();
                            value = true;
                        } else {
                            cmn.showAlertDialog("Alert", "Fill General Details to Proceed", false, Registration.this);
                            value = false;
                        }
                        break;

                    case R.id.bank_deatails:
                        if (sharedPreferences.getBoolean("General", false)) {
                            if (sharedPreferences.getBoolean("Address", false)) {
                                fragment = BankDetailFragment.newInstance();
                                value = true;
                            } else {
                                cmn.showAlertDialog("Alert", "Fill Address Details to Proceed", false, Registration.this);
                                value = false;
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Fill General Details to Proceed", false, Registration.this);
                            value = false;
                        }
                        break;

                    case R.id.identification_deatails:
                        if (sharedPreferences.getBoolean("General", false)) {
                            if (sharedPreferences.getBoolean("Address", false)) {
                                if (sharedPreferences.getBoolean("Bank", false)) {
                                    fragment = IdentificationDetailFragment.newInstance();
                                    value = true;
                                } else {
                                    cmn.showAlertDialog("Alert", "Fill Bank Details to Proceed", false, Registration.this);
                                    value = false;
                                }
                            } else {
                                cmn.showAlertDialog("Alert", "Fill Address Details to Proceed", false, Registration.this);
                                value = false;
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Fill General Details to Proceed", false, Registration.this);
                            value = false;
                        }
                        break;

                    case R.id.other_deatails:
                        if (sharedPreferences.getBoolean("General", false)) {
                            if (sharedPreferences.getBoolean("Address", false)) {
                                if (sharedPreferences.getBoolean("Bank", false)) {
                                    if (sharedPreferences.getBoolean("Identification", false)) {
                                        fragment = OtherDetailFragment.newInstance();
                                        value = true;
                                    } else {
                                        cmn.showAlertDialog("Alert", "Fill Identification Details to Proceed", false, Registration.this);
                                        value = false;
                                    }
                                } else {
                                    cmn.showAlertDialog("Alert", "Fill Bank Details to Proceed", false, Registration.this);
                                    value = false;
                                }
                            } else {
                                cmn.showAlertDialog("Alert", "Fill Address Details to Proceed", false, Registration.this);
                                value = false;
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Fill General Details to Proceed", false, Registration.this);
                            value = false;
                        }
                        break;
                }
            }
            if (fragment != null) {
                fragment.setArguments(basic);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
            }

            return value;
        });
    }

    private void BnbForEdit() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            if (bottomNavigationView.getSelectedItemId() != item.getItemId()) {
                switch (item.getItemId()) {
                    case R.id.general_deatail:
                        selectedFragment = GeneralDetailFragment.newInstance();
                        break;
                    case R.id.address_deatails:
                        selectedFragment = AddressDetailFragment.newInstance();
                        break;
                    case R.id.bank_deatails:
                        selectedFragment = BankDetailFragment.newInstance();
                        break;
                    case R.id.identification_deatails:
                        selectedFragment = IdentificationDetailFragment.newInstance();
                        break;
                    case R.id.other_deatails:
                        selectedFragment = OtherDetailFragment.newInstance();
                        break;
                }
            }
            if (selectedFragment != null) {
                selectedFragment.setArguments(basic);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
            }
            return true;

        });

    }

    private void PutBundle() {
        basic = new Bundle();
        basic.putString("empCode", empCode);
        basic.putString("empId", empId);
        basic.putString("from", from);
    }

    private void Action() {
        PutBundle();
        if (from.equals("add")) {
            sharedPreferences.edit().putBoolean("General", false).apply();
            sharedPreferences.edit().putBoolean("Address", false).apply();
            sharedPreferences.edit().putBoolean("Bank", false).apply();
            sharedPreferences.edit().putBoolean("Identification", false).apply();
            sharedPreferences.edit().putBoolean("Other", false).apply();
            BnbForAdd();
        } else {
            BnbForEdit();
            Badges();
        }
        GeneralDetailFragment generalDetailFragment = GeneralDetailFragment.newInstance();
        generalDetailFragment.setArguments(basic);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, generalDetailFragment).commit();
    }

    @SuppressLint("RestrictedApi")
    public void Badges() {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomNavigationView.getChildAt(0);
        BottomNavigationItemView itemView1 = (BottomNavigationItemView) menuView.getChildAt(1);
        BottomNavigationItemView itemView2 = (BottomNavigationItemView) menuView.getChildAt(2);
        BottomNavigationItemView itemView3 = (BottomNavigationItemView) menuView.getChildAt(3);
        BottomNavigationItemView itemView4 = (BottomNavigationItemView) menuView.getChildAt(4);
        menuView.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
        menuView.setItemTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));

        rootRef.child("Employees").child(empId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                addressBadge = LayoutInflater.from(Registration.this).inflate(R.layout.view_notification_badge, menuView, false);
                bankBadge = LayoutInflater.from(Registration.this).inflate(R.layout.view_notification_badge, menuView, false);
                identificationBadge = LayoutInflater.from(Registration.this).inflate(R.layout.view_notification_badge, menuView, false);
                otherBadge = LayoutInflater.from(Registration.this).inflate(R.layout.view_notification_badge, menuView, false);
                if (!dataSnapshot.hasChild("AddressDetails")) {
                    sharedPreferences.edit().putBoolean("Address", false).apply();
                    itemView1.addView(addressBadge);
                }
                if (!dataSnapshot.hasChild("BankDetails")) {
                    sharedPreferences.edit().putBoolean("Bank", false).apply();
                    itemView2.addView(bankBadge);
                }
                if (!dataSnapshot.hasChild("IdentificationDetails")) {
                    sharedPreferences.edit().putBoolean("Identification", false).apply();
                    itemView3.addView(identificationBadge);
                }
                if (!dataSnapshot.hasChild("OtherDetails")) {
                    itemView4.addView(otherBadge);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void RemoveBadges() {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomNavigationView.getChildAt(0);
        BottomNavigationItemView itemView1 = (BottomNavigationItemView) menuView.getChildAt(1);
        BottomNavigationItemView itemView2 = (BottomNavigationItemView) menuView.getChildAt(2);
        BottomNavigationItemView itemView3 = (BottomNavigationItemView) menuView.getChildAt(3);

        if (sharedPreferences.getBoolean("Address", false)) {
            itemView1.removeView(addressBadge);
        }
        if (sharedPreferences.getBoolean("Bank", false)) {
            itemView2.removeView(bankBadge);
        }
        if (sharedPreferences.getBoolean("Identification", false)) {
            itemView3.removeView(identificationBadge);
        }
    }

    @SuppressLint("RestrictedApi")
    public void iconColor() {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomNavigationView.getChildAt(0);
        BottomNavigationItemView itemView = (BottomNavigationItemView) menuView.getChildAt(0);
        BottomNavigationItemView itemView1 = (BottomNavigationItemView) menuView.getChildAt(1);
        BottomNavigationItemView itemView2 = (BottomNavigationItemView) menuView.getChildAt(2);
        BottomNavigationItemView itemView3 = (BottomNavigationItemView) menuView.getChildAt(3);
        BottomNavigationItemView itemView4 = (BottomNavigationItemView) menuView.getChildAt(4);

        if (sharedPreferences.getBoolean("General", false)) {
            bottomNavigationView.setSelectedItemId(R.id.address_deatails);
            itemView.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView1.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView.setTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView1.setTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));
        }
        if (sharedPreferences.getBoolean("Address", false)) {
            bottomNavigationView.setSelectedItemId(R.id.bank_deatails);
            itemView2.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView2.setTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));
        }
        if (sharedPreferences.getBoolean("Bank", false)) {
            bottomNavigationView.setSelectedItemId(R.id.identification_deatails);
            itemView3.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView3.setTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));
        }
        if (sharedPreferences.getBoolean("Identification", false)) {
            bottomNavigationView.setSelectedItemId(R.id.other_deatails);
            itemView4.setIconTintList(ColorStateList.valueOf(Color.parseColor("#10AD24")));
            itemView4.setTextColor(ColorStateList.valueOf(Color.parseColor("#10AD24")));
        }
    }
}