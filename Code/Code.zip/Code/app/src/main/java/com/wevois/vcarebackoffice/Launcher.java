package com.wevois.vcarebackoffice;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.AccessManagement.AccessManagementActivity;
import com.wevois.vcarebackoffice.BackDateDutyOff.BackDateDutyOff;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Complaints.ComplaintsPage;
import com.wevois.vcarebackoffice.EmployeeData.Employee;
import com.wevois.vcarebackoffice.Login.ChangePassword;
import com.wevois.vcarebackoffice.Monitoring.MonitoringOptionsActivity;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

public class Launcher extends AppCompatActivity {
    private final static int READ_PHONE = 100;
    SharedPreferences sharedPrefLogin;
    String getValueForMetadata;
    String loginId;
    String refet;
    String cityTest, databasePath, sPath, keyName;
    GridView gridView;
    SharedPreferences pathSharedPreferences;
    boolean allowCityChangeOption = false;
    LandingViewAdapter landingViewAdapter = new LandingViewAdapter();
    ArrayList<LandingViewModel> landingList = new ArrayList<>();
    ArrayList<ModelForCities> citiesModel = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    boolean isAllowClick = true, checkPermission = false;
    String[] PERMISSIONS = {
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        common.getIncentive(this);
        common.getSettingsData(this);
        checkVersion();
        setPageTitle();
        initPage();
        allowPhonePermission();
    }
    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }
    private void checkVersion() {
        Launcher.this.runOnUiThread(() -> {
            common.getDatabasePath(this).child("Settings/LatestVersions/vcarebackoffice").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    try {
                        String localVersion = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
                        if (dataSnapshot.getValue() != null) {
                            String version = dataSnapshot.getValue().toString();
                            if (!version.equals(localVersion)) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
                                builder.setCancelable(false);
                                builder.setTitle("Version Expired");
                                builder.setMessage("Your App version is not Matched. Please update your app.");
                                builder.setPositiveButton("Ok", (dialog, which) -> {
                                            dialog.dismiss();
                                            finish();
                                        }
                                );

                                AlertDialog alertDialog = builder.create();
                                alertDialog.show();
                            }
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        });
    }
    private void getMetaDataForBackOfficePageIds() {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        getValueForMetadata = pathSharedPreferences.getString("city", "");
        storageReference.child(getValueForMetadata + "/Defaults/vCare-BackOfficePageIds.json").getMetadata().addOnSuccessListener(storageMetadata -> {

            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("vCare-BackOfficePageIdsDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(getValueForMetadata + "/Defaults/vCare-BackOfficePageIds.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String BackOfficePageIdsData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("vCare-BackOfficePageIds", BackOfficePageIdsData).apply();
                        pathSharedPreferences.edit().putLong("vCare-BackOfficePageIdsDownloadTime", fileCreationTime).apply();
                        dataDownloadForBackOfficePageIds();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                dataDownloadForBackOfficePageIds();
            }
        });
    }
    private void dataDownloadForBackOfficePageIds() {
        common.getDatabasePath(Launcher.this).child("BackOfficeAccess/" + loginId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                landingList = new ArrayList<>();
                if (dataSnapshot.getValue() != null) {
                    ArrayList<String> strings = new ArrayList<>(Arrays.asList(dataSnapshot.getValue().toString().split(",")));
                    try {
                        JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("vCare-BackOfficePageIds", "str"));
                        for (int i = 0; i < jsonArray.length(); i++) {
                            try {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                if (jsonObject.has("pageName") && jsonObject.has("pageIcon")) {
                                    if (strings.contains(String.valueOf(i))) {
                                        landingList.add(new LandingViewModel(i,
                                                jsonObject.getString("pageName"),
                                                jsonObject.getString("pageIcon"),
                                                true));
                                    }
                                } else {
                                    if (jsonObject.has("feature")) {
                                        if (strings.contains(String.valueOf(i))) {
                                            allowCityChangeOption = true;
                                        }
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        landingViewAdapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    landingViewAdapter.notifyDataSetChanged();
                }
                common.closeDialog(Launcher.this);
                landingViewAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void initPage() {
        Launcher.this.runOnUiThread(() -> {
            landingViewAdapter = new LandingViewAdapter();
            gridView = findViewById(R.id.landing_gridView);
            gridView.setAdapter(landingViewAdapter);
            sharedPrefLogin = getSharedPreferences("loginData", MODE_PRIVATE);
            pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
            loginId = sharedPrefLogin.getString("loginType", "");
            common.setProgressDialog("Please Wait", " ", this, this);
            getMetaDataForBackOfficePageIds();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/AttendanceApprovalStatus.json", "AttendanceApprovalStatusDownloadTime", "AttendanceApprovalStatus", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData1("/Common/Departments.json", "DepartmentsDownloadTime", "departmentList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/StatusId.json", "StatusIdDownloadTime", "statusList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/Gender.json", "GenderDownloadTime", "genderList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData1("/Common/Designations.json", "DesignationsDownloadTime", "designationList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/MaritalStatus.json", "MaritalStatusDownloadTime", "maritalStatusList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/Nationality.json", "NationalityDownloadTime", "nationalityList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/Qualification.json", "QualificationDownloadTime", "qualificationList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/OriginCountry.json", "OriginCountryDownloadTime", "originCountryList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/States.json", "StatesDownloadTime", "stateList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/OilTypes.json", "OilTypesDownloadTime", "oilTypeList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/LogBookReasons.json", "LogBookReasonsDownloadTime", "logBookReasonsList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/PenaltyTypes.json", "PenaltyTypesDownloadTime", "penaltyTypeArrayList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/WorkingDayInMonth.json", "WorkingDayInMonthDownloadTime", "workingDaysInMonthSnapshot", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/KmlBoundary.json", "KmlBoundaryDownloadTime", "kmlBoundaryList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/FinalHousesType.json", "FinalHousesTypeDownloadTime", "finalHousesTypeList", this);
            }).start();
            new Thread(() -> {
                common.getCommonFileForMetaData("/Defaults/RemoveHaltReason.json", "RemoveHaltReasonDownloadTime", "removeReasonList", this);
            }).start();
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        try {
            menu.add("App version : " + getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
        } catch (Exception ignore) {
        }

        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.changePassword:
                startActivity(new Intent(Launcher.this, ChangePassword.class));
                break;
            case R.id.changeCity:
                if (allowCityChangeOption) {
                    fetchCities();
                } else {
                    common.showAlertDialog("", "This option is not available for you.", false, this);
                }
                break;
            case R.id.logOut:
                sharedPrefLogin.edit().clear().apply();
                startActivity(new Intent(Launcher.this, SelectCityActivity.class));
                finish();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    private void allowPhonePermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, READ_PHONE);
            return;
        }
        common.wardName(this);
        common.getSortedMarkWardList(this);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == READ_PHONE) {
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {
                    String per = permissions[i];
                    if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, per)) {
                            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
                            alertBuilder.setCancelable(false);
                            alertBuilder.setTitle("जरूरी सूचना");
                            alertBuilder.setMessage("सभी permissions देना अनिवार्य है बिना permissions के आप आगे नहीं बढ़ सकते है |");
                            alertBuilder.setPositiveButton(android.R.string.yes, (dialog, which) -> allowPhonePermission());

                            AlertDialog alert = alertBuilder.create();
                            alert.show();
                        } else {
                            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
                            alertBuilder.setCancelable(false);
                            alertBuilder.setTitle("जरूरी सूचना");
                            alertBuilder.setMessage("सभी permissions देना अनिवार्य है बिना permissions के आप आगे नहीं बढ़ सकते है |");
                            alertBuilder.setPositiveButton(android.R.string.yes, (dialog, which) -> {
                                checkPermission = true;
                                Intent intent = new Intent();
                                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", Launcher.this.getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                            });
                            AlertDialog alert = alertBuilder.create();
                            alert.show();
                        }
                        return;
                    }
                }
                common.wardName(this);
                common.getSortedMarkWardList(this);
            } else {
                allowPhonePermission();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == READ_PHONE) {
            if (resultCode == RESULT_OK) {
                common.wardName(this);
                common.getSortedMarkWardList(this);
            } else {
                allowPhonePermission();
            }
        }
    }

    private void fetchCities() {
        common.setProgressDialog("", "Please Wait ", Launcher.this, Launcher.this);
        String selectedCity = pathSharedPreferences.getString("city", "");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("CityDetails", ""));
            if (jsonArray != null) {
                citiesModel = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String cityName = jsonObject.getString("cityName");
                        String dbPath = jsonObject.getString("dbPath");
                        String storagePath = jsonObject.getString("storagePath");
                        String key = jsonObject.getString("key");
                        if (jsonObject.has("dbPath") && jsonObject.has("storagePath")) {
                            boolean isActive;
                            if (cityName.equals(selectedCity)) {
                                isActive = true;
                            } else {
                                isActive = false;
                            }
                            if (cityName.equalsIgnoreCase("Test")) {
                                cityTest = cityName;
                                databasePath = dbPath;
                                sPath = storagePath;
                                keyName = key;
                            } else {
                                ModelForCities citiesDetails = new ModelForCities(cityName, dbPath, storagePath, isActive,key);
                                citiesModel.add(citiesDetails);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                changeCityCustomAlertBox();
            } else {
                common.closeDialog(Launcher.this);
                common.showAlertDialog("Alert", "Cities Data Not Available", false, Launcher.this);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void callingChangeCityOption() {
        initPage();
        common.getIncentive(Launcher.this);
        common.getSettingsData(Launcher.this);
        allowPhonePermission();
    }
    private void changeCityCustomAlertBox() {
        View dialog = getLayoutInflater().inflate(R.layout.change_city_alert_layout, null);
        AlertDialog alertDialog = new AlertDialog.Builder(Launcher.this).setView(dialog).setCancelable(false).create();
        TextView headingOfChangeCityOption = dialog.findViewById(R.id.heading_of_change_city);
        GridView citiesListview = dialog.findViewById(R.id.cities_listview);
        citiesListview.setAdapter(new CitiesAdapter(alertDialog));
        dialog.findViewById(R.id.cancel_btn).setOnClickListener(view -> alertDialog.dismiss());
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        headingOfChangeCityOption.setOnLongClickListener(view -> {
            pathSharedPreferences.edit().putString("city", cityTest).apply();
            pathSharedPreferences.edit().putString("pathRef", databasePath).apply();
            pathSharedPreferences.edit().putString("storagePathRef", sPath).apply();
            pathSharedPreferences.edit().putString("key", keyName).apply();
            common.wardName(getApplicationContext());
            common.getSortedMarkWardList(getApplicationContext());
            callingChangeCityOption();
            alertDialog.dismiss();
            return false;
        });
        common.closeDialog(Launcher.this);
        alertDialog.show();
    }

    private class ModelForCities {
        String city, dbPath, storagePath,key;
        boolean isActive;

        public boolean isActive() {
            return isActive;
        }

        public void setActive(boolean active) {
            isActive = active;
        }

        public String getCity() {
            return city;
        }

        public String getDbPath() {
            return dbPath;
        }

        public String getStoragePath() {
            return storagePath;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public ModelForCities(String city, String dbPath, String storagePath, boolean isActive, String key) {
            this.city = city;
            this.dbPath = dbPath;
            this.storagePath = storagePath;
            this.isActive = isActive;
            this.key = key;
        }
    }

    private class CitiesAdapter extends BaseAdapter {
        AlertDialog alertDialog;

        public CitiesAdapter(AlertDialog alertDialog) {
            this.alertDialog = alertDialog;
        }

        @Override
        public int getCount() {
            return citiesModel.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "UseCompatLoadingForDrawables"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.selectcity2, null, true);
            ModelForCities model = citiesModel.get(i);
            String s = model.getCity();
                s = s.replace("-", " ");
                s=s.replace("WeVOIS ","");
                s = s.replace("Jaipur","");

            ImageView imageView = view.findViewById(R.id.section_imageView1);
            Glide.with(Launcher.this).load(getResources().getDrawable(R.drawable.city_icon)).into(imageView);
            LinearLayout linearLayout = view.findViewById(R.id.section_Layout1);
            TextView textView = view.findViewById(R.id.section_name_tv1);
            textView.setText(s.trim());
            if (model.isActive) {
                linearLayout.setBackgroundResource(R.drawable.btn_bg);
                textView.setTextColor(Color.WHITE);
            } else {
                linearLayout.setBackgroundResource(R.drawable.green_outline);
                textView.setTextColor(Color.BLACK);
            }
            linearLayout.setOnClickListener(view1 -> {
                pathSharedPreferences.edit().putString("city", model.getCity()).apply();
                pathSharedPreferences.edit().putString("pathRef", model.getDbPath()).apply();
                pathSharedPreferences.edit().putString("storagePathRef", model.getStoragePath()).apply();
                pathSharedPreferences.edit().putString("key", model.getKey()).apply();
                common.wardName(getApplicationContext());
                common.getSortedMarkWardList(getApplicationContext());
                callingChangeCityOption();
                alertDialog.dismiss();
            });
            return view;
        }
    }

    private class LandingViewAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return landingList.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.landing_view_layout, null, true);
            LandingViewModel landingViewModel = landingList.get(i);
            ImageView imageView = view.findViewById(R.id.section_imageView);
            common.getEmployeeList(Launcher.this);
            Glide.with(Launcher.this).load(landingViewModel.getIconUrl()).into(imageView);
            view.findViewById(R.id.section_Layout).setOnClickListener(view1 -> {
                switch (landingViewModel.getPageId()) {
                    case 1:
                        startActivity(new Intent(Launcher.this, AccessManagementActivity.class));
                        break;
                    case 2:
                        startActivity(new Intent(Launcher.this, Employee.class));
                        break;
                    case 3:
                        startActivity(new Intent(Launcher.this, WardSelectKotlin.class));
                        break;
                    case 4:
                        startActivity(new Intent(Launcher.this, MonitoringOptionsActivity.class));
                        break;
                    case 5:
                        startActivity(new Intent(Launcher.this, BackDateDutyOff.class));
                        break;
                    case 6:
                        startActivity(new Intent(Launcher.this, ComplaintsPage.class));
                        break;
                }

            });
            TextView textView = view.findViewById(R.id.section_name_tv);
            textView.setText(landingViewModel.getPageName());
            return view;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isAllowClick = true;
        if (checkPermission) {
            checkPermission = false;
            allowPhonePermission();
        }
    }
}