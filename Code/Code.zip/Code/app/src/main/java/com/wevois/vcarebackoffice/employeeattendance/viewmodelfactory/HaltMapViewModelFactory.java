package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory;

import android.app.Activity;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.maps.SupportMapFragment;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.HaltMapViewModel;

public class HaltMapViewModelFactory implements ViewModelProvider.Factory {
    Activity activity;
    SupportMapFragment fragment;
    ImageButton deleteBtn;

    public HaltMapViewModelFactory(Activity activity, SupportMapFragment fragmentById, ImageButton employeeHaltMapDeleteBtn) {
        this.activity = activity;
        this.fragment = fragmentById;
        this.deleteBtn = employeeHaltMapDeleteBtn;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new HaltMapViewModel(activity, fragment,deleteBtn);
    }
}
