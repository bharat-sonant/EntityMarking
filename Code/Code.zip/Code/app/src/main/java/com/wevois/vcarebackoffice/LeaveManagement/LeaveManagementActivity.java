package com.wevois.vcarebackoffice.LeaveManagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.R.layout.simple_spinner_dropdown_item;

public class LeaveManagementActivity extends AppCompatActivity {
    ArrayList<Model> modelList = new ArrayList<>();
    HashMap<String,String> employeeDataMap = new HashMap<>();
    Adapter adapter = new Adapter();
    DatabaseReference rootRef;
    String year,monthName;
    Spinner leaveRequestCategorySpinner;
    Button monthYearPickerBtn;
    CommonFunctions cmnClass = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_management);
        setPageTitle();
        getEmployeeData();
        instantiate();
        setAction();
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Leave Management");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            LeaveManagementActivity.super.onBackPressed();
        });
    }

    private void instantiate(){
        ListView listView = findViewById(R.id.employee_list_leave_management_lv);
        leaveRequestCategorySpinner  = findViewById(R.id.applyFilterBtn);
        listView.setAdapter(adapter);
        monthYearPickerBtn  = findViewById(R.id.picker_in_leave_request);
        monthYearPickerBtn.setText(new SimpleDateFormat("MMM yyyy").format(new Date()));
        List<String> leaveCategoryList = new ArrayList<>();
        leaveCategoryList.add("Pending");
        leaveCategoryList.add("Approved");
        leaveCategoryList.add("Rejected");
        ArrayAdapter<String> leaveRequestCategoryAdapter = new ArrayAdapter<String>(this, simple_spinner_dropdown_item, leaveCategoryList) {
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                return view;
            }
        };
        leaveRequestCategoryAdapter.setDropDownViewResource(simple_spinner_dropdown_item);
        leaveRequestCategorySpinner.setAdapter(leaveRequestCategoryAdapter);
        year = new SimpleDateFormat("yyyy").format(new Date());
        monthName =  new SimpleDateFormat("MMMM").format(new Date());
        rootRef = cmnClass.getDatabasePath(this);
    }

    private void setAction() {
        leaveRequestCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                fetchLeaveRequests(position,year,monthName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        monthYearPickerBtn.setOnClickListener(view -> {
            MonthYearPicker pickerDialog = new MonthYearPicker();
            pickerDialog.setListener((DatePicker datePicker, int yr, int month, int i2) -> {
                try {
                    String monthYearStr = yr + "-" + (month + 1) + "-" + i2;
                    Date conversionDate =  new SimpleDateFormat("yyyy-MM-dd").parse(monthYearStr);
                    monthYearPickerBtn.setText(new SimpleDateFormat("MMM yyyy").format(conversionDate));
                    year = new SimpleDateFormat("yyyy").format(conversionDate);
                    monthName =  new SimpleDateFormat("MMMM").format(conversionDate);
                    fetchLeaveRequests(leaveRequestCategorySpinner.getSelectedItemPosition(),year,monthName);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            });
            pickerDialog.show(LeaveManagementActivity.this.getSupportFragmentManager(), "MonthYearPickerDialog");
        });
    }

    private void getEmployeeData() {
        String empData = getSharedPreferences("path", MODE_PRIVATE).getString("employeeList", " ");
        if (empData.length() > 1) {
            String[] keyValuePairs = empData.split("~");
            for (String pair : keyValuePairs) {
                String[] entry = pair.split(":");
                employeeDataMap.put(entry[0], entry[1]);
            }
        }
    }

    private void fetchLeaveRequests(int requestStatus,String y,String mn ){
        modelList.clear();
        cmnClass.setProgressDialog("","Please Wait",this,this);
        rootRef.child("LeaveManagement").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot snapshot1 : snapshot.child(y + "/" + mn).getChildren()) {
                            try {
                                if (Integer.parseInt(snapshot1.child("status").getValue().toString()) == requestStatus) {
                                    modelList.add(new Model(
                                            employeeDataMap.get(snapshot.getKey()),
                                            snapshot.getKey(),
                                            new SimpleDateFormat("dd MMM yyyy").format( new SimpleDateFormat("dd-MM-yyyy").parse(snapshot1.child("fromDate").getValue().toString())),
                                            new SimpleDateFormat("dd MMM yyyy").format( new SimpleDateFormat("dd-MM-yyyy").parse(snapshot1.child("toDate").getValue().toString())),
                                            snapshot1.child("duration").getValue().toString(),
                                            snapshot1.child("reason").getValue().toString(),
                                            snapshot1.getKey(),
                                            Integer.parseInt(snapshot1.child("status").getValue().toString())
                                    ));
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
                cmnClass.closeDialog(LeaveManagementActivity.this);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private class Model {
        String fromDate;
        String toDate;
        String duration;
        String reason;
        String empName;
        String empId;
        String leaveRequestKey;
        int leaveRequestStatus;

        public String getLeaveRequestKey() {
            return leaveRequestKey;
        }

        public String getEmpId() {
            return empId;
        }

        public void setLeaveRequestStatus(int leaveRequestStatus) {
            this.leaveRequestStatus = leaveRequestStatus;
        }

        public String getEmpName() {
            return empName;
        }

        public String getFromDate() {
            return fromDate;
        }

        public String getToDate() {
            return toDate;
        }

        public String getDuration() {
            return duration;
        }

        public String getReason() {
            return reason;
        }

        public int getLeaveRequestStatus() {
            return leaveRequestStatus;
        }

        public Model(String empName,String empId,String fromDate, String toDate, String duration, String reason,String leaveRequestKey,int leaveRequestStatus) {
            this.empName = empName;
            this.empId = empId;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.duration = duration;
            this.reason = reason;
            this.leaveRequestKey = leaveRequestKey;
            this.leaveRequestStatus = leaveRequestStatus;

        }
    }

    private class Adapter extends BaseAdapter{

        @Override
        public int getCount() {
            return modelList.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View adapterView = inflater.inflate(R.layout.employee_list_for_leave_management, null, true);
            Model model = modelList.get(i);

            TextView reasonToShowEt = adapterView.findViewById(R.id.reason_to_show_et);
            reasonToShowEt.setText(model.getReason());

            TextView fromDateToShow = adapterView.findViewById(R.id.from_date_to_show_tv);
            fromDateToShow.setText(model.getFromDate());

            TextView toDateToShow = adapterView.findViewById(R.id.to_date_to_show_tv);
            toDateToShow.setText(model.getToDate());

            TextView durationToShow = adapterView.findViewById(R.id.duration_to_show_tv);
            durationToShow.setText(model.getDuration());

            TextView requestFromTv = adapterView.findViewById(R.id.request_from_tv);
            requestFromTv.setText(model.getEmpName());

            TextView leaveStatusTv = adapterView.findViewById(R.id.leave_status_tv);
            if (model.getLeaveRequestStatus() == 1) {
                leaveStatusTv.setText("Approved");
            } else if (model.getLeaveRequestStatus() == 0) {
                leaveStatusTv.setText("Pending");
            } else {
                leaveStatusTv.setText("Rejected");
            }

            Button changeStatusBtn = adapterView.findViewById(R.id.change_status);
            changeStatusBtn.setOnClickListener(view1 -> mSaveLeaveRequest(model));
            return adapterView;
        }
    }

    private void mSaveLeaveRequest(Model model) {
        View dialog = getLayoutInflater().inflate(R.layout.leave_request_status_list_layout, null);
        AlertDialog alertDialog = new AlertDialog.Builder(this).setView(dialog).setCancelable(true).create();
        CheckBox approveLeaveRequestCheckBox = dialog.findViewById(R.id.approve_status_checkbox);
        CheckBox rejectLeaveRequestCheckBox = dialog.findViewById(R.id.reject_status_checkbox);
        TextView cancelTv = dialog.findViewById(R.id.cancel_tv);
        TextView doneTv = dialog.findViewById(R.id.done_tv);

        cancelTv.setOnClickListener(view -> alertDialog.cancel());

        switch (model.getLeaveRequestStatus()) {
            case 1:
                approveLeaveRequestCheckBox.setChecked(true);
                break;
            case 2:
                rejectLeaveRequestCheckBox.setChecked(true);
        }

        approveLeaveRequestCheckBox.setOnClickListener(view -> {
           rejectLeaveRequestCheckBox.setChecked(false);
        });

        rejectLeaveRequestCheckBox.setOnClickListener(view -> {
           approveLeaveRequestCheckBox.setChecked(false);
        });

        doneTv.setOnClickListener(view -> {
            if (approveLeaveRequestCheckBox.isChecked()){
                rootRef.child("LeaveManagement/"+model.getEmpId()+"/"+year+"/"+monthName+"/"+model.getLeaveRequestKey()+"/status").setValue("1");
                modelList.remove(model);
                alertDialog.cancel();

            }else if (rejectLeaveRequestCheckBox.isChecked()){
                rootRef.child("LeaveManagement/"+model.getEmpId()+"/"+year+"/"+monthName+"/"+model.getLeaveRequestKey()+"/status").setValue("2");
                modelList.remove(model);
                alertDialog.cancel();

            }else {
                Toast.makeText(this, "Please Select any status before proceeding", Toast.LENGTH_SHORT).show();
            }
            adapter.notifyDataSetChanged();
        });

        alertDialog.show();

    }
}