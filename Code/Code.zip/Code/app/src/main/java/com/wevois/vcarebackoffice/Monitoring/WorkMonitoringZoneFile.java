package com.wevois.vcarebackoffice.Monitoring;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.io.File;

public class WorkMonitoringZoneFile extends AppCompatActivity {
    String zoneNumber = "";
    Handler handler;
    SharedPreferences sharedPreferences;
    String date = "",storageReference="";
    long fileCreationTime;
    boolean isProgressDialog = true;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_monitoring_zone_file);

        if (getIntent() != null) {
            zoneNumber = getIntent().getStringExtra("wardNo");
            date = getIntent().getStringExtra("date");
        }
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        storageReference = sharedPreferences.getString("storagePathRef","");
        common.setProgressDialog("", "Please wait...", WorkMonitoringZoneFile.this, WorkMonitoringZoneFile.this);
        checkNetwork();
    }


    @SuppressLint("StaticFieldLeak")
    public void checkNetwork() {
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Boolean doInBackground(Void... p) {
                return common.network(WorkMonitoringZoneFile.this);
            }

            @Override
            protected void onPostExecute(Boolean result) {
                if (result) {
                    initiateFileDownload();
                } else {
                    File sdcard = Environment.getExternalStorageDirectory();
                    File file = new File(sdcard, "WardJson");
                    File checkFile = new File(file, zoneNumber + ".json");
                    if (!checkFile.exists()) {
                        if (isProgressDialog) {
                            isProgressDialog = false;
                            common.setProgressDialog("", "Check your internet connection.", WorkMonitoringZoneFile.this, WorkMonitoringZoneFile.this);
                        }
                        handler = new Handler();
                        handler.postDelayed(runnable(), 1000);
                    } else {
                        moveToMapActivity();
                    }
                }
            }
        }.execute();
    }

    private Runnable runnable() {
        return () -> checkNetwork();
    }

    public void initiateFileDownload() {
        FirebaseStorage.getInstance().getReferenceFromUrl(storageReference + "/WardJson").child(zoneNumber + ".json").getMetadata().addOnSuccessListener(storageMetadata -> {
            File file = new File(Environment.getExternalStorageDirectory(), "WardJson/" + zoneNumber + ".json");
            fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = sharedPreferences.getLong("fileDownloadTimeOne", 0);
            if (fileDownloadTime == fileCreationTime && file.exists()) {
                moveToMapActivity();
            } else {
                fileDownload();
            }
        }).addOnFailureListener(e -> {
            common.setProgressDialog("", "File not found ", this, this);
        });
    }

    public void moveToMapActivity() {
        common.closeDialog(this);
        Intent intent = new Intent(WorkMonitoringZoneFile.this, WorkMonitoringMapActivity.class);
        intent.putExtra("wardNo", zoneNumber);
        intent.putExtra("date", date);
        startActivity(intent);
        finish();
    }

    public void fileDownload() {
        File root = new File(Environment.getExternalStorageDirectory(), "WardJson");
        if (!root.exists()) {
            root.mkdirs();
        }
        final File file = new File(Environment.getExternalStorageDirectory(), "WardJson/" + zoneNumber + ".json");
        file.delete();
        FirebaseStorage.getInstance().getReferenceFromUrl(storageReference + "/WardJson").child(zoneNumber + ".json").getFile(file).addOnSuccessListener(taskSnapshot -> {
            sharedPreferences.edit().putLong("fileDownloadTimeOne", fileCreationTime).apply();
            moveToMapActivity();
        }).addOnFailureListener(exception -> {
        });
    }
}
