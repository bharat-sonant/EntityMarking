package com.wevois.vcarebackoffice.ExpenseManagement.Model;

public class VendorsListModel {
    String name;
    String mobileNumber;
    String address;
    String bankName;
    String accountNumber;
    String branch;
    String ifsc;

    public VendorsListModel(String name, String mobileNumber, String address, String bankName, String accountNumber, String branch, String ifsc) {
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.address = address;
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.branch = branch;
        this.ifsc = ifsc;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getIfsc() {
        return ifsc;
    }

    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }

    @Override
    public String toString() {
        return "VendorsListModel{" +
                "name='" + name + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                ", address='" + address + '\'' +
                ", bankName='" + bankName + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", branch='" + branch + '\'' +
                ", ifsc='" + ifsc + '\'' +
                '}';
    }
}
