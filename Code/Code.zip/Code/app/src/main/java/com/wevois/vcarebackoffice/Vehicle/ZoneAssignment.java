package com.wevois.vcarebackoffice.Vehicle;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class ZoneAssignment extends AppCompatActivity implements CustomAdapter.buttonClickListener {

    EditText vehicleNoEdit,zoneNoEdit;
    Button assign;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    String zoneNo;
    ListView vehicleZoneLV;
    ArrayList<String> vehicleNoList = new ArrayList<>();
    ArrayList<String> zoneNoList = new ArrayList<>();
    ProgressDialog progressDialog1;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zone_assignment);

        if (getSupportActionBar()!=null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        vehicleNoEdit = findViewById(R.id.vehicleNo);
        zoneNoEdit = findViewById(R.id.zoneNo);
        assign = findViewById(R.id.assignZone);
        vehicleZoneLV = findViewById(R.id.listView);
        progressDialog1=new ProgressDialog(this);
        progressDialog1.setMessage("Loading...");
        progressDialog1.setTitle("Wait");
        progressDialog1.setCancelable(false);
        progressDialog1.create();
        progressDialog1.show();

        sharedPreferences = getSharedPreferences("path",MODE_PRIVATE);

        getPath();

        final CustomAdapter customAdapter = new CustomAdapter(this,vehicleNoList,zoneNoList);
        customAdapter.setClickListener(this);
        vehicleZoneLV.setAdapter(customAdapter);

        databaseReference.child("VechicleZoneMap").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getValue()!=null) {
                    vehicleNoList.add(dataSnapshot.getKey());
                    zoneNoList.add(dataSnapshot.getValue().toString());
                    customAdapter.notifyDataSetChanged();
                    if (progressDialog1!=null){
                        if(progressDialog1.isShowing()){
                            progressDialog1.dismiss();
                        }
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getValue()!=null&&vehicleNoList.contains(dataSnapshot.getKey())) {
                    vehicleNoList.add(dataSnapshot.getKey());
                    zoneNoList.add(dataSnapshot.getValue().toString());
                    customAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                if (vehicleNoList.contains(dataSnapshot.getKey())) {
                    vehicleNoList.remove(dataSnapshot.getKey());
                    zoneNoList.remove(dataSnapshot.getValue().toString());
                    customAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String vehicleNo = vehicleNoEdit.getText().toString();
                zoneNo = zoneNoEdit.getText().toString();
                progressDialog = new ProgressDialog(ZoneAssignment.this);
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Loading...");
                progressDialog.setTitle("Wait");

                if (vehicleNo.length()>0&&zoneNo!=null) {
                    if (zoneNo.length() > 0) {
                        progressDialog.create();
                        progressDialog.show();
                        if (zoneNo.length()==1)
                            zoneNo  = "0"+zoneNo;
                        databaseReference.child("VechicleZoneMap").child(vehicleNo).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Log.i("abcd", "onDataChange:1 "+dataSnapshot);
                                if (dataSnapshot.getValue()==null){
                                    databaseReference.child("VechicleZoneMap").orderByValue().equalTo(zoneNo).addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                                            Log.i("abcd", "onDataChange: "+dataSnapshot);
                                            progressDialog.dismiss();
                                            if (dataSnapshot.getValue()==null){
                                                databaseReference.child("VechicleZoneMap").child(vehicleNo).setValue(zoneNo);
                                                vehicleNoEdit.getText().clear();
                                                zoneNoEdit.getText().clear();
                                            }
                                            else{
                                                AlertDialog.Builder builder = new AlertDialog.Builder(ZoneAssignment.this);
                                                builder.setCancelable(false);
                                                builder.setTitle(""+zoneNo+" Info");
                                                builder.setMessage("Zone No"+zoneNo+" has Already a Vehicle Assigned");
                                                builder.setPositiveButton("Duplicate", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        databaseReference.child("VechicleZoneMap").child(vehicleNo).setValue(zoneNo);
                                                        vehicleNoEdit.getText().clear();
                                                        zoneNoEdit.getText().clear();
                                                    }
                                                });
                                                builder.setNeutralButton("Replace", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        databaseReference.child("VechicleZoneMap").child(vehicleNo).setValue(zoneNo);
                                                        vehicleNoEdit.getText().clear();
                                                        zoneNoEdit.getText().clear();
                                                        for (DataSnapshot snapshot: dataSnapshot.getChildren())
                                                        {
                                                            Log.i("abcd", "onClick: "+snapshot);
                                                            String child = snapshot.getKey();
                                                            databaseReference.child("VechicleZoneMap").child(child).removeValue();
                                                        }

                                                    }
                                                });
                                                builder.setNegativeButton("Go Back", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        vehicleNoEdit.getText().clear();
                                                        zoneNoEdit.getText().clear();
                                                    }
                                                });
                                                AlertDialog dialog = builder.create();
                                                dialog.show();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                }else{
                                    progressDialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ZoneAssignment.this);
                                    builder.setCancelable(false);
                                    builder.setTitle(""+vehicleNo+" Info");
                                    builder.setMessage("Vehicle No "+vehicleNo+" has Already a Zone Assigned");
                                    builder.setPositiveButton("Replace", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            databaseReference.child("VechicleZoneMap").child(vehicleNo).setValue(zoneNo);
                                            vehicleNoEdit.getText().clear();
                                            zoneNoEdit.getText().clear();
                                        }
                                    });
                                    builder.setNegativeButton("Go Back", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            vehicleNoEdit.getText().clear();
                                            zoneNoEdit.getText().clear();
                                        }
                                    });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else {
                        zoneNoEdit.setError("Enter Zone No");
                        zoneNoEdit.setFocusable(true);
                    }
                }else {
                    vehicleNoEdit.setError("Enter Zone No");
                    vehicleNoEdit.setFocusable(true);
                }
            }
        });
    }
    private void getPath() {
        String pathRef = sharedPreferences.getString("pathRef","");
        if (pathRef.length()>2){
            databaseReference = FirebaseDatabase.getInstance(pathRef).getReference();
        } else{
            databaseReference = FirebaseDatabase.getInstance().getReference();
        }
    }
    @Override
    public void onMethodCallback(String vehicleNo, String zoneNo) {
        vehicleNoEdit.setText(vehicleNo);
        zoneNoEdit.setText(zoneNo);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}
