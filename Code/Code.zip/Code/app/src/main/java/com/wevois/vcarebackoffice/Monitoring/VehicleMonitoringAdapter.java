package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class VehicleMonitoringAdapter extends BaseAdapter {
    private Context context;

    ArrayList<VehicleMonitoringModel> vehicleList;

    public interface buttonClickListener {
        void onMethodCallback(String wardNo);
    }

    public VehicleMonitoringAdapter(Context context, ArrayList<VehicleMonitoringModel> vehicleList) {
        this.context = context;
        this.vehicleList = vehicleList;
    }

    @Override
    public int getCount() {
        return vehicleList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.vehicle_monitoring_list, null, true);


            holder.wardTv = convertView.findViewById(R.id.ward);
            holder.vehicleName = convertView.findViewById(R.id.vehicleNo);
            holder.name = convertView.findViewById(R.id.name);

            convertView.setTag(holder);
        }else {
            holder = (ViewHolder)convertView.getTag();
        }

        VehicleMonitoringModel sList = vehicleList.get(position);

        holder.wardTv.setText(sList.getWard());
        holder.vehicleName.setText(sList.getVehicle());
        holder.name.setText(sList.getName());

        return convertView;
    }

    private class ViewHolder {
        private TextView wardTv, vehicleName, name;
    }

}