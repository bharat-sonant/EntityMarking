package com.wevois.vcarebackoffice.ExpenseManagement.Model;

public class ExpenseListModel {
    String imageName;
    String vendorName;
    String billType;
    String billNo;
    String amount;
    String purchase;
    String expenseBy;
    String date;
    String VendorId;

    public ExpenseListModel(String imageName, String vendorName, String billType, String billNo, String amount, String purchase, String expenseBy, String date, String VendorId) {
        this.imageName = imageName;
        this.vendorName = vendorName;
        this.billType = billType;
        this.billNo = billNo;
        this.amount = amount;
        this.purchase = purchase;
        this.expenseBy = expenseBy;
        this.date = date;
        this.VendorId = VendorId;

    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPurchase() {
        return purchase;
    }

    public void setPurchase(String purchase) {
        this.purchase = purchase;
    }

    public String getExpenseBy() {
        return expenseBy;
    }

    public void setExpenseBy(String expenseBy) {
        this.expenseBy = expenseBy;
    }

    public String getDate() {
        return date;
    }

    public String getVendorId() {
        return VendorId;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ExpenseListModel{" +
                "imageName='" + imageName + '\'' +
                ", vendorName='" + vendorName + '\'' +
                ", billType='" + billType + '\'' +
                ", billNo='" + billNo + '\'' +
                ", amount='" + amount + '\'' +
                ", purchase='" + purchase + '\'' +
                ", expenseBy='" + expenseBy + '\'' +
                ", date='" + date + '\'' +
                ", VendorId='" + VendorId + '\'' +
                '}';
    }
}
