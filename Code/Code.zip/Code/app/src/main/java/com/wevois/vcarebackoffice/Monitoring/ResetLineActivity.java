package com.wevois.vcarebackoffice.Monitoring;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Arrays;

public class ResetLineActivity extends AppCompatActivity {

    Spinner wardSpinner;
    TextInputEditText lineNoEt;
    Button resetBtn;
    TextView currenLineTv;
    ProgressDialog progressDialog;
    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;
    String[] zoneArrayLive;

    CommonFunctions common = CommonFunctions.getInstance();

    ArrayList<String> staticZoneList;
    ArrayAdapter<String> spinnerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_line);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        zoneArrayLive = sharedPreferences.getString("wardList", "").substring(1, sharedPreferences.getString("wardList", "").length() - 1).split(", ");
        staticZoneList = new ArrayList<>(Arrays.asList(zoneArrayLive));

        wardSpinner = findViewById(R.id.wardSpinner);
        lineNoEt = findViewById(R.id.lineNo);
        resetBtn = findViewById(R.id.resetButton);
        currenLineTv = findViewById(R.id.currentLine);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        progressDialog = new ProgressDialog(ResetLineActivity.this);
        progressDialog.setTitle("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.create();

        databaseReference = common.getDatabasePath(this);

        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, staticZoneList);
        wardSpinner.setAdapter(spinnerAdapter);

        wardSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                showDialog();
                databaseReference.child("WasteCollectionInfo/LastLineCompleted").child(
                        wardSpinner.getSelectedItem().toString()).addListenerForSingleValueEvent(
                        new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.getValue() == null) {
                                    dismissProgressDialog();
                                    currenLineTv.setVisibility(View.GONE);
                                    return;
                                }
                                String msg = "Current Line No : " + dataSnapshot.getValue().toString();
                                currenLineTv.setText(msg);
                                currenLineTv.setVisibility(View.VISIBLE);
                                dismissProgressDialog();
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        }
                );
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        resetBtn.setOnClickListener(v -> {
            String lineNo = lineNoEt.getText().toString();
            if (lineNo.length() < 1) {
                lineNoEt.setError("Enter Line No");
                return;
            }
            createAlertDialog(lineNo);
        });
    }


    private void createAlertDialog(String lineNo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ResetLineActivity.this);
        builder.setTitle("Warning!!!");
        builder.setMessage("Are you sure to reset line ?");
        builder.setCancelable(false);
        builder.create();
        builder.setPositiveButton("Yes", (dialog, which) -> {
            progressDialog.show();
            databaseReference.child("WasteCollectionInfo/LastLineCompleted").child(
                    wardSpinner.getSelectedItem().toString()).setValue(lineNo);
            Toast.makeText(ResetLineActivity.this, "Line reset successfully",
                    Toast.LENGTH_SHORT).show();
            wardSpinner.setSelection(0);
            lineNoEt.setText("");
            currenLineTv.setText("");
            currenLineTv.setVisibility(View.GONE);
            dismissProgressDialog();
        });
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        builder.show();

    }

    private void showDialog() {
        if (progressDialog != null && !isFinishing()) {
            if (!progressDialog.isShowing()) {
                progressDialog.show();
            }
        }
    }

    private void dismissProgressDialog() {
        if (progressDialog != null && !isFinishing()) {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }

    @Override
    protected void onDestroy() {
        dismissProgressDialog();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}