package com.wevois.vcarebackoffice.employeeattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class NonNavigationEmpAssignment extends AppCompatActivity {
    SharedPreferences preferences,sharedPreferences;
    DatabaseReference databaseReferencePath;
    Spinner selectVehicle;
    ArrayAdapter<String> vehicleNoAdapter;
    TextView empName, empId, empDeviceName;
    String designationId = "", name = "", id = "", wardName = "",loginId;
    ArrayList<String> vehicleNoList = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    boolean isMoved = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_navigation_emp_assignment);
        initPage();
        getAvailableVehicles();
        setAction();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        TextView title = findViewById(R.id.toolbar_title);
        backButton.setOnClickListener(view -> onBackPressed());
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        loginId = sharedPreferences.getString("loginId", "101");
        preferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReferencePath = common.getDatabasePath(this);
        empName = findViewById(R.id.empNameNonNavigationReviewAssignment);
        empId = findViewById(R.id.empIdNonNavigationReviewAssignment);
        empDeviceName = findViewById(R.id.empDeviceNameNonNavigationReviewAssignment);
        selectVehicle = findViewById(R.id.spinnerVehicleForNonNavigationAssignment);
        vehicleNoList.add("NotApplicable");
        vehicleNoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, vehicleNoList);
        selectVehicle.setAdapter(vehicleNoAdapter);
        wardName = getIntent().getStringExtra("ward");
        name = getIntent().getStringExtra("empName");
        id = getIntent().getStringExtra("empId");
        designationId = getIntent().getStringExtra("designationId");
        title.setText(wardName);
        empName.setText(name);
        empId.setText(id);
        empDeviceName.setText("NotApplicable");
    }

    private void getAvailableVehicles() {
        databaseReferencePath.child("Vehicles").orderByChild("status").equalTo("1").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (designationId.equalsIgnoreCase("5")){
                            if (snapshot.hasChild("assigned-driver")){
                                if (snapshot.child("assigned-driver").getValue().toString().equalsIgnoreCase("")){
                                    vehicleNoList.add(snapshot.getKey());
                                }
                            }
                        }else {
                            if (snapshot.hasChild("assigned-helper")){
                                if (snapshot.child("assigned-helper").getValue().toString().equalsIgnoreCase("")){
                                    vehicleNoList.add(snapshot.getKey());
                                }
                            }
                        }

                    }
                    vehicleNoAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setAction() {
        findViewById(R.id.btnNonNavigationContinueForAssignment).setOnClickListener(view -> {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Vehicle की assignment चेक हो रही है |", this, this);
                checkWardAndVehicle();
            }
        });
    }

    private void checkWardAndVehicle() {
        if (!selectVehicle.getSelectedItem().toString().equalsIgnoreCase("NotApplicable")) {
            databaseReferencePath.child("Vehicles/" + selectVehicle.getSelectedItem().toString() + "/status").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue() != null) {
                        if (dataSnapshot.getValue().toString().equalsIgnoreCase("1")) {
                            checkEmployeeDetails();
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Error!", "Vehicle already assigned है |", false, NonNavigationEmpAssignment.this);
                        }
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Error!", "Vehicle नहीं मिला.", false, NonNavigationEmpAssignment.this);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }else {
            checkEmployeeDetails();
        }
    }

    private void checkEmployeeDetails() {
        databaseReferencePath.child("WorkAssignment/" + id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("current-assignment")) {
                        if (dataSnapshot.child("current-assignment").getValue().toString().equalsIgnoreCase("")) {
                            saveEmpDetails();
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Alert!", "Employee को already "+dataSnapshot.child("current-assignment").getValue().toString()+" assign है |", false, NonNavigationEmpAssignment.this);
                        }
                    } else {
                        saveEmpDetails();
                    }
                } else {
                    saveEmpDetails();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void saveEmpDetails() {
        common.setProgressDialog("", "Employee का data सेव हो रहा है |", NonNavigationEmpAssignment.this, NonNavigationEmpAssignment.this);
        final String year = new SimpleDateFormat("yyyy").format(new Date());
        final String month = new SimpleDateFormat("MMMM", Locale.US).format(new Date());
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        final String date = dateFormat1.format(new Date());
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        final String time = dateFormat.format(new Date());
        databaseReferencePath.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                long child = 1;
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.getKey().contains("task")) {
                            child++;
                        }
                    }
                }
                HashMap<String, String> dataMaps = new HashMap<>();
                dataMaps.put("device", "NotApplicable");
                dataMaps.put("task", wardName);
                dataMaps.put("status", "2");
                dataMaps.put("task-assigned-by", loginId);
                dataMaps.put("vehicle", selectVehicle.getSelectedItem().toString());
                long finalChild = child;
                databaseReferencePath.child("DailyWorkDetail/" + year + "/" + month + "/" + date+"/"+id+"/card-swap-entries/"+time).setValue("In");
                databaseReferencePath.child("DailyWorkDetail/" + year + "/" + month + "/" + date+"/"+id+"/task"+child).setValue(dataMaps).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        databaseReferencePath.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + id).child("task" + finalChild).child("in-out/" + time).setValue("In");
                        HashMap<String, String> datas = new HashMap<>();
                        datas.put("current-assignment", wardName);
                        datas.put("vehicle", selectVehicle.getSelectedItem().toString());
                        datas.put("device", "NotApplicable");
                        databaseReferencePath.child("WorkAssignment/" + id).setValue(datas).addOnCompleteListener(tasks -> {
                            if (tasks.isSuccessful()) {
                                databaseReferencePath.child("RealTimeDetails/peopleOnWork").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        int activeEmp = 0;
                                        if (dataSnapshot.getValue() != null) {
                                            activeEmp = Integer.parseInt(dataSnapshot.getValue().toString());
                                        }
                                        databaseReferencePath.child("RealTimeDetails/peopleOnWork").setValue("" + (activeEmp + 1)).addOnCompleteListener(task1 -> {
                                            if (task1.isSuccessful()){
                                                if (!selectVehicle.getSelectedItem().toString().equalsIgnoreCase("NotApplicable")) {
                                                    databaseReferencePath.child("Vehicles/" + selectVehicle.getSelectedItem().toString()).addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                            if (dataSnapshot.getValue() != null) {
                                                                String status = "3", idString = "";
                                                                if (designationId.equalsIgnoreCase("5")) {
                                                                    idString = "assigned-driver";
                                                                    if (dataSnapshot.hasChild("assigned-helper")) {
                                                                        if (dataSnapshot.child("assigned-helper").getValue().toString().equalsIgnoreCase("")) {
                                                                            status = "1";
                                                                        }
                                                                    }
                                                                } else {
                                                                    idString = "assigned-helper";
                                                                    if (dataSnapshot.hasChild("assigned-driver")) {
                                                                        if (dataSnapshot.child("assigned-driver").getValue().toString().equalsIgnoreCase("")) {
                                                                            status = "1";
                                                                        }
                                                                    }
                                                                }
                                                                HashMap<String, Object> dataMapVehicles = new HashMap<>();
                                                                dataMapVehicles.put(idString, id);
                                                                dataMapVehicles.put("assigned-task", wardName);
                                                                dataMapVehicles.put("status", status);
                                                                databaseReferencePath.child("Vehicles/" + selectVehicle.getSelectedItem().toString()).updateChildren(dataMapVehicles).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        if (task.isSuccessful()) {
                                                                            finishActivity();
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                isMoved = true;
                                                                common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationEmpAssignment.this);
                                                            }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                        }
                                                    });
                                                }else {
                                                    finishActivity();
                                                }
                                            }else {
                                                isMoved = true;
                                                common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationEmpAssignment.this);
                                            }
                                        });
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }else {
                                isMoved = true;
                                common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationEmpAssignment.this);
                            }
                        });
                    }else {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "Employee data सेव नहीं हुआ |", false, NonNavigationEmpAssignment.this);
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void finishActivity() {
        common.closeDialog(NonNavigationEmpAssignment.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(NonNavigationEmpAssignment.this);
        builder.setTitle("Info!!!");
        builder.setCancelable(false);
        builder.setMessage("सफलतापूर्वक assignment हो चूका है |");
        builder.setPositiveButton("Ok", (dialog, which) -> {
            dialog.dismiss();
            Intent intent = new Intent(NonNavigationEmpAssignment.this, WardSelectKotlin.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            Bundle options = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
            startActivity(intent, options);
            finish();
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}