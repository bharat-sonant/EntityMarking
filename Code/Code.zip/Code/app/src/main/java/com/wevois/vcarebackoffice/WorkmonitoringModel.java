package com.wevois.vcarebackoffice;

public class WorkmonitoringModel{
    String ward,drivername,helpername,vehiclename,driverid,helperid,deviceDriver,Devicehelper,Status;
    public WorkmonitoringModel(String ward, String drivername, String helpername, String vehiclename, String driverid, String helperid, String deviceDriver, String devicehelper, String status) {
        this.ward = ward;
        this.drivername = drivername;
        this.helpername = helpername;
        this.vehiclename = vehiclename;
        this.driverid = driverid;
        this.helperid = helperid;
        this.deviceDriver = deviceDriver;
        Devicehelper = devicehelper;
        Status = status;
    }

    public WorkmonitoringModel(String ward, String drivername, String helpername, String vehiclename, String[] driverids, String helperid, String driverdevices, String helperdevices, String status) {
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        this.drivername = drivername;
    }

    public String getHelpername() {
        return helpername;
    }

    public void setHelpername(String helpername) {
        this.helpername = helpername;
    }

    public String getVehiclename() {
        return vehiclename;
    }

    public void setVehiclename(String vehiclename) {
        this.vehiclename = vehiclename;
    }

    public String getDriverid() {
        return driverid;
    }

    public void setDriverid(String driverid) {
        this.driverid = driverid;
    }

    public String getHelperid() {
        return helperid;
    }

    public void setHelperid(String helperid) {
        this.helperid = helperid;
    }

    public String getDeviceDriver() {
        return deviceDriver;
    }

    public void setDeviceDriver(String deviceDriver) {
        this.deviceDriver = deviceDriver;
    }

    public String getDevicehelper() {
        return Devicehelper;
    }

    public void setDevicehelper(String devicehelper) {
        Devicehelper = devicehelper;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
