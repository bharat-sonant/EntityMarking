package com.wevois.vcarebackoffice.Monitoring;

public class VehicleMonitoringModel {
    String vehicle;
    String ward;
    String name;

    public VehicleMonitoringModel(String vehicle, String ward, String name) {
        this.vehicle = vehicle;
        this.ward = ward;
        this.name = name;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getWard() {
        return ward;
    }

    public String getName() {
        return name;
    }
}
