package com.wevois.vcarebackoffice.EmployeeData;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class ItemAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> itemName;
    private ArrayList<String> date;
    public interface buttonClickListener{
        void onMethodCallBack(int position);
    }
    private buttonClickListener clickListener;
    public void setOnClickListener(buttonClickListener listener){
        this.clickListener = listener;
    }

    ItemAdapter(Context context, ArrayList<String> itemName, ArrayList<String> date) {
        this.context = context;
        this.itemName = itemName;
        this.date = date;
    }

    @Override
    public int getCount() {
        return itemName.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView==null){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.add_inventory_item_row,
                    parent,false);

            viewHolder.dateTv = convertView.findViewById(R.id.date);
            viewHolder.nameTv = convertView.findViewById(R.id.itemName);
            viewHolder.deleteItem = convertView.findViewById(R.id.deleteItem);

            convertView.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (position<itemName.size()){
            viewHolder.dateTv.setText(date.get(position));
            viewHolder.nameTv.setText(itemName.get(position));
        }

        viewHolder.deleteItem.setOnClickListener(v -> {
            clickListener.onMethodCallBack(position);
        });

        return convertView;
    }
    @Override
    public int getViewTypeCount() {
        if (getCount() > 0) {
            return getCount();
        } else {
            return super.getViewTypeCount();
        }
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    private class ViewHolder{
        TextView nameTv, dateTv;
        ImageView deleteItem;
    }
}
