package com.wevois.vcarebackoffice.VehicleManagement.Views;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.VehicleManagement.Adapter.RetrieveAdapter;

import java.util.ArrayList;

public class TotalVehicles extends AppCompatActivity {
    private Boolean isBackClick = true;

    TextView back;
    ListView vehicleList;
    ArrayList<String> arrayList = new ArrayList<>();
    RetrieveAdapter adapter;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_vehicles);

        initMethod();
        setAction();
        dataFetch();
    }

    private void initMethod() {
        back = findViewById(R.id.back);
        vehicleList = (ListView) findViewById(R.id.vehicleListView);
        adapter = new RetrieveAdapter(TotalVehicles.this, arrayList);
        vehicleList.setAdapter(adapter);
    }

    private void setAction() {
        back.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });
    }

    public void dataFetch() {
        common.setProgressDialog("Please Wait...", "Downloading Data...", this, this);

        common.getDatabasePath(this).child("Vehicles").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.getValue() != null) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        arrayList.add(dataSnapshot.getKey());
                    }
                    adapter.notifyDataSetChanged();
                }
                common.closeDialog(TotalVehicles.this);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
    }
}

