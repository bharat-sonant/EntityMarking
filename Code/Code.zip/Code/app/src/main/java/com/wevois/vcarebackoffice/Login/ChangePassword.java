package com.wevois.vcarebackoffice.Login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.Objects;

public class ChangePassword extends AppCompatActivity {
    TextInputEditText oldPassEt, newPassEt;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        setPageTitle();

        oldPassEt = findViewById(R.id.oldPassEt);
        newPassEt = findViewById(R.id.newPassEt);

        findViewById(R.id.saveBtn).setOnClickListener(v -> {
            SharedPreferences sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
            String id = sharedPreferences.getString("loginId", " ");
            String oldPassword = Objects.requireNonNull(oldPassEt.getText()).toString().trim();
            String newPassword = Objects.requireNonNull(newPassEt.getText()).toString().trim();
            if (oldPassword.length() > 2) {
                if (newPassword.length() > 2) {
                    verifyDetails(id, oldPassword, newPassword);
                } else {
                    newPassEt.setError("Password min length is 3");
                    newPassEt.requestFocus();
                }
            } else {
                oldPassEt.setError("Enter proper password");
                oldPassEt.requestFocus();
            }
        });
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Change Password");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> ChangePassword.super.onBackPressed());
    }

    private void verifyDetails(String id, String oldPassword, String newPassword) {
        common.setProgressDialog("Checking...", "", this, this);
        common.getDatabasePath(this).child("Employees/" + id + "/GeneralDetails").addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null) {
                            clearInputs();
                            common.showAlertDialog("Alert", "ID does not exist", false, ChangePassword.this);
                            common.closeDialog(ChangePassword.this);
                            return;
                        }
                        if (dataSnapshot.hasChild("password")) {
                            String password = Objects.requireNonNull(dataSnapshot.child("password")
                                    .getValue()).toString();
                            try {
                                if (oldPassword.equals(common.decrypt(password, id))) {
                                    String encPass = common.encrypt(newPassword, id);
                                    dataSnapshot.child("password").getRef().setValue(encPass);
                                    clearInputs();
                                    Toast.makeText(ChangePassword.this,
                                            "Password Updated Successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(ChangePassword.this, LoginSignUp.class));
                                    finish();
                                } else {
                                    clearInputs();
                                    oldPassEt.setError("Wrong password");
                                    oldPassEt.requestFocus();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            clearInputs();
                            oldPassEt.setError("Database issue");
                            oldPassEt.requestFocus();
                        }
                        common.closeDialog(ChangePassword.this);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                }
        );
    }

    private void clearInputs() {
        Objects.requireNonNull(oldPassEt.getText()).clear();
        Objects.requireNonNull(newPassEt.getText()).clear();
    }
}