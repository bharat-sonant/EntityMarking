package com.wevois.vcarebackoffice.Monitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class VersionMonitoringActivity extends AppCompatActivity {
    ListView versionLv;
    TextView versionTv;
    List<String> wardList = new ArrayList<>();
    VersionMonitoringAdapter versionAdapter;
    DatabaseReference databaseReferencePath;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences sharedPreferences;
    ArrayList<VersionMonitoringModel> versionList = new ArrayList<>();
    String navigatorVersion = "", readerVersion = "", city = "";
    Spinner selectApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_version_monitoring);

        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        databaseReferencePath = common.getDatabasePath(this);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        city = sharedPreferences.getString("city", "");
        selectApp = findViewById(R.id.selectAppType);
        versionLv = findViewById(R.id.versionLv);
        versionTv = findViewById(R.id.versionTv);
        versionAdapter = new VersionMonitoringAdapter(this, versionList);
        versionLv.setAdapter(versionAdapter);
        bindAppToSpinner();
    }

    private void bindAppToSpinner() {
        wardList.add("NavigatorApp");
        wardList.add("ReaderApp");
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, wardList) {
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                return view;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectApp.setAdapter(spinnerArrayAdapter);
        selectApp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                common.setProgressDialog("Please wait...", "Loading...", VersionMonitoringActivity.this, VersionMonitoringActivity.this);
                getVersionData();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void getVersionData() {
        databaseReferencePath.child("Settings/LatestVersions").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("navigator")) {
                        navigatorVersion = dataSnapshot.child("navigator").getValue().toString();
                    }
                    if (dataSnapshot.hasChild("reader")) {
                        readerVersion = dataSnapshot.child("reader").getValue().toString();
                    }
                    if (selectApp.getSelectedItem().equals("NavigatorApp")){
                        versionTv.setText("Current Version\n"+navigatorVersion);
                    }else {
                        versionTv.setText("Current Version\n"+readerVersion);
                    }
                    getDeviceId();
                } else {
                    common.showAlertDialog("Info!", "Data not found today", true, VersionMonitoringActivity.this);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getDeviceId() {
        versionList.clear();
        databaseReferencePath.child("Devices/" + city).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    int i=1;
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                        if (selectApp.getSelectedItem().toString().equals("NavigatorApp")){
                            if (snapshot.hasChild("appType")&&snapshot.hasChild("navigatorAppVersion")&& snapshot.hasChild("name")){
                                if (snapshot.child("appType").getValue().toString().equals("1")){
                                    String deviceName = "",navigator="",status="1";
                                    deviceName = snapshot.child("name").getValue().toString();
                                    navigator = snapshot.child("navigatorAppVersion").getValue().toString();
                                    if (navigator.equals(navigatorVersion)){
                                        status = "2";
                                    }
                                    versionList.add(new VersionMonitoringModel(""+i,deviceName,navigator,status));
                                    i++;
                                }
                            }
                        }
                        else {
                            if (snapshot.hasChild("appType")&&snapshot.hasChild("readerAppVersion")&& snapshot.hasChild("name")){
                                if (snapshot.child("appType").getValue().toString().equals("2")){
                                    String deviceName = "",reader="",status="1";
                                    deviceName = snapshot.child("name").getValue().toString();
                                    reader = snapshot.child("readerAppVersion").getValue().toString();
                                    if (reader.equals(readerVersion)){
                                        status = "2";
                                    }
                                    versionList.add(new VersionMonitoringModel(""+i,deviceName,reader,status));
                                    i++;
                                }
                            }
                        }
                    }
                    common.closeDialog(VersionMonitoringActivity.this);
                    Collections.sort(versionList, (obj1, obj2) -> obj1.device.compareToIgnoreCase(obj2.device));
                    versionAdapter.notifyDataSetChanged();
                } else {
                    common.showAlertDialog("Info!", "Data not found today", true, VersionMonitoringActivity.this);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
