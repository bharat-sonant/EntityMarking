package com.wevois.vcarebackoffice.EmployeeData;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.transition.AutoTransition;
import androidx.transition.TransitionManager;

import android.os.Environment;
import android.os.Handler;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.siyamed.shapeimageview.RoundedImageView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import uk.co.senab.photoview.PhotoViewAttacher;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;
import static android.content.Context.MODE_PRIVATE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class IdentificationDetailFragment extends Fragment {
    Button nextBtn;
    Bitmap thumbnailFrontAadhar, thumbnailBackAadhar, thumbnailPan,thumbnailLicence;
    private Camera mCamera;
    private SurfaceView surfaceView;
    Camera.PictureCallback pictureCallback;
    public Context context;
    boolean isApproved = false,isPass = true;
    DatabaseReference rootRef;
    StorageReference mStorageRef;
    CardView cardView, cardView2,cardView3;
    EditText aadharNumber, panNumber;
    Button uploadAadharFrontBtn, uploadAadharBackBtn, uploadPanBtn,uploadLicenceBtn;
    RoundedImageView aadharFrontPhotoIv, aadharBackPhotoIv, panPhotoIv,licencePhotoIv;
    TextView btnIcon, btnIcon2,btnIcon3, aadharFrontPhotoTv, aadharBackPhotoTv, panPhotoTv,licenceTv;
    LinearLayout expand, expand2,expand3, expandable, expandable2,expandable3;
    String empId, from;
    SharedPreferences sharedPreferences, preferences;
    HashMap<String, Object> aadharDetailsMap = new HashMap<>();
    HashMap<String, Object> panDetailsMap = new HashMap<>();
    HashMap<String, Object> licenceDetailsMap = new HashMap<>();
    CommonFunctions cmn = CommonFunctions.getInstance();
    private static final int IMAGE_CAPTURE_CODE = 1001;
    private static final int IMAGE_CAPTURE_CODE1 = 1000;
    private static final int IMAGE_CAPTURE_CODE2 = 1002;
    private static final int IMAGE_CAPTURE_CODE3 = 1003;
    private static final int PERMISSION_CODE = 1000;
    private static final int PERMISSION_CODE1 = 1001;
    private static final int PERMISSION_CODE2 = 1002;
    private static final int PERMISSION_CODE3 = 1003;
    private static final int FOCUS_AREA_SIZE = 300;

    public IdentificationDetailFragment() {
    }

    public static IdentificationDetailFragment newInstance() {
        return new IdentificationDetailFragment();
    }

    @Override
    public void onAttach(@NonNull Context ctx) {
        super.onAttach(ctx);
        context = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_identification_detail, container, false);
        getBundle();
        inIt(view);
        uploadAadharFrontBtn.setOnClickListener(view1 -> {
            cameraPermission(IMAGE_CAPTURE_CODE,PERMISSION_CODE);
        });
        uploadAadharBackBtn.setOnClickListener(view1 -> {
            cameraPermission(IMAGE_CAPTURE_CODE1,PERMISSION_CODE1);
        });
        uploadPanBtn.setOnClickListener(view1 -> {
            cameraPermission(IMAGE_CAPTURE_CODE2,PERMISSION_CODE2);
        });
        uploadLicenceBtn.setOnClickListener(view1 -> {
            cameraPermission(IMAGE_CAPTURE_CODE3,PERMISSION_CODE3);
        });
        nextBtn.setOnClickListener(view13 -> {
            if (isApproved) {
                if (preferences.getBoolean("isAccountant", false)) {
                    setNextBtn();
                } else {
                    cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your supervisor.", false, context);
                }
            } else {
                setNextBtn();
            }
        });
        aadharBackPhotoIv.setOnLongClickListener(view1 -> {
            if (preferences.getBoolean("isAccountant", false)) {
                if (aadharDetailsMap.get("aadharBackPhotoUrl").toString().length() > 0) {
                    cmn.setProgressDialog("Please Wait", "Image downloading...", context, (Activity) context);
                    new GetImages("aadharback").execute();
                } else {
                    cmn.showAlertDialog("Warning !", "Image Url not found. \n please contact to your supervisor.", false, context);
                }
            }
            return true;
        });
        aadharFrontPhotoIv.setOnLongClickListener(view1 -> {
            if (preferences.getBoolean("isAccountant", false)) {
                if (String.valueOf(aadharDetailsMap.get("aadharFrontPhotoUrl")).length() > 0) {
                    cmn.setProgressDialog("Please Wait", "Image downloading...", context, (Activity) context);
                    new GetImages("aadharfront").execute();
                } else {
                    cmn.showAlertDialog("Warning !", "Image Url not found. \n please contact to your supervisor.", false, context);
                }
            }
            return true;
        });
        panPhotoIv.setOnLongClickListener(view1 -> {
            if (preferences.getBoolean("isAccountant", false)) {
                if (panDetailsMap.get("panPhotoUrl").toString().length() > 0) {
                    cmn.setProgressDialog("Please Wait", "Image downloading...", context, (Activity) context);
                    new GetImages("pan").execute();
                } else {
                    cmn.showAlertDialog("Warning !", "Image Url not found. \n please contact to your supervisor.", false, context);
                }
            }
            return true;
        });
        licencePhotoIv.setOnLongClickListener(view1 -> {
            if (preferences.getBoolean("isAccountant", false)) {
                if (licenceDetailsMap.get("licencePhotoUrl").toString().length() > 0) {
                    cmn.setProgressDialog("Please Wait", "Image downloading...", context, (Activity) context);
                    new GetImages("pan").execute();
                } else {
                    cmn.showAlertDialog("Warning !", "Image Url not found. \n please contact to your supervisor.", false, context);
                }
            }
            return true;
        });
        return view;
    }

    private void cameraPermission(int imageCaptureCode, int permissionCode){
        if (isPass){
            isPass =false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, permissionCode);
                } else {
                    showAlertDialog(imageCaptureCode);
                }
            }
        }

    }

    private class GetImages extends AsyncTask<Object, Object, Object> {
        Bitmap bitmaps;
        String back = "";

        public GetImages(String back) {
            this.back = back;
        }

        @Override
        protected Object doInBackground(Object... objects) {
            try {
                URL url;
                if (back.equalsIgnoreCase("pan")) {
                    url = new URL(panDetailsMap.get("panPhotoUrl").toString());
                } else if (back.equalsIgnoreCase("licence")) {
                    url = new URL(licenceDetailsMap.get("licencePhotoUrl").toString());
                } else {
                    if (back.equalsIgnoreCase("aadharback")) {
                        url = new URL(aadharDetailsMap.get("aadharBackPhotoUrl").toString());
                    } else {
                        url = new URL(aadharDetailsMap.get("aadharFrontPhotoUrl").toString());
                    }
                }
                URLConnection conn = url.openConnection();
                bitmaps = BitmapFactory.decodeStream(conn.getInputStream());
            } catch (Exception ex) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            try {
                File root = new File(Environment.getExternalStorageDirectory(), "Employee/" + empId);
                if (!root.exists()) {
                    root.mkdirs();
                }
                File wardFile = new File(root, back + ".jpg");
                try {
                    FileOutputStream out = new FileOutputStream(wardFile);
                    bitmaps.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    out.flush();
                    out.close();
                    cmn.showAlertDialog("", "Successfully save.", false, context);
                } catch (Exception e) {
                    e.printStackTrace();
                    cmn.showAlertDialog("Alert", "Please Retry", false, context);
                }
            } catch (Exception e) {
                cmn.showAlertDialog("Alert", "Please Retry", false, context);
            }
            cmn.closeDialog((Activity) context);
        }
    }

    private void getBundle() {
        if (getArguments() != null) {
            empId = getArguments().getString("empId", " ");
            from = getArguments().getString("from", " ");
        } else {
            cmn.showAlertDialog("Please Retry", "", false, context);
        }
    }

    private void inIt(View view) {
        preferences = context.getSharedPreferences("loginData", MODE_PRIVATE);
        expand = view.findViewById(R.id.identification_expand);
        expand2 = view.findViewById(R.id.identification_expand2);
        expand3 = view.findViewById(R.id.identification_expand3);
        expandable = view.findViewById(R.id.identification_expandable);
        expandable2 = view.findViewById(R.id.identification_expandable2);
        expandable3 = view.findViewById(R.id.identification_expandable3);
        cardView = view.findViewById(R.id.identification_card);
        cardView2 = view.findViewById(R.id.identification_card2);
        cardView3 = view.findViewById(R.id.identification_card3);
        nextBtn = view.findViewById(R.id.next_identification);
        btnIcon = view.findViewById(R.id.identification_btn_icon);
        btnIcon2 = view.findViewById(R.id.identification_btn_icon2);
        btnIcon3 = view.findViewById(R.id.identification_btn_icon3);
        aadharNumber = view.findViewById(R.id.aadhar_number_et);
        panNumber = view.findViewById(R.id.pan_number_et);
        aadharFrontPhotoIv = view.findViewById(R.id.aadhar_front_card_photo);
        aadharBackPhotoIv = view.findViewById(R.id.aadhar_back_card_photo);
        panPhotoIv = view.findViewById(R.id.pan_card_photo);
        licencePhotoIv = view.findViewById(R.id.licence_photo);
        uploadAadharFrontBtn = view.findViewById(R.id.aadhar_card_front_upload_btn);
        uploadAadharBackBtn = view.findViewById(R.id.aadhar_card_back_upload_btn);
        uploadPanBtn = view.findViewById(R.id.pan_card_upload_btn);
        uploadLicenceBtn = view.findViewById(R.id.licence_upload_btn);
        aadharFrontPhotoTv = view.findViewById(R.id.aadhar_front_photo_tv);
        aadharBackPhotoTv = view.findViewById(R.id.aadhar_back_photo_tv);
        panPhotoTv = view.findViewById(R.id.pan_photo_tv);
        licenceTv = view.findViewById(R.id.licence_tv);
        sharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
        rootRef = cmn.getDatabasePath(getContext());
        mStorageRef = FirebaseStorage.getInstance().getReferenceFromUrl(cmn.getDatabaseStorage(context));
        SetExpandableCardView();

        if (from.equals("edit") || sharedPreferences.getBoolean("Identification", false)) {
            setDefaults();
        } else {
            cmn.closeDialog((Activity) context);
        }

        rootRef.child("Employees/" + empId + "/OtherDetails/isApproved").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("true")) {
                        isApproved = true;
                    } else {
                        isApproved = false;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        rootRef.child("Employees/" + empId + "/GeneralDetails/designationId").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("5")) {
                        cardView3.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void SetExpandableCardView() {
        TransitionManager.beginDelayedTransition(cardView, new AutoTransition());
        expand.setOnClickListener(view1 -> {
            if (expandable.getVisibility() == View.GONE) {
                expandable.setVisibility(View.VISIBLE);
                expandable2.setVisibility(View.GONE);
                expandable3.setVisibility(View.GONE);
                btnIcon.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            } else {
                expandable.setVisibility(View.GONE);
                btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            }
        });
        expand2.setOnClickListener(view1 -> {
            if (expandable2.getVisibility() == View.GONE) {
                expandable2.setVisibility(View.VISIBLE);
                expandable.setVisibility(View.GONE);
                expandable3.setVisibility(View.GONE);
                btnIcon2.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            } else {
                expandable2.setVisibility(View.GONE);
                btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            }
        });
        expand3.setOnClickListener(view1 -> {
            if (expandable3.getVisibility() == View.GONE) {
                expandable3.setVisibility(View.VISIBLE);
                expandable.setVisibility(View.GONE);
                expandable2.setVisibility(View.GONE);
                btnIcon3.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            } else {
                expandable3.setVisibility(View.GONE);
                btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            }
        });
    }

    private void focusOnTouch(MotionEvent event) throws Exception {
        if (mCamera != null) {
            try {
                Camera.Parameters parameters = mCamera.getParameters();
                if (parameters.getMaxNumMeteringAreas() > 0) {
                    parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                    Rect rect = calculateFocusArea(event.getX(), event.getY());
                    List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
                    meteringAreas.add(new Camera.Area(rect, 800));
                    parameters.setFocusAreas(meteringAreas);
                    mCamera.setParameters(parameters);
                }
                mCamera.autoFocus((success, camera) -> {

                });

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private Rect calculateFocusArea(float x, float y) {
        int left = clamp(Float.valueOf((x / surfaceView.getWidth()) * 2000 - 1000).intValue());
        int top = clamp(Float.valueOf((y / surfaceView.getHeight()) * 2000 - 1000).intValue());

        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private int clamp(int touchCoordinateInCameraReper) {
        int result;
        if (Math.abs(touchCoordinateInCameraReper) + FOCUS_AREA_SIZE / 2 > 1000) {
            if (touchCoordinateInCameraReper > 0) {
                result = 1000 - FOCUS_AREA_SIZE / 2;
            } else {
                result = -1000 + FOCUS_AREA_SIZE / 2;
            }
        } else {
            result = touchCoordinateInCameraReper - FOCUS_AREA_SIZE / 2;
        }
        return result;
    }

    public static void setCameraDisplayOrientation(Activity activity, int cameraId, android.hardware.Camera camera) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = activity.getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
        }
    }

    public void showAlertDialog(int IMAGE_CAPTURE_CODE_SHOW) {
        LayoutInflater inflater = getLayoutInflater();
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        View dialogLayout = inflater.inflate(R.layout.custom_camera_alertbox, null);
        alertDialog.setView(dialogLayout);
        alertDialog.setCancelable(false);
        final AlertDialog dialog = alertDialog.create();
        surfaceView = (SurfaceView) dialogLayout.findViewById(R.id.surfaceViews);
        SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_HARDWARE);
        SurfaceHolder.Callback surfaceViewCallBack = new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    mCamera = Camera.open();
                    Camera.Parameters parameters;
                    parameters = mCamera.getParameters();
                    List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
                    parameters.setPictureSize(sizes.get(0).width, sizes.get(0).height);
                    mCamera.setParameters(parameters);
                    setCameraDisplayOrientation(getActivity(), 0, mCamera);
                    mCamera.setPreviewDisplay(surfaceHolder);
                    mCamera.startPreview();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

            }
        };
        surfaceHolder.addCallback(surfaceViewCallBack);
        Button btn = dialogLayout.findViewById(R.id.capture_image_btn);
        btn.setOnClickListener(v -> mCamera.takePicture(null, null, null, pictureCallback));
        Button closeBtn = dialogLayout.findViewById(R.id.close_image_btn);
        closeBtn.setOnClickListener(v -> {
            dialog.cancel();
            isPass = true;
        });
        dialog.show();

        pictureCallback = (bytes, camera) -> {
            if (IMAGE_CAPTURE_CODE_SHOW == IMAGE_CAPTURE_CODE) {
                Matrix matrix = new Matrix();
                matrix.postRotate(90F);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmaps = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), matrix, true);
                thumbnailFrontAadhar = Bitmap.createScaledBitmap(bitmaps, 400, 600, false);
                aadharFrontPhotoTv.setVisibility(View.GONE);
                aadharFrontPhotoIv.setImageBitmap(thumbnailFrontAadhar);
            } else if (IMAGE_CAPTURE_CODE_SHOW == IMAGE_CAPTURE_CODE1) {
                Matrix matrix = new Matrix();
                matrix.postRotate(90F);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmaps = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), matrix, true);
                thumbnailBackAadhar = Bitmap.createScaledBitmap(bitmaps, 400, 600, false);
                aadharBackPhotoTv.setVisibility(View.GONE);
                aadharBackPhotoIv.setImageBitmap(thumbnailBackAadhar);
            } else if (IMAGE_CAPTURE_CODE_SHOW == IMAGE_CAPTURE_CODE2) {
                Matrix matrix = new Matrix();
                matrix.postRotate(90F);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmaps = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), matrix, true);
                thumbnailPan = Bitmap.createScaledBitmap(bitmaps, 400, 600, false);
                panPhotoTv.setVisibility(View.GONE);
                panPhotoIv.setImageBitmap(thumbnailPan);
            }else if (IMAGE_CAPTURE_CODE_SHOW == IMAGE_CAPTURE_CODE3) {
                Matrix matrix = new Matrix();
                matrix.postRotate(90F);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmaps = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), matrix, true);
                thumbnailLicence = Bitmap.createScaledBitmap(bitmaps, 400, 600, false);
                licenceTv.setVisibility(View.GONE);
                licencePhotoIv.setImageBitmap(thumbnailLicence);
            }
            camera.stopPreview();
            if (camera != null) {
                camera.release();
                mCamera = null;
            }
            dialog.cancel();
            isPass = true;
        };

        surfaceView.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                try {
                    focusOnTouch(motionEvent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return false;
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        new Handler().post(() -> {
            if (requestCode == PERMISSION_CODE) {
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    showAlertDialog(IMAGE_CAPTURE_CODE);
                } else {
                    isPass = true;
                    Toast.makeText(context, "Permissiondenied...", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == PERMISSION_CODE1) {
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    showAlertDialog(IMAGE_CAPTURE_CODE1);
                } else {
                    isPass = true;
                    Toast.makeText(context, "Permissiondenied...", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == PERMISSION_CODE2) {
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    showAlertDialog(IMAGE_CAPTURE_CODE2);
                } else {
                    isPass = true;
                    Toast.makeText(context, "Permissiondenied...", Toast.LENGTH_SHORT).show();
                }
            }else if (requestCode == PERMISSION_CODE3) {
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    showAlertDialog(IMAGE_CAPTURE_CODE3);
                } else {
                    isPass = true;
                    Toast.makeText(context, "Permissiondenied...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void uploadFrontAadharImage() {
        new Handler().post(() -> {
            if (thumbnailFrontAadhar != null) {
                final StorageReference mountainImagesRef = mStorageRef.child("/EmployeeImage" + "/" + empId + "/" + "aadharFrontCard.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnailFrontAadhar.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    if (uri != null) {
                        aadharDetailsMap.put("aadharFrontPhotoUrl", uri.toString());
                        uploadBackAadharImage();
                    }
                }).addOnFailureListener(e ->
                        cmn.showAlertDialog("Alert", "Please Retry", false, context)));
            } else {
                uploadBackAadharImage();
            }
        });
    }

    private void uploadBackAadharImage() {
        new Handler().post(() -> {
            if (thumbnailBackAadhar != null) {
                final StorageReference mountainImagesRef = mStorageRef.child("/EmployeeImage" + "/" + empId + "/" + "aadharBackCard.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnailBackAadhar.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    if (uri != null) {
                        aadharDetailsMap.put("aadharBackPhotoUrl", uri.toString());
                        UploadPanImage();
                    }
                }).addOnFailureListener(e ->
                        cmn.showAlertDialog("Alert", "Please Retry", false, context)));
            } else {
                UploadPanImage();
            }
        });
    }

    private void UploadPanImage() {
        new Handler().post(() -> {
            if (thumbnailPan != null) {
                final StorageReference mountainImagesRef = mStorageRef.child("/EmployeeImage" + "/" + empId + "/" + "panCard.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnailPan.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    if (uri != null) {
                        panDetailsMap.put("panPhotoUrl", uri.toString());
                        if (thumbnailLicence!=null) {
                            UploadLicenceImage();
                        }else {
                            UploadEmpInfo();
                        }
                    }
                }).addOnFailureListener(e -> cmn.showAlertDialog("Alert", "Please Retry", false, context)
                ));
            } else {
                if (thumbnailLicence!=null) {
                    UploadLicenceImage();
                }else {
                    UploadEmpInfo();
                }
            }
        });
    }

    private void UploadLicenceImage() {
        new Handler().post(() -> {
            if (thumbnailLicence != null) {
                final StorageReference mountainImagesRef = mStorageRef.child("/EmployeeImage" + "/" + empId + "/" + "licence.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnailLicence.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    if (uri != null) {
                        licenceDetailsMap.put("licencePhotoUrl", uri.toString());
                        UploadEmpInfo();
                    }
                }).addOnFailureListener(e -> cmn.showAlertDialog("Alert", "Please Retry", false, context)
                ));
            } else {
                UploadEmpInfo();
            }
        });
    }

    private void setDefaults() {
        cmn.setProgressDialog("Please Wait", "PreparingData", context, (Activity) context);
        rootRef.child("Employees").child(empId).child("IdentificationDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("AadharCardDetails").hasChild("aadharNumber")) {
                    aadharDetailsMap.put("aadharNumber", dataSnapshot.child("AadharCardDetails").child("aadharNumber").getValue());
                    aadharNumber.setText(String.valueOf(aadharDetailsMap.get("aadharNumber")));
                }
                if (dataSnapshot.child("AadharCardDetails").hasChild("aadharFrontPhotoUrl")) {
                    aadharDetailsMap.put("aadharFrontPhotoUrl", dataSnapshot.child("AadharCardDetails").child("aadharFrontPhotoUrl").getValue());
                }
                if (dataSnapshot.child("AadharCardDetails").hasChild("aadharBackPhotoUrl")) {
                    aadharDetailsMap.put("aadharBackPhotoUrl", dataSnapshot.child("AadharCardDetails").child("aadharBackPhotoUrl").getValue());
                }
                if (dataSnapshot.child("PanCardDetails").hasChild("panNumber")) {
                    panDetailsMap.put("panNumber", dataSnapshot.child("PanCardDetails").child("panNumber").getValue());
                    panNumber.setText(panDetailsMap.get("panNumber").toString());
                }
                if (dataSnapshot.child("PanCardDetails").hasChild("panPhotoUrl")) {
                    panDetailsMap.put("panPhotoUrl", dataSnapshot.child("PanCardDetails").child("panPhotoUrl").getValue());
                }
                if (dataSnapshot.hasChild("LicenceDetails/licencePhotoUrl")) {
                    licenceDetailsMap.put("licencePhotoUrl", dataSnapshot.child("LicenceDetails/licencePhotoUrl").getValue());
                }
                try {
                    Picasso.get().load(String.valueOf(aadharDetailsMap.get("aadharFrontPhotoUrl"))).error(R.drawable.error_info).into(aadharFrontPhotoIv);
                    Picasso.get().load(String.valueOf(aadharDetailsMap.get("aadharBackPhotoUrl"))).error(R.drawable.error_info).into(aadharBackPhotoIv);
                    Picasso.get().load(String.valueOf(panDetailsMap.get("panPhotoUrl"))).error(R.drawable.error_info).into(panPhotoIv);
                    Picasso.get().load(String.valueOf(licenceDetailsMap.get("licencePhotoUrl"))).error(R.drawable.error_info).into(licencePhotoIv);
                    aadharFrontPhotoIv.setOnClickListener(view -> extendImage(aadharFrontPhotoIv, view));
                    aadharBackPhotoIv.setOnClickListener(view -> extendImage(aadharBackPhotoIv, view));
                    panPhotoIv.setOnClickListener(view -> extendImage(panPhotoIv, view));
                    licencePhotoIv.setOnClickListener(view -> extendImage(licencePhotoIv, view));
                    if (aadharDetailsMap.get("aadharFrontPhotoUrl") != null &&
                            aadharDetailsMap.get("aadharBackPhotoUrl") != null &&
                            panDetailsMap.get("panPhotoUrl") != null) {
                        aadharFrontPhotoTv.setVisibility(View.GONE);
                        aadharBackPhotoTv.setVisibility(View.GONE);
                        panPhotoTv.setVisibility(View.GONE);
                    }
                    if (licenceDetailsMap.get("licencePhotoUrl") != null) {
                        licenceTv.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                cmn.closeDialog((Activity) context);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void UploadEmpInfo() {
        HashMap<String, Object> identificationDetailsMap = new HashMap<>();
        identificationDetailsMap.put("AadharCardDetails", aadharDetailsMap);
        identificationDetailsMap.put("PanCardDetails", panDetailsMap);
        identificationDetailsMap.put("LicenceDetails", licenceDetailsMap);
        rootRef.child("Employees").child(empId).child("IdentificationDetails").updateChildren(identificationDetailsMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                if (thumbnailBackAadhar != null){
                    thumbnailBackAadhar = null;
                }
                if (thumbnailFrontAadhar != null){
                    thumbnailFrontAadhar = null;
                }
                if (thumbnailPan != null){
                    thumbnailPan = null;
                }
                if (thumbnailLicence != null){
                    thumbnailLicence = null;
                }
                if (from.equals("add")) {
                    sharedPreferences.edit().putBoolean("Identification", true).apply();
                    ((Registration) Objects.requireNonNull(context)).iconColor();
                    cmn.closeDialog((Activity) context);
                } else {
                    sharedPreferences.edit().putBoolean("Identification", true).apply();
                    ((Registration) context).RemoveBadges();
                    cmn.closeDialog((Activity) context);
                    cmn.showAlertDialog("Alert", "Changes Saved Successfully", false, context);
                }
            }
        });
    }

    private void setNextBtn() {
        if (aadharNumber.getText().toString().trim().length() != 0 && !aadharNumber.getText().toString().trim().contains(" ")) {
            aadharDetailsMap.put("aadharNumber", aadharNumber.getText().toString().trim());
            if (aadharDetailsMap.get("aadharFrontPhotoUrl") != null || thumbnailFrontAadhar != null) {
                if (aadharDetailsMap.get("aadharBackPhotoUrl") != null || thumbnailBackAadhar != null) {
                    if (panNumber.getText().toString().trim().length() != 0 && !panNumber.getText().toString().trim().contains(" ")) {
                        panDetailsMap.put("panNumber", panNumber.getText().toString().trim());
                        if (panDetailsMap.get("panPhotoUrl") != null || thumbnailPan != null) {
                            cmn.setProgressDialog("Please Wait", "Uploading data", context, (Activity) context);
                            uploadFrontAadharImage();
                        } else {
                            cmn.showAlertDialog("Alert", "Click Pan card Photo", false, context);
                        }
                    } else {
                        cmn.showAlertDialog("Alert", "Enter Pan number", false, context);
                    }
                } else {
                    cmn.showAlertDialog("Alert", "Click Aadhar card back photo", false, context);
                }
            } else {
                cmn.showAlertDialog("Alert", "Click Aadhar card front photo", false, context);
            }
        } else {
            cmn.showAlertDialog("Alert", "Enter Aadhar number", false, context);
        }
    }

    private void extendImage(RoundedImageView roundedImageView, View view) {
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        int width = display.getWidth();
        int height = display.getWidth();
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.custom_fullimage_dialog, (ViewGroup) view.findViewById(R.id.layout_root));
        ImageView image = layout.findViewById(R.id.fullimage);
        LinearLayout linearLayout = layout.findViewById(R.id.closeBtn);
        image.setImageDrawable(roundedImageView.getDrawable());
        image.getLayoutParams().height = height;
        image.getLayoutParams().width = width;
        new PhotoViewAttacher(image);
        image.requestLayout();
        linearLayout.setOnClickListener(view1 -> dialog.dismiss());
        dialog.setContentView(layout);
        dialog.show();
    }
}