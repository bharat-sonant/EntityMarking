package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.CountDownTimer;

import androidx.databinding.ObservableField;
import androidx.lifecycle.ViewModel;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.employeeattendance.model.HaltPageModel;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.views.SalaryReview;

import java.util.ArrayList;

public class HaltReviewViewModel extends ViewModel {
    Activity activity;
    ArrayList<ArrayList<HaltPageModel>> haltList;
    ArrayList<OtherDetails> otherDetails;
    ArrayList<ParentRecyclerviewModel> userModel;
    SharedPreferences preferences;
    public ObservableField<Boolean> isTimerVisible = new ObservableField<>(true),isConfirmBtnVisible = new ObservableField<>(false);
    public ObservableField<String> timerTv = new ObservableField<>("00"),totalHalt = new ObservableField<>("00"), totalRemovedHalt = new ObservableField<>("00"), totalGeneralHalt = new ObservableField<>(""),
            totalGeneralRemovedHalt = new ObservableField<>("00"),totalMobileOffHalt = new ObservableField<>("00"),totalMobileOffRemovedHalt = new ObservableField<>("00");
    double totalHaltTime = 0.0, removeHaltTime = 0.0, totalMobileOffHaltTime = 0.0, removeMobileOffHaltTime = 0.0, totalGeneralHaltTime = 0.0, removeGeneralHaltTime = 0.0;

    public HaltReviewViewModel(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        haltList = new Gson().fromJson(activity.getIntent().getStringExtra("haltList"), new TypeToken<ArrayList<ArrayList<HaltPageModel>>>() {}.getType());
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {}.getType());
        userModel = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {}.getType());
        setHalt();
    }

    private void setHalt() {
        for (int i=0;i<haltList.size();i++) {
            for (HaltPageModel haltModel : haltList.get(i)) {
                if (Integer.parseInt(haltModel.getDuration()) >= preferences.getInt("minimumHaltShow", 0) && !haltModel.getHaltType().equals("network-off")) {
                    if (haltModel.getActiveHalt().equalsIgnoreCase("inActive")) {
                        if (haltModel.getHaltType().equals("application closed found")) {
                            removeMobileOffHaltTime += Integer.parseInt(haltModel.getDuration());
                        } else {
                            removeGeneralHaltTime += Integer.parseInt(haltModel.getDuration());
                        }
                        removeHaltTime += Integer.parseInt(haltModel.getDuration());
                    }
                    if (haltModel.getHaltType().equals("application closed found")) {
                        totalMobileOffHaltTime += Integer.parseInt(haltModel.getDuration());
                    } else {
                        totalGeneralHaltTime += Integer.parseInt(haltModel.getDuration());
                    }
                    totalHaltTime += Integer.parseInt(haltModel.getDuration());
                }
            }
        }
        totalHalt.set(""+(int)totalHaltTime);
        totalRemovedHalt.set(""+(int)removeHaltTime);
        totalGeneralHalt.set(""+(int)totalGeneralHaltTime);
        totalGeneralRemovedHalt.set(""+(int)removeGeneralHaltTime);
        totalMobileOffHalt.set(""+(int)totalMobileOffHaltTime);
        totalMobileOffRemovedHalt.set(""+(int)removeMobileOffHaltTime);
        setTimer();
    }

    public void onContinueBtn() {
        Intent intent = new Intent(activity, SalaryReview.class);
        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
        intent.putExtra("userModel", new Gson().toJson(userModel));
        activity.startActivity(intent);
    }

    private void setTimer() {
        new CountDownTimer(preferences.getInt("haltReviewWaitTime", 0) * 1000, 1000) {
            public void onTick(long millisUntilFinished) {
                timerTv.set(millisUntilFinished / 1000 > 9 ? ""+ millisUntilFinished / 1000 + " Sec" : "0" + millisUntilFinished / 1000 + " Sec");
            }

            public void onFinish() {
                isTimerVisible.set(false);
                isConfirmBtnVisible.set(true);
            }
        }.start();
    }

    public void onBack(){
        activity.finish();
    }
}