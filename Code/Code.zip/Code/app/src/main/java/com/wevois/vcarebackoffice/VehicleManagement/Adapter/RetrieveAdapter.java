package com.wevois.vcarebackoffice.VehicleManagement.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.VehicleManagement.Views.NewVehicles;

import java.util.ArrayList;

public class RetrieveAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> wordPositionTv;

    public RetrieveAdapter(Context context, ArrayList<String> numberWord) {
        this.context = context;
        this.wordPositionTv = numberWord;
    }

    @Override
    public int getCount() {
        return wordPositionTv.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.vehicles_info, null, true);
        }
        TextView textView = convertView.findViewById(R.id.vehiclesinfo);

        textView.setText(wordPositionTv.get(position));

//        convertView.findViewById(R.id.textView).setOnClickListener(v -> {

        convertView.findViewById(R.id.vehiclesinfo).setOnClickListener(v -> {

            Intent i = new Intent(context, NewVehicles.class);
            i.putExtra("vehicleName", wordPositionTv.get(position));
            context.startActivity(i);
        });
        return convertView;
    }
}
