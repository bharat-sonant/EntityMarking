package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsoluteLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.model.HaltPageModel;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.views.HaltReview;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

public class HaltMapViewModel extends ViewModel {
    private GoogleMap mMap;
    Activity activity;
    SupportMapFragment fragment;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<String> wards;
    SharedPreferences preferences;
    ImageButton deleteBtn;
    DateFormat timeFormat;
    LatLngBounds.Builder builder;
    LatLng mDummyLatLng = new LatLng(26.83, 76.566);
    ArrayList<ArrayList<HaltPageModel>> haltList;
    ArrayList<OtherDetails> otherDetails;
    ArrayList<ParentRecyclerviewModel> userModel;
    String infoWindowText = "";
    public ObservableField<String> wardName = new ObservableField<>(""), currentWard = new ObservableField<>(), totalTime = new ObservableField<>("00:00"), totalHaltTime = new ObservableField<>("00:00"),
            totalApprovedTime = new ObservableField<>("00:00");
    public ObservableField<Boolean> isPreviousVisible = new ObservableField<>(false);
    int currentPosition = 0, backgroundColor;
    private View mCustomMarkerView;
    private ImageView mMarkerImageView;
    TextView markerTV;
    HashMap<String, Integer> markerDetails = new HashMap<>();
    HashMap<String, Marker> imageMarker = new HashMap<>();
    boolean isMoved = true;

    public HaltMapViewModel(Activity activity, SupportMapFragment fragment, ImageButton deleteBtn) {
        this.activity = activity;
        this.fragment = fragment;
        this.deleteBtn = deleteBtn;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        builder = new LatLngBounds.Builder();
        timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        haltList = new Gson().fromJson(activity.getIntent().getStringExtra("haltList"), new TypeToken<ArrayList<ArrayList<HaltPageModel>>>() {
        }.getType());
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {
        }.getType());
        userModel = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {
        }.getType());
        wards = otherDetails.get(0).getWards();
        initViews();
        setMap();
    }

    private void initViews() {
        backgroundColor = R.drawable.outline_bg_map;
        mCustomMarkerView = ((LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.view_custom_marker, null);
        mMarkerImageView = mCustomMarkerView.findViewById(R.id.profile_image);
        markerTV = mCustomMarkerView.findViewById(R.id.haltTimeTV);
    }

    public void setMap() {
        fragment.getMapAsync(googleMap -> {
            mMap = googleMap;
            mMap.getUiSettings().setCompassEnabled(false);
            mMap.getUiSettings().setMapToolbarEnabled(false);
            mMap.setOnMapClickListener(latLng -> {
                deleteBtn.setVisibility(View.GONE);
                builder.include(mDummyLatLng);
                LatLngBounds bounds = builder.build();
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 150);
                mMap.animateCamera(cu);
            });
            mMap.setOnMarkerClickListener(marker -> {
                mDummyLatLng = marker.getPosition();
                new Handler().postDelayed(() -> {
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(17.0f), 700, new GoogleMap.CancelableCallback() {
                        @Override
                        public void onFinish() {
                            int position = markerDetails.get(marker.getTitle());
                            ArrayList<HaltPageModel> haltModels = haltList.get(currentPosition);
                            HaltPageModel model = haltModels.get(position);
                            if (model.getActiveHalt().equals("active")) {
                                deleteBtn.setVisibility(View.VISIBLE);
                                deleteBtn.setImageResource(R.drawable.ic_delete_green_24dp);
                            } else {
                                deleteBtn.setVisibility(View.VISIBLE);
                                deleteBtn.setImageResource(R.drawable.ic_directional);
                            }
                        }

                        @Override
                        public void onCancel() {

                        }
                    });
                }, 300);

                return false;
            });
            mMap.setInfoWindowAdapter(new MyInfoWindowAdapter());
            setMarkerOnMap();
        });
    }

    private void openPopup(Marker marker) {
        int position = markerDetails.get(marker.getTitle());
        ArrayList<HaltPageModel> haltModels = haltList.get(currentPosition);
        HaltPageModel model = haltModels.get(position);
        String path = wards.get(currentPosition);
        if (wards.get(currentPosition).contains("BinLifting")) {
            path = "BinLifting/" + otherDetails.get(0).getVehicle();
        }
        if (haltModels.get(position).getActiveHalt().equals("active")) {
            if (haltModels.get(position).getCanRemove().equalsIgnoreCase("yes")) {
                String finalPath = path;
                common.openHaltDialog(activity, true).observe((LifecycleOwner) activity, response -> {
                    common.getDatabasePath(activity).child("HaltInfo/" + finalPath + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).child(haltModels.get(position).getKey() + "/removeReason").setValue(response).addOnCompleteListener(task -> setDetails("inActive", Color.parseColor("#FFE7E5E5"), model, haltModels, position, true));
                });
            } else {
                Toast.makeText(activity, "You are not authorized to remove this halt.", Toast.LENGTH_SHORT).show();
            }
        } else {
            String finalPath = path;
            common.openHaltDialog(activity, false).observe((LifecycleOwner) activity, response -> {
                common.getDatabasePath(activity).child("HaltInfo/" + finalPath + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).child(haltModels.get(position).getKey() + "/removeReason").removeValue().addOnCompleteListener(task -> setDetails("active", Color.parseColor("#ffffff"), model, haltModels, position, false));
            });
        }
    }

    private void setDetails(String status, int parseColor, HaltPageModel model, ArrayList<HaltPageModel> haltModels, int position, boolean isRemoved) {
        model.setActiveHalt(status);
        model.setLayoutColor(parseColor);
        Long approvedHaltTimeVar = isRemoved ? otherDetails.get(0).getApprovedHaltTime().get(currentPosition) - (Long.parseLong(model.getDuration()) * 60000) : otherDetails.get(0).getApprovedHaltTime().get(currentPosition) + (Long.parseLong(model.getDuration()) * 60000);
        long time = otherDetails.get(0).getTotalTimes().get(currentPosition);
        long diff = approvedHaltTimeVar > time ? 0 : time - approvedHaltTimeVar;
        otherDetails.get(0).getApprovedTime().set(currentPosition, diff);
        otherDetails.get(0).getApprovedHaltTime().set(currentPosition, approvedHaltTimeVar);
        haltModels.set(position, model);
        haltList.set(currentPosition, haltModels);
        setMarkerOnMap();
    }

    class MyInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        private final View myContentsView;

        MyInfoWindowAdapter() {
            myContentsView = activity.getLayoutInflater().inflate(R.layout.custom_info_contents, null);
        }

        @Override
        public View getInfoContents(final Marker marker) {
            TextView tvTitle = myContentsView.findViewById(R.id.title);
            tvTitle.setText(marker.getTitle());
            int[] location = new int[2];
            myContentsView.getLocationOnScreen(location);
            Projection projection = mMap.getProjection();
            LatLng markerLocation = marker.getPosition();
            Point screenPosition = projection.toScreenLocation(markerLocation);
            deleteBtn.setOnClickListener(v -> openPopup(marker));
            AbsoluteLayout.LayoutParams absParams = (AbsoluteLayout.LayoutParams) deleteBtn.getLayoutParams();
            absParams.x = screenPosition.x;
            absParams.y = screenPosition.y;
            mMap.setOnCameraIdleListener(() -> {
                Projection projection1 = mMap.getProjection();
                LatLng markerLocation1 = marker.getPosition();
                Point screenPosition1 = projection1.toScreenLocation(markerLocation1);
                AbsoluteLayout.LayoutParams absParams1 = (AbsoluteLayout.LayoutParams) deleteBtn.getLayoutParams();
                absParams1.x = screenPosition1.x + 90;
                absParams1.y = screenPosition1.y - 270;
                deleteBtn.setLayoutParams(absParams1);
            });
            return myContentsView;
        }

        @Override
        public View getInfoWindow(final Marker marker) {
            return null;
        }
    }

    private void setMarkerOnMap() {
        totalHaltTime.set(timeFormat.format(new Date(otherDetails.get(0).getApprovedHaltTime().get(currentPosition))));
        totalApprovedTime.set("" + timeFormat.format(new Date(otherDetails.get(0).getApprovedTime().get(currentPosition))));
        totalTime.set("" + timeFormat.format(new Date(otherDetails.get(0).getTotalTimes().get(currentPosition))));
        if (wards.get(currentPosition).contains("BinLifting")) {
            wardName.set("BinLifting");
        }else {
            wardName.set(wards.get(currentPosition));
        }
        currentWard.set("Task : " + (currentPosition + 1) + "/" + wards.size());
        common.closeDialog(activity);
        try {
            activity.runOnUiThread(() -> {
                int size = imageMarker.size();
                for (int i = 0; i < size; i++) {
                    try {
                        Marker marker = imageMarker.get((imageMarker.keySet().toArray())[0]);
                        marker.remove();
                        imageMarker.remove((imageMarker.keySet().toArray())[0]);
                    } catch (Exception e) {
                    }
                }
            });
        } catch (Exception e) {
        }
        for (HaltPageModel haltModel : haltList.get(currentPosition)) {
            infoWindowText = "Break Time: " + haltModel.getDuration() + "\n" + "Start Time: " + haltModel.getStartTime() + "\n" + "Halt Type: " + haltModel.getHaltType();
            markerDetails.put(infoWindowText, Integer.parseInt(haltModel.getSno()) - 1);
            addCustomMarker(haltModel.getLatLng(), backgroundColor, haltModel.getDuration());
        }
    }

    private void addCustomMarker(LatLng latLng, int backgroundColor, String duration) {
        mDummyLatLng = latLng;
        if (mMap == null) {
            return;
        }
        Marker marker = mMap.addMarker(new MarkerOptions().position(mDummyLatLng).title(infoWindowText)
                .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(mCustomMarkerView, backgroundColor, duration))));
        marker.setTag(duration);
        imageMarker.put(duration, marker);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(mDummyLatLng));
        builder.include(marker.getPosition());
        LatLngBounds bounds = builder.build();
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 150);
        mMap.animateCamera(cu);
    }

    private Bitmap getMarkerBitmapFromView(View view, int background, String individualHaltTime) {
        mMarkerImageView.setImageResource(R.drawable.marker);
        markerTV.setText(individualHaltTime);
        markerTV.setBackgroundResource(background);
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        view.buildDrawingCache();
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
        Drawable drawable = view.getBackground();
        if (drawable != null)
            drawable.draw(canvas);
        view.draw(canvas);
        return returnedBitmap;
    }

    public void previousOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if (currentPosition != 0) {
            currentPosition = currentPosition - 1;
            if (currentPosition == 0) {
                isPreviousVisible.set(false);
            }
            setMarkerOnMap();
        }
    }

    public void nextOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if ((wards.size() - 1) > currentPosition) {
            if (currentPosition == 0) {
                isPreviousVisible.set(true);
            }
            currentPosition = currentPosition + 1;
            setMarkerOnMap();
        } else {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Please wait...", activity, activity);
                common.getRealTime().observe((LifecycleOwner) activity, response -> {
                    if (response.equalsIgnoreCase("fail")) {
                        isMoved=true;
                        common.showAlertDialog("Warning!", "आपके मोबाइल का Time सही नहीं है |", false, activity);
                    } else {
                        common.closeDialog(activity);
                        Intent intent = new Intent(activity, HaltReview.class);
                        intent.putExtra("haltList", new Gson().toJson(haltList));
                        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
                        intent.putExtra("userModel", new Gson().toJson(userModel));
                        activity.startActivityForResult(intent, 100);
                        isMoved = true;
                    }
                });
            }
        }
    }

    public void onBack() {
        Intent intent = new Intent();
        intent.putExtra("haltList", new Gson().toJson(haltList));
        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
        activity.setResult(RESULT_OK, intent);
        activity.finish();
    }
}
