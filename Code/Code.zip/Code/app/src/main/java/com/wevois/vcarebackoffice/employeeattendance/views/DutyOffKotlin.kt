package com.wevois.vcarebackoffice.employeeattendance.views

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.R
import com.wevois.vcarebackoffice.databinding.ActivityDutyOffKotlinBinding
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.DutyOffKotlinViewModel
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.DutyOffKotlinViewModelFactory

class DutyOffKotlin : AppCompatActivity() {
    var viewModel: DutyOffKotlinViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityDutyOffKotlinBinding = DataBindingUtil.setContentView(this, R.layout.activity_duty_off_kotlin)
        viewModel = ViewModelProvider(this, DutyOffKotlinViewModelFactory(this)).get(DutyOffKotlinViewModel::class.java)
        binding.dutyoffviewmodel = viewModel
        Log.d("TAG", "onCreate: check ")
    }
}