package com.wevois.vcarebackoffice.BackDateDutyOff;

public class BackDateDutyOffModel {
    String empName;
    String empId;
    String inTime;
    String designationId;
    String task;
    String vehicleNo;
    String currentTask;
    String deviceId;

    public BackDateDutyOffModel(String empName, String empId, String inTime, String designationId, String task, String vehicleNo, String currentTask, String deviceId) {
        this.empName = empName;
        this.empId = empId;
        this.inTime = inTime;
        this.designationId = designationId;
        this.task = task;
        this.vehicleNo = vehicleNo;
        this.currentTask = currentTask;
        this.deviceId = deviceId;
    }

    public String getEmpName() {
        return empName;
    }

    public String getEmpId() {
        return empId;
    }

    public String getInTime() {
        return inTime;
    }

    public String getDesignationId() {
        return designationId;
    }

    public String getTask() {
        return task;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public String getCurrentTask() {
        return currentTask;
    }

    public String getDeviceId() {
        return deviceId;
    }
}
