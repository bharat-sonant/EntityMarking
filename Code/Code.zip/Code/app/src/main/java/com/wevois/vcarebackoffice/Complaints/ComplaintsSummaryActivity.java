package com.wevois.vcarebackoffice.Complaints;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.NavigableMap;

public class ComplaintsSummaryActivity extends AppCompatActivity {
    Spinner monthSpinner, YearSpinner;
    CommonFunctions common = CommonFunctions.getInstance();
    Button OkButton;
    TextView totalComplaints,PendingComplaints,InProgressComplaints,ResolveComplaints;
    String presentMonth, presentYear;
    ArrayList<String> yearsList = new ArrayList<String>();
    ArrayList<String> pendingList = new ArrayList<String>();
    ArrayList<String> monthList = new ArrayList<>();
    DatabaseReference databaseReferencePath;
    int n =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_summary);
        YearSpinner = findViewById(R.id.ComplaintsDateSpinner);
        OkButton = findViewById(R.id.OkBtnForSummary);
        totalComplaints = findViewById(R.id.totalComplaints);
        PendingComplaints = findViewById(R.id.pendingComplaints);
        InProgressComplaints = findViewById(R.id.inProgressComplaints);
        ResolveComplaints = findViewById(R.id.resolveComplaints);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(new Date());

        try {
            presentMonth = new SimpleDateFormat("MMMM").format(format.parse(date));
            presentYear = new SimpleDateFormat("yyyy").format(format.parse(date));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        databaseReferencePath = common.getDatabasePath(this);
        monthSpinner = findViewById(R.id.ComplaintsMonthSpinner);
        setPageTitle();
        setMonthSpinner();
        setYearSpinner();
        getComplaintsData();
        getPendingData();
        OkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getComplaintsData();
                getPendingData();
            }
        });
    }

    private void setMonthSpinner() {
        monthList.clear();

        String[] monthName = {"January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"};

        Calendar cal = Calendar.getInstance();
        String month1 = monthName[cal.get(Calendar.MONTH)];
        Log.d("month",month1);
        presentMonth = month1;
        String mnth[] = {month1, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        Log.d("month2",mnth+"");
        LinkedHashSet<String> stringSet = new LinkedHashSet<>(Arrays.asList(mnth));
        String[] filteredArray = stringSet.toArray(new String[0]);

        ArrayAdapter<String> monthadapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, filteredArray);
        monthadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        monthSpinner.setAdapter(monthadapter);
        monthadapter.notifyDataSetChanged();
        monthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presentMonth = "" + adapterView.getSelectedItem();

            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    private void setYearSpinner() {
        int thisYear = Calendar.getInstance().get(Calendar.YEAR);
        presentYear = String.valueOf(thisYear);
        Calendar preYear = Calendar.getInstance();
        preYear.add(Calendar.YEAR, -1);
        int previousYear = preYear.get(Calendar.YEAR);
        for (int i = thisYear; i >= previousYear; i--) {
            yearsList.add(Integer.toString(i));
        }
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, yearsList);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        YearSpinner.setAdapter(yearAdapter);
        yearAdapter.notifyDataSetChanged();
        YearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presentYear = adapterView.getSelectedItem().toString();
                Log.d("year", presentYear);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void getComplaintsData(){
        databaseReferencePath.child("Complaints").child("ComplaintRequest").child(presentYear).child(presentMonth).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<String,String> hashMap = new HashMap<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        for (DataSnapshot snapshot2 : snapshot1.getChildren()) {
                            hashMap.put(snapshot2.getKey(),snapshot2.getKey());
                        }
                    }

                }
                totalComplaints.setText(hashMap.size()+"");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private void getPendingData() {

        databaseReferencePath.child("Complaints").child("ComplaintRequest").child(presentYear).child(presentMonth).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<Integer,String> PendingHashMap = new HashMap<>();
                HashMap<Integer,String> InProgressHashMap = new HashMap<>();
                HashMap<Integer,String> ResolveHashMap = new HashMap<>();
                pendingList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        for (DataSnapshot snapshot2 : snapshot1.getChildren()) {
                            if (snapshot2.hasChild("action")) {
                                if (snapshot2.child("action").getValue().toString().equals("1")) {
//
                                    PendingHashMap.put(n, snapshot2.child("action").
                                            getValue().toString());
                                    n = n + 1;
                                }
                            }
                            if (snapshot2.hasChild("action")) {
                                if (snapshot2.child("action").getValue().toString().equals("2")) {
                                    InProgressHashMap.put(n,snapshot2.child("action").
                                            getValue().toString());
                                    n = n + 1;
                                }
                            }
                            if (snapshot2.hasChild("action")) {
                                if (snapshot2.child("action").getValue().toString().equals("3")) {
                                    ResolveHashMap.put(n,snapshot2.child("action").
                                            getValue().toString());
                                    n = n + 1;
                                }
                            }
                        }
                    }

                }
                InProgressComplaints.setText(InProgressHashMap.size()+"");
                PendingComplaints.setText(PendingHashMap.size()+"");
                ResolveComplaints.setText(ResolveHashMap.size()+"");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private void setPageTitle() {

        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Complaints Summary");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            ComplaintsSummaryActivity.super.onBackPressed();
        });
    }


}