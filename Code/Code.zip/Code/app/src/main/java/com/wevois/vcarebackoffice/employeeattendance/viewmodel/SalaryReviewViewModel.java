package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.employeeattendance.adapter.SalaryAdapter;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.model.SalaryModels;
import com.wevois.vcarebackoffice.employeeattendance.views.DutyOffKotlin;
import com.wevois.vcarebackoffice.employeeattendance.views.LogBook;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class SalaryReviewViewModel extends ViewModel {
    Activity activity;
    ArrayList<OtherDetails> otherDetails;
    ArrayList<ParentRecyclerviewModel> userModels;
    public ObservableField<SalaryAdapter> salaryRecyclerViewAdapter = new ObservableField<>();
    public ObservableField<String> totalTime = new ObservableField<>("00:00"), totalHalt = new ObservableField<>("00:00"),
            totalApprovedTime = new ObservableField<>("00:00"), empName = new ObservableField<>(""),
            empTotalSalary = new ObservableField<>("₹ 0"), currentEmployee = new ObservableField<>();
    public ObservableField<Boolean> isPreviousVisible = new ObservableField<>(false);
    ArrayList<String> wards;
    SharedPreferences preferences;
    CommonFunctions common = CommonFunctions.getInstance();
    DateFormat timeFormat;
    DateFormat dateFormat;
    ArrayList<ArrayList<SalaryModels>> salaryDetails = new ArrayList<>();
    int currentEmp = 0;
    boolean isMoved = true;

    public SalaryReviewViewModel(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        dateFormat = new SimpleDateFormat("HH:mm");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {
        }.getType());
        userModels = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {
        }.getType());
        wards = otherDetails.get(0).getWards();
        long totalTimes = 0, approvedTime = 0, approvedHalt = 0;
        for (int i = 0; i < wards.size(); i++) {
            totalTimes = totalTimes + otherDetails.get(0).getTotalTimes().get(i);
            approvedHalt = approvedHalt + otherDetails.get(0).getApprovedHaltTime().get(i);
            approvedTime = approvedTime + otherDetails.get(0).getApprovedTime().get(i);
        }
        totalHalt.set("" + timeFormat.format(new Date(approvedHalt)));
        totalApprovedTime.set("" + timeFormat.format(new Date(approvedTime)));
        totalTime.set("" + timeFormat.format(new Date(totalTimes)));
        common.setProgressDialog("Please wait...","",activity,activity);
        getEmployeeSalaryList();
    }

    private void getEmployeeSalaryList() {
        activity.runOnUiThread(() -> {
            ArrayList<ParentRecyclerviewModel> userModel = userModels;
            ArrayList<ArrayList<SalaryModels>> salaryDetailsLists = new ArrayList<>();
            for (int i = 0; i < userModel.size(); i++) {
                ArrayList<SalaryModels> salaryDetailsList = new ArrayList<>();
                ArrayList<Integer> taskSalarys = new ArrayList<>();
                final int[] currentPosition = {0};
                int finalI = i;
                common.getDatabasePath(activity).child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date()).child(userModel.get(finalI).getId()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            long previousTime = 0, compactorPreviousTime = 0;
                            double tempTime = 0;
                            for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                String key = dataSnapshot1.getKey();
                                if (key.contains("task")) {
                                    if (dataSnapshot1.hasChild("task-wages")) {
                                        String duration = "0", vehicle = "";
                                        vehicle = dataSnapshot1.child("vehicle").getValue().toString();
                                        String salary = dataSnapshot1.child("task-wages").getValue().toString();
                                        if (dataSnapshot1.hasChild("final-approved-time")) {
                                            String time = dataSnapshot1.child("final-approved-time").getValue().toString();
                                            tempTime = Long.parseLong(time);
                                            duration = convertMilli2String(time);
                                        }
                                        if (dataSnapshot1.hasChild("task")) {
                                            String ward = dataSnapshot1.child("task").getValue().toString();
                                            if (!ward.equals("Compactor")) {
                                                String basic = calculateBasicTime(tempTime, previousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                previousTime += Long.parseLong(dataSnapshot1.child("final-approved-time").getValue().toString());
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, userModel.get(finalI).getDesignationId());
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(setSalaryDetails(ward, duration, salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], userModel.get(finalI).getName(), ""));
                                            } else {
                                                String basic = calculateBasicTime(tempTime, compactorPreviousTime, ward);
                                                String[] basicAndExtra = basic.split("-");
                                                compactorPreviousTime += Long.parseLong(dataSnapshot1.child("final-approved-time").getValue().toString());
                                                String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), vehicle, Integer.parseInt(salary), ward, userModel.get(finalI).getDesignationId());
                                                String[] basicAndExtraSalary = basicSalary.split("-");
                                                salaryDetailsList.add(setSalaryDetails(ward, duration, salary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], userModel.get(finalI).getName(), ""));
                                            }
                                        }
                                    } else {
                                        if (currentPosition[0] > 0) {
                                            previousTime = previousTime + otherDetails.get(0).getApprovedTime().get(currentPosition[0] - 1);
                                        }
                                        int taskSalary = salaryCalculation(previousTime, userModel.get(finalI).getDesignationId(), currentPosition[0]);
                                        String basic = calculateBasicTime(otherDetails.get(0).getApprovedTime().get(currentPosition[0]), previousTime, wards.get(currentPosition[0]));
                                        String[] basicAndExtra = basic.split("-");
                                        String basicSalary = calculateBasicSalary(Integer.parseInt(basicAndExtra[0]), otherDetails.get(0).getVehicle(), taskSalary, wards.get(currentPosition[0]), userModel.get(finalI).getDesignationId());
                                        String[] basicAndExtraSalary = basicSalary.split("-");
                                        int totalSalary = 0;
                                        if (dataSnapshot.hasChild("today-wages")) {
                                            totalSalary = Integer.parseInt(dataSnapshot.child("today-wages").getValue().toString());
                                        }
                                        salaryDetailsList.add(setSalaryDetails(wards.get(currentPosition[0]), timeFormat.format(new Date(otherDetails.get(0).getApprovedTime().get(currentPosition[0]))), "" + taskSalary, convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[0]) * 60000)), convertMilli2String(String.valueOf(Long.parseLong(basicAndExtra[1]) * 60000)), basicAndExtraSalary[0], basicAndExtraSalary[1], userModel.get(finalI).getName(), ""));
                                        taskSalarys.add(taskSalary);
                                        if ((wards.size() - 1) == currentPosition[0]) {
                                            for (Integer arrayList : taskSalarys) {
                                                totalSalary = totalSalary + arrayList;
                                            }
                                            userModel.get(finalI).setTaskSalary(taskSalarys);
                                            userModel.get(finalI).setTotalSalary("" + totalSalary);
                                            userModels.set(finalI, userModel.get(finalI));
                                            Log.d("TAG", "onDataChange: check A1 "+userModel.get(finalI));
                                            Log.d("TAG", "onDataChange: check A2 "+userModels);
                                            salaryDetailsLists.add(salaryDetailsList);
                                        } else {
                                            currentPosition[0] = currentPosition[0] + 1;
                                        }
                                    }
                                }
                            }
                        }
                        if (finalI == (userModel.size() - 1)) {
                            common.closeDialog(activity);
                            salaryDetails = salaryDetailsLists;
                            setSalaryByEmployee();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }

    private SalaryModels setSalaryDetails(String ward, String durations, String salary, String convertMilli2String, String convertMilli2String1, String s, String s1, String name, String messages) {
        boolean isVisible = false;
        SpannableString duration1;
        String extraStrings = durations + " (Hrs)";
        SpannableString ss = new SpannableString(extraStrings);
        ss.setSpan(new RelativeSizeSpan(.8f), 5, ss.length(), 0); // set size
        ss.setSpan(new ForegroundColorSpan(Color.RED), 5, ss.length(), 0);// set color
        duration1 = ss;
        salary = "₹ " + salary;
        if (ward.contains("BinLifting")) {
            ward = "BinLifting";
        }
        if (!convertMilli2String1.equals("00:00")) {
            if (!convertMilli2String.equals("00:00")) {
                isVisible = true;
                SimpleDateFormat f = new SimpleDateFormat("HH:mm");
                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date d = null;
                try {
                    d = f.parse(convertMilli2String);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                int basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
                long basicTime = (basicMinimumHour * 60 * 60000) - d.getTime();
                String duration = f.format(new Date(basicTime));
                if (1 == 0) {
                    messages = name + " ने " + convertMilli2String + " (Hrs) Basic OR " + convertMilli2String + " (Hrs) Extra Work किया हैं | ";
                } else {
                    messages = name + " " + duration + " (Hrs) अन्य task में कर चूका है | इसलिए इस task में " + convertMilli2String + " (Hrs) Basic Hrs व अन्य Extra Hrs लिये जायेंगे। ";
                }
                String basicString = convertMilli2String + " (Basic Hrs)";
                SpannableString ss1 = new SpannableString(basicString);
                ss1.setSpan(new RelativeSizeSpan(.8f), 5, ss1.length(), 0); // set size
                ss1.setSpan(new ForegroundColorSpan(Color.RED), 5, ss1.length(), 0);// set color
                String extraString = convertMilli2String1 + " (Extra Hrs)";
                SpannableString ss2 = new SpannableString(extraString);
                ss2.setSpan(new RelativeSizeSpan(.8f), 5, ss2.length(), 0); // set size
                ss2.setSpan(new ForegroundColorSpan(Color.RED), 5, ss2.length(), 0);// set color
                CharSequence finalText = TextUtils.concat(ss1, " \n", ss2);
                duration1 = new SpannableString(finalText);
                salary = s + "\n" + s1 + "\n---------\n₹ " + salary;
            }
        }
        return new SalaryModels(ward, duration1, salary, messages, true, isVisible);
    }

    private int salaryCalculation(long s, String designId, int i) {
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        double actualSalary;
        actualSalary = calculateSalary(timeFormat.format(new Date(otherDetails.get(0).getApprovedTime().get(i))), designId);
        if (s > 0) {
            String totalSalary = timeFormat.format(new Date(s + otherDetails.get(0).getApprovedTime().get(i)));
            String removeSalary = timeFormat.format(new Date(s));
            double totalActualSalary = calculateSalary(totalSalary, designId);
            double totalRemoveSalary = calculateSalary(removeSalary, designId);
            actualSalary = totalActualSalary - totalRemoveSalary;
        }
        return (int) actualSalary;
    }

    public int calculateSalary(String time, String designId) {
        double salary = 0.0;
        if (preferences.getLong("driverIncPerHour", 0) > 1 && preferences.getLong("helperIncPerHour", 0) > 1) {
            double basicSalaryDriver = preferences.getLong("driverSalaryPerHour", 0);
            double basicSalaryHelper = preferences.getLong("helperSalaryPerHour", 0);
            double driverIncPerHour = preferences.getLong("driverIncPerHour", 0);
            double helperIncPerHour = preferences.getLong("helperIncPerHour", 0);
            double tractorDriverMonthlyIncentive = preferences.getLong("tractorDriverSalary", 0);
            int basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
            double tractorDriver = tractorDriverMonthlyIncentive / 60;
            String text = time;
            String[] arr = text.split(":");
            if (arr.length >= 2) {
                if (designId.equals("5")) {
                    if (otherDetails.get(0).getVehicle().contains("TRACTOR")) {
                        salary = Integer.parseInt(arr[0]) * tractorDriverMonthlyIncentive + Integer.parseInt(arr[1]) * tractorDriver;
                    } else {
                        if (Integer.parseInt(arr[0]) < basicMinimumHour) {
                            salary = Integer.parseInt(arr[0]) * basicSalaryDriver + Integer.parseInt(arr[1]) * (basicSalaryDriver / 60);
                        } else {
                            salary = (basicSalaryDriver * basicMinimumHour) + (Integer.parseInt(arr[0]) - basicMinimumHour) * driverIncPerHour + Integer.parseInt(arr[1]) * (driverIncPerHour / 60);
                        }
                    }
                } else if (designId.contains("6")) {
                    if (Integer.parseInt(arr[0]) < basicMinimumHour) {
                        salary = Integer.parseInt(arr[0]) * basicSalaryHelper + Integer.parseInt(arr[1]) * (basicSalaryHelper / 60);
                    } else {
                        salary = (basicSalaryHelper * basicMinimumHour) + (Integer.parseInt(arr[0]) - basicMinimumHour) * helperIncPerHour + Integer.parseInt(arr[1]) * (helperIncPerHour / 60);
                    }
                }
            }
        }
        return (int) salary;
    }

    private String calculateBasicSalary(int basicTime, String vehicle, int salary, String ward, String designId) {
        String basicSalary;
        double basicSalaryDriver = preferences.getLong("driverSalaryPerHour", 0) / 60.0;
        double basicSalaryHelper = preferences.getLong("helperSalaryPerHour", 0) / 60.0;
        double tractorDriver = preferences.getLong("tractorDriverSalary", 0) / 60.0;
        double compactorBasicSalaryDriver = preferences.getLong("compactorDriverSalaryPerHour", 0) / 60.0;

        if (designId.equals("5")) {
            if (!ward.equals("Compactor")) {
                if (vehicle.contains("TRACTOR")) {
                    int basicSalaryInt = (int) (basicTime * tractorDriver);
                    basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
                } else {
                    int basicSalaryInt = (int) (basicTime * basicSalaryDriver);
                    basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
                }
            } else {
                int basicSalaryInt = (int) (basicTime * compactorBasicSalaryDriver);
                basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
            }
        } else {
            int basicSalaryInt = (int) (basicTime * basicSalaryHelper);
            basicSalary = "" + basicSalaryInt + "-" + (salary - basicSalaryInt);
        }
        return basicSalary;
    }

    private String calculateBasicTime(double duration, long previousTime, String task) {
        int previousTotalTime = (int) (previousTime / 60000);
        int currentTime = (int) (duration / 60000);
        int basicMinimumHour = 0;
        if (task.equals("Compactor")) {
            basicMinimumHour = preferences.getInt("compactorBasicMinimumHour", 0);
        } else {
            basicMinimumHour = preferences.getInt("basicMinimumHour", 0);
        }
        int basicTime = basicMinimumHour * 60;
        int extraTime = 0;
        if (previousTotalTime > basicTime) {
            basicTime = 0;
            extraTime = currentTime;
        } else if (previousTotalTime == 0) {
            if (basicTime < currentTime) {
                extraTime = currentTime - basicTime;
            } else {
                basicTime = currentTime;
            }
        } else {
            basicTime = basicTime - previousTotalTime;
            if (basicTime < currentTime) {
                extraTime = currentTime - basicTime;
            }
        }
        return basicTime + "-" + extraTime;
    }

    private String convertMilli2String(String time) {
        String duration;
        long timeLong = Long.parseLong(time, 10);
        duration = dateFormat.format(new Date(timeLong));
        return duration;
    }

    public void previousOnClick() {
        if (currentEmp != 0) {
            currentEmp = currentEmp - 1;
            if (currentEmp == 0) {
                isPreviousVisible.set(false);
            }
            setSalaryByEmployee();
        }
    }

    public void nextOnClick() {
        if ((userModels.size() - 1) > currentEmp) {
            if (currentEmp == 0) {
                isPreviousVisible.set(true);
            }
            currentEmp = currentEmp + 1;
            setSalaryByEmployee();
        } else {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Please wait...", activity, activity);
                common.getRealTime().observe((LifecycleOwner) activity, response -> {
                    if (response.equalsIgnoreCase("fail")) {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "आपके मोबाइल का Time सही नहीं है |", false, activity);
                    } else {
                        common.closeDialog(activity);
                        Intent intent ;
                        if (wards.get(wards.size()-1).contains("WetWaste")||wards.get(wards.size()-1).contains("Market")||wards.get(wards.size()-1).contains("mkt")||wards.get(wards.size()-1).contains("BinLifting")){
                            intent = new Intent(activity, DutyOffKotlin.class);
                        }else {
                            intent = new Intent(activity, LogBook.class);
                        }
                        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
                        intent.putExtra("userModel", new Gson().toJson(userModels));
                        activity.startActivity(intent);
                        isMoved = true;
                    }
                });
            }
        }
    }

    private void setSalaryByEmployee() {
        currentEmployee.set("Employee : " + (currentEmp + 1) + "/" + userModels.size());
        empName.set(userModels.get(currentEmp).getName());
        empTotalSalary.set(userModels.get(currentEmp).getTotalSalary());
        salaryRecyclerViewAdapter.set(new SalaryAdapter(salaryDetails.get(currentEmp), activity));
    }

    public void onBack(){
        activity.finish();
    }
}
