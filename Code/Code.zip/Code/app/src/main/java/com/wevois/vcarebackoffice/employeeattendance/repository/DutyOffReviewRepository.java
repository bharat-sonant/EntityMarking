package com.wevois.vcarebackoffice.employeeattendance.repository;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class DutyOffReviewRepository {

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> getEmployeeDetails(DatabaseReference databaseReference, String ward, CommonFunctions common,ArrayList<OtherDetails> otherDetails) {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... p) {
                databaseReference.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot employeeSnapShot) {
                        if (employeeSnapShot.getValue() != null) {
                            databaseReference.child("WorkAssignment").orderByChild("current-assignment").equalTo(ward).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() != null) {
                                        ArrayList<ParentRecyclerviewModel> model = new ArrayList<>();
                                        String driverId="", vehicle = "";
                                        int count=3;
                                        if (ward.contains("BinLifting")){
                                            count = 2;
                                        }
                                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                            String device = "", id = "", name = "", designationId = "";
                                            if (snapshot.hasChild("device")) {
                                                device = snapshot.child("device").getValue().toString();
                                            }
                                            if (snapshot.hasChild("vehicle")) {
                                                vehicle = snapshot.child("vehicle").getValue().toString();
                                            }
                                            id = snapshot.getKey();
                                            if (employeeSnapShot.hasChild(id + "/GeneralDetails/designationId")) {
                                                designationId = employeeSnapShot.child(id + "/GeneralDetails/designationId").getValue().toString();
                                                if (designationId.equalsIgnoreCase("5")){
                                                    driverId = id;
                                                }
                                            }
                                            if (employeeSnapShot.hasChild(id + "/GeneralDetails/name")) {
                                                name = employeeSnapShot.child(id + "/GeneralDetails/name").getValue().toString();
                                            }
                                            if (designationId.equalsIgnoreCase("5")){
                                                model.add(new ParentRecyclerviewModel(name,id,device,designationId,""+1,"",null,""));
                                            }else {
                                                if (device.equalsIgnoreCase("NotApplicable")) {
                                                    model.add(new ParentRecyclerviewModel(name, id, device, designationId,""+count,"",null,""));
                                                    count++;
                                                }else {
                                                    model.add(new ParentRecyclerviewModel(name, id, device, designationId,""+2,"",null,""));
                                                }
                                            }
                                        }
                                        Collections.sort(model, (obj1, obj2) -> obj1.getIds().compareToIgnoreCase(obj2.getIds()));
                                        String finalVehicle = vehicle;
                                        databaseReference.child("DailyWorkDetail/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + driverId).addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if (dataSnapshot.getValue() != null) {
                                                    ArrayList<String> wards = new ArrayList<>(),starts = new ArrayList<>();
                                                    ArrayList<Long> totalHaltTime = new ArrayList<>(),approvedTime = new ArrayList<>(),approvedHaltTime = new ArrayList<>(),totalTimes = new ArrayList<>();
                                                    for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                                                        if (snapshot.getKey().contains("task")){
                                                            if (!snapshot.hasChild("task-wages")){
                                                                if (snapshot.hasChild("in-out")){
                                                                    if (snapshot.hasChild("task")){
                                                                        wards.add(snapshot.child("task").getValue().toString());
                                                                    }
                                                                    SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                                                                    String startTime = "", endTime = dateFormat.format(new Date());
                                                                    for (DataSnapshot snapshot1:snapshot.child("in-out").getChildren()){
                                                                        if (snapshot1.getValue().toString().equalsIgnoreCase("In")) {
                                                                            startTime = snapshot1.getKey();
                                                                        }else {
                                                                            endTime = snapshot1.getKey();
                                                                        }
                                                                    }
                                                                    starts.add(startTime);
                                                                    String finalDiff = String.valueOf(common.timeDiff(new SimpleDateFormat("HH:mm:ss"),startTime,endTime));
                                                                    totalTimes.add(Long.valueOf(finalDiff));
                                                                    approvedTime.add(Long.parseLong(finalDiff, 10));
                                                                }
                                                            }
                                                        }
                                                    }
                                                    otherDetails.get(0).setWards(wards);
                                                    otherDetails.get(0).setVehicle(finalVehicle);
                                                    otherDetails.get(0).setStarts(starts);
                                                    otherDetails.get(0).setTotalTimes(totalTimes);
                                                    otherDetails.get(0).setTotalHaltTime(totalHaltTime);
                                                    otherDetails.get(0).setApprovedTime(approvedTime);
                                                    otherDetails.get(0).setApprovedHaltTime(approvedHaltTime);
                                                    response.setValue(new Gson().toJson(model)+"~"+new Gson().toJson(otherDetails));
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                            }
                                        });
                                    }else {
                                        response.setValue("fail");
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }
}
