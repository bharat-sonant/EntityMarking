package com.wevois.vcarebackoffice.EmployeeData;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.siyamed.shapeimageview.RoundedImageView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static android.R.layout.simple_spinner_item;
import static android.content.Context.MODE_PRIVATE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class GeneralDetailFragment extends Fragment {
    Button nextBtn;
    Bitmap thumbnail;
    private Camera mCamera;
    private static final int FOCUS_AREA_SIZE = 300;
    private SurfaceView surfaceView;
    Camera.PictureCallback pictureCallback;
    int mYear, mMonth, mDay;
    boolean isApproved = false, isPass = true;
    Context context;
    DatabaseReference rootRef;
    StorageReference mStorageRef;
    RoundedImageView profilePhotoIV;
    SharedPreferences sharedPreferences, preferences;
    DataSnapshot rfidListSanpshot;
    TextView doj, dob, empCode;
    Spinner genderSpinner, departmentSpinner, designationSpinner, statusSpinner;
    CommonFunctions cmn = CommonFunctions.getInstance();
    EditText empNameET, empFatherET, empMobileET, empPhoneET, empEmailET, empRFIDEt;
    String date_time = "", empId, from;
    ArrayList<CharSequence> departmentList = new ArrayList<>(), departmentIdList = new ArrayList<>(), designationList = new ArrayList<>(), designationIdList = new ArrayList<>(),
            genderList = new ArrayList<>(), genderIdList = new ArrayList<>(), statusList = new ArrayList<>(), statusIdList = new ArrayList<>(), rfidArrayList = new ArrayList<>();
    private static final int PERMISSION_CODE = 1000;
    HashMap<String, Object> employeeStructureMap = new HashMap<>();

    public GeneralDetailFragment() {
    }

    public static GeneralDetailFragment newInstance() {
        return new GeneralDetailFragment();
    }

    @Override
    public void onAttach(@NonNull Context ctx) {
        super.onAttach(ctx);
        context = getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_general_detail, container, false);
        getBundle();
        InIt(view);
        SetAction();
        return view;
    }

    private void getBundle() {
        if (getArguments() != null) {
            empId = getArguments().getString("empId", " ");
            employeeStructureMap.put("empCode", getArguments().getString("empCode", null));
            from = getArguments().getString("from", " ");
        } else {
            cmn.showAlertDialog("Please Retry", "", false, context);
        }
    }

    private void InIt(View view) {
        preferences = context.getSharedPreferences("loginData", MODE_PRIVATE);
        profilePhotoIV = view.findViewById(R.id.profile_photo);
        doj = view.findViewById(R.id.doj);
        dob = view.findViewById(R.id.dob);
        empCode = view.findViewById(R.id.emp_code);
        empNameET = view.findViewById(R.id.emp_name_et);
        empFatherET = view.findViewById(R.id.emp_father_et);
        empMobileET = view.findViewById(R.id.emp_mobile_et);
        empPhoneET = view.findViewById(R.id.emp_phone_et);
        empEmailET = view.findViewById(R.id.emp_email_et);
        empRFIDEt = view.findViewById(R.id.emp_rfid_et);
        genderSpinner = view.findViewById(R.id.gender_spinner);
        departmentSpinner = view.findViewById(R.id.depatment_spinner);
        designationSpinner = view.findViewById(R.id.designation_spinner);
        statusSpinner = view.findViewById(R.id.status_spinner);
        nextBtn = view.findViewById(R.id.next_general);
        empCode.setText(String.valueOf(employeeStructureMap.get("empCode")));
        Glide.with(context).load(R.drawable.profile_photo).into(profilePhotoIV);
        rootRef = cmn.getDatabasePath(context);
        mStorageRef = FirebaseStorage.getInstance().getReferenceFromUrl(cmn.getDatabaseStorage(context));
        sharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
        cmn.setProgressDialog("Please Wait...", "Preparing Data...", context, (Activity) context);
        getSpinner();

        rootRef.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                rfidListSanpshot = dataSnapshot;
                if (rfidListSanpshot.hasChild(empId + "/OtherDetails/isApproved")) {
                    if (rfidListSanpshot.child(empId + "/OtherDetails/isApproved").getValue().toString().equalsIgnoreCase("true")) {
                        isApproved = true;
                    } else {
                        isApproved = false;
                    }
                }
                rfidList();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void rfidList() {
        int j = 100;
        for (int i = 1; i <= rfidListSanpshot.getChildrenCount(); i++) {
            Log.d("TAG", "rfidList:A " + rfidListSanpshot.child(String.valueOf(j + i)));
            if (rfidListSanpshot.child(String.valueOf(j + i)).hasChild("GeneralDetails")) {
                if (rfidListSanpshot.child(String.valueOf(j + i)).child("GeneralDetails").hasChild("rfid")) {
                    if (!rfidListSanpshot.child(String.valueOf(j + i)).child("GeneralDetails").hasChild("rfid")) {
                        rfidArrayList.add(Objects.requireNonNull(rfidListSanpshot.child(String.valueOf(j + i)).child("GeneralDetails").child("rfid").getValue()).toString());
                    }
                }
            }
        }
    }

    private void getSpinner() {
        genderList.add("Gender");
        genderIdList.add("Gender");
        departmentList.add("Department");
        departmentIdList.add("Department");
        statusList.add("Status");
        statusIdList.add("Status");

        try {
            JSONArray jsonArray = new JSONArray(sharedPreferences.getString("genderList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        genderIdList.add("" + i);
                        genderList.add(values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            JSONArray jsonArray = new JSONArray(sharedPreferences.getString("departmentList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    departmentIdList.add(jsonObject.getString("id"));
                    departmentList.add(jsonObject.getString("name"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            JSONArray jsonArray = new JSONArray(sharedPreferences.getString("statusList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        statusIdList.add("" + i);
                        statusList.add(values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ArrayAdapter<CharSequence> genderSpinnerAdapter = new ArrayAdapter<>(context, simple_spinner_item, genderList);
        ArrayAdapter<CharSequence> departmentSpinnerAdapter = new ArrayAdapter<>(context, simple_spinner_item, departmentList);
        ArrayAdapter<CharSequence> statusSpinnerAdapter = new ArrayAdapter<>(context, simple_spinner_item, statusList);
        genderSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        departmentSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderSpinnerAdapter);
        departmentSpinner.setAdapter(departmentSpinnerAdapter);
        statusSpinner.setAdapter(statusSpinnerAdapter);
        if (from.equals("edit") || sharedPreferences.getBoolean("General", false)) {
            if (preferences.getBoolean("isAccountant", false) ||
                    preferences.getBoolean("isSuperAdmin", false) ||
                    preferences.getBoolean("empapproveradmin", false)) {
                departmentSpinner.setEnabled(true);
                designationSpinner.setEnabled(true);
                statusSpinner.setEnabled(true);
            } else {
                departmentSpinner.setEnabled(false);
                designationSpinner.setEnabled(false);
                statusSpinner.setEnabled(false);
            }
            setDefaults();
        } else {
            cmn.closeDialog((Activity) context);
        }

    }

    private void getDesignation(Integer position) {
        try {
            JSONArray jsonArray = new JSONArray(sharedPreferences.getString("designationList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if (Integer.parseInt(jsonObject.getString("deptId")) == position) {
                        designationIdList.add("" + i);
                        designationList.add(jsonObject.getString("name"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ArrayAdapter<CharSequence> designationSpinnerAdapter = new ArrayAdapter<>(context.getApplicationContext(), simple_spinner_item, designationList);
        designationSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        designationSpinner.setAdapter(designationSpinnerAdapter);
        if (employeeStructureMap.get("designationId") != null) {
            designationSpinner.setSelection(designationIdList.indexOf(String.valueOf(employeeStructureMap.get("designationId"))));
        }
        cmn.closeDialog((Activity) context);
    }

    private void setDefaults() {
        rootRef.child("Employees").child(empId).child("GeneralDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("departmentId")) {
                    employeeStructureMap.put("departmentId", dataSnapshot.child("departmentId").getValue());
                    departmentSpinner.setSelection(departmentIdList.indexOf(String.valueOf(employeeStructureMap.get("departmentId"))));
                }
                if (dataSnapshot.hasChild("dateOfJoining")) {
                    employeeStructureMap.put("dateOfJoining", dataSnapshot.child("dateOfJoining").getValue());
                    doj.setText(String.valueOf(employeeStructureMap.get("dateOfJoining")));
                }
                if (dataSnapshot.hasChild("profilePhotoURL")) {
                    employeeStructureMap.put("profilePhotoURL", dataSnapshot.child("profilePhotoURL").getValue());
                }
                if (dataSnapshot.hasChild("name")) {
                    employeeStructureMap.put("name", dataSnapshot.child("name").getValue());
                    empNameET.setText(String.valueOf(employeeStructureMap.get("name")));
                }
                if (dataSnapshot.hasChild("fatherName")) {
                    employeeStructureMap.put("fatherName", dataSnapshot.child("fatherName").getValue());
                    empFatherET.setText(String.valueOf(employeeStructureMap.get("fatherName")));
                }
                if (dataSnapshot.hasChild("mobile")) {
                    employeeStructureMap.put("mobile", dataSnapshot.child("mobile").getValue());
                    empMobileET.setText(String.valueOf(employeeStructureMap.get("mobile")));
                }
                if (dataSnapshot.hasChild("phone")) {
                    employeeStructureMap.put("phone", dataSnapshot.child("phone").getValue());
                    empPhoneET.setText(String.valueOf(employeeStructureMap.get("phone")));
                }
                if (dataSnapshot.hasChild("email")) {
                    employeeStructureMap.put("email", dataSnapshot.child("email").getValue());
                    empEmailET.setText(String.valueOf(employeeStructureMap.get("email")));
                }
                if (dataSnapshot.hasChild("dateOfBirth")) {
                    employeeStructureMap.put("dateOfBirth", dataSnapshot.child("dateOfBirth").getValue());
                    dob.setText(String.valueOf(employeeStructureMap.get("dateOfBirth")));
                }
                if (dataSnapshot.hasChild("gender")) {
                    employeeStructureMap.put("gender", dataSnapshot.child("gender").getValue());
                    genderSpinner.setSelection(genderList.indexOf(String.valueOf(employeeStructureMap.get("gender"))));
                }
                if (dataSnapshot.hasChild("designationId")) {
                    employeeStructureMap.put("designationId", dataSnapshot.child("designationId").getValue());
                    designationSpinner.setSelection(designationIdList.indexOf(String.valueOf(employeeStructureMap.get("designationId"))));
                }
                if (dataSnapshot.hasChild("status")) {
                    employeeStructureMap.put("status", dataSnapshot.child("status").getValue());
                    statusSpinner.setSelection(statusIdList.indexOf(String.valueOf(employeeStructureMap.get("status"))));
                }
                if (dataSnapshot.hasChild("rfid")) {
                    employeeStructureMap.put("rfid", dataSnapshot.child("rfid").getValue());
                    empRFIDEt.setText(String.valueOf(employeeStructureMap.get("rfid")));
                }
                try {
                    Picasso.get().load(String.valueOf(employeeStructureMap.get("profilePhotoURL"))).error(R.drawable.error_info).into(profilePhotoIV);
                    Log.d("TAG", "onDataChangeA: " + employeeStructureMap);
                    cmn.closeDialog((Activity) context);
                } catch (Exception e) {
                    Log.d("TAG", "onActivityResult: check EEDD" + e.toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void UploadEmpInfo() {
        rootRef.child("Employees").child(empId).child("GeneralDetails").updateChildren(employeeStructureMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                thumbnail = null;
                if (from.equals("add")) {
                    rootRef.child("Employees/lastEmpId").setValue(empId);
                    sharedPreferences.edit().putBoolean("General", true).apply();
                    ((Registration) Objects.requireNonNull(context)).iconColor();
                    cmn.closeDialog((Activity) context);
                } else {
                    cmn.closeDialog((Activity) context);
                    cmn.showAlertDialog("Alert", "Changes Saved Successfully", false, context);
                }
            }
        });
    }

    private void setNextBtn() {
        if (employeeStructureMap.get("profilePhotoURL") != null || thumbnail != null) {
            if (doj.getText().toString().trim().contains("-")) {
                employeeStructureMap.put("dateOfJoining", doj.getText().toString().trim());
                if (empNameET.getText().toString().trim().length() != 0) {
                    employeeStructureMap.put("name", empNameET.getText().toString().trim().toUpperCase());
                    if (empFatherET.getText().toString().trim().length() != 0) {
                        employeeStructureMap.put("fatherName", empFatherET.getText().toString().trim().toUpperCase());
                        if (empMobileET.getText().toString().trim().length() == 10 && !empMobileET.getText().toString().trim().contains(" ")) {
                            employeeStructureMap.put("mobile", empMobileET.getText().toString().trim());
                            if (dob.getText().toString().contains("-")) {
                                employeeStructureMap.put("dateOfBirth", dob.getText().toString().trim());
                                if (genderSpinner.getSelectedItemPosition() != 0) {
                                    employeeStructureMap.put("gender", genderSpinner.getSelectedItem());
                                    if (departmentSpinner.getSelectedItemPosition() != 0) {
                                        employeeStructureMap.put("departmentId", departmentIdList.get(departmentSpinner.getSelectedItemPosition()));
                                        if (designationSpinner.getSelectedItemPosition() != 0) {
                                            employeeStructureMap.put("designationId", designationIdList.get(designationSpinner.getSelectedItemPosition()));
                                            employeeStructureMap.put("rfid", empRFIDEt.getText().toString().trim());
                                            if (statusSpinner.getSelectedItemPosition() != 0) {
                                                employeeStructureMap.put("status", statusIdList.get(statusSpinner.getSelectedItemPosition()));
                                                employeeStructureMap.put("userName", empId);
                                                try {
                                                    employeeStructureMap.put("password", cmn.encrypt(empId, empId));
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                                employeeStructureMap.put("email", empEmailET.getText().toString().trim());
                                                employeeStructureMap.put("phone", empPhoneET.getText().toString().trim());
                                                cmn.setProgressDialog("Please Wait", "Uploading data", context, (Activity) context);
                                                uploadImage();
                                            } else {
                                                cmn.showAlertDialog("Alert", "Select Status", false, context);
                                            }
                                        } else {
                                            cmn.showAlertDialog("Alert", "Select Designation", false, context);
                                        }
                                    } else {
                                        cmn.showAlertDialog("Alert", "Select Department", false, context);
                                    }
                                } else {
                                    cmn.showAlertDialog("Alert", "Select Gender", false, context);
                                }

                            } else {
                                cmn.showAlertDialog("Alert", "Enter Date of Birth", false, context);
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Enter Mobile", false, context);
                        }
                    } else {
                        cmn.showAlertDialog("Alert", "Enter Father Name", false, context);

                    }
                } else {
                    cmn.showAlertDialog("Alert", "Enter Name", false, context);
                }

            } else {
                cmn.showAlertDialog("Alert", "Enter Joining Date", false, context);
            }
        } else {
            cmn.showAlertDialog("Alert", "Click Picture", false, context);
        }
    }

    private void SetAction() {
        profilePhotoIV.setOnClickListener(view14 -> GeneralDetailFragment.this.CameraPermission(context));
        doj.setOnClickListener(view1 -> datePicker(doj));
        dob.setOnClickListener(view13 -> datePicker(dob));
        nextBtn.setOnClickListener(view12 -> {
            if (isApproved) {
                if (preferences.getBoolean("isAccountant", false) ||
                        preferences.getBoolean("isSuperAdmin", false) ||
                        preferences.getBoolean("empapproveradmin", false)) {
                    setNextBtn();
                } else {
                    cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your superviser.", false, context);
                }
            } else {
                setNextBtn();
            }
        });
        departmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                designationList.clear();
                designationIdList.clear();
                designationList.add("Designation");
                designationIdList.add("Designation");
                designationSpinner.setSelection(0);
                if (i != 0) {
                    cmn.setProgressDialog("Please Wait", "Loading...", context, (Activity) context);
                    String position = departmentIdList.get(departmentSpinner.getSelectedItemPosition()).toString();
                    getDesignation(Integer.parseInt(position));
                } else {
                    ArrayAdapter<CharSequence> designationSpinnerAdapter = new ArrayAdapter<>(context.getApplicationContext(), simple_spinner_item, designationList);
                    designationSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    designationSpinner.setAdapter(designationSpinnerAdapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void datePicker(TextView textView) {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                (view, year, monthOfYear, dayOfMonth) -> {
                    if (monthOfYear + 1 <= 9) {
                        if (dayOfMonth <= 9) {
                            date_time = "0" + dayOfMonth + "-0" + (monthOfYear + 1) + "-" + year;
                        } else {
                            date_time = dayOfMonth + "-0" + (monthOfYear + 1) + "-" + year;
                        }
                    } else {
                        if (dayOfMonth <= 9) {
                            date_time = "0" + dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        } else {
                            date_time = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        }
                    }
                    textView.setText(date_time);
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void CameraPermission(Context context) {
        if (isPass) {
            isPass = false;
            new Handler().post(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_CODE);
                    } else {
                        showAlertDialog();

                    }
                }
            });
        }
    }

    private void focusOnTouch(MotionEvent event) {
        if (mCamera != null) {
            Camera.Parameters parameters = mCamera.getParameters();
            if (parameters.getMaxNumMeteringAreas() > 0) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                Rect rect = calculateFocusArea(event.getX(), event.getY());
                List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
                meteringAreas.add(new Camera.Area(rect, 800));
                parameters.setFocusAreas(meteringAreas);
                mCamera.setParameters(parameters);
            }
//            mCamera.autoFocus(mAutoFocusTakePictureCallback);
        }
    }

    private Rect calculateFocusArea(float x, float y) {
        int left = clamp(Float.valueOf((x / surfaceView.getWidth()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        int top = clamp(Float.valueOf((y / surfaceView.getHeight()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);

        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private int clamp(int touchCoordinateInCameraReper, int focusAreaSize) {
        int result;
        if (Math.abs(touchCoordinateInCameraReper) + focusAreaSize / 2 > 1000) {
            if (touchCoordinateInCameraReper > 0) {
                result = 1000 - focusAreaSize / 2;
            } else {
                result = -1000 + focusAreaSize / 2;
            }
        } else {
            result = touchCoordinateInCameraReper - focusAreaSize / 2;
        }
        return result;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
        }
    }

    public static void setCameraDisplayOrientation(Activity activity, int cameraId, android.hardware.Camera camera) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = activity.getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    public void showAlertDialog() {
        View dialogLayout = getActivity().getLayoutInflater().inflate(R.layout.custom_camera_alertbox, null);
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity()).setView(dialogLayout).setCancelable(false);
        AlertDialog dialog = alertDialog.create();
        surfaceView = (SurfaceView) dialogLayout.findViewById(R.id.surfaceViews);
        SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_HARDWARE);
        SurfaceHolder.Callback surfaceViewCallBack = new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    mCamera = Camera.open();
                    Camera.Parameters parameters = mCamera.getParameters();
                    List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
                    parameters.setPictureSize(sizes.get(0).width, sizes.get(0).height);
                    mCamera.setParameters(parameters);
                    setCameraDisplayOrientation(getActivity(), 0, mCamera);
                    mCamera.setPreviewDisplay(surfaceHolder);
                    mCamera.startPreview();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

            }
        };
        surfaceHolder.addCallback(surfaceViewCallBack);
        Button btn = dialogLayout.findViewById(R.id.capture_image_btn);
        btn.setOnClickListener(v -> {
            mCamera.takePicture(null, null, null, pictureCallback);
        });
        Button closeBtn = dialogLayout.findViewById(R.id.close_image_btn);
        closeBtn.setOnClickListener(v -> {
            dialog.cancel();
            isPass = true;
        });
        dialog.show();

        pictureCallback = (bytes, camera) -> {
            Matrix matrix = new Matrix();
            matrix.postRotate(90F);
            thumbnail = Bitmap.createBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length), 0, 0, BitmapFactory.decodeByteArray(bytes, 0, bytes.length).getWidth(), BitmapFactory.decodeByteArray(bytes, 0, bytes.length).getHeight(), matrix, true);
            profilePhotoIV.setImageBitmap(thumbnail);
            camera.stopPreview();
            if (camera != null) {
                camera.release();
                mCamera = null;
            }
            dialog.cancel();
            isPass = true;
        };

        surfaceView.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                focusOnTouch(motionEvent);
            }
            return false;
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        new Handler().post(() -> {
            if (requestCode == PERMISSION_CODE) {
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    showAlertDialog();
                } else {
                    isPass = true;
                    Toast.makeText(context, "Permission denied...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void uploadImage() {
        new Handler().post(() -> {
            if (thumbnail != null) {
                final StorageReference mountainImagesRef = mStorageRef.child("/EmployeeImage" + "/" + empId + "/" + "profilePhoto.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> {
                    mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        if (uri != null) {
//                            profilePhotoURL = uri.toString();
                            employeeStructureMap.put("profilePhotoURL", uri.toString());
                            GeneralDetailFragment.this.UploadEmpInfo();
                        }
                    }).addOnFailureListener(e -> cmn.showAlertDialog("Alert", "Please Retry", false, context));
                });
            } else {
                UploadEmpInfo();
            }
        });
    }
}