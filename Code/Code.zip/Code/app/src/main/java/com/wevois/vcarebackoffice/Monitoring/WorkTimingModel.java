package com.wevois.vcarebackoffice.Monitoring;

public class WorkTimingModel {
    String ward;
    String dutyin;
    String synctime;
    String wardin;
    String wardout;
    String dutyout;

    public WorkTimingModel(String ward, String dutyin, String synctime, String wardin, String wardout, String dutyout) {
        this.ward = ward;
        this.dutyin = dutyin;
        this.synctime = synctime;
        this.wardin = wardin;
        this.wardout = wardout;
        this.dutyout = dutyout;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getDutyin() {
        return dutyin;
    }

    public void setDutyin(String dutyin) {
        this.dutyin = dutyin;
    }

    public String getSynctime() {
        return synctime;
    }

    public void setSynctime(String synctime) {
        this.synctime = synctime;
    }

    public String getWardin() {
        return wardin;
    }

    public void setWardin(String wardin) {
        this.wardin = wardin;
    }

    public String getWardout() {
        return wardout;
    }

    public void setWardout(String wardout) {
        this.wardout = wardout;
    }

    public String getDutyout() {
        return dutyout;
    }

    public void setDutyout(String dutyout) {
        this.dutyout = dutyout;
    }
}
