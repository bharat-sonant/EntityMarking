package com.wevois.vcarebackoffice.employeeattendance.model;

import android.text.SpannableString;

public class SalaryModels {
    String ward;
    SpannableString duration;
    String salary;
    String message;
    boolean isVisibleWard;
    boolean isVisible;

    public SalaryModels(String ward, SpannableString duration, String salary, String message, boolean isVisibleWard, boolean isVisible) {
        this.ward = ward;
        this.duration = duration;
        this.salary = salary;
        this.message = message;
        this.isVisibleWard = isVisibleWard;
        this.isVisible = isVisible;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public SpannableString getDuration() {
        return duration;
    }

    public void setDuration(SpannableString duration) {
        this.duration = duration;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isVisibleWard() {
        return isVisibleWard;
    }

    public void setVisibleWard(boolean visibleWard) {
        isVisibleWard = visibleWard;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    @Override
    public String toString() {
        return "SalaryModels{" +
                "ward='" + ward + '\'' +
                ", duration=" + duration +
                ", salary='" + salary + '\'' +
                ", message='" + message + '\'' +
                ", isVisibleWard=" + isVisibleWard +
                ", isVisible=" + isVisible +
                '}';
    }
}
