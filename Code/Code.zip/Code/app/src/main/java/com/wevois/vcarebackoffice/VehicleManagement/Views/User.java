package com.wevois.vcarebackoffice.VehicleManagement.Views;

public class User {
    String createdBy, createdDate,oilFillDateTextView,type;

    public User(String createdBy, String createdDate, String oilFillDateTextView, String type) {
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.oilFillDateTextView = oilFillDateTextView;
        this.type = type;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getOilFillDateTextView() {
        return oilFillDateTextView;
    }

    public void setOilFillDateTextView(String oilFillDateTextView) {
        this.oilFillDateTextView = oilFillDateTextView;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "User{" +
                "createdBy='" + createdBy + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", oilFillDateTextView='" + oilFillDateTextView + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}

