package com.wevois.vcarebackoffice.EmployeeSalary;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class ShowEmployeeSalaryActivity extends AppCompatActivity {
    TextView backBtn, DateName, dateBtn,nameTv;
    ListView listView;
    ArrayList<Model> list = new ArrayList<>();
    Adapter adapter = new Adapter();
    LinearLayout errorMessageLayout,mainLayout;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences preferences;
    DatabaseReference databaseReference;
    MonthAndYearAdapter monthAndYearAdapter = new MonthAndYearAdapter();
    BottomSheetDialog customTimerAlertBox;
    ArrayList<MonthAndYearModel> monthAndYearList = new ArrayList<>();
    SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
    SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMMM");
    SimpleDateFormat dateFormat3 = new SimpleDateFormat("MM");
    boolean isMoved = true, isMonth = true;
    int yearNumber = 0, monthNumber = 0;
    String loginId = "";
    Date date=null;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_employee_salary);
        initMethod();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initMethod() {
        errorMessageLayout = findViewById(R.id.errorEmployeeSalaryLayout);
        mainLayout = findViewById(R.id.mainEmployeeLayout);
        backBtn = findViewById(R.id.backBtnSalary);
        backBtn.setOnClickListener(view -> onBackPressed());
        preferences = getSharedPreferences("navigator.app.preferences", MODE_PRIVATE);
        preferences = getSharedPreferences("loginData", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
//        loginId = preferences.getString("loginType", "");
        loginId = "126";
        DateName = findViewById(R.id.toolbar_title_salary);
        dateBtn = findViewById(R.id.filterDate);
        dateBtn = findViewById(R.id.filterDate);
        listView = findViewById(R.id.employeeSalaryDetailsListView);
        listView.setAdapter(adapter);
        Calendar cal = Calendar.getInstance();
        yearNumber = cal.get(Calendar.YEAR);
        monthNumber = cal.get(Calendar.MONTH)-1;
        try {
            date = input.parse(yearNumber + "-" + (monthNumber + 1) + "-01");
        }catch (Exception e){ }
        DateName.setText(dateFormat1.format(date)+" " +dateFormat.format(date));
        try {
            common.setProgressDialog("", "कृपया प्रतिक्षा करे |", ShowEmployeeSalaryActivity.this, ShowEmployeeSalaryActivity.this);
            currentMonth(dateFormat1.format(date), dateFormat.format(date));
            dateBtn.setOnClickListener(v -> {
                customTimerAlertBox();
            });
        } catch (Exception e) {
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onResume() {
        super.onResume();
        isMoved = true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("StaticFieldLeak")
    private void currentMonth(final String month, final String year) {
        ShowEmployeeSalaryActivity.this.runOnUiThread(() -> {
            databaseReference.child("EmployeeSalary/" + year + "/" + month + "/" + loginId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    try {
                        list.clear();
                        adapter.notifyDataSetChanged();
                    }catch (Exception e){}
                    isMoved = true;
                    common.closeDialog(ShowEmployeeSalaryActivity.this);
                    if (dataSnapshot.getValue()!=null) {
                        errorMessageLayout.setVisibility(View.GONE);
                        mainLayout.setVisibility(View.VISIBLE);
                        String[] dataString = dataSnapshot.getValue().toString().trim().split("~#");
                        for (int i=0;i<dataString.length;i++){
                            String[] keyValue = dataString[i].trim().split(":-");
                            if (keyValue.length==2) {
                                list.add(new Model(keyValue[0], keyValue[1]));
                            }else if (keyValue.length==1){
                                list.add(new Model(keyValue[0], ""));
                            }
                        }
                        adapter.notifyDataSetChanged();
                        common.closeDialog(ShowEmployeeSalaryActivity.this);
                    }else {
                        errorMessageLayout.setVisibility(View.VISIBLE);
                        mainLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        });
    }

    private static class Model {
        private String key;
        private String name;

        public Model(String key, String name) {
            this.key = key;
            this.name = name;
        }

        public String getKey() {
            return key;
        }

        public String getName() {
            return name;
        }
    }

    private class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView key, value;
            convertView = LayoutInflater.from(ShowEmployeeSalaryActivity.this).inflate(R.layout.employee_salary_details_data, parent, false);
            key = convertView.findViewById(R.id.detailsKey);
            value = convertView.findViewById(R.id.detailsValue);
            Model model = list.get(position);
            key.setText(model.getKey());
            value.setText(model.getName());

            return convertView;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void customTimerAlertBox() {
        try {
            if (customTimerAlertBox != null) {
                customTimerAlertBox.dismiss();
            }
        } catch (Exception e) {
        }

        LayoutInflater inflater = getLayoutInflater();
        customTimerAlertBox = new BottomSheetDialog(ShowEmployeeSalaryActivity.this);
        View dialogLayout = inflater.inflate(R.layout.custom_year_and_month_picker, null);
        customTimerAlertBox.setContentView(dialogLayout);
        customTimerAlertBox.setCancelable(false);
        TextView month = dialogLayout.findViewById(R.id.selectMonth);
        TextView year = dialogLayout.findViewById(R.id.selectYear);
        TextView okeyBtn = dialogLayout.findViewById(R.id.alertOkeyBtn);
        TextView cancelBtn = dialogLayout.findViewById(R.id.alertCancelBtn);
        GridView listViews = dialogLayout.findViewById(R.id.monthAndYearList);
        listViews.setAdapter(monthAndYearAdapter);
        Calendar cal = Calendar.getInstance();
        yearNumber = cal.get(Calendar.YEAR);
        monthNumber = cal.get(Calendar.MONTH)-1;
        callMonthAdapter();
        month.setBackgroundColor(Color.parseColor("#10AD24"));
        month.setTextColor(Color.parseColor("#ffffff"));
        year.setBackgroundColor(Color.parseColor("#c1c1c1"));
        year.setTextColor(Color.parseColor("#000000"));
        month.setOnClickListener(view -> {
            month.setBackgroundColor(Color.parseColor("#10AD24"));
            month.setTextColor(Color.parseColor("#ffffff"));
            year.setBackgroundColor(Color.parseColor("#c1c1c1"));
            year.setTextColor(Color.parseColor("#000000"));
            callMonthAdapter();
        });
        year.setOnClickListener(view -> {
            month.setBackgroundColor(Color.parseColor("#c1c1c1"));
            month.setTextColor(Color.parseColor("#000000"));
            year.setBackgroundColor(Color.parseColor("#10AD24"));
            year.setTextColor(Color.parseColor("#ffffff"));
            callYearAdapter();
        });
        okeyBtn.setOnClickListener(v -> {
            if (isMoved) {
                isMoved = false;
                customTimerAlertBox.cancel();
                customTimerAlertBox.dismiss();
                try {
                    date = input.parse(yearNumber + "-" + (monthNumber + 1) + "-01");
                    common.setProgressDialog("", "कृपया प्रतिक्षा करे |", ShowEmployeeSalaryActivity.this, ShowEmployeeSalaryActivity.this);
                    Calendar startCalendar = new GregorianCalendar();
                    startCalendar.setTime(new Date());
                    Calendar endCalendar = new GregorianCalendar();
                    endCalendar.setTime(new SimpleDateFormat("dd/MM/yyyy").parse("01/" + dateFormat3.format(date) + "/" + dateFormat.format(date)));
                    DateName.setText(dateFormat1.format(date)+" " +dateFormat.format(date));
                    int diffYear = startCalendar.get(Calendar.YEAR) - endCalendar.get(Calendar.YEAR);
                    int diffMonth = diffYear * 12 + startCalendar.get(Calendar.MONTH) - endCalendar.get(Calendar.MONTH);
                    if (String.valueOf(diffMonth).toLowerCase().contains("-") || diffMonth == 0) {
                        errorMessageLayout.setVisibility(View.VISIBLE);
                        listViews.setVisibility(View.GONE);
                        isMoved = true;
                        common.closeDialog(ShowEmployeeSalaryActivity.this);
                    } else {
                        errorMessageLayout.setVisibility(View.GONE);
                        listViews.setVisibility(View.GONE);
                        currentMonth(dateFormat1.format(date), dateFormat.format(date));
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
        cancelBtn.setOnClickListener(v -> {
            customTimerAlertBox.cancel();
            customTimerAlertBox.dismiss();
        });
        customTimerAlertBox.create();
        ((View) dialogLayout.getParent()).setBackgroundColor(Color.TRANSPARENT);
        if (!isFinishing()) {
            customTimerAlertBox.show();
        }
    }

    private void callMonthAdapter() {
        isMonth = true;
        try {
            monthAndYearList.clear();
            monthAndYearAdapter.notifyDataSetChanged();
        } catch (Exception e) {
        }
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        for (int i = 0; i < monthNames.length; i++) {
            if (i == monthNumber) {
                monthAndYearList.add(new MonthAndYearModel(monthNames[i], i, "yes"));
            } else {
                monthAndYearList.add(new MonthAndYearModel(monthNames[i], i, "no"));
            }
        }
        monthAndYearAdapter.notifyDataSetChanged();
    }

    private void callYearAdapter() {
        isMonth = false;
        try {
            monthAndYearList.clear();
            monthAndYearAdapter.notifyDataSetChanged();
        } catch (Exception e) {
        }
        for (int y = 2019; y <= yearNumber; y++) {
            if (y == yearNumber) {
                monthAndYearList.add(new MonthAndYearModel("" + y, 0, "yes"));
            } else {
                monthAndYearList.add(new MonthAndYearModel("" + y, 0, "no"));
            }
        }
        monthAndYearAdapter.notifyDataSetChanged();
    }

    private static class MonthAndYearModel {
        String monthAndYear;
        int position;
        String selected;

        public MonthAndYearModel(String monthAndYear, int position, String selected) {
            this.monthAndYear = monthAndYear;
            this.position = position;
            this.selected = selected;
        }

        public String getMonthAndYear() {
            return monthAndYear;
        }

        public void setMonthAndYear(String monthAndYear) {
            this.monthAndYear = monthAndYear;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }

        public String getSelected() {
            return selected;
        }

        public void setSelected(String selected) {
            this.selected = selected;
        }
    }

    private class MonthAndYearAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return monthAndYearList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @SuppressLint({"ViewHolder", "ResourceType"})
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView date;
            convertView = LayoutInflater.from(ShowEmployeeSalaryActivity.this).inflate(R.layout.month_year_dailog, parent, false);
            date = convertView.findViewById(R.id.monthAndYearName);
            MonthAndYearModel monthAndYearModel = monthAndYearList.get(position);
            if (monthAndYearModel.getSelected().equalsIgnoreCase("yes")) {
                date.setBackgroundColor(Color.parseColor("#10AD24"));
                date.setTextColor(Color.parseColor("#ffffff"));
            } else {
                date.setBackgroundColor(Color.parseColor("#ffffff"));
                date.setTextColor(Color.parseColor("#000000"));
            }
            date.setText(monthAndYearModel.getMonthAndYear());
            date.setOnClickListener(view -> {
                if (isMonth) {
                    monthNumber = monthAndYearModel.getPosition();
                } else {
                    yearNumber = Integer.parseInt(monthAndYearModel.getMonthAndYear());
                }
                for (int i = 0; i < monthAndYearList.size(); i++) {
                    if (i == position) {
                        monthAndYearList.get(i).setSelected("yes");
                    } else {
                        monthAndYearList.get(i).setSelected("no");
                    }
                }
                monthAndYearAdapter.notifyDataSetChanged();
            });
            return convertView;
        }
    }
}