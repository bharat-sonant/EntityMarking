package com.wevois.vcarebackoffice.employeeattendance.views;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivityHaltPageBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.HaltPageViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.HaltPageViewModelFactory;

public class HaltPage extends AppCompatActivity {
    ActivityHaltPageBinding binding;
    HaltPageViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_halt_page);
        viewModel = new ViewModelProvider(this,new HaltPageViewModelFactory(this)).get(HaltPageViewModel.class);
        binding.setHaltpageviewmodel(viewModel);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            if(resultCode == RESULT_OK) {
                viewModel.onResult(data);
            }
        }
    }
}