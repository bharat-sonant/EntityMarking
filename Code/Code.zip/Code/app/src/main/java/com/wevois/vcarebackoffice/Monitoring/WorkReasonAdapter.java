package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class WorkReasonAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> ward;
    private ArrayList<String> reason;

    public WorkReasonAdapter(Context context, ArrayList<String> ward, ArrayList<String> reason) {
        this.context = context;
        this.ward = ward;
        this.reason = reason;
    }

    @Override
    public int getCount() {
        return ward.size();
    }

    @Override
    public Object getItem(int position) {
        return ward.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MyViewHolder myViewHolder;
        if (convertView==null){
            myViewHolder = new MyViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.reason_list_row,parent,false);
            myViewHolder.wardTv = convertView.findViewById(R.id.ward);
            myViewHolder.reasonTv = convertView.findViewById(R.id.reason);
            convertView.setTag(myViewHolder);
        } else {
            myViewHolder = (MyViewHolder) convertView.getTag();
        }
        myViewHolder.wardTv.setText(ward.get(position));
        myViewHolder.reasonTv.setText(reason.get(position));
        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getViewTypeCount() {
        return super.getViewTypeCount();
    }

    private class MyViewHolder{
        private TextView wardTv, reasonTv;
    }
}
