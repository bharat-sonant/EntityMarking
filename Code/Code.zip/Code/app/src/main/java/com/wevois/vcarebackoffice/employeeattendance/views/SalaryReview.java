package com.wevois.vcarebackoffice.employeeattendance.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivitySalaryReviewBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.SalaryReviewViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.SalaryReviewViewModelFactory;

public class SalaryReview extends AppCompatActivity {
    ActivitySalaryReviewBinding binding;
    SalaryReviewViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_salary_review);
        viewModel = new ViewModelProvider(this,new SalaryReviewViewModelFactory(this)).get(SalaryReviewViewModel.class);
        binding.setSalaryreviewviewmodel(viewModel);
    }
}