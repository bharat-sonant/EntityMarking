package com.wevois.vcarebackoffice.Vehicle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;


public class CustomAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<String> vehicleNoList;
    private ArrayList<String> zoneNoList;
    private buttonClickListener mClickListener;

    void setClickListener(buttonClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }


    public static interface buttonClickListener {
        void onMethodCallback(String vNo,String zNo);
    }

    public CustomAdapter(Context context, ArrayList<String> vNo,ArrayList<String> zNo) {

        this.context = context;
        this.vehicleNoList = vNo;
        this.zoneNoList = zNo;
    }

    @Override
    public int getViewTypeCount() {
        if(getCount() > 0){
            return getCount();
        }else{
            return super.getViewTypeCount();
        }
    }
    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public int getCount() {
        return vehicleNoList.size();
    }

    @Override
    public Object getItem(int position) {
        return vehicleNoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.vehicle_zone_list_view, null, true);


            holder.vehicleNo = (TextView) convertView.findViewById(R.id.vehicleNoLV);
            holder.zoneNo = (TextView) convertView.findViewById(R.id.zoneNoLV);
            holder.viewBtn = (ImageButton) convertView.findViewById(R.id.viewBtn);

            convertView.setTag(holder);
        }else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (ViewHolder)convertView.getTag();
        }
        holder.vehicleNo.setText(vehicleNoList.get(position));
        holder.zoneNo.setText(zoneNoList.get(position));
        holder.viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mClickListener!=null){
                    mClickListener.onMethodCallback(vehicleNoList.get(position),zoneNoList.get(position));
                }
            }
        });

        return convertView;
    }

    private class ViewHolder {

        ImageButton viewBtn;
        private TextView vehicleNo, zoneNo;

    }

}
