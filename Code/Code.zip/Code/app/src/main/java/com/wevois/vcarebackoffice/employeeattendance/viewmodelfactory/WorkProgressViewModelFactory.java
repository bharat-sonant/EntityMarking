package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.maps.SupportMapFragment;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.WorkProgressViewModel;

public class WorkProgressViewModelFactory implements ViewModelProvider.Factory {
    Activity activity;
    SupportMapFragment fragment;

    public WorkProgressViewModelFactory(Activity activity, SupportMapFragment fragmentById) {
        this.activity = activity;
        this.fragment = fragmentById;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new WorkProgressViewModel(activity,fragment);
    }
}
