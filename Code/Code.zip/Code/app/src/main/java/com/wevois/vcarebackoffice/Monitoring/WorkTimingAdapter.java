package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class WorkTimingAdapter extends BaseAdapter {
    private Context context;
    private String notAssigned ;

    ArrayList<WorkTimingModel> salaryMonitoringList;
    public WorkTimingAdapter(Context context, ArrayList<WorkTimingModel> salaryMonitoringList) {
        this.context = context;
        this.salaryMonitoringList = salaryMonitoringList;
        notAssigned = new CommonUtils(context).notAssigned;
    }

    @Override
    public int getCount() {
        return salaryMonitoringList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.check_ward_timing, null, true);


            holder.wardTv = (TextView) convertView.findViewById(R.id.wardNo);
            holder.dutyInTv = (TextView) convertView.findViewById(R.id.dutyIn);
            holder.wardInTv = (TextView) convertView.findViewById(R.id.wardIn);
            holder.wardOutTv = (TextView) convertView.findViewById(R.id.wardOut);
            holder.dutyOutTv = (TextView) convertView.findViewById(R.id.dutyOut);
            holder.syncedTimeTv = (TextView) convertView.findViewById(R.id.syncTime);

            convertView.setTag(holder);
        }else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (WorkTimingAdapter.ViewHolder)convertView.getTag();
        }
        WorkTimingModel sList = salaryMonitoringList.get(position);
        holder.wardTv.setText(sList.getWard());
        holder.dutyInTv.setText(sList.getDutyin());
        holder.wardInTv.setText(sList.getWardin());
        holder.wardOutTv.setText(sList.getWardout());
        holder.dutyOutTv.setText(sList.getDutyout());
        holder.syncedTimeTv.setText(sList.getSynctime());

        return convertView;
    }

    private class ViewHolder {
        private TextView wardTv, dutyInTv, wardInTv, wardOutTv, dutyOutTv,syncedTimeTv;
    }
}
