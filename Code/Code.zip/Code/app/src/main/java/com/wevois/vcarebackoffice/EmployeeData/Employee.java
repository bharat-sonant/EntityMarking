package com.wevois.vcarebackoffice.EmployeeData;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Employee extends AppCompatActivity {
    String statusId = "1", from;
    private boolean dataDisplaying;
    String empCode = " ", city = null;
    DatabaseReference databaseReference;
    DataSnapshot employeeSnap;
    JSONArray defaultSnap = new JSONArray();
    boolean empDataBool = false, defaultDataBool = false;
    CommonFunctions common = CommonFunctions.getInstance();
    EmployeeList employeeListAdapter = new EmployeeList();
    ArrayList<EmployeePOJO> originalData = new ArrayList<>();
    ArrayList<EmployeePOJO> filteredData = new ArrayList<>();
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);
        setPageTitle();
        initPage();
        setAction();
        getEmployee();
        setDefault();
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Employee list");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        city = sharedPreferences.getString("city", " ").substring(0, 3).toUpperCase();
        databaseReference = common.getDatabasePath(this);

        ListView empListView = findViewById(R.id.empListView);
        empListView.setAdapter(employeeListAdapter);
        getDesignation();
    }

    private void setAction() {
        findViewById(R.id.addEmpBtn).setOnClickListener(v -> {
            common.setProgressDialog("Please Wait...", " ", Employee.this, this);
            if (!sharedPreferences.getString("EmployeeCreationPermission", "").equalsIgnoreCase("")) {
                try {
                    JSONObject jsonObject = new JSONObject(sharedPreferences.getString("EmployeeCreationPermission", ""));
                    if (jsonObject.has(sharedPreferences.getString("city", " "))) {
                        if (!employeeSnap.hasChild(getSharedPreferences("loginData", MODE_PRIVATE).getString("loginId", ""))) {
                            moveToEmployeeAdd();
                        } else {
                            if (employeeSnap.hasChild(getSharedPreferences("loginData", MODE_PRIVATE).getString("loginId", "") + "/GeneralDetails/designationId")) {
                                String desig = employeeSnap.child(getSharedPreferences("loginData", MODE_PRIVATE).getString("loginId", "") + "/GeneralDetails/designationId").getValue().toString();
                                List<String> notAllowDesignation = Arrays.asList(jsonObject.getString(sharedPreferences.getString("city", " ")).toString().split(","));
                                if (notAllowDesignation.contains(desig)) {
                                    common.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your superviser.", false, this);
                                } else {
                                    moveToEmployeeAdd();
                                }
                            }
                        }
                    } else {
                        moveToEmployeeAdd();
                    }
                } catch (Exception e) {
                }
            } else {
                moveToEmployeeAdd();
            }
        });
    }

    private void moveToEmployeeAdd() {
        common.setProgressDialog("Wait", "Loading...", this, this);
        databaseReference.child("Employees/lastEmpId").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    int idNo = (Integer.parseInt(dataSnapshot.getValue().toString())) + 1;
                    empCode = city + idNo;
                    String newEmpId = String.valueOf(idNo);
                    Intent intent = new Intent(Employee.this, Registration.class);
                    from = "add";
                    intent.putExtra("empCode", empCode);
                    intent.putExtra("empId", newEmpId);
                    intent.putExtra("from", from);
                    intent.putExtra("city", city);
                    startActivity(intent);
                    common.closeDialog(Employee.this);
                    finish();
                } else {
                    common.showAlertDialog("", "Please Contact Developer", false, Employee.this);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setDefault() {
        EditText searchEditText = findViewById(R.id.searchEditText);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String text = searchEditText.getText().toString();
                filter(text);
            }
        });
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.activeUsers) {
                statusId = "1";
            } else if (checkedId == R.id.inActiveUsers) {
                statusId = "2";
            }
            if (dataDisplaying) {
                Toast.makeText(Employee.this, "List Loading, Please Wait", Toast.LENGTH_SHORT).show();
                return;
            }
            showList(statusId);
        });
    }

    private void getDesignation() {
        try {
            defaultSnap = new JSONArray(sharedPreferences.getString("designationList", ""));
            defaultDataBool = true;
            showList("1");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getEmployee() {
        databaseReference.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() == null) {
                    common.closeDialog(Employee.this);
                    new CommonUtils(Employee.this).showAlertDialog("no employee details in our database");
                    return;
                }
                employeeSnap = dataSnapshot;
                empDataBool = true;
                showList("1");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void showList(String statusId) {
        if (!dataDisplaying) {
            if (empDataBool && defaultDataBool) {
                if (employeeSnap == null && defaultSnap == null) {
                    common.closeDialog(this);
                    new CommonUtils(Employee.this).showAlertDialog("Something went wrong with database");
                    return;
                }
                dataDisplaying = true;
                originalData.clear();
                filteredData.clear();
                assert employeeSnap != null;
                for (DataSnapshot dataSnapshot1 : employeeSnap.getChildren()) {
                    String username = "", mNo = "", name1 = "", designationId = "", name, url = "", accountNo = "", ifsc;
                    boolean bankDetailsSaved = false, isApproved = false;
                    if (dataSnapshot1.child("GeneralDetails").hasChild("status")) {
                        String sId = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("status").getValue()).toString();
                        if (sId.equals(statusId)) {
                            if (dataSnapshot1.child("GeneralDetails").hasChild("userName"))
                                username = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("userName").getValue()).toString();
                            if (dataSnapshot1.child("GeneralDetails").hasChild("mobile"))
                                mNo = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("mobile").getValue()).toString();
                            if (dataSnapshot1.child("GeneralDetails").hasChild("name"))
                                name1 = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("name").getValue()).toString();
                            if (dataSnapshot1.child("GeneralDetails").hasChild("designationId"))
                                designationId = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("designationId").getValue()).toString();
                            name = name1.toUpperCase() + " (" + username + ")";
                            if (dataSnapshot1.child("GeneralDetails").hasChild("profilePhotoURL"))
                                url = Objects.requireNonNull(dataSnapshot1.child("GeneralDetails").child("profilePhotoURL").getValue()).toString();
                            if (dataSnapshot1.child("BankDetails").child("AccountDetails").hasChild("accountNumber")) {
                                accountNo = Objects.requireNonNull(dataSnapshot1.child("BankDetails").child("AccountDetails").child("accountNumber").getValue()).toString();
                            }
                            if (dataSnapshot1.child("BankDetails").child("AccountDetails").hasChild("ifsc") &&
                                    dataSnapshot1.child("AddressDetails").child("CurrentAddress").hasChild("city") &&
                                    dataSnapshot1.child("IdentificationDetails").child("AadharCardDetails").hasChild("aadharNumber") &&
                                    dataSnapshot1.child("OtherDetails").hasChild("nationality")) {
                                bankDetailsSaved = true;
                            }
                            if (dataSnapshot1.child("OtherDetails").hasChild("isApproved")) {
                                isApproved = Boolean.parseBoolean(dataSnapshot1.child("OtherDetails").child("isApproved").getValue().toString());
                            }
                            Log.d("TAG", "showList: check isApproved " + isApproved + "    " + bankDetailsSaved + "   " + username);

                            String desig = "Not Found";
                            try {
                                JSONObject jsonObject = defaultSnap.getJSONObject(Integer.parseInt(designationId));
                                if (jsonObject.has("name")) {
                                    desig = Objects.requireNonNull(jsonObject.get("name")).toString();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            final String finalDesig = desig;
                            originalData.add(new EmployeePOJO(mNo, name, finalDesig, url, bankDetailsSaved, username, isApproved));
                            filteredData.add(new EmployeePOJO(mNo, name, finalDesig, url, bankDetailsSaved, username, isApproved));
                            employeeListAdapter.notifyDataSetChanged();
                        }
                    }
                }
                employeeListAdapter.notifyDataSetChanged();
                common.closeDialog(this);
                dataDisplaying = false;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public class EmployeeList extends BaseAdapter {

        @Override
        public int getViewTypeCount() {
            if (getCount() > 0) {
                return getCount();
            } else {
                return super.getViewTypeCount();
            }
        }

        @Override
        public int getItemViewType(int position) {

            return position;
        }

        @Override
        public int getCount() {
            return filteredData.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.employee_list, parent, false);
            EmployeePOJO pojo = filteredData.get(position);

            TextView idTv, nameTv, desigTv;
            idTv = convertView.findViewById(R.id.empId);
            nameTv = convertView.findViewById(R.id.empName);
            desigTv = convertView.findViewById(R.id.empDesig);

            idTv.setText(pojo.getId());
            nameTv.setText(pojo.getName());
            desigTv.setText(pojo.getDesignation());

            ImageView errorInfo = convertView.findViewById(R.id.errorInfo);
            if (pojo.getBankDetails()) {
//            holder.errorInfo.setVisibility(View.INVISIBLE);
                if (pojo.getApproved()) {
                    errorInfo.setImageResource(R.drawable.approved_true);
                } else {
                    errorInfo.setImageResource(R.drawable.approved_false);
                }
            } else {
                errorInfo.setImageResource(R.drawable.approved_false);
            }

            ImageView imageView = convertView.findViewById(R.id.imageView3);
            if (pojo.getImage().equalsIgnoreCase("")) {
                Glide.with(Employee.this).load(R.drawable.profile_photo).fitCenter().into(imageView);
            } else {
                Glide.with(Employee.this).load(pojo.getImage()).fitCenter().into(imageView);
            }

            convertView.findViewById(R.id.editDetails).setOnClickListener(view -> {
                Intent intent = new Intent(Employee.this, Registration.class);
                empCode = city + pojo.getUsername();
                from = "edit";
                intent.putExtra("empCode", empCode);
                intent.putExtra("empId", pojo.getUsername());
                intent.putExtra("from", from);
                startActivity(intent);
                finish();
            });

            convertView.findViewById(R.id.addItem).setOnClickListener(view -> {
                Intent intent = new Intent(Employee.this, AddItemsActivity.class);
                intent.putExtra("id", pojo.getId());
                startActivity(intent);
            });
            return convertView;
        }
    }

    void filter(String text) {
        text = text.toUpperCase();

        filteredData = new ArrayList<>();
        if (text.length() == 0) {
            filteredData = originalData;
            employeeListAdapter.notifyDataSetChanged();
        } else {
            for (EmployeePOJO employeePOJO : originalData) {
                String fullName = employeePOJO.getName();
                if (fullName.contains(text))
                    filteredData.add(employeePOJO);
            }
            employeeListAdapter.notifyDataSetChanged();
        }
    }

}