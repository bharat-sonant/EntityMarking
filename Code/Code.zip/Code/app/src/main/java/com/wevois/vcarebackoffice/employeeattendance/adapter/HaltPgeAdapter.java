package com.wevois.vcarebackoffice.employeeattendance.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevois.vcarebackoffice.databinding.HaltListLayoutBinding;
import com.wevois.vcarebackoffice.employeeattendance.Interface.OnClickInterface;
import com.wevois.vcarebackoffice.employeeattendance.model.HaltPageModel;

import java.util.ArrayList;

public class HaltPgeAdapter extends RecyclerView.Adapter<HaltPgeAdapter.ParentViewHolder> {

    ArrayList<HaltPageModel> models;
    Context context;
    OnClickInterface onClickInterface;

    public HaltPgeAdapter(ArrayList<HaltPageModel> models, Context context,OnClickInterface onClickInterface){
        this.models = models;
        this.context = context;
        this.onClickInterface = onClickInterface;
    }

    @NonNull
    @Override
    public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        HaltListLayoutBinding binding = HaltListLayoutBinding.inflate(layoutInflater,parent,false);

        return new ParentViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
        HaltPageModel model = models.get(position);
        holder.binding.setHalt(model);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    class ParentViewHolder extends RecyclerView.ViewHolder{
        HaltListLayoutBinding binding;

        public ParentViewHolder(HaltListLayoutBinding itemVeiw){
            super(itemVeiw.getRoot());
            this.binding = itemVeiw;
            itemVeiw.iconDelete.setOnClickListener(view -> onClickInterface.onItemClick(getAdapterPosition()));
        }
    }
}

