package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.repository.LogBookRepository;
import com.wevois.vcarebackoffice.employeeattendance.views.DutyOffKotlin;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class LogBookViewModel extends ViewModel {
    Activity activity;
    Spinner reasonSpinner;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences preferences;
    LogBookRepository repository = new LogBookRepository();
    ArrayList<OtherDetails> otherDetails;
    ArrayList<ParentRecyclerviewModel> userModels;
    List<String> reasonTypeList = new ArrayList<>();
    public ObservableField<Boolean> isVisible = new ObservableField<>(false);
    public ObservableField<Bitmap> imageViewUrl = new ObservableField<>();
    Bitmap bitmap = null;
    String isRequired="";
    boolean isMoved = true;
    String[] PERMISSIONS = {Manifest.permission.CAMERA};

    public LogBookViewModel(Activity activity, Spinner spinner) {
        this.activity = activity;
        this.reasonSpinner = spinner;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {}.getType());
        userModels = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {}.getType());
        common.setProgressDialog("Please wait...","",activity,activity);
        Log.d("TAG", "LogBookViewModel: check "+preferences.getString("logBookReasonsList", ""));
        repository.getLogBookPermission(activity, common, otherDetails.get(0).getWards().get(otherDetails.get(0).getWards().size() - 1)).observe((LifecycleOwner) activity, response -> {
            isRequired = response;
            Log.d("TAG", "LogBookViewModel: check "+isRequired+"   "+preferences.getString("logBookReasonsList", ""));
            if (response.equalsIgnoreCase("no")) {
                reasonTypeList.add("Select Reason");
                JSONArray jsonObject;
                try {
                    jsonObject = new JSONArray(preferences.getString("logBookReasonsList", ""));
                    for (int i = 1; i <= jsonObject.length(); i++) {
                        try {
                            if (!jsonObject.getString(i).equalsIgnoreCase("null")) {
                                reasonTypeList.add(jsonObject.getString(i));
                            }
                        }catch (Exception e){}
                    }
                    bindHouseTypesToSpinner();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            common.closeDialog(activity);
        });
    }

    @BindingAdapter({"imageUrl"})
    public static void loadImage(ImageView view, Bitmap bitmap) {
        if (bitmap == null) {
            view.setImageResource(R.drawable.no_image);
        } else {
            view.setImageBitmap(bitmap);
        }
    }

    public void onCapture(){
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, PERMISSIONS, 0000);
            Toast.makeText(activity, "Please allow camera permissions", Toast.LENGTH_SHORT).show();
            return;
        }
        common.captureDialog(activity).observe((LifecycleOwner) activity,response->{
            if (response != null) {
                bitmap=response;
                imageViewUrl.set(response);
            }
        });
    }

    public void onContinue(){
        if (isRequired.equalsIgnoreCase("yes")){
            if (bitmap==null) {
                common.showAlertDialog("Please click photo first.","",false,activity);
            }else {
                common.setProgressDialog("Please wait...", "", activity, activity);
                saveImageData();
            }
        }else {
            if (bitmap==null) {
                if (reasonSpinner.getSelectedItem()!=null) {
                    if (reasonSpinner.getSelectedItem().toString().equals("Select Reason")) {
                        View selectedView = reasonSpinner.getSelectedView();
                        if (selectedView != null && selectedView instanceof TextView) {
                            reasonSpinner.requestFocus();
                            TextView selectedTextView = (TextView) selectedView;
                            selectedTextView.setError("error");
                            selectedTextView.setTextColor(Color.RED);
                            selectedTextView.setText("Please select reason");
                            reasonSpinner.performClick();
                        }
                    } else {
                        if (isMoved) {
                            isMoved = false;
                            common.setProgressDialog("Please wait...", "", activity, activity);
                            repository.setWasteCollectionData(activity, common, otherDetails.get(0).getWards().get(otherDetails.get(0).getWards().size() - 1), reasonSpinner.getSelectedItem().toString(), "logBookImageNotCaptureReason").observe((LifecycleOwner) activity, response -> {
                                if (response.equalsIgnoreCase("fail")) {
                                    isMoved = true;
                                } else {
                                    moveActivity();
                                }
                            });
                        }
                    }
                }
            }else {
                common.setProgressDialog("Please wait...", "", activity, activity);
                saveImageData();
            }
        }
    }

    private void moveActivity() {
        common.closeDialog(activity);
        Intent intent = new Intent(activity, DutyOffKotlin.class);
        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
        intent.putExtra("userModel", new Gson().toJson(userModels));
        activity.startActivity(intent);
        isMoved = true;
    }

    private void bindHouseTypesToSpinner() {
        common.closeDialog(activity);
        isVisible.set(true);
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(activity, android.R.layout.simple_spinner_dropdown_item, reasonTypeList) {
            @Override
            public boolean isEnabled(int position) {
                return !(position == 0);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reasonSpinner.setAdapter(spinnerArrayAdapter);
    }

    @SuppressLint("StaticFieldLeak")
    private void saveImageData() {
        if(isMoved) {
            isMoved = false;
            repository.setLogBookImage(bitmap, preferences, common, otherDetails.get(0).getWards().get(otherDetails.get(0).getWards().size() - 1)).observe((LifecycleOwner) activity, response -> {
                if (response.equalsIgnoreCase("fail")) {
                    isMoved = true;
                    common.showAlertDialog("Log Book photo not uploaded", "", false, activity);
                } else {
                    repository.setWasteCollectionData(activity, common, otherDetails.get(0).getWards().get(otherDetails.get(0).getWards().size() - 1), "logBook.jpg", "logBookImage").observe((LifecycleOwner) activity, response1 -> {
                        if (response.equalsIgnoreCase("fail")) {
                            isMoved = true;
                        } else {
                            moveActivity();
                        }
                    });
                }
            });
        }
    }

    public void onBack(){
        activity.finish();
    }
}