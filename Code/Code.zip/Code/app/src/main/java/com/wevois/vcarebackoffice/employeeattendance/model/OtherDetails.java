package com.wevois.vcarebackoffice.employeeattendance.model;

import java.util.ArrayList;

public class OtherDetails {
    ArrayList<String> wards;
    String vehicle;
    String planName;
    String planId;
    ArrayList<String> starts;
    ArrayList<Long> totalTimes;
    ArrayList<Long> totalHaltTime;
    ArrayList<Long> approvedTime;
    ArrayList<Long> approvedHaltTime;
    String time;
    ArrayList<String> offlineSave;
    String workPercentage;
    String newWard;
    String commonReference;

    public OtherDetails(ArrayList<String> wards, String vehicle, String planName, String planId, ArrayList<String> starts, ArrayList<Long> totalTimes, ArrayList<Long> totalHaltTime, ArrayList<Long> approvedTime, ArrayList<Long> approvedHaltTime, String time, ArrayList<String> offlineSave, String workPercentage, String newWard, String commonReference) {
        this.wards = wards;
        this.vehicle = vehicle;
        this.planName = planName;
        this.planId = planId;
        this.starts = starts;
        this.totalTimes = totalTimes;
        this.totalHaltTime = totalHaltTime;
        this.approvedTime = approvedTime;
        this.approvedHaltTime = approvedHaltTime;
        this.time = time;
        this.offlineSave = offlineSave;
        this.workPercentage = workPercentage;
        this.newWard = newWard;
        this.commonReference = commonReference;
    }

    public ArrayList<String> getWards() {
        return wards;
    }

    public void setWards(ArrayList<String> wards) {
        this.wards = wards;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public ArrayList<String> getStarts() {
        return starts;
    }

    public void setStarts(ArrayList<String> starts) {
        this.starts = starts;
    }

    public ArrayList<Long> getTotalTimes() {
        return totalTimes;
    }

    public void setTotalTimes(ArrayList<Long> totalTimes) {
        this.totalTimes = totalTimes;
    }

    public ArrayList<Long> getTotalHaltTime() {
        return totalHaltTime;
    }

    public void setTotalHaltTime(ArrayList<Long> totalHaltTime) {
        this.totalHaltTime = totalHaltTime;
    }

    public ArrayList<Long> getApprovedTime() {
        return approvedTime;
    }

    public void setApprovedTime(ArrayList<Long> approvedTime) {
        this.approvedTime = approvedTime;
    }

    public ArrayList<Long> getApprovedHaltTime() {
        return approvedHaltTime;
    }

    public void setApprovedHaltTime(ArrayList<Long> approvedHaltTime) {
        this.approvedHaltTime = approvedHaltTime;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public ArrayList<String> getOfflineSave() {
        return offlineSave;
    }

    public void setOfflineSave(ArrayList<String> offlineSave) {
        this.offlineSave = offlineSave;
    }

    public String getWorkPercentage() {
        return workPercentage;
    }

    public void setWorkPercentage(String workPercentage) {
        this.workPercentage = workPercentage;
    }

    public String getNewWard() {
        return newWard;
    }

    public void setNewWard(String previousWard) {
        this.newWard = previousWard;
    }

    public String getCommonReference() {
        return commonReference;
    }

    public void setCommonReference(String commonReference) {
        this.commonReference = commonReference;
    }

    @Override
    public String toString() {
        return "OtherDetails{" +
                "wards=" + wards +
                ", vehicle='" + vehicle + '\'' +
                ", planName='" + planName + '\'' +
                ", planId='" + planId + '\'' +
                ", starts=" + starts +
                ", totalTimes=" + totalTimes +
                ", totalHaltTime=" + totalHaltTime +
                ", approvedTime=" + approvedTime +
                ", approvedHaltTime=" + approvedHaltTime +
                ", time='" + time + '\'' +
                ", offlineSave=" + offlineSave +
                ", workPercentage='" + workPercentage + '\'' +
                ", previousWard='" + newWard + '\'' +
                ", commonReference='" + commonReference + '\'' +
                '}';
    }
}
