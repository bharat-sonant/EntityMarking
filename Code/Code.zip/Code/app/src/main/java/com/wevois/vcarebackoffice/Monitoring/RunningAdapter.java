package com.wevois.vcarebackoffice.Monitoring;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class RunningAdapter extends BaseAdapter {
    private Context context;

    ArrayList<RunningStatusModel> salaryMonitoringList;

    public RunningAdapter(Context context, ArrayList<RunningStatusModel> salaryMonitoringList) {
        this.context = context;
        this.salaryMonitoringList = salaryMonitoringList;
    }

    @Override
    public int getCount() {
        return salaryMonitoringList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final RunningAdapter.ViewHolder holder;

        if (convertView == null) {
            holder = new RunningAdapter.ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.running_status_list, null, true);

            holder.wardTv = convertView.findViewById(R.id.runningStatusWardName);
            holder.wardRunningDistance = convertView.findViewById(R.id.runningStatusWard);
            holder.totalRunningDistance = convertView.findViewById(R.id.runningStatusTotal);
            holder.workPercentage = convertView.findViewById(R.id.runningStatusWardPercentage);
            holder.manualReading = convertView.findViewById(R.id.manualReading);
            convertView.setTag(holder);
        }else {
            holder = (RunningAdapter.ViewHolder)convertView.getTag();
        }
        RunningStatusModel sList = salaryMonitoringList.get(position);
        holder.wardTv.setText(sList.getWard());
        holder.wardRunningDistance.setText(sList.getWardrunningdistance());
        holder.totalRunningDistance.setText(sList.getTotalrunningdistance());
        holder.workPercentage.setText(sList.getWorkpercentage());
        holder.manualReading.setText(sList.getManualreading());
        return convertView;
    }

    private class ViewHolder {
        private TextView wardTv, wardRunningDistance, totalRunningDistance, workPercentage,manualReading;
    }
}
