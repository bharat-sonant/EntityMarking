package com.wevois.vcarebackoffice;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.wevois.vcarebackoffice.Login.LoginSignUp;

import java.util.ArrayList;

public class CityDetailsAdapter extends BaseAdapter {
    private Context context;
    private Activity activity;
    private ArrayList<CityDetails> cityDetails;

    public CityDetailsAdapter(Context context, Activity activity, ArrayList<CityDetails> numberWord) {
        this.context = context;
        this.activity = activity;
        this.cityDetails = numberWord;
    }

    @Override
    public int getCount() {
        return cityDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.display_city_list, null, true);
        }
        TextView textView = convertView.findViewById(R.id.cityName);
        String s = cityDetails.get(position).getCityName();
        s = s.replace("-", " ");
        s=s.replace("WeVOIS ","");
        s = s.replace("Jaipur","");
        textView.setText(s);
        convertView.findViewById(R.id.linearLay).setOnClickListener(view -> {
            SharedPreferences pathSharedPreferences = activity.getSharedPreferences("path", MODE_PRIVATE);
            pathSharedPreferences.edit().putString("city", cityDetails.get(position).getCityName()).apply();
            pathSharedPreferences.edit().putString("key",cityDetails.get(position).getKey()).apply();
            pathSharedPreferences.edit().putString("pathRef", cityDetails.get(position).getDbPath()).apply();
            pathSharedPreferences.edit().putString("storagePathRef", cityDetails.get(position).getStoragePath()).apply();
            activity.startActivity(new Intent(context, LoginSignUp.class));
            activity.finish();
        });
        return convertView;
    }

}
