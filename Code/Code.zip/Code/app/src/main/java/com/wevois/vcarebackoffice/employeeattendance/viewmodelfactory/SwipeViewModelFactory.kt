package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory

import android.app.Activity
import android.widget.Spinner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.SwipeViewModel

class SwipeViewModelFactory(var activity: Activity, var spinner: Spinner) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return SwipeViewModel(activity, spinner) as T
    }
}