package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.employeeattendance.viewmodel.HaltReviewViewModel;

public class HaltReviewViewModelFactory implements ViewModelProvider.Factory {
    Activity activity;
    public HaltReviewViewModelFactory(Activity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new HaltReviewViewModel(activity);
    }
}
