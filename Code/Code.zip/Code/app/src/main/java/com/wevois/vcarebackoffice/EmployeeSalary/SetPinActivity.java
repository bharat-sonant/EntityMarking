package com.wevois.vcarebackoffice.EmployeeSalary;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

public class SetPinActivity extends AppCompatActivity {
    CommonFunctions common = CommonFunctions.getInstance();
    EditText[] otpEt = new EditText[4];
    SharedPreferences preferences;
    DatabaseReference databaseReference;
    TextView idNotFoundTv, messageTv, backBtn, backBtn1, salaryPinTv;
    LinearLayout mainLayout, pinOptionLayout;
    RelativeLayout congratulationLayout;
    String salaryPin = "", generatedPin = "",loginId="";
    int check = 0;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pin);
        idNotFoundTv = findViewById(R.id.idNotFound);
        mainLayout = findViewById(R.id.mainLayout);
        pinOptionLayout = findViewById(R.id.pinOption);
        backBtn = findViewById(R.id.backBtn);
        backBtn1 = findViewById(R.id.backBtn1);
        salaryPinTv = findViewById(R.id.pinTv);
        congratulationLayout = findViewById(R.id.congratulationLayout);
        messageTv = findViewById(R.id.messageTv);
        preferences = getSharedPreferences("loginData", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
//        loginId = preferences.getString("loginType", "");
        loginId = "104";
        boolean digitsOnly = TextUtils.isDigitsOnly(loginId);
        if (!digitsOnly) {
            idNotFoundTv.setVisibility(View.VISIBLE);
        } else {
            common.setProgressDialog("", "Please wait...", this, this);
            checkAndGetEmployeePin();
        }
        otpEt[0] = (EditText) findViewById(R.id.pin1);
        otpEt[1] = (EditText) findViewById(R.id.pin2);
        otpEt[2] = (EditText) findViewById(R.id.pin3);
        otpEt[3] = (EditText) findViewById(R.id.pin4);
        setOtpEditTextHandler();

        backBtn.setOnClickListener(view -> onBackPressed());
        backBtn1.setOnClickListener(view -> onBackPressed());
        findViewById(R.id.aageBadheBtn).setOnClickListener(view -> {
            Intent intent = new Intent(SetPinActivity.this, ShowEmployeeSalaryActivity.class);
            startActivity(intent);
            finish();
        });
        findViewById(R.id.changePin).setOnClickListener(view -> {
            check = 4;
            messageTv.setText(Html.fromHtml("आप अपना पुराना<br><b> सुरक्षा पिन</b> डाले |", Html.FROM_HTML_MODE_COMPACT));
        });
    }

    private void checkAndGetEmployeePin() {
        databaseReference.child("Employees/" + loginId + "/GeneralDetails/salaryPinCode").addListenerForSingleValueEvent(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    check = 3;
                    salaryPin = dataSnapshot.getValue().toString();
                    mainLayout.setVisibility(View.VISIBLE);
                    pinOptionLayout.setVisibility(View.VISIBLE);
                    messageTv.setText(Html.fromHtml("<b>वेतन</b> देखने के लिए<br>अपना<b> सुरक्षा पिन</b> डाले |", Html.FROM_HTML_MODE_COMPACT));
                } else {
                    check = 1;
                    mainLayout.setVisibility(View.VISIBLE);
                    messageTv.setText(Html.fromHtml("<b>वेतन</b> देखने के लिए<br>अपना<b> सुरक्षा पिन</b> सेट करे |", Html.FROM_HTML_MODE_COMPACT));
                }
                common.closeDialog(SetPinActivity.this);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void setOtpEditTextHandler() {
        for (int i = 0; i < 4; i++) {
            final int[] iVal = {i};
            otpEt[iVal[0]].addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void afterTextChanged(Editable s) {
                    if (!otpEt[iVal[0]].getText().toString().isEmpty()) {
                        if (iVal[0] != 3) {
                            otpEt[iVal[0] + 1].setEnabled(true);
                            otpEt[iVal[0] + 1].requestFocus();//focuses on the next edittext after a digit is entered.
                            for (int i = 0; i <= iVal[0]; i++) {
                                otpEt[i].setEnabled(false);
                            }
                        } else {
                            if (check != 3) {
                                if (check == 1) {
                                    for (int i = 0; i <= iVal[0]; i++) {
                                        generatedPin = generatedPin + otpEt[i].getText().toString();
                                        otpEt[i].setText("");
                                        otpEt[i].setEnabled(false);
                                    }
                                    otpEt[0].setEnabled(true);
                                    otpEt[0].requestFocus();
                                    check = 2;
                                    messageTv.setText(Html.fromHtml("<b>सुरक्षा पिन</b> की<b> पुस्टीकरण</b> करे |", Html.FROM_HTML_MODE_COMPACT));
                                } else if (check == 4) {
                                    String reviewPin = "";
                                    for (int i = 0; i <= iVal[0]; i++) {
                                        reviewPin = reviewPin + otpEt[i].getText().toString();
                                    }
                                    if (salaryPin.equalsIgnoreCase(reviewPin)) {
                                        for (int i = 0; i <= iVal[0]; i++) {
                                            generatedPin = generatedPin + otpEt[i].getText().toString();
                                            otpEt[i].setText("");
                                            otpEt[i].setEnabled(false);
                                        }
                                        otpEt[0].setEnabled(true);
                                        otpEt[0].requestFocus();
                                        check = 5;
                                        messageTv.setText(Html.fromHtml("आप अपना नया<br><b> सुरक्षा पिन</b> डाले |", Html.FROM_HTML_MODE_COMPACT));
                                    } else {
                                        common.showAlertDialog("आपने गलत पिन दर्ज किया है |", "", false, SetPinActivity.this);
                                    }
                                } else if (check == 5) {
                                    String reviewPin = "";
                                    for (int i = 0; i <= iVal[0]; i++) {
                                        reviewPin = reviewPin + otpEt[i].getText().toString();
                                    }
                                    common.setProgressDialog("", "Please wait...", SetPinActivity.this, SetPinActivity.this);
                                    String finalReviewPin = reviewPin;
                                    databaseReference.child("Employees/" + loginId + "/GeneralDetails/salaryPinCode").setValue(reviewPin).addOnCompleteListener(task -> {
                                        if (task.isSuccessful()) {
                                            common.closeDialog(SetPinActivity.this);
                                            backBtn.setVisibility(View.GONE);
                                            mainLayout.setVisibility(View.GONE);
                                            congratulationLayout.setVisibility(View.VISIBLE);
                                            salaryPinTv.setText(finalReviewPin);
                                            check = 3;
                                        }
                                    });
                                } else {
                                    String reviewPin = "";
                                    for (int i = 0; i <= iVal[0]; i++) {
                                        reviewPin = reviewPin + otpEt[i].getText().toString();
                                    }
                                    if (generatedPin.equalsIgnoreCase(reviewPin)) {
                                        common.setProgressDialog("", "Please wait...", SetPinActivity.this, SetPinActivity.this);
                                        databaseReference.child("Employees/" + loginId + "/GeneralDetails/salaryPinCode").setValue(reviewPin).addOnCompleteListener(task -> {
                                            if (task.isSuccessful()) {
                                                common.closeDialog(SetPinActivity.this);
                                                backBtn.setVisibility(View.GONE);
                                                mainLayout.setVisibility(View.GONE);
                                                congratulationLayout.setVisibility(View.VISIBLE);
                                                salaryPinTv.setText(generatedPin);
                                                check = 3;
                                            }
                                        });
                                    } else {
                                        common.showAlertDialog("आपने गलत पिन दर्ज किया है |", "", false, SetPinActivity.this);
                                    }
                                }
                            } else {
                                String reviewPin = "";
                                for (int i = 0; i <= iVal[0]; i++) {
                                    reviewPin = reviewPin + otpEt[i].getText().toString();
                                }
                                if (salaryPin.equalsIgnoreCase(reviewPin)) {
                                    Intent intent = new Intent(SetPinActivity.this, ShowEmployeeSalaryActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    common.showAlertDialog("आपने गलत पिन दर्ज किया है |", "", false, SetPinActivity.this);
                                }
                            }
                        }
                    }
                }
            });

            otpEt[iVal[0]].setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    return false; //Dont get confused by this, it is because onKeyListener is called twice and this condition is to avoid it.
                }
                if (keyCode == KeyEvent.KEYCODE_DEL && otpEt[iVal[0]].getText().toString().isEmpty() && iVal[0] != 0) {
                    //this condition is to handel the delete input by users.
                    otpEt[iVal[0] - 1].setText("");//Deletes the digit of OTP
                    otpEt[iVal[0] - 1].requestFocus();//and sets the focus on previous digit
                    otpEt[iVal[0] - 1].setEnabled(true);
                    for (int j = iVal[0]; j <= 3; j++) {
                        otpEt[j].setEnabled(false);
                    }
                }
                return false;
            });
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBackPressed() {
        if (check == 2) {
            for (int i = 0; i <= 3; i++) {
                generatedPin = "";
                otpEt[i].setText("");
                otpEt[i].setEnabled(false);
            }
            otpEt[0].setEnabled(true);
            otpEt[0].requestFocus();
            check = 1;
            messageTv.setText(Html.fromHtml("<b>वेतन</b> देखने के लिए<br>अपना<b> सुरक्षा पिन</b> सेट करे |", Html.FROM_HTML_MODE_COMPACT));
        } else {
            finish();
        }
    }
}