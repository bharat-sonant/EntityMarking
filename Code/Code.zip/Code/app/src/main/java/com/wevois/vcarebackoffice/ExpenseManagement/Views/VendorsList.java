package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.ExpenseManagement.Adapter.VendorsListAdapter;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.VendorsListModel;
import com.wevois.vcarebackoffice.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class VendorsList extends AppCompatActivity {
    SharedPreferences pathSharedPreferences;
    VendorsListAdapter vendorsListAdapter;
    private Boolean isBackClick = true, isActivityClick = true;
    Button add_Button;
    TextView backTV;
    ListView vendorsList;
    ArrayList<VendorsListModel> arrayListVendors = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendors_list);
        common.setProgressDialog("", "Please Wait", this, this);
        initMethod();
        getVendorList();
        setAction();
    }

    private void initMethod() {
        backTV = findViewById(R.id.back_Button);
        add_Button = findViewById(R.id.add_Button);
        vendorsList = findViewById(R.id.vendorsList);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
    }

    private void setAction() {
        backTV.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();

            }
        });

        add_Button.setOnClickListener(view -> {
            if (isActivityClick) {
                isActivityClick = false;
                common.setProgressDialog("Please Wait", "", this, this);
                Intent i = new Intent(VendorsList.this, VendorEntries.class);
                startActivity(i);
                common.closeDialog(VendorsList.this);
                finish();
            }
        });
    }

    public void getVendorList() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("Common/VendorList.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("VendorListDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("Common/VendorList.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    String vendorJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                    pathSharedPreferences.edit().putString("VendorList", vendorJsonData).apply();
                    pathSharedPreferences.edit().putLong("VendorListDownloadTime", fileCreationTime).apply();
                    setVendorsList();
                });
            }
            setVendorsList();
        });
        storageReference.child("Common/VendorList.json").getMetadata().addOnFailureListener(e -> common.closeDialog(VendorsList.this));
    }

    public void setVendorsList() {
        try {
            arrayListVendors.clear();
            JSONObject vendorJsonData = new JSONObject(pathSharedPreferences.getString("VendorList", ""));
            Iterator<String> vendorKeys = vendorJsonData.keys();
            while (vendorKeys.hasNext()) {
                String key = vendorKeys.next();
                try {
                    if (key != "lastVendorId") {
                        JSONObject values = vendorJsonData.getJSONObject(key);
                        String name = values.getString("name");
                        String mobileNumber = values.getString("mobile");
                        String address = values.getString("address");
                        String bankName = values.getString("bankName");
                        String accountNumber = values.getString("accountNumber");
                        String branch = values.getString("branch");
                        String ifsc = values.getString("ifsc");
                        arrayListVendors.add(new VendorsListModel(name, mobileNumber, address, bankName, accountNumber, branch, ifsc));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            vendorsListAdapter = new VendorsListAdapter(VendorsList.this, arrayListVendors);
            vendorsList.setAdapter(vendorsListAdapter);
            vendorsListAdapter.notifyDataSetChanged();
            common.closeDialog(VendorsList.this);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
        isActivityClick = true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}