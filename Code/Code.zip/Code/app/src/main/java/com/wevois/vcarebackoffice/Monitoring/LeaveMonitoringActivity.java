package com.wevois.vcarebackoffice.Monitoring;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LeaveMonitoringActivity extends AppCompatActivity implements
        LeaveAdapter.buttonClickListener{
    ProgressDialog progressDialog;
    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;
    ListView leaveMonitoringLv;
    LeaveAdapter leaveAdapter;
    ArrayList<String> dateList = new ArrayList<>();
    ArrayList<String> keyList = new ArrayList<>();
    ArrayList<String> empIdList = new ArrayList<>();
    ArrayList<String> nameList = new ArrayList<>();
    ArrayList<String> statusList = new ArrayList<>();
    String key = "";
    CommonUtils commonUtils;
    SimpleDateFormat simpleDateFormat;
    Date todayDate;
    private DataSnapshot empDataSnap;
    private boolean empData = false, dateData = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_monitoring);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());

        leaveMonitoringLv = findViewById(R.id.leaveMonitoringLv);
        leaveAdapter = new LeaveAdapter(this,dateList,nameList,statusList);
        leaveMonitoringLv.setAdapter(leaveAdapter);
        leaveAdapter.setClickListener(this);

        commonUtils = new CommonUtils(this);

        sharedPreferences = getSharedPreferences("path",MODE_PRIVATE);

        getPath();

        progressDialog = new ProgressDialog(LeaveMonitoringActivity.this);
        progressDialog.setTitle("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.create();
        progressDialog.show();


        Calendar calendar = Calendar.getInstance();
        String month = calendar.getDisplayName(Calendar.MONTH,Calendar.LONG, Locale.ENGLISH);
        int year = calendar.get(Calendar.YEAR);

        key = month+year;

        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Date date = new Date();
        String today = simpleDateFormat.format(date);

        try {
            todayDate = simpleDateFormat.parse(today);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        getEmployees();

        getData();


    }

    private void getPath() {
        String pathRef = sharedPreferences.getString("pathRef","");
        if (pathRef.length()>2){
            databaseReference = FirebaseDatabase.getInstance(pathRef).getReference();
        } else{
            databaseReference = FirebaseDatabase.getInstance().getReference();
        }
    }

    private void getEmployees() {
        databaseReference.child("Employees").addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()==null){
                            commonUtils.showAlertDialog("No employee found");
                            dismissProgressDialog();
                            return;
                        }
                        empData = true;
                        empDataSnap = dataSnapshot;
                        showList();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }

    private void showList() {
        if (empData&&dateData){
            for (String id : empIdList){
                if (empDataSnap.hasChild(id)){
                    if (empDataSnap.child(id).hasChild("GeneralDetails")) {
                        if (empDataSnap.child(id+"/GeneralDetails").hasChild("name")) {
                            String name = empDataSnap.child(id+"/GeneralDetails").child("name")
                                    .getValue().toString();
                            name = toTitleCase(name);
                            nameList.add(name + "[" + id + "]");
                        }
                    }
                }
            }
            leaveAdapter.notifyDataSetChanged();
            dismissProgressDialog();
        }
    }

    private void getData() {
        databaseReference.child("Leave-Request").child(key).orderByChild("date")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()==null){
                            commonUtils.showAlertDialog("No leave request");
                            dismissProgressDialog();
                            return;
                        }
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                            String date = "", empId = "", status = "";
                            if (dataSnapshot1.hasChild("date")) {
                                date = dataSnapshot1.child("date").getValue().toString();
                            }
                            if (dataSnapshot1.hasChild("empId")){
                                empId = dataSnapshot1.child("empId").getValue().toString();
                            }
                            if (dataSnapshot1.hasChild("status")){
                                status = dataSnapshot1.child("status").getValue().toString();
                            }
                            Log.i("tag", "onDataChange: "+date);
                            try {
                                Date date1 = simpleDateFormat.parse(date);
                                if (date1.after(todayDate)){
                                    SimpleDateFormat simpleDateFormat2 =
                                            new SimpleDateFormat("dd MMMM", Locale.US);
                                    String dateF = simpleDateFormat2.format(date1);
                                    dateList.add(dateF);
                                    empIdList.add(empId);
                                    statusList.add(status);
                                    keyList.add(dataSnapshot1.getKey());
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                        dateData = true;
                        showList();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }

    private static String toTitleCase(String input) {
        StringBuilder titleCase = new StringBuilder(input.length());
        boolean nextTitleCase = true;

        for (char c : input.toCharArray()) {
            if (Character.isSpaceChar(c)) {
                nextTitleCase = true;
            }
            else if (c =='/'){
                nextTitleCase = true;
            }
            else if (nextTitleCase) {
                c = Character.toTitleCase(c);
                nextTitleCase = false;
            }

            titleCase.append(c);
        }

        return titleCase.toString();
    }

    private void showProgressDialog() {
        if (progressDialog!=null){
            if (!progressDialog.isShowing()&&!isFinishing()){
                progressDialog.show();
            }
        }
    }
    private void dismissProgressDialog(){
        if(progressDialog!=null){
            if (progressDialog.isShowing()&&!isFinishing()){
                progressDialog.dismiss();
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public void onMethodCallback(String status, int pos) {
        databaseReference.child("Leave-Request/"+key).child(keyList.get(pos))
                .child("status").setValue(status);
    }
}
