package com.wevois.vcarebackoffice.employeeattendance.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivityLogBookBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.LogBookViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.LogBookViewModelFactory;

public class LogBook extends AppCompatActivity {
    ActivityLogBookBinding binding;
    LogBookViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_book);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_log_book);
        viewModel = new ViewModelProvider(this,new LogBookViewModelFactory(this,findViewById(R.id.reasonSpinner))).get(LogBookViewModel.class);
        binding.setLogbookviewmodel(viewModel);
    }
}