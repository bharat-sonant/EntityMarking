package com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory

import android.app.Activity
import android.widget.Spinner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.WardSelectKotlinViewModel

class WardSelectKotlinViewModelFactory(var activity: Activity, var spinner: Spinner) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return WardSelectKotlinViewModel(activity, spinner) as T
    }
}