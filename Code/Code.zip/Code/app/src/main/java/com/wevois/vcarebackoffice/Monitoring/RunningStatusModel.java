package com.wevois.vcarebackoffice.Monitoring;

public class RunningStatusModel {
    String ward;
    String wardrunningdistance;
    String totalrunningdistance;
    String workpercentage;
    String manualreading;

    public RunningStatusModel() {
    }

    public RunningStatusModel(String ward, String wardrunningdistance, String totalrunningdistance, String workpercentage, String manualreading) {
        this.ward = ward;
        this.wardrunningdistance = wardrunningdistance;
        this.totalrunningdistance = totalrunningdistance;
        this.workpercentage = workpercentage;
        this.manualreading = manualreading;
    }

    public String getWard() {
        return ward;
    }

    public String getWardrunningdistance() {
        return wardrunningdistance;
    }

    public String getTotalrunningdistance() {
        return totalrunningdistance;
    }

    public String getWorkpercentage() {
        return workpercentage;
    }

    public String getManualreading() {
        return manualreading;
    }
}
