package com.wevois.vcarebackoffice.Complaints.Model;

public class ResolveModel {
    String ward;
    String count;

    public ResolveModel(String ward, String count) {
        this.ward = ward;
        this.count = count;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
