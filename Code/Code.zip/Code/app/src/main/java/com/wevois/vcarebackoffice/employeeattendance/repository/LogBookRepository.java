package com.wevois.vcarebackoffice.employeeattendance.repository;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.wevois.vcarebackoffice.Common.CommonFunctions;

import java.io.ByteArrayOutputStream;

public class LogBookRepository {

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> getLogBookPermission(Activity activity, CommonFunctions common,String ward) {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... p) {
                common.getDatabasePath(activity).child("Settings/WardSettings/"+ward+"/logBookPhotoRequired").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()!=null){
                            response.setValue(dataSnapshot.getValue().toString());
                        }else {
                            response.setValue("yes");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> setWasteCollectionData(Activity activity, CommonFunctions common,String ward,String reason,String key) {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... p) {
                common.getDatabasePath(activity).child("WasteCollectionInfo/" + ward + "/" + common.year()+"/"+common.monthName()+"/"+common.date() + "/Summary/"+key).setValue(reason).addOnCompleteListener(task -> {
                    if (task.isSuccessful()){
                        response.setValue("success");
                    }else {
                        response.setValue("fail");
                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> setLogBookImage(Bitmap bitmap,SharedPreferences preferences, CommonFunctions common,String ward) {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... p) {
                FirebaseStorage storage = FirebaseStorage.getInstance();
                StorageReference storageRef = storage.getReferenceFromUrl("gs://dtdnavigator.appspot.com/" + preferences.getString("city","") + "/LogBookImages/"+ward+"/"+common.year()+"/"+common.monthName()+"/"+common.date());
                StorageReference mountainImagesRef = storageRef.child( "logBook.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                    response.setValue("fail");
                }).addOnSuccessListener(taskSnapshot -> {
                    response.setValue("success");
                });
                return null;
            }
        }.execute();
        return response;
    }
}
