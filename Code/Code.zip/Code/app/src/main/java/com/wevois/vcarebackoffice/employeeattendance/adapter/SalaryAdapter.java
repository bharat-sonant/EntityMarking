package com.wevois.vcarebackoffice.employeeattendance.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevois.vcarebackoffice.databinding.SalaryDataShowBinding;
import com.wevois.vcarebackoffice.employeeattendance.model.SalaryModels;

import java.util.ArrayList;

public class SalaryAdapter extends RecyclerView.Adapter<SalaryAdapter.ParentViewHolder> {

    ArrayList<SalaryModels> models;
    Context context;

    public SalaryAdapter(ArrayList<SalaryModels> models, Context context){
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        SalaryDataShowBinding binding = SalaryDataShowBinding.inflate(layoutInflater,parent,false);
        return new ParentViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
        holder.binding.setSalarydata(models.get(position));
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    class ParentViewHolder extends RecyclerView.ViewHolder{
        SalaryDataShowBinding binding;

        public ParentViewHolder(SalaryDataShowBinding itemVeiw){
            super(itemVeiw.getRoot());
            this.binding = itemVeiw;
        }
    }
}
