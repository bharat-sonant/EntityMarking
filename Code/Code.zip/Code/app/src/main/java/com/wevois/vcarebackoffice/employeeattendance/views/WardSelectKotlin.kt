package com.wevois.vcarebackoffice.employeeattendance.views
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.R
import com.wevois.vcarebackoffice.databinding.ActivityWardSelectKotlinBinding
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.WardSelectKotlinViewModel
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.WardSelectKotlinViewModelFactory

class WardSelectKotlin : AppCompatActivity() {
    var viewModel: WardSelectKotlinViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityWardSelectKotlinBinding = DataBindingUtil.setContentView(this, R.layout.activity_ward_select_kotlin)
        viewModel = ViewModelProvider(this, WardSelectKotlinViewModelFactory(this,binding.wardSpinnerId)).get(WardSelectKotlinViewModel::class.java)
        binding.wardselectviewmodel = viewModel
    }
}