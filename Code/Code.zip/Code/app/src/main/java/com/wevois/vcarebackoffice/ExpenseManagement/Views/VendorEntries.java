package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VendorEntries extends AppCompatActivity {
    Button saveBtn;
    TextView backTV;
    EditText accountNumberEt, nameEt, numberEt, addressEt, bankNameEt, branchNameEt, ifscCodeEt;
    boolean isBackClick = true;
    private StorageReference mStorageRef;
    SharedPreferences sharedPreferences;
    String type, loggedInName, dateString;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_entries);
        mStorageRef = FirebaseStorage.getInstance().getReference("Common");
        initMethod();
        actionMethod();
    }

    private void initMethod() {
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        backTV = findViewById(R.id.back_Button);
        accountNumberEt = findViewById(R.id.accountNumberEt);
        nameEt = findViewById(R.id.nameEt);
        numberEt = findViewById(R.id.numberEt);
        addressEt = findViewById(R.id.addressEt);
        bankNameEt = findViewById(R.id.bankNameEt);
        branchNameEt = findViewById(R.id.branchNameEt);
        ifscCodeEt = findViewById(R.id.ifscCodeEt);
        saveBtn = findViewById(R.id.saveBtn);
        dateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date().getTime());
    }

    private void actionMethod() {
        backTV.setOnClickListener(view -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });
        saveBtn.setOnClickListener(view -> saveData());
    }

    private void saveData() {
        boolean isValid = validationAllDetails();
        if (isValid) {
            FileCheck();
        }
    }

    private boolean validationAllDetails() {
        boolean isValid = true;
        try {
            if (nameEt.getText().toString().length() == 0) {
                nameEt.setError("Please enter your name");
                nameEt.requestFocus();
                isValid = false;
            } else if (numberEt.getText().toString().length() < 10 || numberEt.getText().toString().startsWith("0") || numberEt.getText().toString().startsWith("00")) {
                numberEt.setError("Please enter mobile no. correctly");
                numberEt.requestFocus();
                isValid = false;
            } else if (addressEt.getText().toString().length() == 0) {
                addressEt.setError("Please enter your address");
                addressEt.requestFocus();
                isValid = false;
            } else {
                common.setProgressDialog("Please Wait", "Data uploading.", this, this);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isValid;
    }
    public JSONObject makeJSONOnStorage() throws IOException {
        JSONObject objectMainList = new JSONObject();
        JSONObject jsonObjectList = new JSONObject();
        try {
            sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
            loggedInName = sharedPreferences.getString("loggedInName", "");
            type = getSharedPreferences("loginData", MODE_PRIVATE).getString("loginType", "");
            try {
                jsonObjectList.put("name", nameEt.getText().toString());
                jsonObjectList.put("mobile", numberEt.getText().toString());
                jsonObjectList.put("address", addressEt.getText().toString());
                jsonObjectList.put("bankName", bankNameEt.getText().toString());
                jsonObjectList.put("accountNumber", accountNumberEt.getText().toString());
                jsonObjectList.put("branch", branchNameEt.getText().toString());
                jsonObjectList.put("ifsc", ifscCodeEt.getText().toString());
                jsonObjectList.put("createdBy", loggedInName + "(" + type + ")");
                jsonObjectList.put("date", dateString);
                objectMainList.put("101", jsonObjectList);
                objectMainList.put("lastVendorId", 101);
                JSONObject VendorsList = objectMainList;
                upLoadToStorage(VendorsList);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectMainList;
    }
    private void upLoadToStorage(JSONObject vendorsList) throws IOException {
        File output = File.createTempFile("VendorsEntriesData", ".json");
        try (FileWriter writer = new FileWriter(output)) {
            writer.write(vendorsList.toString());
            Uri uri = Uri.fromFile(output);
            StorageMetadata metadata = new StorageMetadata.Builder().setContentType("json").build();
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            firebaseStorage.getReference().child("Common/VendorList.json").putFile(uri, metadata).
                    addOnSuccessListener(task -> {
                        if (task.getTask().isSuccessful()) {
                            showDialog("Vendor has been saved.", true);
                            common.closeDialog(this);
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkDataFound() {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        loggedInName = sharedPreferences.getString("loggedInName", "");
        type = getSharedPreferences("loginData", MODE_PRIVATE).getString("loginType", "");

        firebaseStorage.getReference().child("Common/VendorList.json").getBytes(1000000).addOnSuccessListener(taskSnapshot -> {
            String vendorsData = new String(taskSnapshot, StandardCharsets.UTF_8);
            try {
                JSONObject jsonObjectMainList = new JSONObject(vendorsData);
                int lastKey = jsonObjectMainList.getInt("lastVendorId") + 1;
                JSONObject jsonObjectListData = new JSONObject();
                jsonObjectListData.put("name", nameEt.getText().toString());
                jsonObjectListData.put("mobile", numberEt.getText().toString());
                jsonObjectListData.put("address", addressEt.getText().toString());
                jsonObjectListData.put("bankName", bankNameEt.getText().toString());
                jsonObjectListData.put("accountNumber", accountNumberEt.getText().toString());
                jsonObjectListData.put("branch", branchNameEt.getText().toString());
                jsonObjectListData.put("ifsc", ifscCodeEt.getText().toString());
                jsonObjectListData.put("createdBy", loggedInName + "(" + type + ")");
                jsonObjectListData.put("date", dateString);

                jsonObjectMainList.put(String.valueOf(lastKey), jsonObjectListData);
                jsonObjectMainList.put("lastVendorId", lastKey);

                File output = File.createTempFile("VendorsEntriesData", ".json");
                try (FileWriter writer = new FileWriter(output)) {
                    writer.write(jsonObjectMainList.toString());
                    Uri uri = Uri.fromFile(output);
                    StorageMetadata metadata = new StorageMetadata.Builder().setContentType("json").build();
                    firebaseStorage.getReference().child("Common/VendorList.json").putFile(uri, metadata).
                            addOnSuccessListener(task -> {
                                if (task.getTask().isSuccessful()) {
                                    showDialog("Vendor has been saved.", true);
                                    common.closeDialog(this);
                                }
                            });
                }
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }
        });
    }

    private void FileCheck() {
        StorageReference storageReference = mStorageRef.child("VendorList.json");
        storageReference.getDownloadUrl().addOnSuccessListener(uri -> checkDataFound()).addOnFailureListener(e -> {
            try {
                makeJSONOnStorage();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
    }

    public void showDialog(String message, Boolean isFinish) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton("Ok", (dialog, id) -> {
            dialog.dismiss();
            if (isFinish) {
                finish();
                Intent i = new Intent(VendorEntries.this, VendorsList.class);
                startActivity(i);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(VendorEntries.this, VendorsList.class);
        startActivity(intent);
    }
}
