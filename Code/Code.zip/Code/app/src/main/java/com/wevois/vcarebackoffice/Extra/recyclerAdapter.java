package com.wevois.vcarebackoffice.Extra;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.ViewHolder>{

    private ArrayList<String> haltTime;
    private ArrayList<String> location;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;
    Context cxnt;
    private AdapterCallback mAdapterCallback;
    // data is passed into the constructor
    recyclerAdapter(Context context, ArrayList<String> time, ArrayList<String> loc) {
        this.mInflater = LayoutInflater.from(context);
        this.haltTime = time;
        this.location = loc;
        this.cxnt=context;
        try {
            this.mAdapterCallback = ((AdapterCallback) context);
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement AdapterCallback.");
        }
    }

    @NonNull
    @Override
    public recyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = mInflater.inflate(R.layout.recyclerview_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerAdapter.ViewHolder holder, final int position) {
        String time = haltTime.get(position);
//        mAdapterCallback.onMethodCallback(Double.parseDouble(time));
        String loc = location.get(position);
        Log.i("abcd", "onBindViewHolder: "+loc);
        String data = ""+String.valueOf(position+1)+". Halt Time: "+time+"\n"+loc;
        holder.myTextView.setText(""+data);
        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                haltTime.remove(position);
                location.remove(position);
                notifyDataSetChanged();
                double time = 0;
                int counter = 1;
                for (String ht:haltTime) {
                    time += Double.parseDouble(ht);
                    if (counter>=haltTime.size()) {
                        counter = 0;
                        mAdapterCallback.onMethodCallback(time);
                    }
                    counter++;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return haltTime.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView myTextView;
        Button deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myTextView = itemView.findViewById(R.id.surveyerslist);
            deleteBtn=itemView.findViewById(R.id.btndelete);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (mClickListener != null) mClickListener.onItemClick(v, getAdapterPosition());
        }
    }
    // convenience method for getting data at click position
    String getItem(int id) {
        return haltTime.get(id);
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

    public static interface AdapterCallback {
        void onMethodCallback(double yourValue);
    }
}
