package com.wevois.vcarebackoffice;

public class CityDetails {
    String cityName;
    String dbPath;
    String storagePath;
    String key;

    public CityDetails(String cityName, String dbPath, String storagePath,String key) {
        this.cityName = cityName;
        this.dbPath = dbPath;
        this.storagePath = storagePath;
        this.key = key;

    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDbPath() {
        return dbPath;
    }

    public void setDbPath(String dbPath) {
        this.dbPath = dbPath;
    }

    public String getStoragePath() {
        return storagePath;
    }

    public void setStoragePath(String storagePath) {
        this.storagePath = storagePath;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "CityDetails{" +
                "cityName='" + cityName + '\'' +
                ", dpPath='" + dbPath + '\'' +
                ", storagePath='" + storagePath + '\'' +
                '}';
    }
}
