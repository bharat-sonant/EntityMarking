package com.wevois.vcarebackoffice.Monitoring;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.text.Spannable;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

import static android.os.Environment.getExternalStorageDirectory;

public class WorkMonitoringActivity extends AppCompatActivity {

    ListView salaryMonitoringLv;
    String workpercentagenew;
    WorkMonitoringAdapters workMonitoringAdapter;
    DataSnapshot dataSnapshotDaily, dataSnapshotEmployee, dataSnapShotTotalWardLines = null;
    DatabaseReference databaseReferencePath;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences sharedPreferences;
    ArrayList<WorkMonitoringPOJO> salaryMList = new ArrayList<>();
    ArrayList<WorkMonitoringPOJO> sorting = new ArrayList<>();
    ArrayList<WorkMonitoringPOJO> sortingone = new ArrayList<>();
    int[] list = new int[]{1, 2, 3, 6, 2};
    ArrayList<Model> listItem = new ArrayList<>();
    //    ArrayList<Workpercentage> listwork = new ArrayList<>();
    ArrayList<String> allowedWard = new ArrayList<>();
    ArrayList<String> updateDate = new ArrayList<>();
    HashMap<Integer, Double> lineWithWeightage = new HashMap<Integer, Double>();
    String yearSpinner = "", month = "", today = "", date_time = "", notAssigned = new CommonUtils(this).notAssigned;
    ImageButton filterBtn;
    Integer totalLines, LineNo;
    Double lineWeightage;
    LinearLayout spinnerLayout;
    TextView selectDate, downloadReport;
    ArrayList<String> numberPosition = new ArrayList<>();
    JSONObject jsonObject = new JSONObject();
    HashMap<String, String> totalHouseList = new HashMap<>();
    HashMap<String, String> totalScannedList = new HashMap<>();
    String key, value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salary_monitoring);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        databaseReferencePath = common.getDatabasePath(this);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        salaryMonitoringLv = findViewById(R.id.salaryMonitoringLv);
//        downloadReport = findViewById(R.id.downloadExcel);
        spinnerLayout = findViewById(R.id.spinnerLayout);
        selectDate = findViewById(R.id.selectDateTv);
        yearSpinner = new SimpleDateFormat("yyyy").format(new Date());
        month = new SimpleDateFormat("MMMM", Locale.US).format(new Date());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        today = simpleDateFormat.format(new Date());
        workMonitoringAdapter = new WorkMonitoringAdapters();
        salaryMonitoringLv.setAdapter(workMonitoringAdapter);
        selectDate.setOnClickListener(v -> datePicker());
        common.setProgressDialog("Please wait...", "Loading...", this, this);
        common.getWardTotalLines(sharedPreferences).observe(this, Observer -> {
            try {
                jsonObject = new JSONObject(sharedPreferences.getString(sharedPreferences.getString("city", "") + "wardSummary", ""));
            } catch (Exception e) {
            }
            getEmployeeList();
        });
//        downloadReport.setOnClickListener(view -> {
//            if (listItem.size() > 0) {
//                common.setProgressDialog("Please wait...", "Loading...", this, this);
//                templateFileDownload();
//            } else {
//                Toast.makeText(this, "Data not found.", Toast.LENGTH_SHORT).show();
//            }
//        });
    }

    private void getEmployeeList() {
        databaseReferencePath.child("Employees/").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    dataSnapshotEmployee = dataSnapshot;
                    getDailyWorkData();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getDailyWorkData() {

        databaseReferencePath.child("DailyWorkDetail/" + yearSpinner + "/" + month + "/" + today).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    dataSnapshotDaily = dataSnapshot;
                    Log.d("lenght1", String.valueOf(dataSnapshot.getChildrenCount()));
                    new WorkMonitoringActivity.employeeDetails().execute();
                } else {
                    common.showAlertDialog("Info!", "Data not found today", true, WorkMonitoringActivity.this);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void datePicker() {
        int mYear, mMonth, mDay;
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, monthOfYear, dayOfMonth) -> {
                    String date_time;
                    if (monthOfYear + 1 <= 9) {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    } else {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    }
                    SimpleDateFormat fromUser = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat myYear = new SimpleDateFormat("yyyy");
                    SimpleDateFormat myMonth = new SimpleDateFormat("MMMM", Locale.US);
                    try {
                        yearSpinner = myYear.format(fromUser.parse(date_time));
                        month = myMonth.format(fromUser.parse(date_time));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    selectDate.setText(date_time);
                    today = date_time;
                    salaryMList.clear();
                    workMonitoringAdapter.notifyDataSetChanged();
                    getDailyWorkData();
                    common.setProgressDialog("Please wait...", "Loading...", this, this);
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private class employeeDetails extends AsyncTask<Void, String, JSONArray> {
        @Override
        protected JSONArray doInBackground(Void... voids) {
            JSONObject wardJson = new JSONObject();
            ArrayList<String> wardList = new ArrayList<>();
            for (DataSnapshot snapshot : dataSnapshotDaily.getChildren()) {
                int task = 1;
                String name = "", mobile = "", desigName = "", designationId = "", empID = snapshot.getKey();
                if (dataSnapshotEmployee.hasChild(snapshot.getKey())) {
                    if (dataSnapshotEmployee.child(snapshot.getKey()).hasChild("GeneralDetails")) {
                        if (dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").hasChild("mobile")) {
                            mobile = dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").child("mobile").getValue().toString();
                        }
                    }
                }
                String id = " [<b>" + empID + "</b>]<br />Mob: " + mobile;
                if (dataSnapshotEmployee.hasChild(snapshot.getKey())) {
                    if (dataSnapshotEmployee.child(snapshot.getKey()).hasChild("GeneralDetails")) {
                        if (dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").hasChild("name")) {
                            name = dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").child("name").getValue().toString().toUpperCase();
                            name += id;
                        }
                    }
                }
                if (dataSnapshotEmployee.hasChild(snapshot.getKey())) {
                    if (dataSnapshotEmployee.child(snapshot.getKey()).hasChild("GeneralDetails")) {
                        if (dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").hasChild("designationId")) {
                            designationId = dataSnapshotEmployee.child(snapshot.getKey() + "/GeneralDetails").child("designationId").getValue().toString();
                            if (designationId.equals("5")) { // Driver
                                desigName = "Driver";
                            } else if (designationId.equals("6")) {  // Helper
                                desigName = "Helper";
                            }
                        }
                    }
                }
                while (snapshot.hasChild("task" + task)) {
                    if (snapshot.child("task" + task).hasChild("task")) {
                        boolean in = true;
                        String inTime = "", outTime = "", vehicleNo = "", deviceId = "", nameEmp = "";
                        String ward = snapshot.child("task" + task).child("task").getValue().toString();
                        if (!wardList.contains(ward)) {
                            wardList.add(ward);
                        }
                        if (desigName.equalsIgnoreCase("Driver")) {
                            if (snapshot.child("task" + task).hasChild("vehicle")) {
                                vehicleNo = snapshot.child("task" + task).child("vehicle").getValue().toString();
                            }
                        }
                        if (snapshot.child("task" + task).hasChild("device")) {
                            deviceId = snapshot.child("task" + task).child("device").getValue().toString();
                        }
                        if (snapshot.child("task" + task).hasChild("in-out")) {
                            if (snapshot.child("task" + task).child("in-out").getValue() != null) {
                                for (DataSnapshot dataSnapshot3 : snapshot.child("task" + task).child("in-out").getChildren()) {
                                    if (dataSnapshot3.getValue() != null) {
                                        String value = dataSnapshot3.getValue().toString();
                                        if (value.contains("In")) {
                                            if (in) {
                                                inTime = dataSnapshot3.getKey();
                                                in = false;
                                            }
                                        }
                                        if (value.contains("Out")) {
                                            outTime = dataSnapshot3.getKey();
                                        }
                                    }
                                }
                            }
                        }
                        if (deviceId.equalsIgnoreCase("NotApplicable")) {
                            nameEmp = name;
                        } else {
                            nameEmp = name + " [<b>" + deviceId + "</b>]";
                        }
                        try {
                            JSONObject jsonDesign = new JSONObject();
                            JSONObject jsonEmpId = new JSONObject();
                            if (wardJson.has(ward)) {
                                jsonDesign = wardJson.getJSONObject(ward);
                                if (jsonDesign.has(desigName)) {
                                    jsonEmpId = jsonDesign.getJSONObject(desigName);
                                }
                            }
                            JSONArray jsonArray = new JSONArray();
                            jsonArray.put(nameEmp);
                            jsonArray.put(inTime);
                            jsonArray.put(outTime);
                            if (desigName.equalsIgnoreCase("Driver")) {
                                jsonArray.put(vehicleNo);
                            }
                            jsonEmpId.put(empID, jsonArray);
                            jsonDesign.put(desigName, jsonEmpId);
                            wardJson.put(ward, jsonDesign);
                        } catch (Exception e) {
                        }
                        Log.d("ward", wardJson.toString());
                    }
                    task++;
                }
            }
//            try {
//                JSONObject jsonObject = new JSONObject(wardJson.toString());
//                Iterator<String> expenseKeys = jsonObject.keys();
//                while (expenseKeys.hasNext()) {
//                    String key = expenseKeys.next();
//                    try {
//                        JSONObject jsonObject1 = jsonObject.getJSONObject(key);
//                        String approval = String.valueOf(jsonObject.getJSONObject(key));
//                        String Name = jsonObject1.getString("vendorName");
//                        String Date = jsonObject1.getString("uri");
//                        String Amount = jsonObject1.getString("amount");
//                        String Purchase = jsonObject1.getString("purchase");
//                        String ExpenseBy = jsonObject1.getString("expenseBy");
//                        String Approved = jsonObject1.getString("Approval");
//                        String date = key;
//                        expenseArrayList.add(new Expense_Approval_Model_List(Name, Date, Amount, Purchase, ExpenseBy, approval, Approved));
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//
//                }
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }

            String sortedWardList = sharedPreferences.getString("sortedWardList", "");
            Log.e("sortedWardList", sortedWardList);
            Log.e("WardList", wardList.toString());
            for (int i = 0; i < wardList.size(); i++) {
                String ward = "", driverName = "", driverInTime = "", driverOutTime = "", helperName = "", helperInTime = "", helperOutTime = "", vehicleNo = "";
                try {
                    if (wardJson.has(wardList.get(i))) {
                        ward = wardList.get(i);
                        driverName = notAssigned;
                        driverInTime = notAssigned;
                        driverOutTime = notAssigned;
                        helperName = notAssigned;
                        helperInTime = notAssigned;
                        helperOutTime = notAssigned;
                        if (wardJson.getJSONObject(ward).has("Driver")) {
                            Iterator<String> iter = wardJson.getJSONObject(ward).getJSONObject("Driver").keys(); //This should be the iterator you want.
                            int counter = 0;
                            while (iter.hasNext()) {
                                String key = iter.next();
                                JSONArray jsonArray = wardJson.getJSONObject(ward).getJSONObject("Driver").getJSONArray(key);
                                if (ward.equalsIgnoreCase("BinLifting") || ward.equalsIgnoreCase("Compactor")) {
                                    if (counter > 0) {
                                        driverName += "<br /><br />" + jsonArray.get(0).toString() + "<br /> Vehicle  : <b>" + jsonArray.get(3).toString() + "</b><br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                        driverInTime += " / " + jsonArray.get(1).toString();
                                        driverOutTime += " / " + jsonArray.get(2).toString();
                                    } else {
                                        driverName = jsonArray.get(0).toString() + "<br /> Vehicle : <b>" + jsonArray.get(3).toString() + "</b><br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                        driverInTime = jsonArray.get(1).toString();
                                        driverOutTime = jsonArray.get(2).toString();
                                    }
                                } else {
                                    if (counter > 0) {
                                        driverName += "<br /><br />" + jsonArray.get(0).toString() + "<br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                        driverInTime += " / " + jsonArray.get(1).toString();
                                        driverOutTime += " / " + jsonArray.get(2).toString();
                                        vehicleNo += " / " + jsonArray.get(3).toString();
                                    } else {
                                        driverName = jsonArray.get(0).toString() + "<br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                        driverInTime = jsonArray.get(1).toString();
                                        driverOutTime = jsonArray.get(2).toString();
                                        vehicleNo += jsonArray.get(3).toString();
                                    }
                                }
                                counter++;
                            }
                        }
                        if (wardJson.getJSONObject(ward).has("Helper")) {
                            Iterator<String> iter = wardJson.getJSONObject(ward).getJSONObject("Helper").keys(); //This should be the iterator you want.
                            int counter = 0;
                            while (iter.hasNext()) {
                                String key = iter.next();
                                JSONArray jsonArray = wardJson.getJSONObject(ward).getJSONObject("Helper").getJSONArray(key);
                                if (counter > 0) {
                                    helperName += "<br /><br />" + jsonArray.get(0).toString() + "<br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                    helperInTime += " / " + jsonArray.get(1).toString();
                                    helperOutTime += " / " + jsonArray.get(2).toString();
                                } else {
                                    helperName = jsonArray.get(0).toString() + "<br />Start : " + jsonArray.get(1).toString() + " | End : " + jsonArray.get(2).toString();
                                    helperInTime = jsonArray.get(1).toString();
                                    helperOutTime = jsonArray.get(2).toString();
                                }
                                counter++;
                            }
                        }
//                        workpercentagenew = "hello";
//                        readData(ward,new MyCallback() {
//                            @Override
//                            public void onCallback(String value) {
//                                listwork.add(new Workpercentage(value+"%"));
//                            }
//                        });
                        int wardsord = 0;
//                        Log.e("WardJson", wardList.size() + " " + wardList.get(1));
                        getTotalHouseCount(wardList.get(i));
                        getTotalCardScanned(wardList.get(i));
                        try {
                            if (!sortedWardList.equals("")) {
                                JSONArray jsonArray = new JSONArray(sortedWardList);
                                Log.e("jsonArray", jsonArray.length() + " value");
                                boolean val = false;
                                for (int j = 0; j < jsonArray.length(); j++) {
                                    JSONObject object = jsonArray.getJSONObject(j);
                                    if (object.get("wardNo").equals(ward)) {
                                        val = false;
                                        wardsord = Integer.parseInt(object.getString("displayIndex"));
                                        salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", wardsord));
                                        break;
                                    }else {
                                        val = true;
//                                        salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", 1000000));
                                    }
                                }
                                if (val){
                                    salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", 1000000));
                                }
                            } else {
                                common.closeDialog(WorkMonitoringActivity.this);
                                Log.e("driver name","name "+driverName);
                                salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", 1000000));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
//                            Log.e("jsonArray", "0 value");
                        }
                        /*if (ward.contains("-R")) {
                            wardsord = Integer.parseInt(ward.replace("-R", ""));
                            Log.d("wardsord",wardsord+" "+ ward);
                            salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", wardsord));
                        } else {
                            if (ward.contains("Commercial-")) {
                                wardsord = Integer.parseInt(ward.replace("Commercial-", "10"));
                                Log.d("wardsordcomm", wardsord + " " + ward);
                                salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", wardsord));
                            }else {
                                salaryMList.add(new WorkMonitoringPOJO(ward, driverName, driverInTime, driverOutTime, helperName, helperInTime, helperOutTime, vehicleNo, "0%", 1000000000));
                            }
                        }*/
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        protected void onPostExecute(JSONArray aVoid) {

            Collections.sort(salaryMList, new Comparator<WorkMonitoringPOJO>() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public int compare(WorkMonitoringPOJO lhs, WorkMonitoringPOJO rhs) {
                    return lhs.getWardsord() - (rhs.getWardsord());
                }
            });

//            getTotalWardLines();
            listItem.clear();
            Log.d("datadates", today);
            getWardPercentage(0, today);

//            getLineWeightageDataFromStorage(0);
            super.onPostExecute(aVoid);
        }
    }
//    public class Workpercentage{
//        String workpercentaage;
//
//        public String getWorkpercentaage() {
//            return workpercentaage;
//        }
//
//        public void setWorkpercentaage(String workpercentaage) {
//            this.workpercentaage = workpercentaage;
//        }
//
//        public Workpercentage(String workpercentaage) {
//            this.workpercentaage = workpercentaage;
//        }
//    }

//    public void readData(String wardd,MyCallback myCallback) {
//        databaseReferencePath.child("WasteCollectionInfo/" + wardd + "/" + yearSpinner + "/" + month + "/" + today).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                String value = dataSnapshot.child("WorkerDetails").child("driver").getValue().toString();
//                int totalLine = 1;
//                String comRef = common.getCurrentMapReference(wardd, WorkMonitoringActivity.this.today, sharedPreferences.getString(sharedPreferences.getString("city", "") + "wardSummary", ""));
//               Log.d("dkjhajga",comRef);
//                try {
//                    JSONObject jsonObjectWard = jsonObject.getJSONObject(wardd);
//                    totalLine = Integer.parseInt(jsonObjectWard.getJSONObject(comRef).getString("totalLines"));
//                    Log.d("dkjhajga1",totalLine+"");
//                } catch (JSONException ex) {
//                    ex.printStackTrace();
//                }
//                int j = 0, workPercentage = 0;
//                if (dataSnapshot.hasChild("LineStatus")) {
//                    for (DataSnapshot dataSnapshot1 : dataSnapshot.child("LineStatus").getChildren()) {
//                        if (dataSnapshot1.hasChild("Status")) {
//                            String status = dataSnapshot1.child("Status").getValue().toString();
//                            if (status.equals("LineCompleted")) {
//                                j = j + 1;
//                            }
//                        }
//                    }
//
//                    try {
//                        workPercentage = (j * 100) / totalLine;
//                        Log.d("percenr",workPercentage+"");
////                        salaryMList.get(i).setWorkPercentage("" + workPercentage + "%");
//                        common.closeDialog(WorkMonitoringActivity.this);
//                        workMonitoringAdapter.notifyDataSetChanged();
//                    } catch (Exception ee) {
//                    }
//                }
//                long totol = dataSnapshot.child("LineStatus").getChildrenCount();
//                Log.d("wards", String.valueOf(totol));
//                myCallback.onCallback(String.valueOf(workPercentage));
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {}
//        });
//    }


//    public interface MyCallback {
//        void onCallback(String value);
//    }

    private void getTotalHouseCount(String ward) {

        Log.e("TotalHouseCount ward", ward);
        databaseReferencePath.child("EntitySurveyData/TotalHouseCount").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot != null) {
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        if (dataSnapshot1.getKey().equals(ward)) {
                            Log.d("children", ward + " " + dataSnapshot1.getValue().toString());
                            totalHouseList.put(ward, dataSnapshot1.getValue().toString());
                        }

                    }
//                    if (!dataSnapshot.getValue().toString().equals("0"))
//                        Log.e("dataSnapshot", dataSnapshot.getValue().toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getTotalCardScanned(String ward) {

        databaseReferencePath.child("HousesCollectionInfo").child(ward).child(yearSpinner).child(month).child(today).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot != null) {
                    Log.d("databefore", dataSnapshot.child("totalScanned").getValue() + "" + ward);
//                    totalScannedList.add(""+dataSnapshot.child("totalScanned").getValue().toString());
                    if (dataSnapshot.child("totalScanned").getValue() != null)
                        totalScannedList.put(ward, dataSnapshot.child("totalScanned").getValue() + "");
                    else
                        totalScannedList.put(ward, "0");
                    Log.d("totalScannedList Size", totalScannedList.size() + "");
                    /*for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Log.d("dataofscaanned", dataSnapshot1.getChildren() + "");
                    }*/
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getWardPercentage(int i, String todaydate) {
        try {
            if (i < salaryMList.size()) {
                WorkMonitoringActivity.this.runOnUiThread(() -> {
                    databaseReferencePath.child("WasteCollectionInfo/" + salaryMList.get(i).getWard() + "/" + yearSpinner + "/" + month + "/" + todaydate).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.getValue() != null) {

                                String vehicle = "", driverName = "", currentRef = "", helperName = "", ward = salaryMList.get(i).getWard(), startTime = "", endTime = "", totalWorkingTimes = "";
                                if (dataSnapshot.hasChild("WorkerDetails")) {
                                    if (dataSnapshot.hasChild("WorkerDetails/driver") && dataSnapshot.hasChild("WorkerDetails/driverName")) {
                                        if (dataSnapshot.child("WorkerDetails/driver").getValue().toString().contains(",")) {
                                            String[] driver = dataSnapshot.child("WorkerDetails/driver").getValue().toString().split(",");
                                            String[] driverNames = dataSnapshot.child("WorkerDetails/driverName").getValue().toString().split(",");
                                            for (int i = 0; i < driver.length; i++) {
                                                if (i == 0) {
                                                    driverName = driverNames[i] + " (" + driver[i] + ")";
                                                } else {
                                                    driverName = driverName + "," + driverNames[i] + " (" + driver[i] + ")";
                                                }
                                            }
                                        } else {
                                            driverName = dataSnapshot.child("WorkerDetails/driverName").getValue().toString() + " (" + dataSnapshot.child("WorkerDetails/driver").getValue().toString() + ")";
                                        }
                                    }
                                    if (dataSnapshot.hasChild("WorkerDetails/helper") && dataSnapshot.hasChild("WorkerDetails/helperName")) {
                                        if (dataSnapshot.child("WorkerDetails/helper").getValue().toString().contains(",")) {
                                            String[] driver = dataSnapshot.child("WorkerDetails/helper").getValue().toString().split(",");
                                            String[] driverNames = dataSnapshot.child("WorkerDetails/helperName").getValue().toString().split(",");
                                            for (int i = 0; i < driver.length; i++) {
                                                if (i == 0) {
                                                    helperName = driverNames[i] + " (" + driver[i] + ")";
                                                } else {
                                                    helperName = helperName + "," + driverNames[i] + " (" + driver[i] + ")";
                                                }
                                            }
                                        } else {
                                            helperName = dataSnapshot.child("WorkerDetails/helperName").getValue().toString() + " (" + dataSnapshot.child("WorkerDetails/helper").getValue().toString() + ")";
                                        }
                                    }
                                    if (dataSnapshot.hasChild("WorkerDetails/secondHelper") && dataSnapshot.hasChild("WorkerDetails/secondHelperName")) {
                                        if (dataSnapshot.child("WorkerDetails/secondHelper").getValue().toString().contains(",")) {
                                            String[] driver = dataSnapshot.child("WorkerDetails/secondHelper").getValue().toString().split(",");
                                            String[] driverNames = dataSnapshot.child("WorkerDetails/secondHelperName").getValue().toString().split(",");
                                            for (int i = 0; i < driver.length; i++) {
                                                if (i == 0) {
                                                    helperName = driverNames[i] + " (" + driver[i] + ")";
                                                } else {
                                                    helperName = helperName + "," + driverNames[i] + " (" + driver[i] + ")";
                                                }
                                            }
                                        } else {
                                            helperName = dataSnapshot.child("WorkerDetails/secondHelperName").getValue().toString() + " (" + dataSnapshot.child("WorkerDetails/secondHelper").getValue().toString() + ")";
                                        }
                                    }
                                    if (dataSnapshot.hasChild("WorkerDetails/thirdHelper") && dataSnapshot.hasChild("WorkerDetails/thirdHelperName")) {
                                        if (dataSnapshot.child("WorkerDetails/thirdHelper").getValue().toString().contains(",")) {
                                            String[] driver = dataSnapshot.child("WorkerDetails/thirdHelper").getValue().toString().split(",");
                                            String[] driverNames = dataSnapshot.child("WorkerDetails/thirdHelperName").getValue().toString().split(",");
                                            for (int i = 0; i < driver.length; i++) {
                                                if (i == 0) {
                                                    helperName = driverNames[i] + " (" + driver[i] + ")";
                                                } else {
                                                    helperName = helperName + "," + driverNames[i] + " (" + driver[i] + ")";
                                                }
                                            }
                                        } else {
                                            helperName = dataSnapshot.child("WorkerDetails/thirdHelperName").getValue().toString() + " (" + dataSnapshot.child("WorkerDetails/thirdHelper").getValue().toString() + ")";
                                        }
                                    }
                                    if (dataSnapshot.hasChild("WorkerDetails/fourthHelper") && dataSnapshot.hasChild("WorkerDetails/fourthHelperName")) {
                                        if (dataSnapshot.child("WorkerDetails/fourthHelper").getValue().toString().contains(",")) {
                                            String[] driver = dataSnapshot.child("WorkerDetails/fourthHelper").getValue().toString().split(",");
                                            String[] driverNames = dataSnapshot.child("WorkerDetails/fourthHelperName").getValue().toString().split(",");
                                            for (int i = 0; i < driver.length; i++) {
                                                if (i == 0) {
                                                    helperName = driverNames[i] + " (" + driver[i] + ")";
                                                } else {
                                                    helperName = helperName + "," + driverNames[i] + " (" + driver[i] + ")";
                                                }
                                            }
                                        } else {
                                            helperName = dataSnapshot.child("WorkerDetails/fourthHelperName").getValue().toString() + " (" + dataSnapshot.child("WorkerDetails/fourthHelper").getValue().toString() + ")";
                                        }
                                    }
                                    if (dataSnapshot.hasChild("WorkerDetails/vehicle")) {
                                        vehicle = dataSnapshot.child("WorkerDetails/vehicle").getValue().toString();
                                    }
                                }
                                if (dataSnapshot.hasChild("Summary")) {
                                    if (dataSnapshot.hasChild("Summary/mapReference")) {
                                        currentRef = dataSnapshot.child("Summary/mapReference").getValue().toString();
                                    }
                                    if (dataSnapshot.hasChild("Summary/dutyInTime")) {
                                        startTime = dataSnapshot.child("Summary/dutyInTime").getValue().toString();
                                    }
                                    if (dataSnapshot.hasChild("Summary/dutyOutTime")) {
                                        endTime = dataSnapshot.child("Summary/dutyOutTime").getValue().toString();
                                    }
                                    int time = 0;
                                    if (startTime.contains(",")) {
                                        String[] start = startTime.trim().split(",");
                                        String[] end = endTime.trim().split(",");
                                        for (int i = 0; i < start.length; i++) {
                                            if (end.length > i) {
                                                time = time + common.formatDate(start[i], end[i]);
                                            } else {
                                                time = time + common.formatDate(start[i], new SimpleDateFormat("HH:mm").format(new Date()));
                                            }
                                        }
                                    } else {
                                        if (endTime.equalsIgnoreCase("")) {
                                            time = common.formatDate(startTime, new SimpleDateFormat("HH:mm").format(new Date()));
                                        } else {
                                            time = common.formatDate(startTime, endTime);
                                        }
                                    }
                                    int hour = time / 60;
                                    int minute = time % 60;
                                    totalWorkingTimes = "" + hour + "h " + minute + "m";
                                    Log.d("Amit", "Value 12 " + salaryMList.get(i).getWard());
                                    String lineWeightageStoragePath = common.getDatabaseStorage(WorkMonitoringActivity.this) + "/WardLineWeightageJson/";
                                    String finalStartTime = startTime;
                                    String finalEndTime = endTime;
                                    String finalDriverName = driverName;
                                    String finalHelperName = helperName;
                                    String finalTotalWorkingTimes = totalWorkingTimes;
                                    String finalVehicle = vehicle;
                                    String finalStartTime1 = startTime;
                                    String finalEndTime1 = endTime;
                                    String finalDriverName1 = driverName;
                                    String finalHelperName1 = helperName;
                                    String finalTotalWorkingTimes1 = totalWorkingTimes;
                                    String finalVehicle1 = vehicle;
                                    FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + "wardLineWeightageAllowed.json").getBytes(100000).
                                            addOnSuccessListener(taskSnapshot -> {
                                                Log.d("dataload", "Check 1");
                                                String wardLineWeightageAllowedString = new String(taskSnapshot, StandardCharsets.UTF_8);
                                                try {
                                                    JSONArray allowedJsonWardAsJsonArray = new JSONArray(wardLineWeightageAllowedString);
                                                    for (int j = 0; j < allowedJsonWardAsJsonArray.length(); j++) {
                                                        allowedWard.add(String.valueOf(allowedJsonWardAsJsonArray.get(j)));
                                                    }
                                                    if (allowedWard.contains(salaryMList.get(i).getWard())) {
                                                        FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + salaryMList.get(i).getWard() + "/weightageUpdateHistoryJson.json").
                                                                getBytes(1000000).addOnSuccessListener(taskSnapshot1 -> {
                                                                    String updateDateString = new String(taskSnapshot1, StandardCharsets.UTF_8);
                                                                    try {
                                                                        String lastUpdatedDate = "";
                                                                        JSONArray dateAsJsonArray = new JSONArray(updateDateString);
                                                                        for (int k = 0; k < dateAsJsonArray.length(); k++) {
                                                                            updateDate.add(String.valueOf(dateAsJsonArray.get(k)));
                                                                            lastUpdatedDate = updateDate.get(updateDate.size() - 1);

                                                                        }
                                                                        FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + salaryMList.get(i).getWard() + "/" + lastUpdatedDate + ".json").getBytes(1000000).addOnSuccessListener(taskSnapshot2 -> {
                                                                            String str = new String(taskSnapshot2, StandardCharsets.UTF_8);
                                                                            float workPercentage = 0;
                                                                            double k = 0;
                                                                            float totalLinesFromWardLines = 0;
                                                                            try {
                                                                                JSONArray jsonArray = new JSONArray(str);
                                                                                for (int i1 = 0; i1 < jsonArray.length(); i1++) {
                                                                                    try {
                                                                                        JSONObject jsonObject3 = jsonArray.getJSONObject(i1);
                                                                                        LineNo = Integer.valueOf(jsonObject3.getString("lineNo"));
                                                                                        lineWeightage = jsonObject3.getDouble("weightage");
                                                                                        lineWithWeightage.put(LineNo, lineWeightage);
                                                                                    } catch (JSONException e) {
                                                                                        e.printStackTrace();
                                                                                    }
                                                                                }
                                                                                JSONObject jsonObject2 = jsonArray.getJSONObject(jsonArray.length() - 1);
                                                                                totalLines = jsonObject2.getInt("totalLines");
                                                                                try {
                                                                                    if (jsonObject.has(ward)) {
                                                                                        JSONObject jsonObjectWard = jsonObject.getJSONObject(ward);
                                                                                        String comRef = common.getCurrentMapReference(ward, WorkMonitoringActivity.this.today, sharedPreferences.getString(sharedPreferences.getString("city", "") + "wardSummary", ""));
                                                                                        if (!comRef.equalsIgnoreCase("")) {
                                                                                            if (jsonObjectWard.has(comRef)) {
                                                                                                totalLinesFromWardLines = Integer.parseInt(jsonObjectWard.getJSONObject(comRef).getString("totalLines"));
                                                                                                Log.d("Amit", "Value B" + totalLinesFromWardLines);
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } catch (JSONException e) {
                                                                                    e.printStackTrace();
                                                                                }
                                                                                if (dataSnapshot.hasChild("LineStatus")) {
                                                                                    for (DataSnapshot dataSnapshot2 : dataSnapshot.child("LineStatus").getChildren()) {
                                                                                        if (dataSnapshot2.hasChild("Status")) {
                                                                                            String status = dataSnapshot2.child("Status").getValue().toString();
                                                                                            int key = Integer.parseInt(dataSnapshot2.getKey());
                                                                                            if (status.equals("LineCompleted") && lineWithWeightage.containsKey(key)) {
                                                                                                float percentage = (100 / totalLinesFromWardLines);
                                                                                                Log.d("Amit ", "Value 890 " + percentage * lineWithWeightage.get(key));
                                                                                                workPercentage = (float) (workPercentage + (percentage * lineWithWeightage.get(key)));
                                                                                                Log.d("Amit", "Value 891 " + lineWithWeightage.get(key));
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    salaryMList.get(i).setWorkPercentage("" + workPercentage + "%");
                                                                                    workMonitoringAdapter.notifyDataSetChanged();
                                                                                }
                                                                                listItem.add(new Model(ward, finalStartTime, finalEndTime, finalDriverName, finalHelperName, "", finalTotalWorkingTimes, "" + workPercentage + " %", finalVehicle));
                                                                            } catch (JSONException e) {
                                                                                e.printStackTrace();
                                                                            }
                                                                        });
                                                                    } catch (JSONException e) {
                                                                        e.printStackTrace();
                                                                    }
                                                                });
                                                    } else {
                                                        int totalLine = 1, j = 0, workPercentage = 0;
                                                        try {
                                                            if (jsonObject.has(ward)) {
                                                                JSONObject jsonObjectWard = jsonObject.getJSONObject(ward);
                                                                String comRef = common.getCurrentMapReference(ward, WorkMonitoringActivity.this.today, sharedPreferences.getString(sharedPreferences.getString("city", "") + "wardSummary", ""));
                                                                if (!comRef.equalsIgnoreCase("")) {
                                                                    if (jsonObjectWard.has(comRef)) {
                                                                        totalLine = Integer.parseInt(jsonObjectWard.getJSONObject(comRef).getString("totalLines"));
                                                                    }
                                                                }
                                                            }
                                                        } catch (Exception e) {
                                                        }
                                                        if (totalLine == 1) {
                                                            listItem.add(new Model(ward, finalStartTime1, finalEndTime1, finalDriverName1, finalHelperName1, "", finalTotalWorkingTimes1, "" + 0 + " %", finalVehicle1));
                                                        } else {
                                                            if (dataSnapshot.hasChild("LineStatus")) {
                                                                for (DataSnapshot dataSnapshot1 : dataSnapshot.child("LineStatus").getChildren()) {
                                                                    if (dataSnapshot1.hasChild("Status")) {
                                                                        String status = dataSnapshot1.child("Status").getValue().toString();
                                                                        if (status.equals("LineCompleted")) {
                                                                            j = j + 1;
                                                                        }
                                                                    }
                                                                }
                                                                try {
                                                                    workPercentage = (j * 100) / totalLine;
                                                                    salaryMList.get(i).setWorkPercentage("" + workPercentage + "%");
                                                                    workMonitoringAdapter.notifyDataSetChanged();
                                                                } catch (Exception e) {
                                                                }
                                                            }
                                                            listItem.add(new Model(ward, finalStartTime1, finalEndTime1, finalDriverName1, finalHelperName1, "", finalTotalWorkingTimes1, "" + workPercentage + " %", finalVehicle1));
                                                        }
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    int totalLine = 1;
                                                    String comRef = common.getCurrentMapReference(ward, WorkMonitoringActivity.this.today, sharedPreferences.getString(sharedPreferences.getString("city", "") + "wardSummary", ""));
                                                    try {
                                                        JSONObject jsonObjectWard = jsonObject.getJSONObject(ward);
                                                        totalLine = Integer.parseInt(jsonObjectWard.getJSONObject(comRef).getString("totalLines"));
                                                    } catch (JSONException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                    int j = 0, workPercentage = 0;
                                                    Log.d("dataload", String.valueOf(salaryMList.size()));
                                                    if (dataSnapshot.hasChild("LineStatus")) {
                                                        for (DataSnapshot dataSnapshot1 : dataSnapshot.child("LineStatus").getChildren()) {
                                                            if (dataSnapshot1.hasChild("Status")) {
                                                                String status = dataSnapshot1.child("Status").getValue().toString();
                                                                if (status.equals("LineCompleted")) {
                                                                    j = j + 1;
                                                                }
                                                            }
                                                        }

                                                        try {
                                                            workPercentage = (j * 100) / totalLine;
                                                            salaryMList.get(i).setWorkPercentage("" + workPercentage + "%");
                                                            common.closeDialog(WorkMonitoringActivity.this);
                                                            workMonitoringAdapter.notifyDataSetChanged();
                                                        } catch (Exception ee) {
                                                        }
                                                    }
                                                    long totol = dataSnapshot.child("LineStatus").getChildrenCount();
                                                    Log.d("wards", String.valueOf(totol));
                                                }
                                            });
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                });
                getWardPercentage(i + 1, today);
            }
        } catch (Exception e) {
        }
    }


    private void getLineWeightageDataFromStorage(int i) {
        Log.d("Amit", "Value 12 " + salaryMList.get(i).getWard());
        String lineWeightageStoragePath = common.getDatabaseStorage(this) + "/WardLineWeightageJson/";
        FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + "wardLineWeightageAllowed.json").getBytes(100000).
                addOnSuccessListener(taskSnapshot -> {
                    Log.d("Amit", "Check 1");
                    String wardLineWeightageAllowedString = new String(taskSnapshot, StandardCharsets.UTF_8);
                    try {
                        JSONArray allowedJsonWardAsJsonArray = new JSONArray(wardLineWeightageAllowedString);
                        for (int j = 0; j < allowedJsonWardAsJsonArray.length(); j++) {
                            allowedWard.add(String.valueOf(allowedJsonWardAsJsonArray.get(j)));
                        }
                        if (allowedWard.contains(salaryMList.get(i).getWard())) {
                            FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + salaryMList.get(i).getWard() + "/weightageUpdateHistoryJson.json").
                                    getBytes(1000000).addOnSuccessListener(taskSnapshot1 -> {
                                        String updateDateString = new String(taskSnapshot1, StandardCharsets.UTF_8);
                                        Log.d("Amit", "Value 55 " + updateDateString);
                                        try {
                                            String lastUpdatedDate = "";
                                            JSONArray dateAsJsonArray = new JSONArray(updateDateString);
                                            for (int k = 0; k < dateAsJsonArray.length(); k++) {
                                                updateDate.add(String.valueOf(dateAsJsonArray.get(k)));
                                                lastUpdatedDate = updateDate.get(updateDate.size() - 1);

                                            }
                                            FirebaseStorage.getInstance().getReferenceFromUrl(lineWeightageStoragePath + salaryMList.get(i).getWard() + "/" + lastUpdatedDate + ".json").getBytes(1000000).addOnSuccessListener(taskSnapshot2 -> {
                                                String str = new String(taskSnapshot2, StandardCharsets.UTF_8);
                                                int workPercentage = 0;
                                                Log.d("Amit", "Value 22 " + str);
                                                try {
                                                    JSONArray jsonArray = new JSONArray(str);
                                                    JSONObject jsonObject2 = jsonArray.getJSONObject(jsonArray.length() - 1);
                                                    Log.d("jsonobjectall",jsonObject2+"-==="+jsonArray);
                                                    totalLines = jsonObject2.getInt("totalLines");
                                                    Log.d("totallines", "Value 908 " +totalLines);

                                                    for (int i1 = 0; i1 < jsonArray.length(); i1++) {
                                                        JSONObject jsonObject1 = jsonArray.getJSONObject(i1);
                                                        Double lineWeightage = jsonObject1.getDouble("weightage");
                                                        Log.d("Amit", "Check " + (1 / totalLines) * 100);
                                                        workPercentage = (int) (workPercentage + ((100 / totalLines) * lineWeightage));
                                                        if (workPercentage >= 100) {
                                                            workPercentage = 100;
                                                            break;
                                                        }
                                                    }
                                                    Log.d("Amit", "Value 88 " + workPercentage);

                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            });

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }


                                    });

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                });


    }

    public class Model {
        String ward, start, end, driver, helper, tripInWard, totalWorkingTime, workPercentage, vehicle;
        String wardsort;

        public Model(String wardsort) {
            this.wardsort = wardsort;
        }

        public Model(String ward, String start, String end, String driver, String helper, String tripInWard, String totalWorkingTime, String workPercentage, String vehicle) {
            this.ward = ward;
            this.start = start;
            this.end = end;
            this.driver = driver;
            this.helper = helper;
            this.tripInWard = tripInWard;
            this.totalWorkingTime = totalWorkingTime;
            this.workPercentage = workPercentage;
            this.vehicle = vehicle;
        }

        public String getWard() {
            return ward;
        }

        public String getStart() {
            return start;
        }

        public String getEnd() {
            return end;
        }

        public String getDriver() {
            return driver;
        }

        public String getHelper() {
            return helper;
        }

        public String getTripInWard() {
            return tripInWard;
        }

        public String getTotalWorkingTime() {
            return totalWorkingTime;
        }

        public String getWorkPercentage() {
            return workPercentage;
        }

        public String getVehicle() {
            return vehicle;
        }
    }

    public void onMethodCallback(String wardNo) {
        String date = today;
        if (date_time.length() > 1) {
            date = date_time;
        }
        Intent intent = new Intent(WorkMonitoringActivity.this, WorkMonitoringMapActivity.class);
        intent.putExtra("wardNo", wardNo);
        intent.putExtra("date", date);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        common.closeDialog(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        common.closeDialog(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public class WorkMonitoringAdapters extends BaseAdapter {

        @Override
        public int getCount() {
            return salaryMList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView wardTv, hNameTv, dNameTv, vehicleNo, workProgress, totalScan;
            ImageButton viewBtn;
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.salary_monitoring_list, null, true);
            wardTv = (TextView) convertView.findViewById(R.id.wardNo);
            hNameTv = (TextView) convertView.findViewById(R.id.helperName);
            dNameTv = (TextView) convertView.findViewById(R.id.driverName);
            viewBtn = (ImageButton) convertView.findViewById(R.id.viewBtn);
            vehicleNo = (TextView) convertView.findViewById(R.id.vehicleNumber);
            workProgress = (TextView) convertView.findViewById(R.id.workProgresTv);
            totalScan = convertView.findViewById(R.id.totalScan);
            WorkMonitoringPOJO sList = salaryMList.get(position);
            Log.d("length", String.valueOf(salaryMList.size()));
            viewBtn.setImageResource(R.drawable.ic_remove_green_eye_black_24dp);
            wardTv.setText(sList.getWard());
            Set keys = totalHouseList.keySet();
            for (Iterator i = keys.iterator(); i.hasNext(); ) {
                key = (String) i.next();
                value = totalHouseList.get(key);
                if (wardTv.getText().equals(key)) {
                    if (Integer.parseInt(totalScannedList.get(key)) > Integer.parseInt(value)){
                        totalScan.setText(value + "/" + value);
                    }else {
                        totalScan.setText(totalScannedList.get(key) + "/" + value);
                    }
                }
            }
            numberPosition = new ArrayList<>();
            String[] myString = String.valueOf(Html.fromHtml(sList.getDriverName())).split("Mob: ");
            for (int i = 1; i < myString.length; i++) {
                numberPosition.add(myString[i].substring(0, 10));
            }

            phoneCall(dNameTv, sList.getDriverName(), numberPosition);
            vehicleNo.setText(sList.getVehicleNo());
            workProgress.setText(sList.getWorkPercentage());
//            totalScan.setText(totalScannedList.get(position) + "/" + totalHouseList.get(position));
            if (sList.getDriverName().contains(notAssigned) || sList.getHelperName().contains(notAssigned)) {
                wardTv.setBackgroundColor(Color.RED);
            } else if (sList.getDriverOutTime().length() > 1 && sList.getHelperOutTime().length() > 1) {
                if (!(sList.getDriverOutTime().contains(notAssigned) && sList.getHelperOutTime().contains(notAssigned))) {
                    wardTv.setBackgroundColor(Color.GREEN);
                }
            } else {
                wardTv.setBackgroundColor(Color.TRANSPARENT);
            }
            numberPosition = new ArrayList<>();
            String[] myStrings = String.valueOf(Html.fromHtml(sList.getHelperName())).split("Mob: ");
            for (int i = 1; i < myStrings.length; i++) {
                numberPosition.add(myStrings[i].substring(0, 10));
            }
            phoneCall(hNameTv, sList.getHelperName(), numberPosition);
            viewBtn.setOnClickListener(v -> {
                onMethodCallback(sList.getWard());
            });

            return convertView;
        }
    }

    public void phoneCall(TextView dNameTv, String string, ArrayList<String> numberPosition) {
        String myString = String.valueOf(Html.fromHtml(string));
        dNameTv.setMovementMethod(LinkMovementMethod.getInstance());
        dNameTv.setText(Html.fromHtml(string), TextView.BufferType.SPANNABLE);
        Spannable mySpannable = (Spannable) dNameTv.getText();
        for (int i = 0; i < numberPosition.size(); i++) {
            int i1 = myString.indexOf(numberPosition.get(i));
            ClickableSpan myClickableSpan = new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    try {
                        Intent callIntent = new Intent(Intent.ACTION_CALL);
                        callIntent.setData(Uri.parse("tel:" + mySpannable.toString().substring(i1, i1 + 10)));
                        if (ActivityCompat.checkSelfPermission(WorkMonitoringActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(WorkMonitoringActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 10);
                        } else {
                            try {
                                startActivity(callIntent);
                            } catch (android.content.ActivityNotFoundException ex) {
                            }
                        }
                    } catch (Exception e) {
                    }
                }
            };
            mySpannable.setSpan(myClickableSpan, i1, i1 + 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mySpannable.setSpan(new ForegroundColorSpan(Color.parseColor("#54C7F4")), i1, i1 + 10, 0);
        }
    }

//    public void templateFileDownload() {
//        System.setProperty("org.apache.poi.javax.xml.stream.XMLInputFactory", "com.fasterxml.aalto.stax.InputFactoryImpl");
//        System.setProperty("org.apache.poi.javax.xml.stream.XMLOutputFactory", "com.fasterxml.aalto.stax.OutputFactoryImpl");
//        System.setProperty("org.apache.poi.javax.xml.stream.XMLEventFactory", "com.fasterxml.aalto.stax.EventFactoryImpl");
//        SharedPreferences sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
//        File root = new File(Environment.getExternalStorageDirectory(), "TemplateFile");
//        if (!root.exists()) {
//            root.mkdirs();
//        }
//        final File file = new File(Environment.getExternalStorageDirectory(), "TemplateFile/WardReport.xlsx");
//        file.delete();
//        StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(sharedPreferences.getString("storagePathRef", "") + "/TemplateFile").child("WardReport.xlsx");
//        storageReference.getFile(file).addOnSuccessListener(taskSnapshot -> {
//            exportWardReport();
//        }).addOnFailureListener(exception -> {
//            common.closeDialog(WorkMonitoringActivity.this);
//        });
//    }

    public void exportWardReport() {
        String[] columns = {"Ward No", "Start", "End", "Driver Name(Id)", "Helper Name(Id)", "Trip in ward", "Work time", "Work percentage", "Vehicle"};
        String fileName = "Work Report[" + selectDate.getText().toString() + "]";
        if (selectDate.getText().toString().equalsIgnoreCase("-- Select Date --")) {
            fileName = "Work Report[" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "]";
        }
        try {
            FileInputStream file = new FileInputStream(new File(getExternalStorageDirectory(), "TemplateFile/WardReport.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheetAt(0);

            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setFontHeightInPoints((short) 14);
            headerFont.setColor(IndexedColors.BLACK.getIndex());

            Font noteFont = workbook.createFont();
            noteFont.setBold(true);
            noteFont.setFontHeightInPoints((short) 11);
            noteFont.setColor(IndexedColors.WHITE.getIndex());

            // Create a CellStyle for total
            CellStyle totalCellStyle = workbook.createCellStyle();
            totalCellStyle.setFont(headerFont);
            totalCellStyle.setAlignment(HorizontalAlignment.RIGHT);

            // amount style
            CellStyle amountStyle = workbook.createCellStyle();
            amountStyle.setFont(headerFont);
            amountStyle.setAlignment(HorizontalAlignment.LEFT);

            int rowNum = 1;
            int rowNo = 1;
            for (Model data : listItem) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(data.getWard());
                row.createCell(1).setCellValue(data.getStart());
                row.createCell(2).setCellValue(data.getEnd());
                row.createCell(3).setCellValue(data.getDriver());
                row.createCell(4).setCellValue(data.getHelper());
                row.createCell(5).setCellValue("");
                row.createCell(6).setCellValue(data.getTotalWorkingTime());
                row.createCell(7).setCellValue(data.getWorkPercentage());
                row.createCell(8).setCellValue(data.getVehicle());
                rowNo++;
            }

            for (WorkMonitoringPOJO data : salaryMList) {
                if (data.getWard().contains("BinLifting") || data.getWard().contains("Compactor")) {
                    Row row = sheet.createRow(rowNum++);
                    String[] inTime = data.getDriverInTime().split("/");
                    String[] outTime = data.getDriverOutTime().split("/");
                    String totalWorkingTime = "";
                    for (int i = 0; i < inTime.length; i++) {
                        Log.d("TAG", "exportWardReport: check " + outTime[i].length());
                        if (outTime[i].length() > 1) {
                            int minute = common.formatDate(inTime[i], outTime[i]);
                            if (i == 0) {
                                totalWorkingTime = totalWorkingTime + minute / 60 + "h " + minute % 60 + "m";
                            } else {
                                totalWorkingTime = totalWorkingTime + "/" + minute / 60 + "h " + minute % 60 + "m";
                            }
                        } else {
                            int minute = common.formatDate(inTime[i], new SimpleDateFormat("HH:mm:ss").format(new Date()));
                            if (i == 0) {
                                totalWorkingTime = totalWorkingTime + minute / 60 + "h " + minute % 60 + "m";
                            } else {
                                totalWorkingTime = totalWorkingTime + "/" + minute / 60 + "h " + minute % 60 + "m";
                            }
                        }
                    }
                    row.createCell(0).setCellValue(data.getWard());
                    row.createCell(1).setCellValue(data.getDriverInTime());
                    row.createCell(2).setCellValue(data.getDriverOutTime());
                    row.createCell(3).setCellValue(String.valueOf(Html.fromHtml(data.getDriverName())));
                    row.createCell(4).setCellValue(String.valueOf(Html.fromHtml(data.getHelperName())));
                    row.createCell(5).setCellValue("");
                    row.createCell(6).setCellValue(totalWorkingTime);
                    row.createCell(7).setCellValue(data.getWorkPercentage());
                    rowNo++;
                }
            }
            Row totalRow = sheet.createRow(rowNo);
            for (int i = 0; i < columns.length; i++) {
                Cell cell = totalRow.createCell(i);
                if (i == 0) {
                    cell.setCellStyle(totalCellStyle);
                } else {
                    cell.setCellStyle(amountStyle);
                }
            }

            File files = new File(Environment.getExternalStorageDirectory(), fileName + ".xlsx");
            FileOutputStream fileOut = null;
            try {
                fileOut = new FileOutputStream(files);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                workbook.write(fileOut);
            } catch (IOException e) {
                e.printStackTrace();
            }
            assert fileOut != null;
            fileOut.close();

            workbook.close();
            Toast.makeText(WorkMonitoringActivity.this, "Report Downloaded", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(() -> shareReport(files.getPath()), 200);
        } catch (Exception e) {
            common.closeDialog(WorkMonitoringActivity.this);
        }
    }

    private void shareReport(String path) {
        common.closeDialog(WorkMonitoringActivity.this);
        try {
            File outputFile = new File(path);
            Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", outputFile);
            Intent share = new Intent();
            share.setAction(Intent.ACTION_SEND);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setType("application/pdf|application/x-excel");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setPackage("com.whatsapp");
            startActivity(share);
        } catch (Exception e) {
        }
    }
}