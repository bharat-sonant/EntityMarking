package com.wevois.vcarebackoffice.Complaints;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

public class ComplaintsRegisterActivity extends AppCompatActivity {


    EditText nameET, mobileET, cardNumberET, complainTypeET, wardET, messageET;
    Button submit_Button;
    DatabaseReference ref;
    CommonFunctions common = CommonFunctions.getInstance();
    String date, month, year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_register);
        nameET = findViewById(R.id.nameET);
        mobileET = findViewById(R.id.mobileET);
        cardNumberET = findViewById(R.id.cardNumberET);
        complainTypeET = findViewById(R.id.complainTypeET);
        wardET = findViewById(R.id.wardET);
        messageET = findViewById(R.id.messageET);
        submit_Button = findViewById(R.id.submit_Button);

        ref = common.getDatabasePath(this);

        getSimpleDateFormat();
        setPageTitle();

        submit_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isTrue()) {
                    submitData();
                }
            }
        });

    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Complaints Register");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            ComplaintsRegisterActivity.super.onBackPressed();
        });
    }

    @SuppressLint("SimpleDateFormat")
    private void getSimpleDateFormat() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        date = format.format(new Date());
        try {
            month = new SimpleDateFormat("MMMM").format(format.parse(date));
            year = new SimpleDateFormat("yyyy").format(format.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void submitData() {
        String name = nameET.getText().toString();
        String mobile = mobileET.getText().toString();
        String cardNumber = cardNumberET.getText().toString();
        String complainType = complainTypeET.getText().toString();
        String ward = wardET.getText().toString();
        String message = messageET.getText().toString();

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("आपकी शिकायत दर्ज कर लिया गया | ")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Map<String, Object> map = new HashMap<>();
                        map.put("action", "1");
                        map.put("cardNumber", cardNumber);
                        map.put("complainType", complainType);
                        map.put("comlaintNumber", String.valueOf(new Random().nextInt(10000000)));
                        map.put("date", date);
                        map.put("message", message);
                        map.put("name", name);
                        map.put("number", mobile);
                        map.put("zone", ward);

                        ref.child("Complaints")
                                .child("ComplaintRequest")
                                .child(year).child(month)
                                .child(date).child(cardNumber).push().updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        ref.child("Complaints").child("WardListCount").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if (dataSnapshot.exists()) {
                                                    int count = 0;
                                                    for (DataSnapshot snap : dataSnapshot.getChildren()) {
                                                        if (Objects.equals(snap.getKey(), ward)) {
                                                            count = Integer.parseInt(snap.getValue()+"");
                                                        }
                                                    }
                                                    count++;
                                                    ref.child("Complaints").child("WardListCount").child(ward).setValue(count);
                                                } else {
                                                    setCount(ward);
                                                }
                                            }
                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                });

                        ref.child("Complaints")
                                .child("UserComplaintReference")
                                .child(cardNumber)
                                .child(date).setValue(year + "/" + month + "/" + date);
                    }
                });
        dialog.show();
    }

    private void setCount(String ward) {

        ref.child("Complaints").child("WardListCount").child(ward).setValue("1");
    }

    private boolean isTrue() {
        if (nameET.getText().toString().equals("") && nameET.getText().toString().isEmpty()) {
            nameET.setError("Enter name");
            return false;
        } else if (mobileET.getText().toString().equals("") && mobileET.getText().toString().isEmpty()) {
            mobileET.setError("Enter mobile number");
            return false;
        } else if (mobileET.getText().toString().length() < 10) {
            mobileET.setError("Please enter valid number");
            return false;
        }
        else if (cardNumberET.getText().toString().equals("") && cardNumberET.getText().toString().isEmpty()) {
            cardNumberET.setError("Enter mobile number");
            return false;
        } else if (complainTypeET.getText().toString().equals("") && complainTypeET.getText().toString().isEmpty()) {
            complainTypeET.setError("Enter mobile number");
            return false;
        } else if (wardET.getText().toString().equals("") && wardET.getText().toString().isEmpty()) {
            wardET.setError("Enter mobile number");
            return false;
        } else if (messageET.getText().toString().equals("") && messageET.getText().toString().isEmpty()) {
            messageET.setError("Enter mobile number");
            return false;
        }
        return true;
    }


}