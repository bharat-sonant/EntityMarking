package com.wevois.vcarebackoffice.Monitoring.VehicleMonitoring;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class InActiveVehiclesFragment extends Fragment {
    DatabaseReference databaseReferencePath;
    ArrayList<VehicleMonitoringModel> vehicleList = new ArrayList<>();
    InactiveVehicleAdapter vehicleMonitoringAdapter;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mainView = inflater.inflate(R.layout.fragment_in_active_vehicles, container, false);
        databaseReferencePath = common.getDatabasePath(getActivity());
        ListView listView = mainView.findViewById(R.id.vehicle_monitoring_lv_2);
        vehicleMonitoringAdapter = new InactiveVehicleAdapter();
        listView.setAdapter(vehicleMonitoringAdapter);
        getDatabaseFromFirebase();
        return mainView;
    }

    private void getDatabaseFromFirebase() {
        databaseReferencePath.child("Vehicles").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getKey() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.hasChild("status")) {
                            if (String.valueOf(snapshot.child("status").getValue()).equals("1")) {
                                vehicleList.add(new VehicleMonitoringModel(String.valueOf(snapshot.getKey()), " ", " "));
                            }
                        }

                    }
                    Collections.sort(vehicleList, (obj1, obj2) -> obj1.vehicle.compareToIgnoreCase(obj2.vehicle));
                    vehicleMonitoringAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private class InactiveVehicleAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return vehicleList.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) Objects.requireNonNull(getActivity()).getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.inactive_vehicle_list_layout, null, true);
            VehicleMonitoringModel model = vehicleList.get(i);
            TextView vehicleNameTv = view.findViewById(R.id.vehicle_name_tv);
            vehicleNameTv.setText(model.getVehicle());
            return view;
        }
    }
}