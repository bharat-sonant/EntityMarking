package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.wevois.vcarebackoffice.R;

public class VendorDetails extends AppCompatActivity {
    String vName = "";
    String vMobile = "";
    String vAddress = "";
    String vBank = "";
    String vAccount = "";
    String vBranch = "";
    String vIFSC = "";
    TextView vendorName, vendorMobile, vendorAddress, vendorBank, vendorAccount, vendorBranch, vendorIFSC;
    Button button;
    private Boolean isBackClick = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_details);
        button = findViewById(R.id.backToList);
        setAction();

        vendorName = findViewById(R.id.vendorName);
        vendorMobile = findViewById(R.id.vendorMobile);
        vendorAddress = findViewById(R.id.vendorAddress);
        vendorBank = findViewById(R.id.vendorBank);
        vendorAccount = findViewById(R.id.vendorAccount);
        vendorBranch = findViewById(R.id.vendorBranch);
        vendorIFSC = findViewById(R.id.vendorIFSC);

        vName = getIntent().getStringExtra("vendorName");
        vMobile = getIntent().getStringExtra("vendorMobile");
        vAddress = getIntent().getStringExtra("vendorAddress");
        vBank = getIntent().getStringExtra("vendorBank");
        vAccount = getIntent().getStringExtra("vendorAccount");
        vBranch = getIntent().getStringExtra("vendorBranch");
        vIFSC = getIntent().getStringExtra("vendorIFSC");

        vendorName.setText(vName);
        vendorMobile.setText(vMobile);
        vendorAddress.setText(vAddress);
        vendorBank.setText(vBank);
        vendorAccount.setText(vAccount);
        vendorBranch.setText(vBranch);
        vendorIFSC.setText(vIFSC);

    }

    public void setAction() {
        button.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                Intent intent = new Intent(VendorDetails.this, VendorsList.class);
                startActivity(intent);
                finish();
            }
        });
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}




