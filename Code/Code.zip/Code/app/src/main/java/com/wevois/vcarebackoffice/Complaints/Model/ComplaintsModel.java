package com.wevois.vcarebackoffice.Complaints.Model;

public class ComplaintsModel {
String ward;
    public  ComplaintsModel(){

    }

    public ComplaintsModel(String ward) {
        this.ward = ward;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    @Override
    public String toString() {
        return "ComplaintsModel{" +
                "ward='" + ward + '\'' +
                '}';
    }
}
