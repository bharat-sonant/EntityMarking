package com.wevois.vcarebackoffice.Common;

import android.content.Context;
import android.os.AsyncTask;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendMail {

    public SendMail(Context context){

    }

    public void sendMail(String email, String subject, String messageBody, String filePath, String fileName)
    {
        Session session = createSessionObject();

        try {
            Message message = createMessage(email, subject, messageBody, filePath, fileName, session);
            new SendMailTask().execute(message);
        } catch (MessagingException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private Message createMessage(String email, String subject, String messageBody,String filePath,
                                  String fileName, Session session) throws MessagingException, UnsupportedEncodingException {

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("sikarsurvey@gmail.com", "WeVOIS Team"));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(email, email));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress("bharat.sonant@gmail.com", "Bharat"));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress("abhinav.vashistha@gmail.com", "Abhinav"));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress("guptavjabhi@gmail.com", "Abhishek"));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress("mandeep.sonant@gmail.com", "Mandeep"));
        message.setSubject(subject);
//        message.setText(messageBody);

        // Create the message part
        BodyPart messageBodyPart = new MimeBodyPart();

        // Now set the actual message
        messageBodyPart.setText(messageBody);

        // Create a multipart message
        Multipart multipart = new MimeMultipart();

        // Set text message part
        multipart.addBodyPart(messageBodyPart);

        // Part two is attachment
        messageBodyPart = new MimeBodyPart();
        DataSource source = new FileDataSource(filePath);
        messageBodyPart.setDataHandler(new DataHandler(source));
        messageBodyPart.setFileName(fileName);
        multipart.addBodyPart(messageBodyPart);
        message.setContent(multipart);
        return message;
    }

    private Session createSessionObject() {
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        return Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("sikarsurvey@gmail.com", "nydgpyohdgtfyapy");
            }
        });
    }

    private class SendMailTask extends AsyncTask<Message, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }

        @Override
        protected Void doInBackground(Message... messages) {
            try {
                Transport.send(messages[0]);
            } catch (MessagingException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
