package com.wevois.vcarebackoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class ReportCheck extends AppCompatActivity {
    EditText dateEt, monthEt, wardEt, skipEt, maxLineEt, lastLineEt;
    Button startBtn;
    String year="",month="";
    DatabaseReference databaseReference;
    CommonFunctions common = CommonFunctions.getInstance();
    SharedPreferences sharedPreferences;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_check);
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        dateEt = findViewById(R.id.date);
        monthEt = findViewById(R.id.month);
        wardEt = findViewById(R.id.ward);
        skipEt = findViewById(R.id.skip);
        maxLineEt = findViewById(R.id.maxLine);
        lastLineEt = findViewById(R.id.lasLine);
        startBtn = findViewById(R.id.start);

        startBtn.setOnClickListener(view ->
        {
            String date = dateEt.getText().toString().trim();
            String month = monthEt.getText().toString().trim();
            String ward = wardEt.getText().toString().trim();
            String skipLines = skipEt.getText().toString().trim();
            String startLine = maxLineEt.getText().toString().trim();
            String lastLine = lastLineEt.getText().toString().trim();
            String [] arr = skipLines.split("/");
            ArrayList<String> skipList = new ArrayList<>(Arrays.asList(arr));
            date = formatDate(date, month);
            if (startLine.length()>0) {
                if (date.length() > 0 && lastLine.length() > 0) {
                    setData(date, ward, skipList, Integer.parseInt(startLine), Integer.parseInt(lastLine));
                } else {
                    Toast.makeText(this, "Enter date and min lines", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Enter start lines", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setData(String date, String ward, ArrayList<String> skipList,int startLine, int lastLine) {
        try {
            year = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
            month = new SimpleDateFormat("MMMM", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        for (int i = startLine; i<= lastLine;i++){
            if (!skipList.contains(String.valueOf(i))) {
                databaseReference.child("WasteCollectionInfo/" + ward+"/"+year+"/"+month).child(date + "/LineStatus").child("" + i)
                        .child("Status").setValue("LineCompleted");
            } else {
                databaseReference.child("WasteCollectionInfo/" + ward+"/"+year+"/"+month).child(date + "/LineStatus").child("" + i)
                        .child("Status").setValue("skip");
            }
        }
        Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show();
    }

    private String formatDate(String date, String month) {
        String fDate = "";
        if(month.length()>0&&date.length()>0){
            String format = String.format(Locale.getDefault(),"%02d-%02d",Integer.parseInt(month),Integer.parseInt(date));
            fDate = "2020-"+format;
        } else{
            Toast.makeText(this, "enter date and month", Toast.LENGTH_SHORT).show();
        }
        return fDate;
    }
}
