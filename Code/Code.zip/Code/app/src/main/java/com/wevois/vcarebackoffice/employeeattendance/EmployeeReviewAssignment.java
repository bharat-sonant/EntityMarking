package com.wevois.vcarebackoffice.employeeattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class EmployeeReviewAssignment extends AppCompatActivity {
    String driverName = "", driverId = "", driverDeviceId = "", helperName = "", helperId = "", helperDeviceId = "", helperOneName = "", helperOneId = "", helperOneDeviceId = "",
            helperTwoName = "", helperTwoId = "", helperTwoDeviceId = "", helperThreeName = "", helperThreeId = "", helperThreeDeviceId = "", ward = "", vehicle = "", loginId = "", planName = "", planId = "",
            year = "", month = "", date = "", time = "";
    JSONObject mainObjects = new JSONObject(), detailsObjects = new JSONObject(), assignObjects = new JSONObject();
    int totalEmp = 2;
    TextView timerTv;
    LinearLayout timerLayout;
    Button continueBtn;
    SharedPreferences preferences, sharedPreferences;
    DatabaseReference databaseReference;
    CommonFunctions common = CommonFunctions.getInstance();
    CountDownTimer countDownTimer;
    boolean isMoved = true;
    String TIME_SERVER = "ntp.xs4all.nl",currentMapReference="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_review_assignment);
        initPage();
        setAction();
    }

    @SuppressLint("StaticFieldLeak")
    public void getRealTime() {
        new AsyncTask<Void, Void, Long>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Long doInBackground(Void... p) {
                long returnTime = 0;
                NTPUDPClient timeClient = new NTPUDPClient();
                timeClient.setDefaultTimeout(1000);
                for (int retries = 7; retries >= 0; retries--) {
                    try {
                        InetAddress inetAddress = InetAddress.getByName(TIME_SERVER);
                        TimeInfo timeInfo = timeClient.getTime(inetAddress);
                        returnTime = timeInfo.getMessage().getTransmitTimeStamp().getTime();
                        return returnTime;
                    } catch (IOException e) {
                    }
                }
                return returnTime;
            }

            @Override
            protected void onPostExecute(Long result) {
                if (result != 0) {
                    final Date date = new Date(result);
                    final Date dates = new Date(new Date().getTime());
                    int timeGap = common.TimeDifference(date, dates);
                    if (String.valueOf(timeGap).contains("-")) {
                        timeGap = Integer.parseInt(String.valueOf(timeGap).substring(1));
                    }
                    if (timeGap < 5) {
                        common.setProgressDialog("", "Ward और vehicle की assignment चेक हो रही है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
                        checkWardAndVehicle();
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "आपके मोबाइल का Time सही नहीं है |", false, EmployeeReviewAssignment.this);
                    }
                } else {
                    common.setProgressDialog("", "Ward और vehicle की assignment चेक हो रही है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
                    checkWardAndVehicle();
                }
            }
        }.execute();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        sharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
        loginId = sharedPreferences.getString("loginId", "101");
        preferences = this.getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        timerTv = findViewById(R.id.timerTextView);
        continueBtn = findViewById(R.id.btnContinueForReviewAssignment);
        timerLayout = findViewById(R.id.timerLayout);
        TextView note = findViewById(R.id.noticeAssignment);
        note.setText("Note : " + preferences.getString("assignmentWarningMessage", ""));
        TextView wardTV = findViewById(R.id.wardForReviewAssignment);
        ward = getIntent().getStringExtra("ward");
        vehicle = getIntent().getStringExtra("vehicle");
        if (ward.contains("Market") || ward.contains("mkt")) {
            wardTV.setText(ward);
        } else if (getIntent().getStringExtra("ward").contains("BinLifting")) {
            if (getIntent().hasExtra("planName")) {
                planName = getIntent().getStringExtra("planName");
                planId = getIntent().getStringExtra("planId");
                TextView planTV = findViewById(R.id.planForReviewAssignment);
                planTV.setVisibility(View.VISIBLE);
                planTV.setText(planName);
            }
            wardTV.setText(ward);
        } else {
            wardTV.setText("Ward : " + ward);
        }
        TextView vehicleTV = findViewById(R.id.vehicleForReviewAssignment);
        vehicleTV.setText(vehicle);
        driverName = getIntent().getStringExtra("driverName");
        TextView driverNameTV = findViewById(R.id.driverNameReviewAssignment);
        driverNameTV.setText(driverName);
        driverId = getIntent().getStringExtra("driver");
        TextView driverIdTV = findViewById(R.id.driverIdReviewAssignment);
        driverIdTV.setText(driverId);
        driverDeviceId = getIntent().getStringExtra("driverDevice");
        TextView driverDeviceNameTV = findViewById(R.id.driverDeviceNameReviewAssignment);
        driverDeviceNameTV.setText(driverDeviceId);
        helperName = getIntent().getStringExtra("helperName");
        TextView helperTV = findViewById(R.id.helperNameReviewAssignment);
        helperTV.setText(helperName);
        helperId = getIntent().getStringExtra("helper");
        TextView helperIdTv = findViewById(R.id.helperIdReviewAssignment);
        helperIdTv.setText(helperId);
        helperDeviceId = getIntent().getStringExtra("helperDevice");
        TextView helperDeviceNameId = findViewById(R.id.helperDeviceNameReviewAssignment);
        helperDeviceNameId.setText(helperDeviceId);

        if (getIntent().hasExtra("helperOne")) {
            LinearLayout helperLayout = findViewById(R.id.helperOneLayout);
            helperLayout.setVisibility(View.VISIBLE);
            helperOneName = getIntent().getStringExtra("helperOneName");
            TextView helperOneTV = findViewById(R.id.helperTwoNameReviewAssignment);
            helperOneTV.setText(helperOneName);
            helperOneId = getIntent().getStringExtra("helperOne");
            TextView helperOneIdTv = findViewById(R.id.helperTwoIdReviewAssignment);
            helperOneIdTv.setText(helperOneId);
            helperOneDeviceId = getIntent().getStringExtra("helperOneDevice");
            TextView helperTwoDeviceNameId = findViewById(R.id.helperTwoDeviceNameReviewAssignment);
            helperTwoDeviceNameId.setText(helperOneDeviceId);
            totalEmp = 3;
        }
        if (getIntent().hasExtra("helperTwo")) {
            LinearLayout helperLayout = findViewById(R.id.helperTwoLayout);
            helperLayout.setVisibility(View.VISIBLE);
            helperTwoName = getIntent().getStringExtra("helperTwoName");
            TextView helperTwoTV = findViewById(R.id.helperThreeNameReviewAssignment);
            helperTwoTV.setText(helperTwoName);
            helperTwoId = getIntent().getStringExtra("helperTwo");
            TextView helperTwoIdTv = findViewById(R.id.helperThreeIdReviewAssignment);
            helperTwoIdTv.setText(helperTwoId);
            helperTwoDeviceId = getIntent().getStringExtra("helperTwoDevice");
            TextView helperTwoDeviceNameId = findViewById(R.id.helperThreeDeviceNameReviewAssignment);
            helperTwoDeviceNameId.setText(helperTwoDeviceId);
            totalEmp = 4;
        }
        if (getIntent().hasExtra("helperThree")) {
            LinearLayout helperThreeLayout = findViewById(R.id.helperThreeLayout);
            helperThreeLayout.setVisibility(View.VISIBLE);
            helperThreeName = getIntent().getStringExtra("helperThreeName");
            TextView helperThreeTV = findViewById(R.id.helperFourthNameReviewAssignment);
            helperThreeTV.setText(helperThreeName);
            helperThreeId = getIntent().getStringExtra("helperThree");
            TextView helperThreeIdTv = findViewById(R.id.helperFourthIdReviewAssignment);
            helperThreeIdTv.setText(helperThreeId);
            helperThreeDeviceId = getIntent().getStringExtra("helperThreeDevice");
            TextView helperThreeDeviceNameId = findViewById(R.id.helperFourthDeviceNameReviewAssignment);
            helperThreeDeviceNameId.setText(helperThreeDeviceId);
            totalEmp = 5;
        }

        setTimer();
    }

    private void setAction() {
        continueBtn.setOnClickListener(view -> {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Please wait...", this, this);
                getRealTime();
            }
        });
    }

    private void checkWardAndVehicle() {
        databaseReference.child("Tasks/" + ward).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("Available")) {
                        databaseReference.child("Vehicles/" + vehicle + "/status").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.getValue() != null) {
                                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("1")) {
                                        if (planName.length() > 0) {
                                            databaseReference.child("DustbinData/DustbinPickingPlans/" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "/" + planId + "/isAssigned").addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                    if (dataSnapshot.getValue() != null) {
                                                        if (dataSnapshot.getValue().toString().equalsIgnoreCase("false")) {
                                                            common.setProgressDialog("", "employee की assignment चेक हो रही है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
                                                            checkEmployeeDetails(driverId, driverDeviceId, "1", "Driver");
                                                        } else {
                                                            isMoved = true;
                                                            common.showAlertDialog("Error!", "Plan already assigned है |", false, EmployeeReviewAssignment.this);
                                                        }
                                                    } else {
                                                        isMoved = true;
                                                        common.showAlertDialog("Error!", "Plan already assigned है |", false, EmployeeReviewAssignment.this);
                                                    }
                                                }

                                                @Override
                                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                                }
                                            });
                                        } else {
                                            common.setProgressDialog("", "employee की assignment चेक हो रही है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
                                            checkEmployeeDetails(driverId, driverDeviceId, "1", "Driver");
                                        }
                                    } else {
                                        isMoved = true;
                                        common.showAlertDialog("Error!", "Vehicle already assigned है |", false, EmployeeReviewAssignment.this);
                                    }
                                } else {
                                    isMoved = true;
                                    common.showAlertDialog("Error!", "Vehicle नहीं मिला.", false, EmployeeReviewAssignment.this);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Error!", "Ward already assigned है |", false, EmployeeReviewAssignment.this);
                    }
                } else {
                    isMoved = true;
                    common.showAlertDialog("Error!", "Ward नहीं मिला.", false, EmployeeReviewAssignment.this);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkEmployeeDetails(String id, String deviceIdString, String isDriver, String message) {
        databaseReference.child("WorkAssignment/" + id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("current-assignment")) {
                        if (dataSnapshot.child("current-assignment").getValue().toString().equalsIgnoreCase("")) {
                            checkDeviceDetails(id, deviceIdString, isDriver, message);
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Alert!", message + " को already " + dataSnapshot.child("current-assignment").getValue().toString() + " assign है |", false, EmployeeReviewAssignment.this);
                        }
                    } else {
                        checkDeviceDetails(id, deviceIdString, isDriver, message);
                    }
                } else {
                    checkDeviceDetails(id, deviceIdString, isDriver, message);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkDeviceDetails(String id, String deviceId, String isDriver, String message) {
        if (isDriver.equalsIgnoreCase("1") || isDriver.equalsIgnoreCase("2")) {
            if (planName.length() > 0 && isDriver.equalsIgnoreCase("2")) {
                if (!helperOneName.equalsIgnoreCase("")) {
                    checkEmployeeDetails(helperOneId, helperOneDeviceId, "3", "Second helper");
                } else {
                    saveLocalData();
                }
            } else {
                databaseReference.child("Devices/" + preferences.getString("city", "")).orderByChild("name").equalTo(deviceId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                if (snapshot.hasChild("status")&&snapshot.hasChild("appType")) {
                                    if (snapshot.child("status").getValue().toString().equalsIgnoreCase("1")) {
                                        if (isDriver.equalsIgnoreCase("1")) {
                                            if (planName.length() > 0){
                                                if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("3")) {
                                                    checkEmployeeDetails(helperId, helperDeviceId, "2", "Helper");
                                                } else {
                                                    isMoved = true;
                                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeReviewAssignment.this);
                                                }
                                            }else {
                                                if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("1")) {
                                                    checkEmployeeDetails(helperId, helperDeviceId, "2", "Helper");
                                                } else {
                                                    isMoved = true;
                                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeReviewAssignment.this);
                                                }
                                            }
                                        } else if (isDriver.equalsIgnoreCase("2")) {
                                            if (snapshot.child("appType").getValue().toString().equalsIgnoreCase("2")) {
                                                if (!helperOneName.equalsIgnoreCase("")) {
                                                    checkEmployeeDetails(helperOneId, helperOneDeviceId, "3", "Second helper");
                                                } else {
                                                    saveLocalData();
                                                }
                                            }else {
                                                isMoved = true;
                                                common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeReviewAssignment.this);
                                            }
                                        }
                                    } else {
                                        isMoved = true;
                                        common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeReviewAssignment.this);
                                    }
                                } else {
                                    isMoved = true;
                                    common.showAlertDialog("Warning!", message + " device free नहीं है |", false, EmployeeReviewAssignment.this);
                                }
                            }
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Error!", message + " device id गलत है |", false, EmployeeReviewAssignment.this);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        } else {
            if (isDriver.equalsIgnoreCase("3")) {
                if (!helperTwoName.equalsIgnoreCase("")) {
                    checkEmployeeDetails(helperTwoId, helperTwoDeviceId, "4", "Third helper");
                } else {
                    saveLocalData();
                }
            } else if (isDriver.equalsIgnoreCase("4")) {
                if (helperThreeName.equalsIgnoreCase("")) {
                    checkEmployeeDetails(helperThreeId, helperThreeDeviceId, "5", "Fourth helper");
                } else {
                    saveLocalData();
                }
            } else {
                saveLocalData();
            }
        }
    }

    private void saveLocalData() {
        databaseReference.child("Defaults/WardLines/"+ward+"/currentMapReference").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue()!=null){
                    currentMapReference = dataSnapshot.getValue().toString();
                }
                Log.d("TAG", "onDataChange: check map reference "+currentMapReference);
                year = new SimpleDateFormat("yyyy").format(new Date());
                month = new SimpleDateFormat("MMMM", Locale.US).format(new Date());
                SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
                date = dateFormat1.format(new Date());
                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                time = dateFormat.format(new Date());
                try {
                    mainObjects = new JSONObject();
                    detailsObjects = new JSONObject();
                    assignObjects = new JSONObject();
                    detailsObjects.put("driverId", driverId + "#" + driverName + "#" + driverDeviceId);
                    detailsObjects.put("helperId", helperId + "#" + helperName + "#" + helperDeviceId);
                    assignObjects.put("driverDetails", "");
                    assignObjects.put("helperDetails", "");
                    if (!helperOneId.equalsIgnoreCase("")) {
                        assignObjects.put("secondHelperDetails", "");
                        detailsObjects.put("secondHelper", helperOneId + "#" + helperOneName + "#" + helperOneDeviceId);
                    }
                    if (!helperTwoId.equalsIgnoreCase("")) {
                        assignObjects.put("thirdHelperDetails", "");
                        detailsObjects.put("thirdHelper", helperTwoId + "#" + helperTwoName + "#" + helperTwoDeviceId);
                    }
                    if (!helperThreeId.equalsIgnoreCase("")) {
                        assignObjects.put("fourthHelperDetails", "");
                        detailsObjects.put("fourthHelper", helperThreeId + "#" + helperThreeName + "#" + helperThreeDeviceId);
                    }
                    detailsObjects.put("ward", ward);
                    detailsObjects.put("vehicle", vehicle);
                    detailsObjects.put("totalEmp", "" + totalEmp);
                    detailsObjects.put("mapReference", currentMapReference);
                    detailsObjects.put("dateAndTime", year + "#" + month + "#" + date + "#" + time);
                    if (ward.contains("BinLifting")) {
                        detailsObjects.put("planId", planId);
                        detailsObjects.put("planName", planName);
                        assignObjects.put("dustbinAssignment", "");
                    }

                    assignObjects.put("realTime", "");
                    assignObjects.put("locationHistory", "");
                    assignObjects.put("task", "");
                    assignObjects.put("vehicle", "");
                    assignObjects.put("whoAssignWork", "");
                    assignObjects.put("wasteCollectionInfo", "");

                    mainObjects.put("details", detailsObjects);
                    mainObjects.put("assignDetails", assignObjects);

                    Log.d("TAG", "saveLocalData: check details" + mainObjects.toString());
                    preferences.edit().putString("TaskRelatedData", mainObjects.toString()).apply();
                } catch (Exception e) {
                }
                if (!ward.contains("BinLifting")){
                    setWasteCollectionInfoa();
                }else {
                    removedLocal("wasteCollectionInfo");
                    saveWardAssignment(driverId, driverDeviceId, "1", "Driver","driverDetails");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void saveEmpDetail(String userId, String deviceId, String isDriver, String message, String remoteData) {
        common.setProgressDialog("", message + " का data सेव हो रहा है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                long child = 1;
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.getKey().contains("task")) {
                            child++;
                        }
                    }
                }
                HashMap<String, String> timeData = new HashMap<>();
                HashMap<String, Object> dataMaps = new HashMap<>();
                dataMaps.put("device", deviceId);
                if (ward.contains("BinLifting")) {
                    dataMaps.put("task", ward + "(" + planName + ")");
                } else {
                    dataMaps.put("task", ward);
                }
                if (planName.length() > 0) {
                    dataMaps.put("binLiftingPlanId", planId);
                }
                dataMaps.put("status", "2");
                dataMaps.put("task-assigned-by", loginId);
                dataMaps.put("vehicle", vehicle);
                timeData.put(time, "In");
                dataMaps.put("in-out", timeData);
                long finalChild = child;
                databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + userId + "/card-swap-entries/" + time).setValue("In").addOnCompleteListener(tasks -> {
                    if (tasks.isSuccessful()) {
                        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + userId + "/task" + finalChild).setValue(dataMaps).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                removedLocal(remoteData);
                                if (isDriver.equalsIgnoreCase("1")) {
                                    saveWardAssignment(helperId, helperDeviceId, "2", "Helper", "helperDetails");
                                } else if (isDriver.equalsIgnoreCase("2")) {
                                    if (!helperOneName.equalsIgnoreCase("")) {
                                        saveWardAssignment(helperOneId, "NotApplicable", "3", "Second helper", "secondHelperDetails");
                                    } else {
                                        saveWard();
                                    }
                                } else if (isDriver.equalsIgnoreCase("3")) {
                                    if (!helperTwoName.equalsIgnoreCase("")) {
                                        saveWardAssignment(helperTwoId, "NotApplicable", "4", "Third helper","thirdHelperDetails");
                                    } else {
                                        saveWard();
                                    }
                                } else if (isDriver.equalsIgnoreCase("4")) {
                                    if (!helperThreeName.equalsIgnoreCase("")) {
                                        saveWardAssignment(helperThreeId, "NotApplicable", "5", "Fourth helper","fourthHelperDetails");
                                    } else {
                                        saveWard();
                                    }
                                } else {
                                    saveWard();
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void saveWardAssignment(String userId, String deviceId, String isDriver, String message, String removeData) {
        HashMap<String, String> data = new HashMap<>();
        if (ward.contains("BinLifting")) {
            data.put("current-assignment", ward + "(" + planName + ")");
        } else {
            data.put("current-assignment", ward);
        }
        data.put("vehicle", vehicle);
        data.put("device", deviceId);
        databaseReference.child("WorkAssignment/" + userId).setValue(data).addOnCompleteListener(task1 -> {
            if (task1.isSuccessful()) {
                if (isDriver.equalsIgnoreCase("1")) {
                    saveDevice(userId, deviceId, isDriver, message, removeData);
                } else if (isDriver.equalsIgnoreCase("2")) {
                    if (planName.length() > 0) {
                        saveEmpDetail(userId, deviceId, isDriver, message, removeData);
                    } else {
                        saveDevice(userId, deviceId, isDriver, message, removeData);
                    }
                } else {
                    saveEmpDetail(userId, deviceId, isDriver, message, removeData);
                }
            } else {
                isMoved = true;
                common.showAlertDialog("Warning!", message + " data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
            }
        });
    }

    private void saveDevice(String userId, String deviceId, String isDriver, String message, String removeData) {
        databaseReference.child("Devices/" + preferences.getString("city", "")).orderByChild("name").equalTo(deviceId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        String key = dataSnapshot1.getKey();
                        databaseReference.child("Devices/" + preferences.getString("city", "")).child(key).child("status").setValue("2").addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                if (isDriver.equalsIgnoreCase("1")) {
                                    saveEmpDetail(userId, deviceId, isDriver, message, removeData);
                                } else {
                                    saveEmpDetail(userId, deviceId, isDriver, message, removeData);
                                }
                            } else {
                                isMoved = true;
                                common.showAlertDialog("Warning!", "Data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void removedLocal(String removeData) {
        try {
            if (assignObjects.has(removeData)) {
                assignObjects.remove(removeData);
            }
            mainObjects.put("details", detailsObjects);
            mainObjects.put("assignDetails", assignObjects);
            Log.d("TAG", "saveLocalData: check details" + mainObjects.toString());
            preferences.edit().putString("TaskRelatedData", mainObjects.toString()).apply();
        } catch (Exception e) {
        }
    }

    private void saveWard() {
        common.setProgressDialog("", "Ward और vehicle का data सेव हो रहा है |", EmployeeReviewAssignment.this, EmployeeReviewAssignment.this);
        HashMap<String, String> vehicleData = new HashMap<>();
        vehicleData.put("assigned-driver", driverId);
        vehicleData.put("assigned-helper", helperId);
        if (ward.contains("BinLifting")) {
            vehicleData.put("assigned-task", ward + "(" + planName + ")");
        } else {
            vehicleData.put("assigned-task", ward);
        }
        vehicleData.put("status", "3");
        databaseReference.child("Vehicles/" + vehicle).setValue(vehicleData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                removedLocal("vehicle");
                String taskStatus = "Assigned";
                if (planName.length() > 0) {
                    taskStatus = "Available";
                }
                databaseReference.child("Tasks/" + ward).setValue(taskStatus).addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful()) {
                        removedLocal("task");
                        databaseReference.child("WhoAssignWork/" + year + "/" + month + "/" + date + "/" + loginId).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int count = 1;
                                if (dataSnapshot.getValue() != null) {
                                    count = (int) dataSnapshot.getChildrenCount() + 1;
                                }
                                HashMap<String, Object> data = new HashMap<>();
                                data.put("task", ward);
                                data.put("time", time.substring(0, time.length() - 3));
                                databaseReference.child("WhoAssignWork/" + year + "/" + month + "/" + date + "/" + loginId + "/" + count).setValue(data).addOnCompleteListener(task22 -> {
                                    if (task22.isSuccessful()) {
                                        removedLocal("whoAssignWork");
                                        String path = ward;
                                        if (planName.length() > 0) {
                                            path = ward + "/" + vehicle;
                                        }
                                        String finalPath = path;
                                        databaseReference.child("LocationHistory/" + path + "/" + year + "/" + month + "/" + date).child("/last-update-time").setValue(time.substring(0, time.length() - 3)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    removedLocal("locationHistory");
                                                    databaseReference.child("RealTimeDetails/peopleOnWork").addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                            int activeEmp = 0;
                                                            if (dataSnapshot.getValue() != null) {
                                                                activeEmp = Integer.parseInt(dataSnapshot.getValue().toString());
                                                            }
                                                            databaseReference.child("RealTimeDetails/peopleOnWork").setValue("" + (activeEmp + totalEmp)).addOnCompleteListener(task1 -> {
                                                                if (task1.isSuccessful()) {
                                                                    HashMap<String, Object> wardData = new HashMap<>();
                                                                    wardData.put("isOnDuty", "yes");
                                                                    wardData.put("activityStatus", "active");
                                                                    wardData.put("micStatus", "notActive");
                                                                    databaseReference.child("RealTimeDetails/WardDetails/" + finalPath).updateChildren(wardData).addOnCompleteListener(task2 -> {
                                                                        if (task2.isSuccessful()) {
                                                                            removedLocal("realTime");
                                                                            if (planName.length() > 0) {
                                                                                setDustbinAssignments();
                                                                            } else {
                                                                                finishActivity();
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                            });
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    }
                                });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "Ward data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
                    }
                });
            } else {
                isMoved = true;
                common.showAlertDialog("Warning!", "Vehicle data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
            }
        });
    }

    private void setWasteCollectionInfoa() {
        databaseReference.child("WasteCollectionInfo/" + ward + "/" + year + "/" + month + "/" + date + "/WorkerDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<String, String> wasteCollectionInfoData = new HashMap<>();
                String driverIds = driverId, driverNames = driverName, helperIds = helperId, helperNames = helperName, vehicles = vehicle, secondHelperIds = helperOneId, secondHelperNames = helperOneName,
                        thirdHelperIds = helperTwoId, thirdHelperNames = helperTwoName, fourthHelperIds = helperThreeId, fourthHelperNames = helperThreeName;
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("driver")) {
                        driverIds = dataSnapshot.child("driver").getValue().toString() + "," + driverIds;
                    }
                    if (dataSnapshot.hasChild("driverName")) {
                        driverNames = dataSnapshot.child("driverName").getValue().toString() + "," + driverNames;
                    }
                    if (dataSnapshot.hasChild("helper")) {
                        helperIds = dataSnapshot.child("helper").getValue().toString() + "," + helperIds;
                    }
                    if (dataSnapshot.hasChild("helperName")) {
                        helperNames = dataSnapshot.child("helperName").getValue().toString() + "," + helperNames;
                    }
                    if (dataSnapshot.hasChild("vehicle")) {
                        vehicles = dataSnapshot.child("vehicle").getValue().toString() + "," + vehicles;
                    }
                    if (dataSnapshot.hasChild("secondHelper")) {
                        if (secondHelperIds.equalsIgnoreCase("")) {
                            secondHelperIds = dataSnapshot.child("secondHelper").getValue().toString();
                        } else {
                            secondHelperIds = dataSnapshot.child("secondHelper").getValue().toString() + "," + secondHelperIds;
                        }
                    }
                    if (dataSnapshot.hasChild("thirdHelper")) {
                        if (thirdHelperIds.equalsIgnoreCase("")) {
                            thirdHelperIds = dataSnapshot.child("thirdHelper").getValue().toString();
                        } else {
                            thirdHelperIds = dataSnapshot.child("thirdHelper").getValue().toString() + "," + thirdHelperIds;
                        }
                    }
                    if (dataSnapshot.hasChild("fourthHelper")) {
                        if (fourthHelperIds.equalsIgnoreCase("")) {
                            fourthHelperIds = dataSnapshot.child("fourthHelper").getValue().toString();
                        } else {
                            fourthHelperIds = dataSnapshot.child("fourthHelper").getValue().toString() + "," + fourthHelperIds;
                        }
                    }
                    if (dataSnapshot.hasChild("secondHelperName")) {
                        if (secondHelperNames.equalsIgnoreCase("")) {
                            secondHelperNames = dataSnapshot.child("secondHelperName").getValue().toString();
                        } else {
                            secondHelperNames = dataSnapshot.child("secondHelperName").getValue().toString() + "," + secondHelperNames;
                        }
                    }
                    if (dataSnapshot.hasChild("thirdHelperName")) {
                        if (thirdHelperNames.equalsIgnoreCase("")) {
                            thirdHelperNames = dataSnapshot.child("thirdHelperName").getValue().toString();
                        } else {
                            thirdHelperNames = dataSnapshot.child("thirdHelperName").getValue().toString() + "," + thirdHelperNames;
                        }
                    }
                    if (dataSnapshot.hasChild("fourthHelperName")) {
                        if (fourthHelperNames.equalsIgnoreCase("")) {
                            fourthHelperNames = dataSnapshot.child("fourthHelperName").getValue().toString();
                        } else {
                            fourthHelperNames = dataSnapshot.child("fourthHelperName").getValue().toString() + "," + fourthHelperNames;
                        }
                    }
                }
                wasteCollectionInfoData.put("driver", driverIds);
                wasteCollectionInfoData.put("driverName", driverNames);
                wasteCollectionInfoData.put("helper", helperIds);
                wasteCollectionInfoData.put("helperName", helperNames);
                if (!secondHelperIds.equalsIgnoreCase("")) {
                    wasteCollectionInfoData.put("secondHelper", secondHelperIds);
                    wasteCollectionInfoData.put("secondHelperName", secondHelperNames);
                }
                if (!thirdHelperIds.equalsIgnoreCase("")) {
                    wasteCollectionInfoData.put("thirdHelper", thirdHelperIds);
                    wasteCollectionInfoData.put("thirdHelperName", thirdHelperNames);
                }
                if (!fourthHelperIds.equalsIgnoreCase("")) {
                    wasteCollectionInfoData.put("fourthHelper", fourthHelperIds);
                    wasteCollectionInfoData.put("fourthHelperName", fourthHelperNames);
                }
                wasteCollectionInfoData.put("vehicle", vehicles);
                databaseReference.child("WasteCollectionInfo/" + ward + "/" + year + "/" + month + "/" + date + "/WorkerDetails").setValue(wasteCollectionInfoData).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        databaseReference.child("WasteCollectionInfo/" + ward + "/" + year + "/" + month + "/" + date + "/Summary/dutyInTime").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String dutyInTime = "";
                                if (dataSnapshot.getValue() != null) {
                                    dutyInTime = dataSnapshot.getValue().toString() + ",";
                                }
                                dutyInTime = dutyInTime + time.substring(0, time.length() - 3);
                                HashMap<String,Object> wasteData = new HashMap<>();
                                wasteData.put("dutyInTime",dutyInTime);
                                if (!currentMapReference.equalsIgnoreCase("")) {
                                    wasteData.put("mapReference", currentMapReference);
                                }
                                databaseReference.child("WasteCollectionInfo/" + ward + "/" + year + "/" + month + "/" + date + "/Summary").updateChildren(wasteData).addOnCompleteListener(task1 -> {
                                    if (task1.isSuccessful()) {
                                        removedLocal("wasteCollectionInfo");
                                        saveWardAssignment(driverId, driverDeviceId, "1", "Driver","driverDetails");
                                    } else {
                                        isMoved = true;
                                        common.showAlertDialog("Warning!", "WasteCollectionInfo data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
                                    }
                                });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "WasteCollectionInfo data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setDustbinAssignments() {
        HashMap<String, String> wasteCollectionInfoData = new HashMap<>();
        wasteCollectionInfoData.put("driver", driverId);
        wasteCollectionInfoData.put("helper", helperId);
        if (!helperOneName.equalsIgnoreCase("")) {
            wasteCollectionInfoData.put("secondHelper", helperOneId);
        }
        if (!helperTwoName.equalsIgnoreCase("")) {
            wasteCollectionInfoData.put("thirdHelper", helperTwoId);
        }
        if (!helperThreeName.equalsIgnoreCase("")) {
            wasteCollectionInfoData.put("fourthHelper", helperThreeId);
        }
        wasteCollectionInfoData.put("planName", planName);
        wasteCollectionInfoData.put("planId", planId);
        wasteCollectionInfoData.put("vehicle", vehicle);
        databaseReference.child("DustbinData/DustbinAssignment/" + year + "/" + month + "/" + date + "/" + planId).setValue(wasteCollectionInfoData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                databaseReference.child("DustbinData/DustbinPickingPlans/" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "/" + planId + "/isAssigned").setValue("true").addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful()) {
                        removedLocal("dustbinAssignment");
                        finishActivity();
                    } else {
                        isMoved = true;
                        common.showAlertDialog("Warning!", "DustbinAssignment data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
                    }
                });
            } else {
                isMoved = true;
                common.showAlertDialog("Warning!", "DustbinAssignment data सेव नहीं हुआ |", false, EmployeeReviewAssignment.this);
            }
        });
    }

    private void finishActivity() {
        preferences.edit().putString("TaskRelatedData", "").apply();
        common.closeDialog(EmployeeReviewAssignment.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(EmployeeReviewAssignment.this);
        builder.setTitle("Info!!!");
        builder.setCancelable(false);
        builder.setMessage("सफलतापूर्वक assignment हो चूका है |");
        builder.setPositiveButton("Ok", (dialog, which) -> {
            dialog.dismiss();
            Intent intent = new Intent(EmployeeReviewAssignment.this, WardSelectKotlin.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            Bundle options = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
            startActivity(intent, options);
            finish();
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void setTimer() {
        int time = preferences.getInt("assignmentReviewWaitTime", 0) * 1000;
        countDownTimer = new CountDownTimer(time, 1000) {
            public void onTick(long millisUntilFinished) {
                timerTv.setText(millisUntilFinished / 1000 > 9 ? "" + millisUntilFinished / 1000 + " Sec" : "0" + millisUntilFinished / 1000 + " Sec");
            }

            public void onFinish() {
                timerLayout.setVisibility(View.GONE);
                continueBtn.setVisibility(View.VISIBLE);
            }
        }.start();
    }
}