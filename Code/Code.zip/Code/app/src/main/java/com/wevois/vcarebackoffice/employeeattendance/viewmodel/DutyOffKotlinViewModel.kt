package com.wevois.vcarebackoffice.employeeattendance.viewmodel

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.wevois.vcarebackoffice.Common.CommonFunctions
import com.wevois.vcarebackoffice.Monitoring.WardSelectActivity
import com.wevois.vcarebackoffice.employeeattendance.adapter.DutyOffAdapter
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel
import com.wevois.vcarebackoffice.employeeattendance.repository.DutyOffKotlinRepository
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin
import java.text.SimpleDateFormat
import java.util.*

class DutyOffKotlinViewModel(var activity: Activity) : ViewModel() {
    var common = CommonFunctions.getInstance()
    var preferences: SharedPreferences
    var otherDetails: ArrayList<OtherDetails>
    var userModels: ArrayList<ParentRecyclerviewModel>
    var wards: ArrayList<String>
    var offLineData: ArrayList<String>
    var repository = DutyOffKotlinRepository()
    var parentRecyclerViewAdapter = ObservableField<DutyOffAdapter>()
    var workPercent = 0
    var isMoved = true
    var outTime = ""

    init {
        preferences = activity.getSharedPreferences("path", Context.MODE_PRIVATE)
        otherDetails = Gson().fromJson(activity.intent.getStringExtra("otherDetails"), object : TypeToken<ArrayList<OtherDetails?>?>() {}.type)
        userModels = Gson().fromJson(activity.intent.getStringExtra("userModel"), object : TypeToken<ArrayList<ParentRecyclerviewModel?>?>() {}.type)
        wards = otherDetails[0].wards
        offLineData = ArrayList()
        repository.getWorkPercentage(activity, common, otherDetails[0].wards[otherDetails[0].wards.size - 1])?.observe((activity as LifecycleOwner), { response: Int -> workPercent = response })
        parentRecyclerViewAdapter.set(DutyOffAdapter(userModels, activity))
    }

    fun onContinueClick() {
        if (isMoved) {
            isMoved = false
            common.setProgressDialog("", "Please wait...", activity, activity)
            common.realTime.observe((activity as LifecycleOwner)) { response: String ->
                if (response.equals("fail", ignoreCase = true)) {
                    isMoved = true
                    common.showAlertDialog(
                        "Warning!",
                        "आपके मोबाइल का Time सही नहीं है |",
                        false,
                        activity
                    )
                } else {
                    common.closeDialog(activity)
                    var pathString = wards[wards.size - 1]
                    var message = "Navigator application"
                    if (wards[wards.size - 1].contains("BinLifting")) {
                        pathString = "BinLifting/" + otherDetails[0].vehicle
                        message = "DustbinRouting application"
                    }
                    common.setProgressDialog(
                        "",
                        "$message offline तो नहीं है चेक कर रहे है |...",
                        activity,
                        activity
                    )
                    common.checkResponse(
                        activity,
                        pathString,
                        message,
                        userModels[0].name,
                        userModels[0].id
                    ).observe((activity as LifecycleOwner)) { responses: String ->
                        if (responses.equals("success", ignoreCase = true)) {
                            saveLocalData()
                        } else {
                            isMoved = true
                        }
                    }
                }
            }
        }
    }

    private fun saveLocalData() {
        outTime = SimpleDateFormat("HH:mm:ss").format(Date())
        otherDetails[0].workPercentage = workPercent.toString()
        otherDetails[0].time = outTime
        offLineData.add("emp")
        offLineData.add("realTimeCount")
        offLineData.add("vehicle")
        offLineData.add("realTimeDetails")
        if (wards[wards.size - 1].contains("BinLifting")) {
            offLineData.add("dustbinAssignment")
        } else {
            offLineData.add("taskDetails")
            offLineData.add("WasteCollectionInfo")
            offLineData.add("TripWasteCollectionInfo")
        }
        otherDetails[0].offlineSave = offLineData
        preferences.edit().putString("dutyOffUserDetails", Gson().toJson(userModels)).apply()
        preferences.edit().putString("dutyOffOtherDetails", Gson().toJson(otherDetails)).apply()
        repository.setEmployeeData(activity,common,otherDetails,userModels,preferences,outTime,wards,workPercent)?.observe((activity as LifecycleOwner)) { response: String ->
            removedLocal("emp")
        }
        repository.realTimeCountDetails(activity,common,userModels)?.observe((activity as LifecycleOwner)) { response: String ->
            removedLocal("realTimeCount")
        }
        repository.sendVehicleData(activity,common,otherDetails,"","","","1")?.observe((activity as LifecycleOwner)) { response: String ->
            removedLocal("vehicle")
        }
        repository.sendRealTimeDetailData(activity,common,otherDetails,wards[wards.size-1],"no","completed","notActive")?.observe((activity as LifecycleOwner)) { response: String ->
            removedLocal("realTimeDetails")
        }
        if (wards[wards.size - 1].contains("BinLifting")) {
            repository.planFree(activity,common,otherDetails)?.observe((activity as LifecycleOwner)) { response: String ->
                removedLocal("dustbinAssignment")
            }
        } else {
            repository.sendTaskDetailData(activity,common,wards[wards.size-1],"Available")?.observe((activity as LifecycleOwner)) { response: String ->
                removedLocal("taskDetails")
            }
            repository.sendWasteCollectionInfoDetailData(activity,common,wards,outTime)?.observe((activity as LifecycleOwner)) { response: String ->
                removedLocal("WasteCollectionInfo")
            }
            repository.checkTripWasteCollectionInfoComplete(activity,common,otherDetails,preferences,wards)?.observe((activity as LifecycleOwner)) { response: String ->
                if (response == "success") {
                    offLineData.add("setTripWards")
                    offLineData.add("setTripRealTimeWardsDetails")
                    removedLocal("TripWasteCollectionInfo")
                    repository.setTripWards(activity, common, otherDetails, preferences)
                        ?.observe((activity as LifecycleOwner)) { response: String ->
                            removedLocal("setTripWards")
                        }
                    repository.setTripRealTimeWardsDetails(activity, common, wards)
                        ?.observe((activity as LifecycleOwner)) { response: String ->
                            removedLocal("setTripRealTimeWardsDetails")
                        }
                } else {
                    removedLocal("TripWasteCollectionInfo")
                }
            }
        }
    }

    private fun removedLocal(removeData: String) {
        try {
            if (offLineData.contains(removeData)){
                offLineData.remove(removeData)
            }
            Log.d("TAG", "removedLocal: check A "+offLineData+"   "+offLineData.size)
            otherDetails[0].offlineSave = offLineData
            Log.d("TAG", "removedLocal: check B "+otherDetails)
            preferences.edit().putString("dutyOffUserDetails", Gson().toJson(userModels)).apply()
            preferences.edit().putString("dutyOffOtherDetails", Gson().toJson(otherDetails)).apply()
            if(offLineData.size==0)
                moveActivity()
        } catch (e: Exception) {
        }
    }

    private fun moveActivity() {
        common.closeDialog(activity)
        preferences.edit().putString("dutyOffUserDetails", "").apply()
        preferences.edit().putString("dutyOffOtherDetails", "").apply()
        val intent = Intent(activity, WardSelectKotlin::class.java)
//        intent.putExtra("vehicleNo", otherDetails[0].vehicle)
//        intent.putExtra("ward", wards[wards.size - 1])
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        val options = ActivityOptions.makeSceneTransitionAnimation(activity).toBundle()
        activity.startActivity(intent, options)
        activity.finish()
    }

    fun onBack() {
        activity.finish()
    }
}