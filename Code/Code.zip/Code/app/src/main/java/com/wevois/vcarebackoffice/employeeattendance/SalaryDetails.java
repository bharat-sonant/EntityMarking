package com.wevois.vcarebackoffice.employeeattendance;

public class SalaryDetails {
    String ward;
    String duration;
    String salary;
    String basicTime;
    String extraTime;
    String basicSalary;
    String extraSalary;
    String name;

    public SalaryDetails(String ward, String duration, String salary, String basicTime, String extraTime, String basicSalary, String extraSalary, String name) {
        this.ward = ward;
        this.duration = duration;
        this.salary = salary;
        this.basicTime = basicTime;
        this.extraTime = extraTime;
        this.basicSalary = basicSalary;
        this.extraSalary = extraSalary;
        this.name = name;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getBasicTime() {
        return basicTime;
    }

    public void setBasicTime(String basicTime) {
        this.basicTime = basicTime;
    }

    public String getExtraTime() {
        return extraTime;
    }

    public void setExtraTime(String extraTime) {
        this.extraTime = extraTime;
    }

    public String getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(String basicSalary) {
        this.basicSalary = basicSalary;
    }

    public String getExtraSalary() {
        return extraSalary;
    }

    public void setExtraSalary(String extraSalary) {
        this.extraSalary = extraSalary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "SalaryDetails{" +
                "ward='" + ward + '\'' +
                ", duration='" + duration + '\'' +
                ", salary='" + salary + '\'' +
                ", basicTime='" + basicTime + '\'' +
                ", extraTime='" + extraTime + '\'' +
                ", basicSalary='" + basicSalary + '\'' +
                ", extraSalary='" + extraSalary + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
