package com.wevois.vcarebackoffice.Monitoring;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

public class CardDetailActivity extends AppCompatActivity {

    SharedPreferences pathSharedPreferences;
    String key;
    TextView txtPrefix, txtCardNo;
    String cardNo, assignedWard, assignedLine;
    CommonFunctions common = CommonFunctions.getInstance();
    String name,address,mobile;
    String latlng;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_details);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        init();


    }

    public void init() {
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        key = pathSharedPreferences.getString("key", "");
        txtPrefix = findViewById(R.id.txtPrefix);
        txtCardNo = findViewById(R.id.serialNo);
        txtPrefix.setText("" + key);
        findViewById(R.id.btnSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cardNo = txtPrefix.getText().toString() + "" + txtCardNo.getText().toString();
                Log.e("Cardno", cardNo);
                common.setProgressDialog("Please wait...", "Loading...", CardDetailActivity.this, CardDetailActivity.this);
                CommonFunctions.getInstance().getDatabasePath(CardDetailActivity.this).child("CardWardMapping/" + cardNo).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.e("DataSnapshot", dataSnapshot.toString());
                        if (dataSnapshot.getValue() != null) {
                            if (dataSnapshot.hasChild("line")) {
                                assignedLine = dataSnapshot.child("line").getValue().toString();
                                pathSharedPreferences.edit().putString("line", assignedLine).apply();
                            }
                            if (dataSnapshot.hasChild("ward")) {
                                assignedWard = dataSnapshot.child("ward").getValue().toString();
                                pathSharedPreferences.edit().putString("ward", assignedWard).apply();
                            }

                            CommonFunctions.getInstance().getDatabasePath(CardDetailActivity.this).child("Houses/" + assignedWard + "/" + assignedLine + "/" + cardNo).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() != null) {
                                        Log.e("dataSnapshot1", dataSnapshot.toString());
                                        common.closeDialog(CardDetailActivity.this);
                                        if (dataSnapshot.hasChild("name")) {
                                            Log.e("name", dataSnapshot.child("name").getValue().toString());
                                            name = dataSnapshot.child("name").getValue().toString();
                                        }
                                        if (dataSnapshot.hasChild("mobile")) {
                                            Log.e("mobile", dataSnapshot.child("mobile").getValue().toString());
                                            mobile = dataSnapshot.child("mobile").getValue().toString();
                                        }
                                        if (dataSnapshot.hasChild("address")) {
                                            Log.e("address", dataSnapshot.child("address").getValue().toString());
                                            address = dataSnapshot.child("address").getValue().toString();
                                        }

                                        if (dataSnapshot.hasChild("latLng")) {
                                            Log.e("latLng", dataSnapshot.child("latLng").getValue().toString());
                                            latlng = dataSnapshot.child("latLng").getValue().toString();
                                        }

                                        Intent intent = new Intent(CardDetailActivity.this, HouseDetailActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        intent.putExtra("name", name);
                                        intent.putExtra("address", address);
                                        intent.putExtra("mobile", mobile);
                                        intent.putExtra("latlng",latlng);
                                        intent.putExtra("ward",assignedWard);
                                        intent.putExtra("line",assignedLine);
                                        startActivity(intent);

                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                }
                            });
                        }else {
                            common.closeDialog(CardDetailActivity.this);
                            new AlertDialog.Builder(CardDetailActivity.this)
                                    .setMessage("CardNumber Not Found !")

                                    // Specifying a listener allows you to take an action before dismissing the dialog.
                                    // The dialog is automatically dismissed when a dialog button is clicked.
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            // Continue with delete operation
                                        }
                                    }).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });

            }
        });
    }
}
