package com.wevois.vcarebackoffice.employeeattendance.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.databinding.ActivityDutyOffReviewBinding;
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.DutyOffReviewViewModel;
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.DutyOffReviewViewModelFactory;

public class DutyOffReview extends AppCompatActivity {
    ActivityDutyOffReviewBinding binding;
    DutyOffReviewViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_duty_off_review);
        viewModel = new ViewModelProvider(this, new DutyOffReviewViewModelFactory(this)).get(DutyOffReviewViewModel.class);
        binding.setDutyoffreviewviewmodel(viewModel);
    }
}