package com.wevois.vcarebackoffice.Common;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.SystemClock;
import android.widget.Toast;

public class CommonUtils {
    public String databaseReference = "";
    public String notAssigned = "--NA--";
    private long mLastClickTime = 0;
    private ProgressDialog progressDialog;
    private Context context;

    public String[] monthArray = {"Select Month", "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};


    public CommonUtils(Context context) {
        this.context = context;
    }

    public void initProgressDialog() {
        progressDialog = new ProgressDialog(context);
    }

    public void showProgressDialog(String title, String message, boolean cancelable) {
        if (progressDialog != null) {
            Activity activity = (Activity) context;
            if (!progressDialog.isShowing() && !activity.isFinishing()) {
                progressDialog.setTitle(title);
                progressDialog.setMessage(message);
                progressDialog.setCancelable(cancelable);
                progressDialog.create();
                progressDialog.show();
            }
        }
    }

    public void dismissProgressDialog() {
        if (progressDialog != null) {
            Activity activity = (Activity) context;
            if (progressDialog.isShowing() && !activity.isFinishing()) {
                progressDialog.dismiss();
            }
        }
    }

    public void showAlertDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Info!!!");
        builder.setMessage(message);
        builder.setPositiveButton("Ok", (dialog, which) -> dialog.dismiss());

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void checkDoubleClick(Context context) {
        if ((SystemClock.elapsedRealtime() - mLastClickTime) < 3000) {
            Toast.makeText(context, "Wait...process is going on", Toast.LENGTH_SHORT).show();
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();
    }
}
