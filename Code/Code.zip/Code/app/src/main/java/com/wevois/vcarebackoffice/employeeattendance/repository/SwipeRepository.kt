package com.wevois.vcarebackoffice.employeeattendance.repository

import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.wevois.vcarebackoffice.Common.CommonFunctions
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SwipeRepository() {
    fun checkTask(activity:Activity,ward:String): LiveData<String> {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            CommonFunctions.getInstance().getDatabasePath(activity).child("Tasks/" + ward).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value != null) {
                        if (dataSnapshot.value.toString().equals("Available", ignoreCase = true)) {
                            response.value = "success"
                        } else {
                            response.value = "fail"
                        }
                    } else {
                        response.value = "fail"
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }

    fun getMapReference(activity:Activity,ward:String): LiveData<String> {
        val response = MutableLiveData<String>()
        GlobalScope.launch {
            CommonFunctions.getInstance().getDatabasePath(activity).child ("Defaults/WardLines/" + ward + "/currentMapReference").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value != null) {
                        response.value = dataSnapshot.value.toString()
                    }else{
                        response.value = "fail"
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
        return response
    }
}