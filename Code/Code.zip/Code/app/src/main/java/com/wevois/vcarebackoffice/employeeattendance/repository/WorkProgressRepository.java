package com.wevois.vcarebackoffice.employeeattendance.repository;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;

import java.util.ArrayList;

public class WorkProgressRepository {

    @SuppressLint("StaticFieldLeak")
    public LiveData<String> getBins(Activity activity, CommonFunctions common, ArrayList<OtherDetails> otherDetails) {
        MutableLiveData<String> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... p) {
                common.getDatabasePath(activity).child("DustbinData/DustbinPickingPlans/" + common.date() + "/" + otherDetails.get(0).getPlanId()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            if (dataSnapshot.hasChild("bins")) {
                                if (dataSnapshot.child("bins").getValue().toString().equalsIgnoreCase("")){
                                    response.setValue("fail");
                                }else {
                                    response.setValue(dataSnapshot.child("bins").getValue().toString());
                                }
                            } else {
                                response.setValue("fail");
                            }
                        } else {
                            common.getDatabasePath(activity).child("DustbinData/DustbinPickingPlanHistory/" + common.year() + "/" + common.monthName() + "/" + common.date() + "/" + otherDetails.get(0).getPlanId()).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() != null) {
                                        if (dataSnapshot.hasChild("bins")) {
                                            if (dataSnapshot.child("bins").getValue().toString().equalsIgnoreCase("")){
                                                response.setValue("fail");
                                            }else {
                                                response.setValue(dataSnapshot.child("bins").getValue().toString());
                                            }
                                        } else {
                                            response.setValue("fail");
                                        }
                                    } else {
                                        response.setValue("fail");
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<DataSnapshot> getDustbinList(Activity activity, CommonFunctions common) {
        MutableLiveData<DataSnapshot> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... p) {
                common.getDatabasePath(activity).child("DustbinData/DustbinDetails").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                        if (dataSnapshot1.getValue() != null) {
                            response.setValue(dataSnapshot1);
                        } else {
                            response.setValue(null);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

    @SuppressLint("StaticFieldLeak")
    public LiveData<DataSnapshot> getPickHistoryList(Activity activity, CommonFunctions common) {
        MutableLiveData<DataSnapshot> response = new MutableLiveData<>();
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... p) {
                common.getDatabasePath(activity).child("DustbinData/DustbinPickHistory/" + common.year() + "/" + common.monthName() + "/" + common.date()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        response.setValue(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                return null;
            }
        }.execute();
        return response;
    }

}
