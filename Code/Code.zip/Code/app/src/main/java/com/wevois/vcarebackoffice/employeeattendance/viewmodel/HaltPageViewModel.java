package com.wevois.vcarebackoffice.employeeattendance.viewmodel;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableField;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.employeeattendance.Interface.OnClickInterface;
import com.wevois.vcarebackoffice.employeeattendance.adapter.HaltPgeAdapter;
import com.wevois.vcarebackoffice.employeeattendance.model.HaltPageModel;
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails;
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel;
import com.wevois.vcarebackoffice.employeeattendance.views.HaltMap;
import com.wevois.vcarebackoffice.employeeattendance.views.HaltReview;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class HaltPageViewModel extends ViewModel implements OnClickInterface {
    Activity activity;
    boolean isMoved = true;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<OtherDetails> otherDetails;
    DateFormat timeFormat;
    public ObservableField<HaltPgeAdapter> haltRecyclerViewAdapter = new ObservableField<>();
    public ObservableField<String> wardName = new ObservableField<>(""), currentWard = new ObservableField<>(), totalTime = new ObservableField<>("00:00"), totalHaltTime = new ObservableField<>("00:00"),
            totalApprovedTime = new ObservableField<>("00:00");
    ArrayList<Long> totalHaltTimeFbs = new ArrayList<>(), finalApprovedTimes = new ArrayList<>(), approvedHaltTimeVars = new ArrayList<>();
    ArrayList<ArrayList<HaltPageModel>> haltList = new ArrayList<>();
    ArrayList<ParentRecyclerviewModel> userModel;
    ArrayList<String> wards;
    SharedPreferences preferences;
    public ObservableField<Boolean> isPreviousVisible = new ObservableField<>(false);
    int currentPosition = 0;

    public HaltPageViewModel(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("path", MODE_PRIVATE);
        otherDetails = new Gson().fromJson(activity.getIntent().getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {
        }.getType());
        userModel = new Gson().fromJson(activity.getIntent().getStringExtra("userModel"), new TypeToken<ArrayList<ParentRecyclerviewModel>>() {
        }.getType());
        wards = otherDetails.get(0).getWards();
        timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        common.setProgressDialog("Please wait...","",activity,activity);
        getHalt();
    }

    public void getHalt() {
        activity.runOnUiThread(() -> {
            ArrayList<ArrayList<HaltPageModel>> haltLists = new ArrayList<>();
            for (int i = 0; i < wards.size(); i++) {
                int finalI = i;
                final long[] approvedHaltTimeVar = {0};
                final long[] totalHaltTimeVar = {0};
                int counts = finalI;
                String path = wards.get(counts);
                if (path.contains("BinLifting")) {
                    path = "BinLifting/" + otherDetails.get(0).getVehicle();
                }
                common.getDatabasePath(activity).child("HaltInfo/" + path + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        ArrayList<HaltPageModel> haltModels = new ArrayList<>();
                        if (dataSnapshot.getValue() != null) {
                            int i = 1;
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String haltStartTime = "", endTime = "", locality = "", haltType = "", canRemoveHalt = "yes";
                                int textColor = Color.parseColor("#000000");
                                LatLng latLng = new LatLng(0.0, 0.0);
                                if (snapshot.hasChild("startTime")) {
                                    final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
                                    haltStartTime = snapshot.child("startTime").getValue().toString();
                                    try {
                                        Date date1 = dateFormat.parse(otherDetails.get(0).getStarts().get(counts));
                                        Date date2 = dateFormat.parse(haltStartTime);
                                        if ((date1.getTime() <= date2.getTime())) {
                                            if (snapshot.hasChild("duration")) {
                                                String individualHaltTime = snapshot.child("duration").getValue().toString();
                                                double iHT = Double.parseDouble(individualHaltTime);
                                                if (snapshot.hasChild("haltType")) {
                                                    if (snapshot.child("haltType").getValue().toString().equalsIgnoreCase("mobile-off")) {
                                                        haltType = "application closed found";
                                                    } else {
                                                        haltType = snapshot.child("haltType").getValue().toString();
                                                    }
                                                }
                                                if (iHT >= preferences.getInt("minimumHaltShow", 0) && !haltType.equals("network-off")) {
                                                    if (snapshot.hasChild("locality")) {
                                                        locality = snapshot.child("locality").getValue().toString();
                                                    }
                                                    if (snapshot.hasChild("startTime")) {
                                                        haltStartTime = snapshot.child("startTime").getValue().toString();
                                                    }
                                                    if (snapshot.hasChild("endTime")) {
                                                        endTime = snapshot.child("endTime").getValue().toString();
                                                    }
                                                    if (snapshot.hasChild("canRemove")) {
                                                        canRemoveHalt = snapshot.child("canRemove").getValue().toString();
                                                    }
                                                    if (snapshot.hasChild("location")) {
                                                        String loc = snapshot.child("location").getValue().toString();
                                                        loc = loc.replace("lat/lng: (", "");
                                                        loc = loc.replace(")", "");
                                                        String[] locArr = loc.split(",");
                                                        latLng = new LatLng(Double.parseDouble(locArr[0]), Double.parseDouble(locArr[1]));
                                                    }
                                                    if (!snapshot.hasChild("removeReason")) {
                                                        if (preferences.getInt("minimumTimeForOrange", 0) >= Integer.parseInt(individualHaltTime) && Integer.parseInt(individualHaltTime) > preferences.getInt("minimumTimeForGreen", 0)) {
                                                            textColor = Color.parseColor("#10AD24");
                                                        } else if (preferences.getInt("minimumTimeForRed", 0) >= Integer.parseInt(individualHaltTime) && Integer.parseInt(individualHaltTime) > preferences.getInt("minimumTimeForOrange", 0)) {
                                                            textColor = Color.parseColor("#FC9627");
                                                        } else if (Integer.parseInt(individualHaltTime) > preferences.getInt("minimumTimeForRed", 0)) {
                                                            textColor = Color.parseColor("#ff0000");
                                                        }
                                                        haltModels.add(new HaltPageModel("" + i, "" + (int) iHT, haltStartTime, endTime, locality, haltType, snapshot.getKey(), "active", canRemoveHalt, textColor, Color.parseColor("#ffffff"), latLng));
                                                        i++;
                                                        approvedHaltTimeVar[0] += iHT;
                                                    } else {
                                                        haltModels.add(new HaltPageModel("" + i, "" + (int) iHT, haltStartTime, endTime, locality, haltType, snapshot.getKey(), "inActive", canRemoveHalt, textColor, Color.parseColor("#FFE7E5E5"), latLng));
                                                        i++;
                                                    }
                                                    totalHaltTimeVar[0] += iHT;
                                                }
                                            }
                                        }
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                        haltLists.add(haltModels);
                        totalHaltTimeFbs.add((Long) totalHaltTimeVar[0] * 60000);
                        approvedHaltTimeVars.add((Long) approvedHaltTimeVar[0] * 60000);
                        long time = otherDetails.get(0).getTotalTimes().get(counts);
                        long diff = ((long) approvedHaltTimeVar[0] * 60000) > time ? 0 : time - ((long) approvedHaltTimeVar[0] * 60000);
                        finalApprovedTimes.add(diff);
                        if (counts == (wards.size() - 1)) {
                            haltList = haltLists;
                            otherDetails.get(0).setTotalHaltTime(totalHaltTimeFbs);
                            otherDetails.get(0).setApprovedHaltTime(approvedHaltTimeVars);
                            otherDetails.get(0).setApprovedTime(finalApprovedTimes);
                            setWard();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }

    public void previousOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if (currentPosition != 0) {
            currentPosition = currentPosition - 1;
            if (currentPosition == 0) {
                isPreviousVisible.set(false);
            }
            setWard();
        }
    }

    public void nextOnClick() {
        common.setProgressDialog("", "Loading...", activity, activity);
        if ((wards.size() - 1) > currentPosition) {
            if (currentPosition == 0) {
                isPreviousVisible.set(true);
            }
            currentPosition = currentPosition + 1;
            setWard();
        } else {
            if (isMoved) {
                isMoved = false;
                common.setProgressDialog("", "Please wait...", activity, activity);
                common.getRealTime().observe((LifecycleOwner) activity, response -> {
                    if (response.equalsIgnoreCase("fail")) {
                        isMoved=true;
                        common.showAlertDialog("Warning!", "आपके मोबाइल का Time सही नहीं है |", false, activity);
                    } else {
                        common.closeDialog(activity);
                        Intent intent = new Intent(activity, HaltReview.class);
                        intent.putExtra("haltList", new Gson().toJson(haltList));
                        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
                        intent.putExtra("userModel", new Gson().toJson(userModel));
                        activity.startActivityForResult(intent, 100);
                        isMoved = true;
                    }
                });
            }
        }
    }

    private void setWard() {
        totalHaltTime.set(timeFormat.format(new Date(otherDetails.get(0).getApprovedHaltTime().get(currentPosition))));
        haltRecyclerViewAdapter.set(new HaltPgeAdapter(haltList.get(currentPosition), activity, this));
        totalApprovedTime.set("" + timeFormat.format(new Date(otherDetails.get(0).getApprovedTime().get(currentPosition))));
        totalTime.set("" + timeFormat.format(new Date(otherDetails.get(0).getTotalTimes().get(currentPosition))));
        if (wards.get(currentPosition).contains("BinLifting")) {
            wardName.set("BinLifting");
        }else {
            wardName.set(wards.get(currentPosition));
        }
        currentWard.set("Task : " + (currentPosition + 1) + "/" + wards.size());
        common.closeDialog(activity);
    }

    public void onMapClick() {
        common.closeDialog(activity);
        Intent intent = new Intent(activity, HaltMap.class);
        intent.putExtra("haltList", new Gson().toJson(haltList));
        intent.putExtra("otherDetails", new Gson().toJson(otherDetails));
        intent.putExtra("userModel", new Gson().toJson(userModel));
        activity.startActivityForResult(intent, 100);
    }

    public void onBack() {
        activity.finish();
    }

    @Override
    public void onItemClick(int position) {
        ArrayList<HaltPageModel> haltModels = haltList.get(currentPosition);
        HaltPageModel model = haltModels.get(position);
        String path = wards.get(currentPosition);
        if (wards.get(currentPosition).contains("BinLifting")) {
            path = "BinLifting/" + otherDetails.get(0).getVehicle();
        }
        if (haltModels.get(position).getActiveHalt().equals("active")) {
            if (haltModels.get(position).getCanRemove().equalsIgnoreCase("yes")) {
                String finalPath = path;
                common.openHaltDialog(activity, true).observe((LifecycleOwner) activity, response -> {
                    common.getDatabasePath(activity).child("HaltInfo/" + finalPath + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).child(haltModels.get(position).getKey() + "/removeReason").setValue(response).addOnCompleteListener(task -> setDetails("inActive", Color.parseColor("#FFE7E5E5"), model, haltModels, position, true));
                });
            } else {
                Toast.makeText(activity, "You are not authorized to remove this halt.", Toast.LENGTH_SHORT).show();
            }
        } else {
            String finalPath = path;
            common.openHaltDialog(activity, false).observe((LifecycleOwner) activity, response -> {
                common.getDatabasePath(activity).child("HaltInfo/" + finalPath + "/" + common.year() + "/" + common.monthName() + "/" + common.date()).child(haltModels.get(position).getKey() + "/removeReason").removeValue().addOnCompleteListener(task -> setDetails("active", Color.parseColor("#ffffff"), model, haltModels, position, false));
            });
        }
    }

    private void setDetails(String status, int parseColor, HaltPageModel model, ArrayList<HaltPageModel> haltModels, int position, boolean isRemoved) {
        model.setActiveHalt(status);
        model.setLayoutColor(parseColor);
        Long approvedHaltTimeVar = isRemoved ? approvedHaltTimeVars.get(currentPosition) - (Long.parseLong(model.getDuration()) * 60000) : approvedHaltTimeVars.get(currentPosition) + (Long.parseLong(model.getDuration()) * 60000);
        long time = otherDetails.get(0).getTotalTimes().get(currentPosition);
        long diff = approvedHaltTimeVar > time ? 0 : time - approvedHaltTimeVar;
        finalApprovedTimes.set(currentPosition, diff);
        approvedHaltTimeVars.set(currentPosition, approvedHaltTimeVar);
        otherDetails.get(0).setTotalHaltTime(totalHaltTimeFbs);
        otherDetails.get(0).setApprovedHaltTime(approvedHaltTimeVars);
        otherDetails.get(0).setApprovedTime(finalApprovedTimes);
        preferences.edit().putString("otherDetails", new Gson().toJson(otherDetails)).apply();
        haltModels.set(position, model);
        haltList.set(currentPosition, haltModels);
        setWard();
    }

    public void onResult(Intent data) {
        haltList = new Gson().fromJson(data.getStringExtra("haltList"), new TypeToken<ArrayList<ArrayList<HaltPageModel>>>() {
        }.getType());
        otherDetails = new Gson().fromJson(data.getStringExtra("otherDetails"), new TypeToken<ArrayList<OtherDetails>>() {
        }.getType());
        setWard();
    }
}