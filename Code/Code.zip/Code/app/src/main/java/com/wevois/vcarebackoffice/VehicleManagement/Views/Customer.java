package com.wevois.vcarebackoffice.VehicleManagement.Views;

public class Customer {
    String date;

    public Customer(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }
}
