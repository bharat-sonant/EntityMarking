package com.wevois.vcarebackoffice.VehicleManagement.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.VehicleManagement.Views.User;

import java.util.ArrayList;

public class AllDataRetrieveAdapter extends RecyclerView.Adapter<AllDataRetrieveAdapter.MyViewHolder> {
    Context context;
    ArrayList<User> list;

    public AllDataRetrieveAdapter(Context context, ArrayList<User> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.display_items, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        User user = list.get(position);
        holder.createdBy.setText(user.getCreatedBy());
        holder.createdDate.setText(user.getCreatedDate());
        holder.oilFillDateTextView.setText(user.getOilFillDateTextView());
        holder.type.setText(user.getType());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView createdBy;
        TextView createdDate;
        TextView oilFillDateTextView;
        TextView type;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            createdBy = itemView.findViewById(R.id.createdbytextView);
            createdDate = itemView.findViewById(R.id.createddatetextView);
            oilFillDateTextView = itemView.findViewById(R.id.oilFillDateTextView);
            type = itemView.findViewById(R.id.oiltypetextView);
        }
    }
}
