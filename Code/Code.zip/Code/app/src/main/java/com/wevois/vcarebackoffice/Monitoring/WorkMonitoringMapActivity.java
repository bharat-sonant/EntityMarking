package com.wevois.vcarebackoffice.Monitoring;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.maps.android.data.kml.KmlLayer;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class WorkMonitoringMapActivity extends AppCompatActivity implements OnMapReadyCallback {
    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;
    String wardNo = "", date = "";
    GoogleMap mMap;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<LatLng> directionpositionlist = new ArrayList<>();
    LatLngBounds.Builder builder;
    private View mCustomMarkerView;
    private ImageView mMarkerImageView;
    private TextView mMarkerTextView;
    int backgroundColor;
    LatLng latLng;
    private LatLng mDummyLatLng = new LatLng(26.83, 76.566);
    String indivisualHaltTime = "";
    TextView totalLineTv, completedLineTv, workPercentTv;
    Button wardNoView;
    ImageButton path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_monitoring_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        totalLineTv = findViewById(R.id.totalLine);
        completedLineTv = findViewById(R.id.completedLine);
        workPercentTv = findViewById(R.id.workPercent);
        wardNoView = findViewById(R.id.wardTextButton);
        path = findViewById(R.id.path);
        sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (getIntent() != null) {
            wardNo = getIntent().getStringExtra("wardNo");
            date = getIntent().getStringExtra("date");
        }
        wardNoView.setText(wardNo);
        path.setOnClickListener(view -> {
            showRoute();
        });
        initViews();
    }

    private void initViews() {
        backgroundColor = R.drawable.outline_bg_map;
        mCustomMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.view_custom_marker, null);
        mMarkerImageView = (ImageView) mCustomMarkerView.findViewById(R.id.profile_image);
        mMarkerTextView = (TextView) mCustomMarkerView.findViewById(R.id.haltTimeTV);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        int LOCATION_REQUEST = 500;
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
            return;
        }
        mMap.setMyLocationEnabled(false);
        mMap.getUiSettings().setCompassEnabled(false);
        mMap.getUiSettings().setMapToolbarEnabled(false);

        builder = new LatLngBounds.Builder();

        getStatus();

        new DownloadKmlFile(common.getKmlFilePath(wardNo, this)).execute();

        if (wardNo.length() > 0) {
            getHaltTime(wardNo);
        }

        getCurrentLocation();
        path.setVisibility(View.VISIBLE);
    }

    private void getCurrentLocation() {
        final String[] status = {"InActive"};
        databaseReference.child("RealTimeDetails/WardDetails/" + wardNo+"/activityStatus").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    status[0] = dataSnapshot.getValue().toString();
                }
                databaseReference.child("CurrentLocationInfo/" + wardNo + "/latLng").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            String[] gpsVal = dataSnapshot.getValue().toString().split(",");
                            if (gpsVal.length > 1) {
                                LatLng latLng = new LatLng(Double.parseDouble(gpsVal[0]), Double.parseDouble(gpsVal[1]));
                                MarkerOptions markerOptions = new MarkerOptions();
                                markerOptions.position(latLng);
                                markerOptions.title(status[0]);
                                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.tipper));
                                mMap.addMarker(markerOptions);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void showRoute() {
        databaseReference.child("CurrentLocationInfo/" + wardNo + "/latLng").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    String[] gpsVal = dataSnapshot.getValue().toString().split(",");
                    if (gpsVal.length > 1) {
                        String latLng = gpsVal[0]+","+gpsVal[1];
                        try {
                            Uri gmmIntentUri = Uri.parse("geo:" + latLng + "?q=" + latLng + "(Label+Name)");
                            Intent intent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void getStatus() {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(sharedPreferences.getString("city","")+"/WardLinesHouseJson/"+wardNo+"/mapUpdateHistoryJson.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = sharedPreferences.getLong(sharedPreferences.getString("city","")+""+wardNo+"mapUpdateHistoryJsonDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child(sharedPreferences.getString("city","")+"/WardLinesHouseJson/"+wardNo+"/mapUpdateHistoryJson.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        sharedPreferences.edit().putString(sharedPreferences.getString("city","")+wardNo+"mapUpdateHistoryJson", str).apply();
                        sharedPreferences.edit().putLong(sharedPreferences.getString("city","")+""+wardNo+"mapUpdateHistoryJsonDownloadTime", fileCreationTime).apply();
                        checkDate();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }else {
                checkDate();
            }
        });
    }

    private void checkDate() {
        try {
            JSONArray jsonArray = new JSONArray(sharedPreferences.getString(sharedPreferences.getString("city","")+wardNo+"mapUpdateHistoryJson",""));
            for (int i=jsonArray.length()-1;i>=0;i--){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date date1 = format.parse(date);
                    Date date2 = format.parse(jsonArray.getString(i));
                    if (date1.after(date2)){
                        fileMetaDownload(String.valueOf(jsonArray.getString(i)));
                        break;
                    }else if (date1.equals(date2)){
                        fileMetaDownload(String.valueOf(jsonArray.getString(i)));
                        break;
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void fileMetaDownload(String dates) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(sharedPreferences.getString("city","")+"/WardLinesHouseJson/"+wardNo+"/"+dates+".json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = sharedPreferences.getLong(sharedPreferences.getString("city","")+wardNo+dates+"DownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                getFileDownload(dates);
                sharedPreferences.edit().putLong(sharedPreferences.getString("city","")+wardNo+dates+"DownloadTime", fileCreationTime).apply();
            }else {
                try {
                    String str="";
                    File file = new File(Environment.getExternalStorageDirectory(), "WardJson/"+
                            sharedPreferences.getString("city","")+"/"+wardNo+"/"+dates + ".json");
                    if (file.exists()) {
                        BufferedReader br = new BufferedReader(new FileReader(file));
                        StringBuilder result = new StringBuilder();
                        while ((str = br.readLine()) != null) {
                            result.append(str);
                        }
                        JSONObject jsonObject = new JSONObject(String.valueOf(result));
                        showLine(jsonObject);
                    }else {
                        getFileDownload(dates);
                    }
                }catch (Exception e){

                }
            }
        });
    }

    private void getFileDownload(String dates) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child(sharedPreferences.getString("city","")+"/WardLinesHouseJson/"+wardNo+"/"+dates+".json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
            try {
                String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                File root = new File(Environment.getExternalStorageDirectory(), "WardJson/"+
                        sharedPreferences.getString("city","")+"/"+wardNo);
                if (!root.exists()) {
                    root.mkdirs();
                }
                File wardFile = new File(root, dates + ".json");
                FileWriter writer = new FileWriter(wardFile, true);
                writer.append(str);
                writer.flush();
                writer.close();
                JSONObject jsonObject = new JSONObject(str);
                showLine(jsonObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void showLine(JSONObject jsonObject) {
        String yearD = "", monthD = "";
        try {
            yearD = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
            monthD = new SimpleDateFormat("MMMM", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        databaseReference.child("WasteCollectionInfo/" + wardNo + "/" + yearD + "/" + monthD + "/" + date + "/LineStatus").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int completeLine=0,totalLines=0;
                for (int i=1;i<jsonObject.length();i++){
                    try {
                        JSONArray lineJsonArray = jsonObject.getJSONObject(""+i).getJSONArray("points");
                        int color = Color.parseColor("#0C9EF1");
                        if (dataSnapshot.getValue()!=null){
                            if (dataSnapshot.hasChild(i+"/Status")){
                                if (dataSnapshot.child(i+"/Status").getValue().toString().equalsIgnoreCase("Skipped")){
                                    color = Color.RED;
                                }else if (dataSnapshot.child(i+"/Status").getValue().toString().equalsIgnoreCase("LineCompleted")){
                                    color = Color.GREEN;
                                    completeLine++;
                                }else {
                                    color = Color.RED;
                                }
                            }
                        }
                        for (int j=0;j<lineJsonArray.length();j++){
                            directionpositionlist.add(new LatLng(Double.parseDouble(lineJsonArray.getJSONArray(j).getString(0)), Double.parseDouble(lineJsonArray.getJSONArray(j).getString(1))));
                        }
                        totalLines++;
                        mMap.addPolyline(new PolylineOptions().addAll((directionpositionlist)).color(color).width(4.0f));
                        builder.include(directionpositionlist.get(0));
                        LatLngBounds bounds = builder.build();
                        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 150);
                        mMap.animateCamera(cu);
                        directionpositionlist.clear();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                totalLineTv.setText("Total Lines : " + totalLines);
                workPercentTv.setText("Work Percent : " + (completeLine*100)/totalLines);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private class DownloadKmlFile extends AsyncTask<String, Void, byte[]> {
        private final String mUrl;

        public DownloadKmlFile(String url) {
            mUrl = url;
        }

        protected byte[] doInBackground(String... params) {
            try {
                Log.d("tag", "doInBackground: check url  " + mUrl);
                InputStream is = new URL(mUrl).openStream();
                Log.d("tag", "doInBackground: check url A " + is);
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                int nRead;
                byte[] data = new byte[16384];
                while ((nRead = is.read(data, 0, data.length)) != -1) {
                    buffer.write(data, 0, nRead);
                }
                buffer.flush();
                return buffer.toByteArray();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(byte[] byteArr) {
            try {
                if (byteArr != null) {
                    KmlLayer kmlLayer = new KmlLayer(mMap, new ByteArrayInputStream(byteArr),
                            getApplicationContext());
                    kmlLayer.addLayerToMap();
                }
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void getHaltTime(String zoneNumber) {
        String year = "", month = "";
        try {
            year = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
            month = new SimpleDateFormat("MMMM", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        databaseReference.child("HaltInfo/" + zoneNumber + "/" + year + "/" + month + "/" + date).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String haltType = "";
                                if (snapshot.hasChild("haltType")) {
                                    haltType = snapshot.child("haltType").getValue().toString();
                                }
                                if (!haltType.equals("network-off")) {
                                    if (snapshot.hasChild("Duration") || snapshot.hasChild("duration")) {
                                        if (snapshot.hasChild("Duration")) {
                                            indivisualHaltTime = snapshot.child("Duration").getValue().toString();
                                        }
                                        if (snapshot.hasChild("duration")) {
                                            indivisualHaltTime = snapshot.child("duration").getValue().toString();
                                        }
                                    }
                                    if (snapshot.hasChild("Location") || snapshot.hasChild("location")) {
                                        String loc = "";
                                        if (snapshot.hasChild("Location")) {
                                            loc = snapshot.child("Location").getValue().toString();
                                        }
                                        if (snapshot.hasChild("location")) {
                                            loc = snapshot.child("location").getValue().toString();
                                        }
                                        loc = loc.replace("lat/lng: (", "");
                                        loc = loc.replace(")", "");
                                        String[] locArr = loc.split(",");
                                        Log.i("abcd", "onDataChange: " + loc);
                                        latLng = new LatLng(Double.parseDouble(locArr[0]), Double.parseDouble(locArr[1]));
                                        addCustomMarker(latLng, backgroundColor, haltType);
                                    }
                                }
                            }
                        } else {
                            Toast.makeText(WorkMonitoringMapActivity.this, "No halt data for today date",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

    }

    private void addCustomMarker(LatLng latLng, int backgroundColor, String haltType) {
        mDummyLatLng = latLng;
        if (mMap == null) {
            return;
        }

        Marker marker = mMap.addMarker(new MarkerOptions()
                .position(mDummyLatLng)
                .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(mCustomMarkerView, backgroundColor, haltType))));
        marker.setTitle(haltType);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(mDummyLatLng));
        builder.include(marker.getPosition());
        LatLngBounds bounds = builder.build();
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 150);
        mMap.animateCamera(cu);

        Log.d("abcd", "addCustomMarker() " + mDummyLatLng);
    }

    private Bitmap getMarkerBitmapFromView(View view, int background, String haltType) {
        if (haltType.equals("mobile-off")) {
            mMarkerImageView.setImageResource(R.drawable.redhaltmarker);
        } else {
            mMarkerImageView.setImageResource(R.drawable.marker);
        }
        mMarkerTextView.setText(indivisualHaltTime);
        mMarkerTextView.setBackgroundResource(background);
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        view.buildDrawingCache();
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
        Drawable drawable = view.getBackground();
        if (drawable != null)
            drawable.draw(canvas);
        view.draw(canvas);
        Log.i("tag", "getMarkerBitmapFromView: " + returnedBitmap + " background " + background);
        return returnedBitmap;
    }
}