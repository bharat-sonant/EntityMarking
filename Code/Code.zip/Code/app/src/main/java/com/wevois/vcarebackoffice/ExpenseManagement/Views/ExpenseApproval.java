package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.ExpenseManagement.Adapter.Expense_Approval_List_Adapter;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.ExpenseListModel;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.Expense_Approval_Model_List;
import com.wevois.vcarebackoffice.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class ExpenseApproval extends AppCompatActivity {
    TextView backTV;
    ArrayList<ExpenseListModel> arrayListExpense = new ArrayList<>();
    SharedPreferences pathSharedPreferences;
    CommonFunctions common = CommonFunctions.getInstance();
    private boolean isBackClick = true;
    Expense_Approval_List_Adapter expenseAdapter;
    ListView expenseList;
    String vendorID;
    Spinner spinner;
    TextView back;
    ArrayList<String> keyList = new ArrayList<>();
    ArrayList<String> vendorArrayList = new ArrayList<>();

    StorageReference reference = FirebaseStorage.getInstance().getReference("Common").child("Expenses");
    ArrayList<Expense_Approval_Model_List> expenseArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_approval);
        common.setProgressDialog("","Data Uploading",this,this);
        initMethod();
        setAction();
        getVendorlist();
    }

    private void setAction() {
        back.setOnClickListener(view -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    @SuppressLint("CommitPrefEdits")
    private void getExpense(String vendorId) {
        arrayListExpense.clear();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences("path", MODE_PRIVATE);
        preferences.edit().remove("ExpenseData");
        common.setProgressDialog("Please Wait", "Data Loading.", this, this);
        reference.child(vendorId+".json").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {

                reference.child(vendorId+".json").getMetadata().addOnSuccessListener(storageMetadata -> {
                    reference.child(vendorId+".json").getBytes(1000000).addOnSuccessListener(taskSnapshot -> {
                        String ExpenseData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        preferences.edit().putString("ExpenseData", ExpenseData).apply();
                        setExpense();

                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            common.closeDialog(ExpenseApproval.this);
                            Toast.makeText(ExpenseApproval.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                    common.closeDialog(ExpenseApproval.this);
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        common.closeDialog(ExpenseApproval.this);
//                        Toast.makeText(ExpenseApproval.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override

            public void onFailure(@NonNull Exception e) {
                common.closeDialog(ExpenseApproval.this);
                Toast.makeText(ExpenseApproval.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }
    private void setExpense() {
        expenseArrayList.clear();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences("path", MODE_PRIVATE);
        try {
            JSONObject jsonObject = new JSONObject(preferences.getString("ExpenseData", ""));
            Iterator<String> expenseKeys = jsonObject.keys();
            while (expenseKeys.hasNext()) {
                String key = expenseKeys.next();
                try {
                    JSONObject jsonObject1 = jsonObject.getJSONObject(key);
                    String approval = String.valueOf(jsonObject.getJSONObject(key));
                    String Name = jsonObject1.getString("vendorName");
                    String Date = jsonObject1.getString("uri");
                    String Amount = jsonObject1.getString("amount");
                    String Purchase = jsonObject1.getString("purchase");
                    String ExpenseBy = jsonObject1.getString("expenseBy");
                    String Approved = jsonObject1.getString("Approval");
                    String date = key;
                    expenseArrayList.add(new Expense_Approval_Model_List(Name, Date, Amount, Purchase, ExpenseBy, approval, Approved));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        expenseAdapter = new Expense_Approval_List_Adapter(getApplicationContext(), expenseArrayList, new Expense_Approval_List_Adapter.OnClickView() {
            @Override
            public void onClick(int i, String Amount, String Approved, String Approval) {
                SharedPreferences preferences = getApplicationContext().getSharedPreferences("path", MODE_PRIVATE);
                String OldExpenseData = preferences.getString("ExpenseData", "");

                final AlertDialog.Builder builder = new AlertDialog.Builder(ExpenseApproval.this);
                builder.setTitle("Do you Want To Approve?");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        JSONObject jsonObject = null;
                        try {

                            jsonObject = new JSONObject(Approved);
                            jsonObject.put("Approval", "Yes");
                            String json = jsonObject.toString();
                            String Check = OldExpenseData.replace(Approved, json);
                            JSONObject Check1 = new JSONObject(Check);
                            pathSharedPreferences.edit().putString("ExpenseData", Check1.toString()).apply();
                            uploadToStorage(Check1);
                            Toast.makeText(ExpenseApproval.this, "Approved", Toast.LENGTH_SHORT).show();
                        } catch (JSONException | IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ExpenseApproval.this, "Cancelled Approval", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }

        });
        expenseList.setAdapter(expenseAdapter);
        expenseAdapter.notifyDataSetChanged();

    }
    private void uploadToStorage(JSONObject Check1) throws IOException {
        StorageReference reference = FirebaseStorage.getInstance().getReference("Common").child("Expenses");
        File file = File.createTempFile("TempFile", ".json");
        try (FileWriter filewriter = new FileWriter(file)) {
            filewriter.write(Check1.toString());
            Uri uri = Uri.fromFile(file);
            StorageMetadata metadata = new StorageMetadata.Builder().setContentType("json").build();
            reference.child(vendorID+".json").putFile(uri, metadata).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                    Toast.makeText(ExpenseApproval.this, "Approved", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    @SuppressLint("WrongViewCast")
    private void initMethod() {
        expenseList = findViewById(R.id.expenseListE);
        back = findViewById(R.id.back_ButtonE);
        spinner = findViewById(R.id.spinnerFilterVendorE);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
    }

    private void getVendorlist() {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child("Common/VendorList.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            //This
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            storageReference.child("Common/VendorList.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                try {
                    String vendorJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                    pathSharedPreferences.edit().putString("VendorList", vendorJsonData).apply();
                    pathSharedPreferences.edit().putLong("VendorListDownloadTime", fileCreationTime).apply();
                    setVendorsList();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            common.closeDialog(ExpenseApproval.this);
        });
    }

    private void setVendorsList() {
        vendorArrayList.add("Select Vendor");
        try {
            JSONObject vendorJsonData = new JSONObject(pathSharedPreferences.getString("VendorList", ""));
            Iterator<String> vendorKeys = vendorJsonData.keys();
            while (vendorKeys.hasNext()) {
                String key = vendorKeys.next();
                try {
                    if (key != "lastVendorId") {
                        JSONObject values = vendorJsonData.getJSONObject(key);
                        String vendorName = values.getString("name");
                        vendorArrayList.add(vendorName + " (" + key + ") ");
                        keyList.add(key)
                        ;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> vendorSpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, vendorArrayList);
        vendorSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(vendorSpinnerAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
                if (i == 0) {
                    TextView tv = (TextView) view;
                    tv.setTextColor(i == 0 ? Color.GRAY : Color.BLACK);
                    arrayListExpense.clear();
                } else {
                    arrayListExpense.clear();
                    String spin = spinner.getSelectedItem().toString();
                    vendorID = spin.split("\\(")[1].split("\\)")[0];
                    getExpense(vendorID);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}