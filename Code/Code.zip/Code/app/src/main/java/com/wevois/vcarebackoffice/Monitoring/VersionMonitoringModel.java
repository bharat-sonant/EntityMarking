package com.wevois.vcarebackoffice.Monitoring;

public class VersionMonitoringModel {
    String serialno;
    String device;
    String version;
    String status;

    public VersionMonitoringModel(String serialno, String device, String version, String status) {
        this.serialno = serialno;
        this.device = device;
        this.version = version;
        this.status = status;
    }

    public String getSerialno() {
        return serialno;
    }

    public void setSerialno(String serialno) {
        this.serialno = serialno;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
