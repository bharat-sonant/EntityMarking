package com.wevois.vcarebackoffice.AccessManagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class AccessList extends AppCompatActivity {
    TextView checkCountTv;
    int checkCount = 0;
    String empId;
    ArrayList<Model> list = new ArrayList<>();
    CommonFunctions cmn = CommonFunctions.getInstance();
    SharedPreferences pathSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access_list);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        empId = getIntent().getExtras().getString("empId");
        setPageTitle();
        init();
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Access");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> {
            AccessList.super.onBackPressed();
        });
    }

    private void init() {
        TextView textView = findViewById(R.id.access_empName);
        textView.setText(getIntent().getExtras().getString("empName"));
        checkCountTv = findViewById(R.id.check_count);
        setList();
    }

    private void setListForCondition() {
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("vCare-BackOfficePageIds", "str"));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if (!jsonObject.has("feature")) {
                        list.add(new Model(i,
                                jsonObject.getString("pageName"),
                                false));
                    } else {
                        list.add(new Model(i,
                                jsonObject.getString("feature"),
                                false));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setList() {
        Adapter adapter = new Adapter();
        ListView listView = findViewById(R.id.access_list);
        listView.setAdapter(adapter);
        cmn.setProgressDialog("Please Wait", " ", this, this);

        cmn.getDatabasePath(AccessList.this).child("BackOfficeAccess").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild(empId)) {
                        String[] string = dataSnapshot.child(empId).getValue().toString().split(",");
                        ArrayList<String> strings = new ArrayList<>(Arrays.asList(string));
                        try {
                            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("vCare-BackOfficePageIds", "str"));
                            for (int i = 0; i < jsonArray.length(); i++) {
                                try {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    boolean isTrue;
                                    if (strings.contains(String.valueOf(i))) {
                                        isTrue = true;
                                        checkCount++;
                                    } else {
                                        isTrue = false;
                                    }
                                    if (!jsonObject.has("feature")) {
                                        list.add(new Model(i,
                                                jsonObject.getString("pageName"),
                                                isTrue));
                                    } else {
                                        list.add(new Model(i,
                                                jsonObject.getString("feature"),
                                                isTrue));
                                    }
                                } catch (Exception e) {
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    } else {
                        setListForCondition();
                    }
                } else {
                    setListForCondition();
                }
                Collections.sort(list, (model, t1) -> model.getPageName().compareTo(t1.getPageName()));
                checkCountTv.setText(String.valueOf(checkCount));
                adapter.notifyDataSetChanged();
                cmn.closeDialog(AccessList.this);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private class Adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.access_list_view, null, true);
            Model model = list.get(i);
            TextView pageName = view.findViewById(R.id.page_name);
            pageName.setText(model.getPageName());
            CheckBox checkBox = view.findViewById(R.id.page_check);
            if (model.isVisible) {
                checkBox.setChecked(true);
            } else {
                checkBox.setChecked(false);
            }

            checkBox.setOnClickListener(view1 -> {
                if (checkBox.isChecked()) {
                    list.get(i).setVisible(true);
                    checkCount++;
                } else {
                    list.get(i).setVisible(false);
                    checkCount--;
                }
                checkCountTv.setText(String.valueOf(checkCount));
                StringBuilder stringBuilder = new StringBuilder();
                for (Model accessModel1 : list) {
                    if (accessModel1.isVisible()) {
                        stringBuilder.append(accessModel1.getPageId() + ",");
                    }
                }

                if (stringBuilder.length() > 1) {
                    cmn.getDatabasePath(AccessList.this).child("BackOfficeAccess/" + empId).setValue(stringBuilder.toString().substring(0, stringBuilder.length() - 1));
                } else {
                    cmn.getDatabasePath(AccessList.this).child("BackOfficeAccess/" + empId).setValue(null);
                }

            });
            return view;
        }
    }

    private class Model {
        int pageId;
        String pageName;
        boolean isVisible;

        public int getPageId() {
            return pageId;
        }

        public String getPageName() {
            return pageName;
        }

        public boolean isVisible() {
            return isVisible;
        }

        public void setVisible(boolean visible) {
            isVisible = visible;
        }

        public Model(int pageId, String pageName, boolean isVisible) {
            this.pageId = pageId;
            this.pageName = pageName;
            this.isVisible = isVisible;
        }

    }
}