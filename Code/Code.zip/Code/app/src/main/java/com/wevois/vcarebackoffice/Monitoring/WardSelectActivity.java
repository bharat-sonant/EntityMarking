package com.wevois.vcarebackoffice.Monitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.List;

public class
WardSelectActivity extends AppCompatActivity {
    List<String> wardList = new ArrayList<>();
    SharedPreferences preferences;
    Spinner selectWard;
    Button btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ward_select);
        selectWard = findViewById(R.id.spinnerWard);
        btnContinue = findViewById(R.id.btncontinue);
        preferences = getSharedPreferences("path", MODE_PRIVATE);
        getWardNamesToSpinner();
        btnContinue.setOnClickListener(v -> {
            if (selectWard.getSelectedItem().toString().equals("Select Ward")) {
                View selectedView = selectWard.getSelectedView();
                if (selectedView != null && selectedView instanceof TextView) {
                    selectWard.requestFocus();
                    TextView selectedTextView = (TextView) selectedView;
                    selectedTextView.setError("error");
                    selectedTextView.setTextColor(Color.RED);
                    selectedTextView.setText("please select type");
                    selectWard.performClick();
                }
            } else {
                Intent i = new Intent(WardSelectActivity.this, RunningMap.class);
                i.putExtra("ward", selectWard.getSelectedItem().toString());
                i.putExtra("isRunning", true);
                startActivity(i);
            }
        });
    }

    private void getWardNamesToSpinner() {
        wardList.add("Select Ward");
        String listAsString = preferences.getString("wardList", null);
        String[] reasonString = listAsString.substring(1, listAsString.length() - 1).split(",");
        for (int i = 0; i < reasonString.length; i++) {
            String reasonType = reasonString[i].replace(" ", "");
            wardList.add(reasonType);
        }

        bindWardToSpinner();
    }

    private void bindWardToSpinner() {
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, wardList) {
            @Override
            public boolean isEnabled(int position) {
                return !(position == 0);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectWard.setAdapter(spinnerArrayAdapter);
    }
}
