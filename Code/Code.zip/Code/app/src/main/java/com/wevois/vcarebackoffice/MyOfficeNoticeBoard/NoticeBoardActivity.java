package com.wevois.vcarebackoffice.MyOfficeNoticeBoard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class NoticeBoardActivity extends AppCompatActivity {
    ArrayList<Model> list = new ArrayList<>();
    List<String> toSaveEmployeeList = new ArrayList<>();
    EditText noticeEt;
    RadioButton selectAllRBtn, chooseEmployeeRBtn;
    CommonFunctions common = CommonFunctions.getInstance();
    boolean btnHandleBool = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_board);
        setPageTitle();
        SharedPreferences sharedPreferences = getSharedPreferences("path", MODE_PRIVATE);

        selectAllRBtn = findViewById(R.id.select_all_radio_btn);
        chooseEmployeeRBtn = findViewById(R.id.choose_employee_radio_btn);
        noticeEt = findViewById(R.id.notice_et);

        String empData = sharedPreferences.getString("employeeList", "");
        if (empData.length() > 1) {
            String[] keyValuePairs = empData.split("~");
            list.clear();
            for (String pair : keyValuePairs) {
                String[] entry = pair.split(":");
                list.add(new Model(entry[1].trim(), entry[0].trim(), false));
            }
        }
        setAction();
    }

    private void setAction() {
        findViewById(R.id.publish_notice_btn).setOnClickListener(view -> {
            if (btnHandleBool) {
                btnHandleBool = false;
                if (noticeEt.getText().toString().trim().length() > 1) {
                    if (selectAllRBtn.isChecked() || chooseEmployeeRBtn.isChecked()) {
                        common.setProgressDialog("", "Uploading notice", NoticeBoardActivity.this, NoticeBoardActivity.this);
                        HashMap<String, String> map = new HashMap<>();
                        map.put("notice", noticeEt.getText().toString().trim());
                        map.put("createdOn", String.valueOf(new Date()));
                        if (selectAllRBtn.isChecked()) {
                            common.getDatabasePath(this).child("Notices/ToAll").push().setValue(map);
                        } else {
                            map.put("isSeen", "false");
                            for (int i = 0; i < toSaveEmployeeList.size(); i++) {
                                common.getDatabasePath(this).child("Notices/").child(toSaveEmployeeList.get(i)).push().setValue(map);
                            }
                            for (int i = 0; i < list.size(); i++) {
                                Model model = list.get(i);
                                model.setChecked(false);
                            }
                        }
                        selectAllRBtn.setChecked(false);
                        chooseEmployeeRBtn.setChecked(false);
                        toSaveEmployeeList.clear();
                        noticeEt.getText().clear();
                        common.closeDialog(NoticeBoardActivity.this);
                        btnHandleBool = true;
                        common.showAlertDialog("Alert", "Notice Published Successfully", false, this);

                    } else {
                        btnHandleBool = true;
                        Toast.makeText(this, "Please select employee", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    btnHandleBool = true;
                    Toast.makeText(this, "Please Enter Notice to publish", Toast.LENGTH_SHORT).show();
                }
            }

        });

        selectAllRBtn.setOnClickListener(view -> {
            selectAllRBtn.setChecked(true);
            chooseEmployeeRBtn.setChecked(false);
        });

        chooseEmployeeRBtn.setOnClickListener(view1 -> {
            if (btnHandleBool) {
                btnHandleBool = false;
                View dialog = getLayoutInflater().inflate(R.layout.alert_box_employee_list, null);
                AlertDialog alertDialog = new AlertDialog.Builder(NoticeBoardActivity.this).setView(dialog).setCancelable(false).create();
                ListView listView = dialog.findViewById(R.id.selectable_employee_list);
                listView.setAdapter(new ListAdapter());

                dialog.findViewById(R.id.cancel_tv).setOnClickListener(view -> {
                    selectAllRBtn.setChecked(true);
                    chooseEmployeeRBtn.setChecked(false);
                    for (int i = 0; i < list.size(); i++) {
                        Model model = list.get(i);
                        model.setChecked(false);
                    }
                    toSaveEmployeeList.clear();
                    btnHandleBool = true;
                    alertDialog.cancel();
                });

                dialog.findViewById(R.id.done_tv).setOnClickListener(view -> {
                    selectAllRBtn.setChecked(false);
                    chooseEmployeeRBtn.setChecked(true);
                    btnHandleBool = true;
                    alertDialog.cancel();

                });
                alertDialog.show();
            }
        });
    }

    private void setPageTitle() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        mTitle.setText("Notice Board");
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(v -> NoticeBoardActivity.super.onBackPressed());
    }

    private class Model {
        private String empName;
        private String empId;
        private boolean isChecked;

        public void setChecked(boolean checked) {
            isChecked = checked;
        }

        public boolean isChecked() {
            return isChecked;
        }

        public String getEmpName() {
            return empName;
        }

        public String getEmpId() {
            return empId;
        }

        public Model(String empName, String empId, boolean isChecked) {
            this.empName = empName;
            this.empId = empId;
            this.isChecked = isChecked;
        }
    }

    private class ListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.selectable_employee_list, null, true);
            Model listModel = list.get(i);

            String[] breakNameArray = listModel.getEmpName().split(" ");
            StringBuilder newName = new StringBuilder();
            for (String breakName : breakNameArray) {
                String firstLetter = breakName.substring(0, 1).toUpperCase() + breakName.substring(1).toLowerCase();
                newName.append(firstLetter + " ");
            }

            TextView empName = view.findViewById(R.id.emp_name);
            empName.setText(newName.toString());

            CheckBox employeeCheckBox = view.findViewById(R.id.per_employee_check_box);
            employeeCheckBox.setOnClickListener(view1 -> {
                if (employeeCheckBox.isChecked()) {
                    toSaveEmployeeList.add(listModel.getEmpId());
                    listModel.setChecked(true);
                } else {
                    toSaveEmployeeList.remove(listModel.getEmpId());
                    listModel.setChecked(false);
                }
            });

            if (listModel.isChecked) {
                employeeCheckBox.setChecked(true);
            } else {
                employeeCheckBox.setChecked(false);
            }
            return view;
        }
    }
}