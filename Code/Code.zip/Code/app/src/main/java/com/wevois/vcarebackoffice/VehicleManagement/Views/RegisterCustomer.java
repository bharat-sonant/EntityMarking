package com.wevois.vcarebackoffice.VehicleManagement.Views;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class RegisterCustomer extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button submitButton, dateButton;
    TextView backTV;
    private Boolean isSubmitClick = true;
    private Boolean isButtonClick = true;
    private Boolean isBackClick = true;
    DatePickerDialog datePickerDialog;
    SharedPreferences pathSharedPreferences;
    CommonFunctions common = CommonFunctions.getInstance();
    Spinner spinner;
    String year = "", monthName = "", dateString = "", vehicleName = "";
    ArrayList<String> oilTypeList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer);

        initMethod();
        setAction();
    }

    private void initMethod() {
        vehicleName = getIntent().getStringExtra("vehicleName");

        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        dateButton = findViewById(R.id.dateButton);
        submitButton = findViewById(R.id.submitButton);

        backTV = findViewById(R.id.back);
        spinner = findViewById(R.id.spinner);

        year = new SimpleDateFormat("yyyy").format(new Date().getTime());
        monthName = new SimpleDateFormat("MMMM").format(new Date().getTime());
        dateString = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
        dateButton.setText(dateString);
    }

    protected void setAction() {
        getOilTypeData();
        setSpinner();

        backTV.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });

        dateButton.setOnClickListener(v -> {
            if (isButtonClick) {
                isButtonClick = false;
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonths = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(RegisterCustomer.this, (view, years, monthsOfYear, dayOfMonths) -> {

                    year = "" + years;
                    dateString = dayOfMonths + "-" + (monthsOfYear + 1) + "-" + years;

                    try {
                        monthName = new SimpleDateFormat("MMMM").format(new SimpleDateFormat("dd-MM-yyyy").parse(dateString));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        dateString = new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd-MM-yyyy").parse(dateString));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    dateButton.setText(dateString);
                    isButtonClick = true;
                }, mYear, mMonths, mDay);
                datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", ((dialog, which) -> {
                    datePickerDialog.dismiss();
                    isButtonClick = true;
                }));
                datePickerDialog.show();
            }
        });

        submitButton.setOnClickListener(v -> insertOilEntryData());
    }

    private void getOilTypeData() {
        oilTypeList.add("Select Oil Type");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("oilTypeList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        oilTypeList.add(values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setSpinner() {
        spinner.setOnItemSelectedListener(this);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, oilTypeList) {

            @Override
            public boolean isEnabled(int position) {
                return !(position == 0);
            }

            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }
        };
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position,
                               long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void insertOilEntryData() {
        if (isSubmitClick) {
            isSubmitClick = false;
            String oilTypeName = spinner.getSelectedItem().toString();
            if (oilTypeName.equalsIgnoreCase("Select Oil Type")) {
                showDialog("Please Select Valid Oil Type", false);
                isSubmitClick = true;
            } else {
                common.setProgressDialog("Please Wait...", "Uploading Data...", this, this);
                pathSharedPreferences = getSharedPreferences("loginData", MODE_PRIVATE);
                String loggedInName = pathSharedPreferences.getString("loggedInName", "");
                String type = getSharedPreferences("loginData", MODE_PRIVATE).getString("loginType", "");

                HashMap<String, Object> data = new HashMap<>();
                data.put("createdBy", loggedInName + "(" + type + ")");
                data.put("createdDate", DateFormat.format("yyyy-MM-dd", new Date().getTime()));
                data.put("oilFillDate", dateString);
                data.put("oilType", oilTypeName);
                common.getDatabasePath(RegisterCustomer.this).child("OilEntry").child(vehicleName).push().setValue(data).addOnCompleteListener(task -> {
                    showDialog("Oil Entry Successfully...", true);
                    common.closeDialog(RegisterCustomer.this);
                });
            }
        }
    }

    public void showDialog(String message, Boolean isFinish) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton("Ok", (dialog, id) -> {
            dialog.dismiss();
            if (isFinish) {
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    protected void onResume() {
        super.onResume();
        isSubmitClick = true;
        isButtonClick = true;
        isBackClick = true;
    }
}
