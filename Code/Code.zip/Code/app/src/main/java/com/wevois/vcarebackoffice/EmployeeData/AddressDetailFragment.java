package com.wevois.vcarebackoffice.EmployeeData;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.transition.AutoTransition;
import androidx.transition.TransitionManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import static android.R.layout.simple_spinner_item;
import static android.content.Context.MODE_PRIVATE;

import org.json.JSONArray;

public class AddressDetailFragment extends Fragment {
    String empId, from;
    Button nextBtn;
    CheckBox checkBox;
    private Context context;
    DatabaseReference rootRef;
    boolean isApproved = false;
    TextView btnIcon, btnIcon2;
    LinearLayout expand, expand2;
    CardView cardView, cardView2;
    SharedPreferences sharedPreferences, preferences,pathSharedPreferences;
    LinearLayout expandable, expandable2;
    CommonFunctions cmn = CommonFunctions.getInstance();
    Spinner cStateSpinner, pStateSpinner;
    EditText cHouse, cSubLocality, cLocality, cPinCode, pHouse, pSubLocality, pLocality, pPinCode, pCityEt, cCityEt;
    ArrayList<String> stateList = new ArrayList<>(), stateIdList = new ArrayList<>();
    HashMap<String, Object> currentAddressMap = new HashMap<>();
    HashMap<String, Object> permanentAddressMap = new HashMap<>();

    public AddressDetailFragment() {

    }

    public static AddressDetailFragment newInstance() {
        return new AddressDetailFragment();
    }

    @Override
    public void onAttach(@NonNull Context ctx) {
        super.onAttach(ctx);
        context = getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_address_detail, container, false);
        GetBundle();
        inIt(view);
        checkBox.setOnClickListener(view1 -> setCheckBox());
        nextBtn.setOnClickListener(view13 -> {
            if (isApproved) {
                if (preferences.getBoolean("isAccountant", false)) {
                    setNextBtn();
                } else {
                    cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your superviser.", false, context);
                }
            } else {
                setNextBtn();
            }
        });
        return view;
    }

    private void GetBundle() {
        if (getArguments() != null) {
            empId = getArguments().getString("empId", " ");
            from = getArguments().getString("from", " ");
        } else {
            cmn.showAlertDialog("Please Retry", "", false, context);
        }
    }

    private void inIt(View view) {
        pathSharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
        preferences = context.getSharedPreferences("loginData", MODE_PRIVATE);
        expand = view.findViewById(R.id.expand);
        expandable = view.findViewById(R.id.expandable);
        cardView = view.findViewById(R.id.card);
        expand2 = view.findViewById(R.id.expand_2);
        expandable2 = view.findViewById(R.id.expandable_2);
        cardView2 = view.findViewById(R.id.card_2);
        nextBtn = view.findViewById(R.id.next_address);
        btnIcon = view.findViewById(R.id.btn_icon);
        btnIcon2 = view.findViewById(R.id.btn_icon2);
        cHouse = view.findViewById(R.id.current_house_et);
        cSubLocality = view.findViewById(R.id.current_sub_locality_et);
        cLocality = view.findViewById(R.id.current_locality_et);
        cPinCode = view.findViewById(R.id.current_pin_code_et);
        pHouse = view.findViewById(R.id.permanemnt_house_et);
        pSubLocality = view.findViewById(R.id.permanent_sub_locality_et);
        pLocality = view.findViewById(R.id.permanent_locality_et);
        pPinCode = view.findViewById(R.id.permanent_pin_code_et);
        cCityEt = view.findViewById(R.id.current_city_spinner);
        cStateSpinner = view.findViewById(R.id.current_state_spinner);
        pCityEt = view.findViewById(R.id.permanent_city_et);
        pStateSpinner = view.findViewById(R.id.permanent_state_spinner);
        checkBox = view.findViewById(R.id.same_address);
        rootRef = cmn.getDatabasePath(context);
        sharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
        rootRef.child("Employees/" + empId + "/OtherDetails/isApproved").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("true")) {
                        isApproved = true;
                    } else {
                        isApproved = false;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        SetExpandableCardView();
        getSpinner();
    }

    private void SetExpandableCardView() {
        TransitionManager.beginDelayedTransition(cardView, new AutoTransition());
        expand.setOnClickListener(view1 -> {
            if (expandable.getVisibility() == view1.GONE) {
                expandable.setVisibility(view1.VISIBLE);
                expandable2.setVisibility(view1.GONE);
                btnIcon.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            } else {
                expandable.setVisibility(view1.GONE);
                btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            }
        });
        expand2.setOnClickListener(view1 -> {
            if (expandable2.getVisibility() == view1.GONE) {
                expandable2.setVisibility(view1.VISIBLE);
                expandable.setVisibility(view1.GONE);
                btnIcon2.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            } else {
                expandable2.setVisibility(view1.GONE);
                btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
            }
        });
    }

    private void getSpinner() {
        cmn.setProgressDialog("Please Wait...", "Preparing Data...", context, (Activity) context);

        stateList.add("States");
        stateIdList.add("States");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("stateList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        stateList.add(values);
                        stateIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ArrayAdapter<String> stateSpinnerAdapter = new ArrayAdapter<>(context, simple_spinner_item, stateList);
        stateSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cStateSpinner.setAdapter(stateSpinnerAdapter);
        pStateSpinner.setAdapter(stateSpinnerAdapter);
        cStateSpinner.setSelection(stateIdList.indexOf("22"));
        pStateSpinner.setSelection(stateIdList.indexOf("22"));
        if (from.equals("edit") || sharedPreferences.getBoolean("Address", false)) {
            setDefaults();
        } else {
            cmn.closeDialog((Activity) context);
        }
    }

    private void setDefaults() {
        rootRef.child("Employees").child(empId).child("AddressDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("CurrentAddress").hasChild("houseName")) {
                    currentAddressMap.put("houseName", dataSnapshot.child("CurrentAddress").child("houseName").getValue());
                    cHouse.setText(String.valueOf(currentAddressMap.get("houseName")));
                }
                if (dataSnapshot.child("CurrentAddress").hasChild("subLocality")) {
                    currentAddressMap.put("subLocality", dataSnapshot.child("CurrentAddress").child("subLocality").getValue());
                    cSubLocality.setText(String.valueOf(currentAddressMap.get("subLocality")));
                }
                if (dataSnapshot.child("CurrentAddress").hasChild("locality")) {
                    currentAddressMap.put("locality", dataSnapshot.child("CurrentAddress").child("locality").getValue());
                    cLocality.setText(String.valueOf(currentAddressMap.get("locality")));
                }
                if (dataSnapshot.child("CurrentAddress").hasChild("pinCode")) {
                    currentAddressMap.put("pinCode", dataSnapshot.child("CurrentAddress").child("pinCode").getValue());
                    cPinCode.setText(String.valueOf(currentAddressMap.get("pinCode")));
                }
                if (dataSnapshot.child("CurrentAddress").hasChild("city")) {
                    currentAddressMap.put("city", dataSnapshot.child("CurrentAddress").child("city").getValue());
                    cCityEt.setText(String.valueOf(currentAddressMap.get("city")));
                }
                if (dataSnapshot.child("CurrentAddress").hasChild("state")) {
                    currentAddressMap.put("state", dataSnapshot.child("CurrentAddress").child("state").getValue());
                    cStateSpinner.setSelection(stateList.indexOf(String.valueOf(currentAddressMap.get("state"))));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("houseName")) {
                    permanentAddressMap.put("houseName", dataSnapshot.child("PermanentAddress").child("houseName").getValue());
                    pHouse.setText(String.valueOf(permanentAddressMap.get("houseName")));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("subLocality")) {
                    permanentAddressMap.put("subLocality", dataSnapshot.child("PermanentAddress").child("subLocality").getValue());
                    pSubLocality.setText((String) permanentAddressMap.get("subLocality"));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("locality")) {
                    permanentAddressMap.put("locality", dataSnapshot.child("PermanentAddress").child("locality").getValue());
                    pLocality.setText((String) permanentAddressMap.get("locality"));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("pinCode")) {
                    permanentAddressMap.put("pinCode", dataSnapshot.child("PermanentAddress").child("pinCode").getValue());
                    pPinCode.setText((String) permanentAddressMap.get("pinCode"));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("city")) {
                    permanentAddressMap.put("city", dataSnapshot.child("PermanentAddress").child("city").getValue());

                    pCityEt.setText((String) permanentAddressMap.get("city"));
                }
                if (dataSnapshot.child("PermanentAddress").hasChild("state")) {
                    permanentAddressMap.put("state", dataSnapshot.child("PermanentAddress").child("state").getValue());
                    pStateSpinner.setSelection(stateList.indexOf((String) permanentAddressMap.get("state")));
                }
                if (currentAddressMap.get("houseName") != null && permanentAddressMap.get("houseName") != null) {
                    if (String.valueOf(currentAddressMap.get("houseName")).equals(String.valueOf(permanentAddressMap.get("houseName")))) {
                        checkBox.setChecked(true);
                    }
                }
                cmn.closeDialog((Activity) context);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setCheckBox() {
        if (cHouse.getText().length() != 0) {
            if (cSubLocality.getText().length() != 0) {
                if (cLocality.getText().length() != 0) {
                    if (cPinCode.getText().length() != 0) {
                        if (cCityEt.getText().length() != 0) {
                            if (cStateSpinner.getSelectedItemPosition() != 0) {
                                if (checkBox.isChecked()) {
                                    pHouse.setText(cHouse.getText().toString());
                                    pSubLocality.setText(cSubLocality.getText().toString());
                                    pLocality.setText(cLocality.getText().toString());
                                    pPinCode.setText(cPinCode.getText().toString());
                                    pCityEt.setText(String.valueOf(cCityEt.getText()));
                                    pStateSpinner.setSelection(cStateSpinner.getSelectedItemPosition());
                                } else {
                                    pHouse.getText().clear();
                                    pSubLocality.getText().clear();
                                    pLocality.getText().clear();
                                    pPinCode.getText().clear();
                                    pCityEt.getText().clear();
                                    pStateSpinner.setSelection(0);
                                }
                            } else {
                                checkBox.setChecked(false);
                                cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
                            }
                        } else {
                            checkBox.setChecked(false);
                            cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
                        }
                    } else {
                        checkBox.setChecked(false);
                        cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
                    }
                } else {
                    checkBox.setChecked(false);
                    cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
                }
            } else {
                checkBox.setChecked(false);
                cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
            }
        } else {
            checkBox.setChecked(false);
            cmn.showAlertDialog("Alert", "Incomplete current address", false, context);
        }
    }

    private void setNextBtn() {
        if (cHouse.getText().toString().trim().length() != 0) {
            currentAddressMap.put("houseName", cHouse.getText().toString().trim());
            if (cSubLocality.getText().toString().trim().length() != 0) {
                currentAddressMap.put("subLocality", cSubLocality.getText().toString().trim());
                if (cLocality.getText().toString().trim().length() != 0) {
                    currentAddressMap.put("locality", cLocality.getText().toString().trim());
                    if (cPinCode.getText().toString().trim().length() == 6) {
                        currentAddressMap.put("pinCode", cPinCode.getText().toString().trim());
                        if (cStateSpinner.getSelectedItemPosition() != 0) {
                            currentAddressMap.put("state", cStateSpinner.getSelectedItem().toString().trim());
                            if (cCityEt.getText().toString().trim().length() != 0) {
                                currentAddressMap.put("city", cCityEt.getText().toString().trim());
                                if (pHouse.getText().toString().trim().length() != 0) {
                                    permanentAddressMap.put("houseName", pHouse.getText().toString().trim());
                                    if (pSubLocality.getText().toString().trim().length() != 0) {
                                        permanentAddressMap.put("subLocality", pSubLocality.getText().toString().trim());
                                        if (pLocality.getText().toString().trim().length() != 0) {
                                            permanentAddressMap.put("locality", pLocality.getText().toString().trim());
                                            if (pPinCode.getText().toString().trim().length() == 6) {
                                                permanentAddressMap.put("pinCode", pPinCode.getText().toString().trim());
                                                if (pStateSpinner.getSelectedItemPosition() != 0) {
                                                    permanentAddressMap.put("state", pStateSpinner.getSelectedItem().toString());
                                                    if (pCityEt.getText().toString().trim().length() != 0) {
                                                        permanentAddressMap.put("city", pCityEt.getText().toString().trim());
                                                        cmn.setProgressDialog("Please Wait", "Uploading data", context, (Activity) context);
                                                        UploadEmpInfo();
                                                    } else {
                                                        cmn.showAlertDialog("Alert", "Permanent Address: Enter city", false, context);
                                                    }
                                                } else {
                                                    cmn.showAlertDialog("Alert", "Permanent Address: Enter state", false, context);
                                                }
                                            } else {
                                                cmn.showAlertDialog("Alert", "Permanent Address: Enter pinCode", false, context);
                                            }
                                        } else {
                                            cmn.showAlertDialog("Alert", "Permanent Address: Enter locality", false, context);
                                        }
                                    } else {
                                        cmn.showAlertDialog("Alert", "Permanent Address: Enter subLocality", false, context);
                                    }
                                } else {
                                    cmn.showAlertDialog("Alert", "Permanent Address: Enter House Name", false, context);
                                }
                            } else {
                                cmn.showAlertDialog("Alert", "Current Address: Enter city", false, context);
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Current Address: Enter state", false, context);
                        }
                    } else {
                        cmn.showAlertDialog("Alert", "Current Address: Enter pinCode", false, context);
                    }
                } else {
                    cmn.showAlertDialog("Alert", "Current Address: Enter locality", false, context);
                }
            } else {
                cmn.showAlertDialog("Alert", "Current Address: Enter subLocality", false, context);
            }
        } else {
            cmn.showAlertDialog("Alert", "Current Address: Enter HouseName", false, context);
        }
    }

    private void UploadEmpInfo() {
        HashMap<String, Object> addressStructureMap = new HashMap<>();
        addressStructureMap.put("CurrentAddress", currentAddressMap);
        addressStructureMap.put("PermanentAddress", permanentAddressMap);
        rootRef.child("Employees").child(empId).child("AddressDetails").updateChildren(addressStructureMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    if (from.equals("add")) {
                        sharedPreferences.edit().putBoolean("Address", true).apply();
                        ((Registration) Objects.requireNonNull(context)).iconColor();
                        cmn.closeDialog((Activity) context);
                    } else {
                        sharedPreferences.edit().putBoolean("Address", true).apply();
                        ((Registration) context).RemoveBadges();
                        cmn.closeDialog((Activity) context);
                        cmn.showAlertDialog("Alert", "Changes Saved Successfully", false, context);
                    }
                }
            }
        });

    }
}