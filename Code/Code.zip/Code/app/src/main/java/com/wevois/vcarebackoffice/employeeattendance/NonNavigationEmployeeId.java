package com.wevois.vcarebackoffice.employeeattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class NonNavigationEmployeeId extends AppCompatActivity {
    EditText empId;
    DatabaseReference databaseReference;
    SharedPreferences preference;
    String ward = "";
    boolean isMoved=true;
    CommonFunctions common = CommonFunctions.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_navigation_employee_id);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        TextView title = findViewById(R.id.toolbar_title);
        backButton.setOnClickListener(view -> onBackPressed());
        preference = getSharedPreferences("path", MODE_PRIVATE);
        databaseReference = common.getDatabasePath(this);
        ward = getIntent().getStringExtra("ward");
        title.setText(ward);
        empId = findViewById(R.id.nonNavigationEmpId);
        findViewById(R.id.btnNonNavigationEmpId).setOnClickListener(view -> {
            if (empId.getText().toString().trim().length()!=0){
                if (isMoved){
                    isMoved=false;
                    common.setProgressDialog("","Checking assignment...",this,this);
                    checkEmployeeDetails(empId.getText().toString().trim());
                }
            }else {
                common.showAlertDialog("Error!", "Please enter empId.", false, NonNavigationEmployeeId.this);
            }
        });
    }

    private void checkEmployeeDetails(String empId) {
        databaseReference.child("Employees/"+empId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("GeneralDetails/status")){
                        if (dataSnapshot.child("GeneralDetails/status").getValue().toString().equalsIgnoreCase("1")) {
                            if (dataSnapshot.hasChild("GeneralDetails/designationId")) {
                                if (dataSnapshot.child("GeneralDetails/designationId").getValue().toString().equalsIgnoreCase("5" )||dataSnapshot.child("GeneralDetails/designationId").getValue().toString().equalsIgnoreCase("6" )) {
                                    checkAssignment(empId,dataSnapshot.child("GeneralDetails/name").getValue().toString(),dataSnapshot.child("GeneralDetails/designationId").getValue().toString());
                                } else {
                                    isMoved = true;
                                    common.showAlertDialog("Wrong Assignment!", "Id गलत है | ", false, NonNavigationEmployeeId.this);
                                }
                            }else {
                                isMoved = true;
                                common.showAlertDialog("Wrong Assignment!", "Id गलत है | ", false, NonNavigationEmployeeId.this);
                            }
                        }else {
                            isMoved = true;
                            common.showAlertDialog("Wrong Assignment!", "Id गलत है | ", false, NonNavigationEmployeeId.this);
                        }
                    }else {
                        isMoved = true;
                        common.showAlertDialog("Wrong Assignment!", "Id गलत है | ", false, NonNavigationEmployeeId.this);
                    }
                }else {
                    isMoved = true;
                    common.showAlertDialog("Wrong Assignment!", "Id गलत है | ", false, NonNavigationEmployeeId.this);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void checkAssignment(String empId, String name, String s) {
        final String year = new SimpleDateFormat("yyyy").format(new Date());
        final String month = new SimpleDateFormat("MMMM", Locale.US).format(new Date());
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        final String date = dateFormat1.format(new Date());
        databaseReference.child("DailyWorkDetail/" + year + "/" + month + "/" + date + "/" + empId).orderByChild("task").equalTo(ward).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    long totalChildren = dataSnapshot.getChildrenCount();
                    long counter = 1;
                    for (DataSnapshot dataSnapshot3 : dataSnapshot.getChildren()) {
                        if (counter >= totalChildren) {
                            if (dataSnapshot3.hasChild("status")) {
                                String status = Objects.requireNonNull(dataSnapshot3.child("status").getValue()).toString();
                                if (status.equals("1")) {
                                    startDuty(ward,name,empId,s);
                                } else if (status.equals("2")) {
                                    Intent i = new Intent(NonNavigationEmployeeId.this,NonNavigationDutyOffPage.class);
                                    i.putExtra("ward",ward);
                                    i.putExtra("empName", name);
                                    i.putExtra("empId", empId);
                                    i.putExtra("vehicle", dataSnapshot3.child("vehicle").getValue().toString());
                                    i.putExtra("designationId", s);
                                    common.closeDialog(NonNavigationEmployeeId.this);
                                    startActivity(i);
                                }
                            }
                        }
                        counter++;
                    }
                } else {
                    startDuty(ward,name,empId,s);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void startDuty(String ward, String name, String empId, String s) {
        databaseReference.child("WorkAssignment/" + empId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.hasChild("current-assignment")) {
                        if (dataSnapshot.child("current-assignment").getValue().toString().equalsIgnoreCase("")) {
                            Intent i = new Intent(NonNavigationEmployeeId.this,NonNavigationEmpAssignment.class);
                            i.putExtra("ward",ward);
                            i.putExtra("empName", name);
                            i.putExtra("empId", empId);
                            i.putExtra("designationId", s);
                            common.closeDialog(NonNavigationEmployeeId.this);
                            startActivity(i);
                        } else {
                            isMoved = true;
                            common.showAlertDialog("Alert!", "Employee को already "+dataSnapshot.child("current-assignment").getValue().toString()+" assign है |", false, NonNavigationEmployeeId.this);
                        }
                    } else {
                        Intent i = new Intent(NonNavigationEmployeeId.this,NonNavigationEmpAssignment.class);
                        i.putExtra("ward",ward);
                        i.putExtra("empName", name);
                        i.putExtra("empId", empId);
                        i.putExtra("designationId", s);
                        common.closeDialog(NonNavigationEmployeeId.this);
                        startActivity(i);
                    }
                } else {
                    Intent i = new Intent(NonNavigationEmployeeId.this,NonNavigationEmpAssignment.class);
                    i.putExtra("ward",ward);
                    i.putExtra("empName", name);
                    i.putExtra("empId", empId);
                    i.putExtra("designationId", s);
                    common.closeDialog(NonNavigationEmployeeId.this);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMoved = true;
    }
}