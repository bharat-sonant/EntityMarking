package com.wevois.vcarebackoffice.Complaints;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.wevois.vcarebackoffice.R;

public class ShowWardComplaintsList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_ward_complaints_list);
    }
}