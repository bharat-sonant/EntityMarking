package com.wevois.vcarebackoffice.BackDateDutyOff;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class BackDateDutyOff extends AppCompatActivity {
    ListView listView;
    BackDateDutyOffAdapter backDateDutyOffAdapter;
    DataSnapshot employeeSnapshot = null;
    DatabaseReference databaseReferencePath;
    String todayDate = "", yearDate = "", monthDate = "", city = "";
    SharedPreferences preferences;
    ArrayList<BackDateDutyOffModel> backDateDutyOffModels = new ArrayList<>();
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<String> nonNavigationTask = new ArrayList<>();
    int positions = 0;

    @SuppressLint("SimpleDateFormat")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back_date_duty_off);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        preferences = getSharedPreferences("path", MODE_PRIVATE);
        databaseReferencePath = common.getDatabasePath(this);
        city = preferences.getString("city", "");
        listView = findViewById(R.id.backDateDutyOffLv);
        Date date = new Date(new Date().getTime() - (1000 * 60 * 60 * 24));
        todayDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
        yearDate = new SimpleDateFormat("yyyy").format(date);
        monthDate = new SimpleDateFormat("MMMM", Locale.US).format(date);
        backDateDutyOffAdapter = new BackDateDutyOffAdapter();
        listView.setAdapter(backDateDutyOffAdapter);
        common.setProgressDialog("Please Wait...", "Loading...", this, this);
        getNonNavigationTask();
        getEmployeeData();
    }

    private void getEmployeeData() {
        databaseReferencePath.child("Employees").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    employeeSnapshot = dataSnapshot;
                    new getData().execute();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getNonNavigationTask() {
        try {
            JSONArray jsonArray = new JSONArray(preferences.getString("nonNavigationTaskList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        nonNavigationTask.add(values);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class getData extends AsyncTask<Void, String, String> {
        @Override
        protected String doInBackground(Void... voids) {
            BackDateDutyOff.this.runOnUiThread(() -> {
                backDateDutyOffModels.clear();
                backDateDutyOffAdapter.notifyDataSetChanged();
                databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                    if (snapshot1.getKey().contains("task")) {
                                        if (snapshot1.hasChild("status")) {
                                            if (snapshot1.child("status").getValue().toString().equals("2")) {
                                                String inTime = "", id = "", name = "", designationId = "", task = "", vehicle = "", device = "NotApplicable";
                                                if (snapshot1.hasChild("in-out")) {
                                                    for (DataSnapshot snapshot2 : snapshot1.child("in-out").getChildren()) {
                                                        if (snapshot2.getValue().toString().equalsIgnoreCase("In")) {
                                                            inTime = snapshot2.getValue().toString();
                                                        }
                                                    }
                                                }
                                                if (employeeSnapshot.getValue() != null) {
                                                    if (employeeSnapshot.hasChild(snapshot.getKey() + "/GeneralDetails/name")) {
                                                        name = employeeSnapshot.child(snapshot.getKey() + "/GeneralDetails/name").getValue().toString();
                                                    }
                                                    if (employeeSnapshot.hasChild(snapshot.getKey() + "/GeneralDetails/designationId")) {
                                                        designationId = employeeSnapshot.child(snapshot.getKey() + "/GeneralDetails/designationId").getValue().toString();
                                                    }
                                                }
                                                if (snapshot1.hasChild("task")) {
                                                    task = snapshot1.child("task").getValue().toString();
                                                }
                                                if (snapshot1.hasChild("vehicle")) {
                                                    vehicle = snapshot1.child("vehicle").getValue().toString();
                                                }
                                                if (snapshot1.hasChild("device")) {
                                                    device = snapshot1.child("device").getValue().toString();
                                                }
                                                name = name + "(" + task + ")";
                                                backDateDutyOffModels.add(new BackDateDutyOffModel(name, snapshot.getKey(), inTime, designationId, task, vehicle, snapshot1.getKey(), device));
                                                backDateDutyOffAdapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        common.closeDialog(BackDateDutyOff.this);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            });
            return null;
        }
    }

    public class BackDateDutyOffAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return backDateDutyOffModels.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView empName;
            Button dutyOffBtn;
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.back_date_duty_off_data, null, true);
            empName = convertView.findViewById(R.id.empNameWithWard);
            dutyOffBtn = convertView.findViewById(R.id.dutyOffButton);
            BackDateDutyOffModel sList = backDateDutyOffModels.get(position);
            empName.setText(sList.empName);
            dutyOffBtn.setOnClickListener(view -> {
                TextView selectEndTime;
                LayoutInflater inflaters = getLayoutInflater();
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(BackDateDutyOff.this);
                View dialogLayout = inflaters.inflate(R.layout.custom_alertbox_endtime, null);
                alertDialog.setView(dialogLayout);
                alertDialog.setCancelable(false);
                final AlertDialog dialog = alertDialog.create();
                selectEndTime = dialogLayout.findViewById(R.id.selectEndTime);
                selectEndTime.setOnClickListener(v -> {
                    final Calendar myCalender = Calendar.getInstance();
                    int hour = myCalender.get(Calendar.HOUR_OF_DAY);
                    int minute = myCalender.get(Calendar.MINUTE);
                    TimePickerDialog timePickerDialog = new TimePickerDialog(BackDateDutyOff.this, android.R.style.Theme_Holo_Light_Dialog_NoActionBar, (timePicker, selectedHour, selectedMinute) -> selectEndTime.setText(getTime(selectedHour) + ":" + getTime(selectedMinute) + ":00"), hour, minute, true);
                    timePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                    timePickerDialog.show();
                });
                Button btn = dialogLayout.findViewById(R.id.duty_off_btn);
                btn.setOnClickListener(v -> {
                    if (selectEndTime.getText().toString().equalsIgnoreCase("Select End Time")) {
                        common.showAlertDialog("Info!", "Please select Time", true, BackDateDutyOff.this);
                    } else {
                        positions = position;
                        common.setProgressDialog("Please Wait", "Loading...", BackDateDutyOff.this, BackDateDutyOff.this);
                        long difference = 0;
                        final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                        Date date1;
                        try {
                            date1 = dateFormat.parse(selectEndTime.getText().toString());
                            Date date2 = dateFormat.parse(sList.getInTime());
                            difference += date1.getTime() - date2.getTime();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        final String finalDiff = String.valueOf(difference);
                        dutyOffMethod(sList.getEmpId(), sList.getCurrentTask(), sList.getTask(), selectEndTime.getText().toString(), finalDiff, sList.getVehicleNo(), sList.getDesignationId(), sList.getDeviceId());
                    }
                    dialog.cancel();
                });
                Button closeBtn = dialogLayout.findViewById(R.id.cancel_btn);
                closeBtn.setOnClickListener(v -> {
                    dialog.cancel();
                });
                dialog.show();
            });

            return convertView;
        }
    }

    private void dutyOffMethod(String userId, String currentTaskNo, String ward, String outTime, String timeInMillis, String vehicle, String designId, String deviceId) {
        HashMap<String, Object> data = new HashMap<>();
        data.put("status", "1");
        data.put("task-wages", "-1");
        data.put("final-approved-time", "0");
        data.put("final-approved-time-in-minute", "0");
        data.put("total-halt-time", "0");
        data.put("total-halt-time-in-minute", "0");
        data.put("approved-halt-time", "0");
        data.put("final-halt-after-remove-time-in-minute", "0");
        data.put("total-remove-halt-time-in-minute", "0");
        data.put("total-time-spent", timeInMillis);
        data.put("total-time-spent-in-minute", "" + Long.valueOf(timeInMillis) / 60000);
        databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/" + "card-swap-entries/" + outTime).setValue("Out");
        databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/" + currentTaskNo + "/in-out/" + outTime).setValue("Out");
        databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/" + currentTaskNo).updateChildren(data).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String path = ward;
                if (ward.contains("BinLifting")) {
                    path = "BinLifting/" + vehicle;
                }
                if (!nonNavigationTask.contains(ward)) {
                    HashMap<String, Object> hashMap = new HashMap<>();
                    hashMap.put("isOnDuty", "no");
                    hashMap.put("activityStatus", "completed");
                    databaseReferencePath.child("RealTimeDetails/WardDetails/" + path).updateChildren(hashMap);
                } else {
                    if (ward.contains("BinLifting")) {
                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("isOnDuty", "no");
                        hashMap.put("activityStatus", "completed");
                        databaseReferencePath.child("RealTimeDetails/WardDetails/" + path).updateChildren(hashMap);
                    }
                }
                databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "/" + userId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null) {
                            databaseReferencePath.child("WorkAssignment/" + userId).child("device").setValue("");
                            databaseReferencePath.child("WorkAssignment/" + userId).child("vehicle").setValue("");
                            databaseReferencePath.child("WorkAssignment/" + userId).child("current-assignment").setValue("");
                            if (!deviceId.equalsIgnoreCase("NotApplicable")) {
                                databaseReferencePath.child("Devices/" + city).orderByChild("name").equalTo(deviceId).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (dataSnapshot.getValue() != null) {
                                            for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                                String key = dataSnapshot1.getKey();
                                                databaseReferencePath.child("Devices/" + city).child(key + "/status").setValue("1");
                                            }
                                        }
                                        freeVehicle(userId, ward, vehicle, designId, currentTaskNo);
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            } else {
                                freeVehicle(userId, ward, vehicle, designId, currentTaskNo);
                            }
                        } else {
                            freeVehicle(userId, ward, vehicle, designId, currentTaskNo);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }

    private void freeVehicle(String userId, String ward, String vehicleNo, String designId, String currentTask) {
        if (!vehicleNo.equals("NotApplicable")) {
            databaseReferencePath.child("Vehicles/" + vehicleNo).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.hasChild("assigned-task")) {
                        if (ward.equalsIgnoreCase(dataSnapshot.child("assigned-task").getValue().toString())) {
                            if (designId.equalsIgnoreCase("5")) {
                                if (dataSnapshot.hasChild("assigned-helper")) {
                                    if (dataSnapshot.child("assigned-helper").getValue().toString().equalsIgnoreCase("")) {
                                        databaseReferencePath.child("Vehicles").child(vehicleNo).child("status").setValue("1");
                                        databaseReferencePath.child("Vehicles").child(vehicleNo).child("assigned-task").setValue("");
                                        if (!ward.contains("BinLifting")) {
                                            databaseReferencePath.child("Tasks/" + ward).setValue("Available");
                                        }
                                    }
                                    databaseReferencePath.child("Vehicles").child(vehicleNo).child("assigned-driver").setValue("");
                                }
                            } else {
                                if (dataSnapshot.hasChild("assigned-driver")) {
                                    if (dataSnapshot.child("assigned-driver").getValue().toString().equalsIgnoreCase("")) {
                                        databaseReferencePath.child("Vehicles").child(vehicleNo).child("status").setValue("1");
                                        databaseReferencePath.child("Vehicles").child(vehicleNo).child("assigned-task").setValue("");
                                        if (!ward.contains("BinLifting")) {
                                            databaseReferencePath.child("Tasks/" + ward).setValue("Available");
                                        }
                                    }
                                    databaseReferencePath.child("Vehicles").child(vehicleNo).child("assigned-helper").setValue("");
                                }
                            }
                        }
                    }
                    setTodayWages(ward, designId, userId, currentTask);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } else {
            setTodayWages(ward, designId, userId, currentTask);
        }
    }

    String getTime(int time) {
        String changeTime = time > 9 ? "" + time : "0" + time;
        return changeTime;
    }

    private void setTodayWages(String ward, String designId, String userId, String currentTask) {
        databaseReferencePath.child("RealTimeDetails/peopleOnWork").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int activeEmp = 0;
                if (dataSnapshot.getValue() != null) {
                    activeEmp = Integer.parseInt(dataSnapshot.getValue().toString());
                    if (activeEmp != 0) {
                        databaseReferencePath.child("RealTimeDetails/peopleOnWork").setValue("" + (activeEmp - 1));
                    }
                }
                databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/today-wages").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null) {
                            databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/today-wages").getRef().setValue(("-1"));
                        } else {
                            databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate).child(userId + "/today-wages").getRef().setValue((dataSnapshot.getValue().toString()));
                        }
                        planFree(ward, designId, userId, currentTask);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void planFree(String task, String designationId, String userId, String currentTask) {
        if (task.contains("BinLifting")) {
            if (designationId.equalsIgnoreCase("5")) {
                databaseReferencePath.child("DailyWorkDetail/" + yearDate + "/" + monthDate + "/" + todayDate + "/" + userId + "/" + currentTask + "/binLiftingPlanId").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            databaseReferencePath.child("DustbinData/DustbinPickingPlans/" + todayDate + "/" + dataSnapshot.getValue().toString()).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.getValue() != null) {
                                        for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                            if (snapshot1.getKey().equalsIgnoreCase("bins")) {
                                                String[] bins = snapshot1.getValue().toString().split(",");
                                                for (int i = 0; i < bins.length; i++) {
                                                    databaseReferencePath.child("DustbinData/DustbinDetails/" + bins[i].trim() + "/isAssigned").setValue("false");
                                                }
                                            }
                                            databaseReferencePath.child("DustbinData/DustbinPickingPlanHistory/" + yearDate + "/" + monthDate + "/" + todayDate + "/" + dataSnapshot.getValue().toString() + "/" + snapshot1.getKey()).setValue(snapshot1.getValue().toString());
                                        }
                                        databaseReferencePath.child("DustbinData/DustbinPickingPlanHistory/" + yearDate + "/" + monthDate + "/" + todayDate + "/" + dataSnapshot.getValue().toString() + "/doneDate").setValue(todayDate);
                                        databaseReferencePath.child("DustbinData/DustbinPickingPlans/" + todayDate + "/" + dataSnapshot.getValue().toString()).removeValue();
                                        backDateDutyOffModels.remove(positions);
                                        backDateDutyOffAdapter.notifyDataSetChanged();
                                        common.closeDialog(BackDateDutyOff.this);
                                    } else {
                                        backDateDutyOffModels.remove(positions);
                                        backDateDutyOffAdapter.notifyDataSetChanged();
                                        common.closeDialog(BackDateDutyOff.this);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        } else {
                            backDateDutyOffModels.remove(positions);
                            backDateDutyOffAdapter.notifyDataSetChanged();
                            common.closeDialog(BackDateDutyOff.this);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            } else {
                backDateDutyOffModels.remove(positions);
                backDateDutyOffAdapter.notifyDataSetChanged();
                common.closeDialog(BackDateDutyOff.this);
            }
        } else {
            backDateDutyOffModels.remove(positions);
            backDateDutyOffAdapter.notifyDataSetChanged();
            common.closeDialog(BackDateDutyOff.this);
        }
    }
}