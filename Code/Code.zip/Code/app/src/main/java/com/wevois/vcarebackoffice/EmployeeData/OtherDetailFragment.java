package com.wevois.vcarebackoffice.EmployeeData;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

import static android.R.layout.simple_spinner_item;
import static android.content.Context.MODE_PRIVATE;

import org.json.JSONArray;

public class OtherDetailFragment extends Fragment {
    Bundle basic;
    Button finishBtn;
    EditText passportNumber;
    TextView validFrom, validTill, radioGrpTv;
    RadioGroup radioGroup;
    RadioButton btnApproved, btnNotApproved;
    public Context context;
    int mYear, mMonth, mDay;
    DatabaseReference rootRef;
    boolean isApproved = false;
    SharedPreferences preferences;
    CommonFunctions cmn = CommonFunctions.getInstance();
    String empId, from, date_time = "";
    Spinner internationalSpinner, locomotiveSpinner, visualSpinner, handicapSpinner, maritalSpinner, nationalitySpinner, qualificationSpinner, originSpinner;
    ArrayList<String> originCountryList = new ArrayList<>(), originCountryIdList = new ArrayList<>(), maritalStatusList = new ArrayList<>(), maritalIdList = new ArrayList<>(),
            nationalityList = new ArrayList<>(), nationalityIdList = new ArrayList<>(), qualificationList = new ArrayList<>(), qualificationIdList = new ArrayList<>();
    boolean radioStatus = false;
    HashMap<String, Object> otherDetailStructureMap = new HashMap<>();
    SharedPreferences pathSharedPreferences;
    String TAG = "MyTesting";

    public OtherDetailFragment() {
    }

    public static OtherDetailFragment newInstance() {
        return new OtherDetailFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_other_detail, container, false);
        getBundle();
        inIt(view);
        setRadioGrp();
        setAction();
        finishBtn.setOnClickListener(view1 -> {
            if (isApproved) {
                if (preferences.getBoolean("isAccountant", false)) {
                    setFinishBtn();
                } else {
                    cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your supervisor.", false, context);
                }
            } else {
                setFinishBtn();
            }
        });
        return view;
    }

    private void setRadioGrp() {
        if (preferences.getBoolean("isAccountant", false)) {
            radioGroup.setOnCheckedChangeListener((radioGroup, i) -> {
                radioStatus = R.id.radio_btn_approved == i;
            });
        } else {
            radioGrpTv.setVisibility(View.GONE);
            radioGroup.setVisibility(View.GONE);
        }
    }

    private void setAction() {
        validFrom.setOnClickListener(view -> datePicker(validFrom));

        validTill.setOnClickListener(view -> datePicker(validTill));
    }

    @Override
    public void onAttach(@NonNull Context ctx) {
        super.onAttach(ctx);
        context = getActivity();
    }

    private void getBundle() {
        basic = getArguments();
        if (basic != null) {
            empId = basic.getString("empId", " ");
            from = basic.getString("from", " ");
        } else {
            cmn.showAlertDialog("Please Retry", "", false, context);
        }
    }

    private void datePicker(TextView textView) {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                (view, year, monthOfYear, dayOfMonth) -> {
                    if (monthOfYear + 1 <= 9) {
                        if (dayOfMonth <= 9) {
                            date_time = "0" + dayOfMonth + "-0" + (monthOfYear + 1) + "-" + year;
                        } else {
                            date_time = dayOfMonth + "-0" + (monthOfYear + 1) + "-" + year;
                        }
                    } else {
                        if (dayOfMonth <= 9) {
                            date_time = "0" + dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        } else {
                            date_time = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        }
                    }
                    textView.setText(date_time);
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void inIt(View view) {
        pathSharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
        internationalSpinner = view.findViewById(R.id.international_spinner);
        locomotiveSpinner = view.findViewById(R.id.locomotive_spinner);
        visualSpinner = view.findViewById(R.id.visual_spinner);
        handicapSpinner = view.findViewById(R.id.handicap_spinner);
        maritalSpinner = view.findViewById(R.id.marital_spinner);
        nationalitySpinner = view.findViewById(R.id.nationality_spinner);
        qualificationSpinner = view.findViewById(R.id.qualification_spinner);
        originSpinner = view.findViewById(R.id.origin_spinner);
        finishBtn = view.findViewById(R.id.next_other);
        passportNumber = view.findViewById(R.id.passport_number_et);
        validFrom = view.findViewById(R.id.valid_from_tv);
        validTill = view.findViewById(R.id.valid_till_tv);
        radioGrpTv = view.findViewById(R.id.radio_grp_tv);
        radioGroup = view.findViewById(R.id.radio_grp);
        btnApproved = view.findViewById(R.id.radio_btn_approved);
        btnNotApproved = view.findViewById(R.id.radio_btn_not_approved);
        btnNotApproved.setChecked(true);
        preferences = context.getSharedPreferences("loginData", MODE_PRIVATE);
        rootRef = cmn.getDatabasePath(context);
        rootRef.child("Employees/" + empId + "/OtherDetails/isApproved").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    if (dataSnapshot.getValue().toString().equalsIgnoreCase("true")) {
                        isApproved = true;
                    } else {
                        isApproved = false;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        getStaticSpinner();
        getSpinner();
    }

    private void getStaticSpinner() {
        ArrayAdapter<CharSequence> internationalAdapter = ArrayAdapter.createFromResource(context, R.array.international, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> locomotiveAdapter = ArrayAdapter.createFromResource(context, R.array.locomotive, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> handicapAdapter = ArrayAdapter.createFromResource(context, R.array.handicap, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> visualAdapter = ArrayAdapter.createFromResource(context, R.array.visual, android.R.layout.simple_spinner_item);
        internationalAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locomotiveAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        handicapAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        visualAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        internationalSpinner.setAdapter(internationalAdapter);
        locomotiveSpinner.setAdapter(locomotiveAdapter);
        visualSpinner.setAdapter(visualAdapter);
        handicapSpinner.setAdapter(handicapAdapter);

    }

    private void getSpinner() {
        cmn.setProgressDialog("Please Wait...", "Preparing Data...", context, (Activity) context);

        originCountryList.add("Country");
        originCountryIdList.add("Country");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("originCountryList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        originCountryList.add(values);
                        originCountryIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        maritalStatusList.add("Status");
        maritalIdList.add("Status");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("maritalStatusList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        maritalStatusList.add(values);
                        maritalIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        nationalityList.add("Nationality");
        nationalityIdList.add("Nationality");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("nationalityList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        nationalityList.add(values);
                        nationalityIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        qualificationList.add("Qualification");
        qualificationIdList.add("Qualification");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("qualificationList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        qualificationList.add(values);
                        qualificationIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> qualificationAdapter = new ArrayAdapter<>(context, simple_spinner_item, qualificationList);
        ArrayAdapter<String> nationalityAdapter = new ArrayAdapter<>(context, simple_spinner_item, nationalityList);
        ArrayAdapter<String> maritalAdapter = new ArrayAdapter<>(context, simple_spinner_item, maritalStatusList);
        ArrayAdapter<String> originAdapter = new ArrayAdapter<>(context, simple_spinner_item, originCountryList);

        qualificationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nationalityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        maritalAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        originAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        qualificationSpinner.setAdapter(qualificationAdapter);
        nationalitySpinner.setAdapter(nationalityAdapter);
        maritalSpinner.setAdapter(maritalAdapter);
        originSpinner.setAdapter(originAdapter);

        internationalSpinner.setSelection(2);
        handicapSpinner.setSelection(2);
        locomotiveSpinner.setSelection(2);
        visualSpinner.setSelection(2);

        nationalitySpinner.setSelection(1);
        originSpinner.setSelection(1);
        if (from.equals("edit")) {
            setDefaults();
        } else {
            cmn.closeDialog((Activity) context);
        }
    }

    private void setDefaults() {
        rootRef.child("Employees").child(empId).child("OtherDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("originCountry")) {
                    otherDetailStructureMap.put("originCountry", dataSnapshot.child("originCountry").getValue());
                    originSpinner.setSelection(originCountryList.indexOf(String.valueOf(otherDetailStructureMap.get("originCountry"))));
                }
                if (dataSnapshot.hasChild("qualification")) {
                    otherDetailStructureMap.put("qualification", dataSnapshot.child("qualification").getValue());
                    qualificationSpinner.setSelection(qualificationList.indexOf(String.valueOf(otherDetailStructureMap.get("qualification"))));
                }
                if (dataSnapshot.hasChild("isInternational")) {
                    otherDetailStructureMap.put("isInternational", dataSnapshot.child("isInternational").getValue());
                    internationalSpinner.setSelection(setSpinner(String.valueOf(otherDetailStructureMap.get("isInternational"))));
                }
                if (dataSnapshot.hasChild("isLocomotive")) {
                    otherDetailStructureMap.put("isLocomotive", dataSnapshot.child("isLocomotive").getValue());
                    locomotiveSpinner.setSelection(setSpinner(String.valueOf(otherDetailStructureMap.get("isLocomotive"))));
                }
                if (dataSnapshot.hasChild("isVisual")) {
                    otherDetailStructureMap.put("isVisual", dataSnapshot.child("isVisual").getValue());
                    visualSpinner.setSelection(setSpinner(String.valueOf(otherDetailStructureMap.get("isVisual"))));
                }
                if (dataSnapshot.hasChild("isHandicap")) {
                    otherDetailStructureMap.put("isHandicap", dataSnapshot.child("isHandicap").getValue());
                    handicapSpinner.setSelection(setSpinner(String.valueOf(otherDetailStructureMap.get("isHandicap"))));
                }
                if (dataSnapshot.hasChild("maritalStatus")) {
                    otherDetailStructureMap.put("maritalStatus", dataSnapshot.child("maritalStatus").getValue());
                    maritalSpinner.setSelection(maritalStatusList.indexOf(String.valueOf(otherDetailStructureMap.get("maritalStatus"))));
                }
                if (dataSnapshot.hasChild("nationality")) {
                    otherDetailStructureMap.put("nationality", dataSnapshot.child("nationality").getValue());
                    nationalitySpinner.setSelection(nationalityList.indexOf(String.valueOf(otherDetailStructureMap.get("nationality"))));
                }
                if (dataSnapshot.hasChild("passportNumber")) {
                    otherDetailStructureMap.put("passportNumber", dataSnapshot.child("passportNumber").getValue());
                    passportNumber.setText(String.valueOf(otherDetailStructureMap.get("passportNumber")));
                }
                if (dataSnapshot.hasChild("passportValidFrom")) {
                    otherDetailStructureMap.put("passportValidFrom", dataSnapshot.child("passportValidFrom").getValue());
                    validFrom.setText(String.valueOf(otherDetailStructureMap.get("passportValidFrom")));
                }
                if (dataSnapshot.hasChild("passportValidTill")) {
                    otherDetailStructureMap.put("passportValidTill", dataSnapshot.child("passportValidTill").getValue());
                    validTill.setText(String.valueOf(otherDetailStructureMap.get("passportValidTill")));
                }
                if (dataSnapshot.hasChild("isApproved")) {
                    radioStatus = Boolean.parseBoolean(Objects.requireNonNull(dataSnapshot.child("isApproved").getValue()).toString());
                    if (radioStatus) {
                        btnApproved.setChecked(true);
                    } else {
                        btnNotApproved.setChecked(true);
                    }
                }
                cmn.closeDialog((Activity) context);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    private Integer setSpinner(String string) {
        int value;
        if (string.equals("Yes")) {
            value = 1;
        } else {
            value = 2;
        }
        return value;
    }

    private void UploadEmpInfo() {
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isManager").setValue("false");
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isApproved").setValue(radioStatus);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("originCountry").setValue(uOrigin);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("qualification").setValue(uQualification);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isInternational").setValue(uInternational);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isLocomotive").setValue(uLocomotive);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isVisual").setValue(uVisual);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("isHandicap").setValue(uHandicap);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("maritalStatus").setValue(uMarital);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("nationality").setValue(uNationality);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("passportNumber").setValue(uPassportNumber);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("passportValidFrom").setValue(uValidFrom);
//        rootRef.child("Employees").child(empId).child("OtherDetails").child("passportValidTill").setValue(uValidTill);
        otherDetailStructureMap.put("isManager", "false");
        otherDetailStructureMap.put("isApproved", isApproved);
        rootRef.child("Employees").child(empId).child("OtherDetails").updateChildren(otherDetailStructureMap);
    }

    private void setFinishBtn() {
        if (originSpinner.getSelectedItemPosition() != 0) {
            otherDetailStructureMap.put("originCountry", originSpinner.getSelectedItem().toString());
            if (qualificationSpinner.getSelectedItemPosition() != 0) {
                otherDetailStructureMap.put("qualification", qualificationSpinner.getSelectedItem().toString());
                if (internationalSpinner.getSelectedItemPosition() != 0) {
                    otherDetailStructureMap.put("isInternational", internationalSpinner.getSelectedItem().toString());
                    if (locomotiveSpinner.getSelectedItemPosition() != 0) {
                        otherDetailStructureMap.put("isLocomotive", locomotiveSpinner.getSelectedItem().toString());
                        if (visualSpinner.getSelectedItemPosition() != 0) {
                            otherDetailStructureMap.put("isVisual", visualSpinner.getSelectedItem().toString());
                            if (handicapSpinner.getSelectedItemPosition() != 0) {
                                otherDetailStructureMap.put("isHandicap", handicapSpinner.getSelectedItem().toString());
                                if (maritalSpinner.getSelectedItemPosition() != 0) {
                                    otherDetailStructureMap.put("maritalStatus", maritalSpinner.getSelectedItem().toString());
                                    if (nationalitySpinner.getSelectedItemPosition() != 0) {
                                        otherDetailStructureMap.put("nationality", nationalitySpinner.getSelectedItem().toString());
                                        otherDetailStructureMap.put("passportNumber", passportNumber.getText().toString().trim());
                                        otherDetailStructureMap.put("passportValidFrom", validFrom.getText().toString().trim());
                                        otherDetailStructureMap.put("passportValidTill", validTill.getText().toString().trim());
                                        UploadEmpInfo();
                                        Intent intent = new Intent(context, Employee.class);
                                        startActivity(intent);
                                        ((Registration) context).finish();
                                    } else {
                                        cmn.showAlertDialog("Alert", "Select Nationality", false, context);
                                    }
                                } else {
                                    cmn.showAlertDialog("Alert", "Select Marital", false, context);
                                }
                            } else {
                                cmn.showAlertDialog("Alert", "Select Handicap", false, context);
                            }
                        } else {
                            cmn.showAlertDialog("Alert", "Select Visual", false, context);
                        }
                    } else {
                        cmn.showAlertDialog("Alert", "Select Locomotive", false, context);
                    }
                } else {
                    cmn.showAlertDialog("Alert", "Select International", false, context);
                }
            } else {
                cmn.showAlertDialog("Alert", "Select Qualification", false, context);
            }
        } else {
            cmn.showAlertDialog("Alert", "Select origin Country", false, context);
        }
    }
}