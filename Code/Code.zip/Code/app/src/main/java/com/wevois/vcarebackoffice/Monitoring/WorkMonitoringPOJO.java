package com.wevois.vcarebackoffice.Monitoring;


public class WorkMonitoringPOJO {
    String ward,driverName,driverInTime,driverOutTime,helperName,helperInTime,helperOutTime,vehicleNo,workPercentage;
    int wardsord;

    public int getWardsord() {
        return wardsord;
    }

    public void setWardsord(int wardsord) {
        this.wardsord = wardsord;
    }

    public WorkMonitoringPOJO(String ward, String driverName, String driverInTime, String driverOutTime, String helperName, String helperInTime, String helperOutTime, String vehicleNo, String workPercentage, int wardsord) {
        this.ward = ward;
        this.driverName = driverName;
        this.driverInTime = driverInTime;
        this.driverOutTime = driverOutTime;
        this.helperName = helperName;
        this.helperInTime = helperInTime;
        this.helperOutTime = helperOutTime;
        this.vehicleNo = vehicleNo;
        this.workPercentage = workPercentage;
        this.wardsord = wardsord;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverInTime() {
        return driverInTime;
    }

    public void setDriverInTime(String driverInTime) {
        this.driverInTime = driverInTime;
    }

    public String getDriverOutTime() {
        return driverOutTime;
    }

    public void setDriverOutTime(String driverOutTime) {
        this.driverOutTime = driverOutTime;
    }

    public String getHelperName() {
        return helperName;
    }

    public void setHelperName(String helperName) {
        this.helperName = helperName;
    }

    public String getHelperInTime() {
        return helperInTime;
    }

    public void setHelperInTime(String helperInTime) {
        this.helperInTime = helperInTime;
    }

    public String getHelperOutTime() {
        return helperOutTime;
    }

    public void setHelperOutTime(String helperOutTime) {
        this.helperOutTime = helperOutTime;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getWorkPercentage() {
        return workPercentage;
    }

    public void setWorkPercentage(String workPercentage) {
        this.workPercentage = workPercentage;
    }

}
