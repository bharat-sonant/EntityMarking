package com.wevois.vcarebackoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Login.LoginSignUp;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class SelectCityActivity extends AppCompatActivity {
    SharedPreferences pathSharedPreferences;
    ListView cityName;
    CityDetailsAdapter cityDetailsAdapter;
    ArrayList<CityDetails> arrayList = new ArrayList<>();
    ArrayList<CityDetails> originalData = new ArrayList<>();
    String city, databasePath, sPath,key;
    CommonFunctions common = CommonFunctions.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_city);
        cityName = (ListView) findViewById(R.id.cityName);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
        common.setProgressDialog("", "Please Wait...", this, this);
        getCityDetails();
        findViewById(R.id.selectCity).setOnLongClickListener(view -> {
            pathSharedPreferences.edit().putString("city", city).apply();
            pathSharedPreferences.edit().putString("key",key).apply();
            pathSharedPreferences.edit().putString("pathRef", databasePath.replaceAll("\\\\", "")).apply();
            pathSharedPreferences.edit().putString("storagePathRef", sPath.replaceAll("\\\\", "")).apply();
            startActivity(new Intent(SelectCityActivity.this, LoginSignUp.class));
            finish();
            return true;
        });
    }
    private void getCityDetails() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("CityDetails/VCareCities.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("CityDetailsDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("CityDetails/VCareCities.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String str = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("CityDetails", str).apply();
                        pathSharedPreferences.edit().putLong("CityDetailsDownloadTime", fileCreationTime).apply();
                        setCityList();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }else {
                setCityList();
            }
        });
    }

    public void setCityList(){
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("CityDetails",""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String cityName = jsonObject.getString("cityName");
                    String dbPath = jsonObject.getString("dbPath");
                    String key = jsonObject.getString("key");
                    String storagePath = jsonObject.getString("storagePath");
                    if (cityName.equalsIgnoreCase("Test")) {
                        city = cityName;
                        this.key = key;
                        databasePath = dbPath;
                        sPath = storagePath;
                    } else {
                        arrayList.add(new CityDetails(cityName, dbPath, storagePath,key));
                        originalData.add(new CityDetails(cityName,dbPath,storagePath,key));
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            common.closeDialog(SelectCityActivity.this);
            cityDetailsAdapter = new CityDetailsAdapter(SelectCityActivity.this, SelectCityActivity.this, arrayList);
            cityName.setAdapter(cityDetailsAdapter);
            cityDetailsAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}