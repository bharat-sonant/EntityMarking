package com.wevois.vcarebackoffice.employeeattendance.model;

import java.util.ArrayList;

public class ParentRecyclerviewModel {
    String name;
    String id;
    String device;
    String designationId;
    String ids;
    String totalSalary;
    ArrayList<Integer> taskSalary;
    String saveData;

    public ParentRecyclerviewModel(String name, String id, String device, String designationId, String ids, String totalSalary, ArrayList<Integer> taskSalary, String saveData) {
        this.name = name;
        this.id = id;
        this.device = device;
        this.designationId = designationId;
        this.ids = ids;
        this.totalSalary = totalSalary;
        this.taskSalary = taskSalary;
        this.saveData = saveData;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getDesignationId() {
        return designationId;
    }

    public void setDesignationId(String designationId) {
        this.designationId = designationId;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getTotalSalary() {
        return totalSalary;
    }

    public void setTotalSalary(String totalSalary) {
        this.totalSalary = totalSalary;
    }

    public ArrayList<Integer> getTaskSalary() {
        return taskSalary;
    }

    public void setTaskSalary(ArrayList<Integer> taskSalary) {
        this.taskSalary = taskSalary;
    }

    public String getSaveData() {
        return saveData;
    }

    public void setSaveData(String saveData) {
        this.saveData = saveData;
    }

    @Override
    public String toString() {
        return "ParentRecyclerviewModel{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", device='" + device + '\'' +
                ", designationId='" + designationId + '\'' +
                ", ids='" + ids + '\'' +
                ", totalSalary='" + totalSalary + '\'' +
                ", taskSalary=" + taskSalary +
                ", saveData='" + saveData + '\'' +
                '}';
    }
}
