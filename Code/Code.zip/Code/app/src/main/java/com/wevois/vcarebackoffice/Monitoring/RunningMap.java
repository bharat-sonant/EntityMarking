package com.wevois.vcarebackoffice.Monitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.maps.android.data.kml.KmlLayer;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class RunningMap extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    CommonFunctions common = CommonFunctions.getInstance();
    String wardName = "", date = "";
    LatLng latLng;
    float pathDis[] = new float[1];
    TextView selectedDate;
    LinearLayout linearLayout;
    boolean isRunning = true;
    int lineNumber = 1;
    LatLng latLngs;
    JSONObject jsonObject;
    DatabaseReference databaseReference;
    ArrayList<LatLng> directionPositionList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_running_map);
        if (getSupportActionBar()!=null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        linearLayout = findViewById(R.id.mapLayout);
        wardName = getIntent().getStringExtra("ward");
        isRunning = getIntent().getBooleanExtra("isRunning", true);
        if (isRunning) {
            selectedDate = findViewById(R.id.dateSelect);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            date = dateFormat.format(new Date());
            selectedDate.setOnClickListener(v -> datePicker());
        } else {
            lineNumber = Integer.parseInt(getIntent().getStringExtra("lineNumber"));
            String[] lat = getIntent().getStringExtra("latLng").split(",");
            latLngs = new LatLng(Double.parseDouble(lat[0]), Double.parseDouble(lat[1]));
            linearLayout.setVisibility(View.GONE);
        }
        databaseReference = common.getDatabasePath(this);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setCompassEnabled(false);
        mMap.getUiSettings().setMapToolbarEnabled(false);
        if (isRunning) {
            new downloadAllRequired().execute();
        } else {
            jsonObject = common.getJsonData(wardName,getSharedPreferences("path", MODE_PRIVATE));
            try {
                drawMap();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        new RunningMap.DownloadKmlFile(common.getKmlFilePath(wardName, this)).execute();
    }

    private void drawMap() throws JSONException {
        ArrayList<LatLng> directionPositionList1 = new ArrayList<>();
        JSONArray jsonArray;
        if (jsonObject == null || jsonObject.length() == 0) {
            return;
        }
        int color = Color.parseColor("#0C9EF1");
        jsonArray = jsonObject.getJSONObject(String.valueOf(lineNumber)).getJSONArray("points");
        for (int i = 0; i < jsonArray.length(); i++) {
            directionPositionList1.add(new LatLng(jsonArray.getJSONArray(i).getDouble(0), jsonArray.getJSONArray(i).getDouble(1)));
            if (i >= jsonArray.length() - 1) {
                mMap.addPolyline(new PolylineOptions().addAll((directionPositionList1)).color(color).width(20));
                CameraPosition cameraPosition = new CameraPosition.Builder().target(directionPositionList1.get(0)).zoom(19).build();
                mMap.animateCamera(CameraUpdateFactory.newLatLng(directionPositionList1.get(0)));
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                directionPositionList1.clear();
            }
        }
        int height = 50;
        int width = 50;
        BitmapDrawable bitMapDraw = (BitmapDrawable) getResources().getDrawable(R.drawable.redmarker);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLngs);
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(Bitmap.createScaledBitmap(bitMapDraw.getBitmap(), width, height, false)));
        mMap.addMarker(markerOptions);
    }

    private void datePicker() {
        int mYear, mMonth, mDay;
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, monthOfYear, dayOfMonth) -> {
                    String date_time;
                    if (monthOfYear + 1 <= 9) {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    } else {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    }
                    selectedDate.setText(date_time);
                    date = date_time;
                    new downloadAllRequired().execute();
                    common.setProgressDialog("Please wait...", "Loading...", this, this);
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private class downloadAllRequired extends AsyncTask<Void, String, String> {
        @Override
        protected String doInBackground(Void... voids) {
            RunningMap.this.runOnUiThread(() -> {
                mMap.clear();
                String year = "", month = "";
                try {
                    year = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
                    month = new SimpleDateFormat("MMMM", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                databaseReference.child("LocationHistory/" + wardName + "/" + year + "/" + month + "/" + date).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() != null) {
                            latLng = new LatLng(0.0, 0.0);
                            directionPositionList.clear();
                            double lat = 0.0, lng = 0.0;
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                if (snapshot.hasChild("lat-lng") || snapshot.hasChild("latlng")) {
                                    String[] stringLatLng;
                                    if (snapshot.hasChild("lat-lng")) {
                                        stringLatLng = snapshot.child("lat-lng").getValue().toString().split("~");
                                    } else {
                                        stringLatLng = snapshot.child("latlng").getValue().toString().split("~");
                                    }
                                    for (int i = 0; i < stringLatLng.length; i++) {
                                        String[] latLngs = stringLatLng[i].substring(1, stringLatLng[i].length() - 1).split(",");
                                        if (Double.parseDouble(latLngs[0].trim()) != 0.0 && Double.parseDouble(latLngs[1].trim()) != 0.0) {
                                            latLng = new LatLng(Double.parseDouble(latLngs[0].trim()), Double.parseDouble(latLngs[1].trim()));
                                            if (lat == 0.0 && lng == 0.0) {
                                                lat = latLng.latitude;
                                                lng = latLng.longitude;
                                                directionPositionList.add(latLng);
                                            }
                                            Location.distanceBetween(lat, lng, latLng.latitude, latLng.longitude, pathDis);
                                            if (pathDis[0] > 2) {
                                                if (pathDis[0] <= 10) {
                                                    Log.d("TAG", "onDataChange: check line distance A " + pathDis[0]);
                                                    directionPositionList.add(latLng);
                                                    lat = latLng.latitude;
                                                    lng = latLng.longitude;
                                                } else {
                                                    Log.d("TAG", "onDataChange: check line distance B " + pathDis[0]);
                                                    lat = latLng.latitude;
                                                    lng = latLng.longitude;
                                                }
                                            }
                                        }
                                    }
                                    mMap.addPolyline(new PolylineOptions().addAll((directionPositionList)).color(Color.GREEN));
                                    if (directionPositionList.size() > 0) {
                                        LatLng tempLatLng = directionPositionList.get(directionPositionList.size() - 1);
                                        directionPositionList.clear();
                                        directionPositionList.add(tempLatLng);
                                    }
                                }
                            }
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 23));
                            common.closeDialog(RunningMap.this);
                        } else {
                            common.showAlertDialog("Info!", "Data not found today", true, RunningMap.this);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            });
            return null;
        }
    }

//    private void getStatus() {
//        mMap.clear();
//        String year = "",month = "";
//        try {
//            year = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
//            month = new SimpleDateFormat("MMMM", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        databaseReference.child("LocationHistory/" + wardName + "/"+year+"/"+month+"/" + date).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                if (dataSnapshot.getValue() != null) {
//                    latLng = new LatLng(0.0, 0.0);
//                    double lat = 0.0,lng=0.0;
//                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                        if (snapshot.hasChild("lat-lng")||snapshot.hasChild("latlng")) {
//                            String[] stringLatLng ;
//                            if (snapshot.hasChild("lat-lng")) {
//                                stringLatLng = snapshot.child("lat-lng").getValue().toString().split("~");
//                            } else {
//                                stringLatLng = snapshot.child("latlng").getValue().toString().split("~");
//                            }
//                            for (int i = 0; i < stringLatLng.length; i++) {
//                                String[] latLngs = stringLatLng[i].substring(1, stringLatLng[i].length() - 1).split(",");
//                                if (Double.parseDouble(latLngs[0].trim())!=0.0&&Double.parseDouble(latLngs[1].trim())!=0.0) {
//                                    latLng = new LatLng(Double.parseDouble(latLngs[0].trim()), Double.parseDouble(latLngs[1].trim()));
//                                    if (lat == 0.0 && lng == 0.0) {
//                                        lat = latLng.latitude;
//                                        lng = latLng.longitude;
//                                        directionPositionList.add(new LatLng(Double.parseDouble(latLngs[0].trim()), Double.parseDouble(latLngs[1].trim())));
//                                    }
//                                    Location.distanceBetween(lat, lng, latLng.latitude, latLng.longitude, pathDis);
//                                    if (pathDis[0] > 2) {
//                                        directionPositionList.add(new LatLng(Double.parseDouble(latLngs[0].trim()), Double.parseDouble(latLngs[1].trim())));
//                                        lat = latLng.latitude;
//                                        lng = latLng.longitude;
//                                    }
//                                }
//                            }
//                            mMap.addPolyline(new PolylineOptions().addAll((directionPositionList)).color(Color.GREEN).endCap(new CustomCap(BitmapDescriptorFactory.fromResource(R.drawable.headarrowskyblue),
//                                    40)).width(4.0f));
//                            directionPositionList.clear();
//                            if (lat != 0.0 && lng != 0.0) {
//                                directionPositionList.add(new LatLng(lat, lng));
//                            }
//                        }
//                    }
//                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 23));
//                    common.closeDialog(RunningMap.this);
//                } else {
//                    common.showAlertDialog("Info!", "Data not found today", true, RunningMap.this);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//    }

    private class DownloadKmlFile extends AsyncTask<String, Void, byte[]> {
        private final String mUrl;

        public DownloadKmlFile(String url) {
            mUrl = url;
        }

        protected byte[] doInBackground(String... params) {
            try {
                InputStream is = new URL(mUrl).openStream();
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                int nRead;
                byte[] data = new byte[16384];
                while ((nRead = is.read(data, 0, data.length)) != -1) {
                    buffer.write(data, 0, nRead);
                }
                buffer.flush();
                return buffer.toByteArray();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(byte[] byteArr) {
            try {
                if (byteArr != null) {
                    KmlLayer kmlLayer = new KmlLayer(mMap, new ByteArrayInputStream(byteArr),
                            getApplicationContext());
                    kmlLayer.addLayerToMap();
                }
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
