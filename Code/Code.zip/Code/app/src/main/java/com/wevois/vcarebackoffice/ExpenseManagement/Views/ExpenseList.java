package com.wevois.vcarebackoffice.ExpenseManagement.Views;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.ExpenseManagement.Adapter.ExpenseListAdapter;
import com.wevois.vcarebackoffice.ExpenseManagement.Model.ExpenseListModel;
import com.wevois.vcarebackoffice.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class ExpenseList extends AppCompatActivity {
    Button add_Button;
    TextView back_Button;
    ListView expenseList;
    SharedPreferences pathSharedPreferences;
    Spinner spinnerFilterVendor;
    private boolean isBackClick = true, isActivityClick = true;
    String vendorId;
    CommonFunctions common = CommonFunctions.getInstance();
    ArrayList<ExpenseListModel> arrayListExpense = new ArrayList<>();
    ArrayList<String> vendorArrayList = new ArrayList<>();
    ExpenseListAdapter expenseListAdapter;
    ArrayList<String> keyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_list);
        common.setProgressDialog("", "Please Wait", this, this);
        initMethod();
        setAction();
        getVendorsList();
    }

    private void initMethod() {
        back_Button = findViewById(R.id.back_Button);
        add_Button = findViewById(R.id.add_Button);
        expenseList = findViewById(R.id.expenseList);
        spinnerFilterVendor = findViewById(R.id.spinnerFilterVendor);
        pathSharedPreferences = getSharedPreferences("path", MODE_PRIVATE);
    }

    private void setAction() {
        back_Button.setOnClickListener(v -> {
            if (isBackClick) {
                isBackClick = false;
                onBackPressed();
            }
        });

        add_Button.setOnClickListener(view -> {
            if (isActivityClick) {
                isActivityClick = false;
                common.setProgressDialog("Please Wait", "", this, this);
                Intent i = new Intent(ExpenseList.this, ExpenseEntries.class);
                i.putExtra("expenseListData", new Gson().toJson(arrayListExpense));
                startActivityForResult(i, 100);
                common.closeDialog(ExpenseList.this);
                finish();
            }
        });
    }

    public void getExpense() {
        String keys = spinnerFilterVendor.getSelectedItem().toString();
        vendorId = keys.split("\\(")[1].split("\\)")[0];
        common.setProgressDialog("Please Wait", "Data Loading.", this, this);
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("Common/Expenses/" + vendorId + ".json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("ExpenseEntriesDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("Common/Expenses/" + vendorId + ".json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String expenseJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("ExpenseList", expenseJsonData).apply();
                        pathSharedPreferences.edit().putLong("ExpenseEntriesDownloadTime", fileCreationTime).apply();
                        setExpense();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                setExpense();
            }
        });
        storageReference.child("Common/Expenses/" + vendorId + ".json").getMetadata().addOnFailureListener(e -> {
            arrayListExpense.clear();
            notifyList();
            common.closeDialog(ExpenseList.this);
        });
    }
    public void setExpense() {
        try {
            arrayListExpense.clear();
            notifyList();
            JSONObject expenseJsonData = new JSONObject(pathSharedPreferences.getString("ExpenseList", ""));
            Iterator<String> expenseKeys = expenseJsonData.keys();
            while (expenseKeys.hasNext()) {
                String key = expenseKeys.next();
                try {
                    JSONObject values = expenseJsonData.getJSONObject(key);
                    String imageName = values.getString("uri");
                    String vendorName = values.getString("vendorName");
                    String billType = values.getString("billType");
                    String billNo = values.getString("billNo");
                    String amount = values.getString("amount");
                    String purchase = values.getString("purchase");
                    String expenseBy = values.getString("expenseBy");
                    String date = key;

                    arrayListExpense.add(new ExpenseListModel(imageName, vendorName, billType, billNo, amount, purchase, expenseBy, date, vendorId));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        common.closeDialog(ExpenseList.this);
    }
    public void notifyList() {
        expenseListAdapter = new ExpenseListAdapter(ExpenseList.this, arrayListExpense);
        expenseList.setAdapter(expenseListAdapter);
        expenseListAdapter.notifyDataSetChanged();
    }
    public void getVendorsList() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        storageReference.child("Common/VendorList.json").getMetadata().addOnSuccessListener(storageMetadata -> {
            long fileCreationTime = storageMetadata.getCreationTimeMillis();
            long fileDownloadTime = pathSharedPreferences.getLong("VendorListDownloadTime", 0);
            if (fileDownloadTime != fileCreationTime) {
                storageReference.child("Common/VendorList.json").getBytes(10000000).addOnSuccessListener(taskSnapshot -> {
                    try {
                        String vendorJsonData = new String(taskSnapshot, StandardCharsets.UTF_8);
                        pathSharedPreferences.edit().putString("VendorList", vendorJsonData).apply();
                        pathSharedPreferences.edit().putLong("VendorListDownloadTime", fileCreationTime).apply();
                        setVendorsList();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } else {
                setVendorsList();
            }
        });
        storageReference.child("Common/VendorList.json").getMetadata().addOnFailureListener(e -> common.closeDialog(ExpenseList.this));
    }
    public void setVendorsList() {
        vendorArrayList.add("Select Vendor");
        try {
            JSONObject vendorJsonData = new JSONObject(pathSharedPreferences.getString("VendorList", ""));
            Iterator<String> vendorKeys = vendorJsonData.keys();
            while (vendorKeys.hasNext()) {
                String key = vendorKeys.next();
                try {
                    if (key != "lastVendorId") {
                        JSONObject values = vendorJsonData.getJSONObject(key);
                        String vendorName = values.getString("name");
                        vendorArrayList.add(vendorName + " (" + key + ") ");
                        keyList.add(key);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            common.closeDialog(ExpenseList.this);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> vendorSpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, vendorArrayList);
        vendorSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilterVendor.setAdapter(vendorSpinnerAdapter);

        spinnerFilterVendor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position == 0) {
                    TextView tv = (TextView) view;
                    tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                    arrayListExpense.clear();
                    common.closeDialog(ExpenseList.this);
                } else {
                    arrayListExpense.clear();
                    getExpense();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                common.closeDialog(ExpenseList.this);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            if (resultCode == RESULT_OK) {
                if (data.hasExtra("expenseListData1")) {
                    arrayListExpense = new Gson().fromJson(data.getStringExtra("expenseListData1"), new TypeToken<ArrayList<ExpenseListModel>>() {
                    }.getType());
                }
                expenseList.setAdapter(expenseListAdapter);
                expenseListAdapter.notifyDataSetChanged();
            }
            common.closeDialog(this);
        }
        common.closeDialog(this);
    }

    protected void onResume() {
        super.onResume();
        isBackClick = true;
        isActivityClick = true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}