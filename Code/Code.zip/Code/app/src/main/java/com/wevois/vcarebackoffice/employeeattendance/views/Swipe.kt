package com.wevois.vcarebackoffice.employeeattendance.views

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.wevois.vcarebackoffice.R
import com.wevois.vcarebackoffice.databinding.ActivitySwipeBinding
import com.wevois.vcarebackoffice.employeeattendance.viewmodel.SwipeViewModel
import com.wevois.vcarebackoffice.employeeattendance.viewmodelfactory.SwipeViewModelFactory

class Swipe : AppCompatActivity() {
    var viewModel: SwipeViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivitySwipeBinding = DataBindingUtil.setContentView(this, R.layout.activity_swipe)
        viewModel = ViewModelProvider(this, SwipeViewModelFactory(this,binding.swipeWardForAttendance)).get(SwipeViewModel::class.java)
        binding.swipeviewmodel = viewModel
    }
}