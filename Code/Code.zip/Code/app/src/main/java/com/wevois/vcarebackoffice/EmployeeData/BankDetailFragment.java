package com.wevois.vcarebackoffice.EmployeeData;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.transition.AutoTransition;
import androidx.transition.TransitionManager;

import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.siyamed.shapeimageview.RoundedImageView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import uk.co.senab.photoview.PhotoViewAttacher;

import static android.R.layout.simple_spinner_item;
import static android.content.Context.LAYOUT_INFLATER_SERVICE;
import static android.content.Context.MODE_PRIVATE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import org.json.JSONArray;

public class BankDetailFragment extends Fragment {
    Button next, addNewFamilyMember;
    private Camera mCamera;
    private static final int FOCUS_AREA_SIZE = 300;
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    SurfaceHolder.Callback surfaceViewCallBack;
    Camera.PictureCallback pictureCallback;
    Bitmap thumbnail;
    public Context context;
    Button uploadPassbookBtn;
    DatabaseReference rootRef;
    StorageReference mStorageRef;
    RoundedImageView passbookPhotoIv;
    SharedPreferences sharedPreferences, preferences,pathSharedPreferences;
    CardView cardView, cardView2, cardView3;
    CommonFunctions cmn = CommonFunctions.getInstance();
    TextView btnIcon, btnIcon2, btnIcon3, btnIcon4, passbookPhotoTv, fMDOB;
    LinearLayout expand, expand2, expand3, expand4, expandable, expandable2, expandable3, expandable4, linearResidence, addFamilyLayout, familyMemberListViewLayout;
    EditText bAccountNumber, bIFSC, bFamilyMember, nName, nRelation, nAddress, nMobile, nUID, nEmail, pfUAN, fMName, fMRelation, fMTown, fMIncome,
            previousPFNumber, previousEmpCode, previousCompanyName, previousCompanyEmail, previousCompanyAddress;
    Spinner fMResidingSpinner, fMStateSpinner, fMDisabilitySpinner;
    String empId, passbookPhotoUrl = "", storagePath, uAccountNumber, uIFSC, uNName, uNRelation, uNAddress, uNMobile, uNUID, uNEmail, upfUAN, from,
            uFamilyMember, changesFamilyId = "";
    ArrayList<String> stateList = new ArrayList<>(), stateIdList = new ArrayList<>();
    ListView familyMemberLV;
    ArrayList<FamilyMemberModel> familyMemberList = new ArrayList<>();
    FamilyMemberAdapter familyMemberAdapter;
    boolean isAddFamily = true, isApproved = false, isPass = true;
    private static final int PERMISSION_CODE = 1000;
    String isLock = "0";

    public BankDetailFragment() {

    }

    @Override
    public void onAttach(@NonNull Context ctx) {
        super.onAttach(ctx);
        context = getActivity();
    }

    public static BankDetailFragment newInstance() {
        return new BankDetailFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bank_detail, container, false);
        try {
            getBundle();
            inIt(view);
            uploadPassbookBtn.setOnClickListener(view1 -> BankDetailFragment.this.CameraPermission(context));
            next.setOnClickListener(view13 -> {
                if (isApproved) {
                    if (preferences.getBoolean("isAccountant", false)) {
                        setNextBtn();
                    } else {
                        cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your supervisor.", false, context);
                    }
                } else {
                    setNextBtn();
                }
            });
            addNewFamilyMember.setOnClickListener(view12 -> {
                if (isApproved) {
                    if (preferences.getBoolean("isAccountant", false)) {
                        if (familyMemberLV.getVisibility() == View.VISIBLE) {
                            isAddFamily = true;
                            addNewFamilyMember.setText("Add new");
                            addFamilyLayout.setVisibility(View.VISIBLE);
                            familyMemberListViewLayout.setVisibility(View.GONE);
                            familyMemberLV.setVisibility(View.GONE);
                        } else {
                            if (validateFamilyMember()) {
                                cmn.setProgressDialog("Please wait...", "", context, getActivity());
                                sendFamilyMemberData();
                            }
                        }
                    } else {
                        cmn.showAlertDialog("Warning !", "You are not authorized to edit this section. \n please contact to your supervisor.", false, context);
                    }
                } else {
                    if (familyMemberLV.getVisibility() == View.VISIBLE) {
                        isAddFamily = true;
                        addNewFamilyMember.setText("Add new");
                        addFamilyLayout.setVisibility(View.VISIBLE);
                        familyMemberListViewLayout.setVisibility(View.GONE);
                        familyMemberLV.setVisibility(View.GONE);
                    } else {
                        if (validateFamilyMember()) {
                            cmn.setProgressDialog("Please wait...", "", context, getActivity());
                            sendFamilyMemberData();
                        }
                    }
                }

            });
            view.findViewById(R.id.viewFamilyBtn).setOnClickListener(view14 -> {
                if (familyMemberList.size() > 0) {
                    isAddFamily = true;
                    addNewFamilyMember.setText("Add new");
                    addFamilyLayout.setVisibility(View.GONE);
                    familyMemberListViewLayout.setVisibility(View.VISIBLE);
                    familyMemberLV.setVisibility(View.VISIBLE);
                } else {
                    cmn.showAlertDialog("Info.", "Family member not found.", false, context);
                }
            });
            fMDOB.setOnClickListener(v -> datePicker());
            getFamilyMemberData();
            passbookPhotoIv.setOnLongClickListener(view1 -> {
                Log.d("TAG", "onCreateView: check "+preferences.getBoolean("isAccountant", false));
                if (preferences.getBoolean("isAccountant", false)) {
                    if (passbookPhotoUrl.length() > 0) {
                        cmn.setProgressDialog("Please Wait", "Image downloading...", context, (Activity) context);
                        new GetImages().execute();
                    } else {
                        cmn.showAlertDialog("Warning !", "Image Url not found. \n please contact to your supervisor.", false, context);
                    }
                }
                return true;
            });
        } catch (Exception e) {
        }
        return view;
    }

    private boolean validateFamilyMember() {
        boolean isValid = true;
        try {
            if (fMName.getText().toString().length() == 0) {
                fMName.setError("Please enter name.");
                fMName.requestFocus();
                isValid = false;
            } else if (!fMDOB.getText().toString().contains("-")) {
                cmn.showAlertDialog("Alert", "Enter Date of Birth", false, context);
                isValid = false;
            } else if (fMRelation.getText().toString().length() == 0) {
                fMRelation.setError("Please enter relation.");
                fMRelation.requestFocus();
                isValid = false;
            } else if (fMResidingSpinner.getSelectedItem().toString().equals("Select")) {
                View selectedView = fMResidingSpinner.getSelectedView();
                isValid = false;
                if (selectedView != null && selectedView instanceof TextView) {
                    fMResidingSpinner.requestFocus();
                    TextView selectedTextView = (TextView) selectedView;
                    selectedTextView.setError("error");
                    selectedTextView.setTextColor(Color.RED);
                    selectedTextView.setText("please select");
                    fMResidingSpinner.performClick();
                }
            } else if (fMResidingSpinner.getSelectedItem().toString().equals("No")) {
                if (fMTown.getText().toString().length() == 0) {
                    fMTown.setError("Please enter town.");
                    fMTown.requestFocus();
                    isValid = false;
                } else if (fMStateSpinner.getSelectedItem().toString().equals("Select")) {
                    isValid = false;
                    View selectedView = fMStateSpinner.getSelectedView();
                    if (selectedView != null && selectedView instanceof TextView) {
                        fMStateSpinner.requestFocus();
                        TextView selectedTextView = (TextView) selectedView;
                        selectedTextView.setError("error");
                        selectedTextView.setTextColor(Color.RED);
                        selectedTextView.setText("please select");
                        fMStateSpinner.performClick();
                    }
                }
            } else if (fMIncome.getText().toString().length() == 0) {
                fMIncome.setError("Please enter income.");
                fMIncome.requestFocus();
                isValid = false;
            } else if (fMDisabilitySpinner.getSelectedItem().toString().equals("Select")) {
                isValid = false;
                View selectedView = fMDisabilitySpinner.getSelectedView();
                if (selectedView != null && selectedView instanceof TextView) {
                    fMDisabilitySpinner.requestFocus();
                    TextView selectedTextView = (TextView) selectedView;
                    selectedTextView.setError("error");
                    selectedTextView.setTextColor(Color.RED);
                    selectedTextView.setText("please select");
                    fMDisabilitySpinner.performClick();
                }
            }
        } catch (Exception e) {
            Log.d("TAG", "onActivityResult: check 2" + e.toString());
        }
        return isValid;
    }

    public void getFamilyMemberData() {
        rootRef.child("Employees/" + empId + "/BankDetails/FamilyMemberDetails/").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    familyMemberList.clear();
                    int i = 1;
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String name = "", dateOfBirth = "", relation = "", reside = "", resideTown = "", resideState = "", income = "", disability = "";
                        if (snapshot.hasChild("name")) {
                            name = snapshot.child("name").getValue().toString();
                        }
                        if (snapshot.hasChild("dateOfBirth")) {
                            dateOfBirth = snapshot.child("dateOfBirth").getValue().toString();
                        }
                        if (snapshot.hasChild("relation")) {
                            relation = snapshot.child("relation").getValue().toString();
                        }
                        if (snapshot.hasChild("residing")) {
                            reside = snapshot.child("residing").getValue().toString();
                        }
                        if (snapshot.hasChild("town")) {
                            resideTown = snapshot.child("town").getValue().toString();
                        }
                        if (snapshot.hasChild("state")) {
                            resideState = snapshot.child("state").getValue().toString();
                        }
                        if (snapshot.hasChild("income")) {
                            income = snapshot.child("income").getValue().toString();
                        }
                        if (snapshot.hasChild("disability")) {
                            disability = snapshot.child("disability").getValue().toString();
                        }
                        familyMemberList.add(new FamilyMemberModel(name, dateOfBirth, relation, reside, resideTown, resideState, income, disability, snapshot.getKey(), i));
                        i = i + 1;
                    }
                    familyMemberAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void sendFamilyMemberData() {
        if (isAddFamily) {
            HashMap<String, String> fMDetails = new HashMap<>();
            fMDetails.put("name", fMName.getText().toString());
            fMDetails.put("dateOfBirth", fMDOB.getText().toString());
            fMDetails.put("relation", fMRelation.getText().toString());
            fMDetails.put("residing", fMResidingSpinner.getSelectedItem().toString());
            if (fMResidingSpinner.getSelectedItem().equals("No")) {
                fMDetails.put("town", fMTown.getText().toString());
                fMDetails.put("state", fMStateSpinner.getSelectedItem().toString());
            }
            fMDetails.put("income", fMIncome.getText().toString());
            fMDetails.put("disability", fMDisabilitySpinner.getSelectedItem().toString());
            rootRef.child("Employees/" + empId + "/BankDetails/FamilyMemberDetails").push().setValue(fMDetails).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    isAddFamily = true;
                    addNewFamilyMember.setText("Add new");
                    fMName.setText("");
                    fMDOB.setText("Select Date Of Birth");
                    fMRelation.setText("");
                    fMResidingSpinner.setSelection(0);
                    fMTown.setText("");
                    fMStateSpinner.setSelection(0);
                    fMIncome.setText("");
                    fMDisabilitySpinner.setSelection(0);
                    changesFamilyId = "";
                    getFamilyMemberData();
                    Toast.makeText(context, "Successfully add ", Toast.LENGTH_SHORT).show();
                }
                cmn.closeDialog(getActivity());
            });
        } else {
            if (!changesFamilyId.equals("")) {
                DatabaseReference databaseReference = rootRef.child("Employees/" + empId + "/BankDetails/FamilyMemberDetails/" + changesFamilyId);
                databaseReference.child("name").setValue(fMName.getText().toString());
                databaseReference.child("dateOfBirth").setValue(fMDOB.getText().toString());
                databaseReference.child("relation").setValue(fMRelation.getText().toString());
                databaseReference.child("residing").setValue(fMResidingSpinner.getSelectedItem().toString());
                if (fMResidingSpinner.getSelectedItem().equals("No")) {
                    databaseReference.child("town").setValue(fMTown.getText().toString());
                    databaseReference.child("state").setValue(fMStateSpinner.getSelectedItem().toString());
                }
                databaseReference.child("income").setValue(fMIncome.getText().toString());
                databaseReference.child("disability").setValue(fMDisabilitySpinner.getSelectedItem().toString());
                cmn.closeDialog(getActivity());
                isAddFamily = true;
                addNewFamilyMember.setText("Add new");
                fMName.setText("");
                fMDOB.setText("Select Date Of Birth");
                fMRelation.setText("");
                fMResidingSpinner.setSelection(0);
                fMTown.setText("");
                fMStateSpinner.setSelection(0);
                fMIncome.setText("");
                fMDisabilitySpinner.setSelection(0);
                changesFamilyId = "";
                getFamilyMemberData();
            } else {
                cmn.closeDialog(getActivity());
                cmn.showAlertDialog("Error.", "Something went wrong.", false, context);
            }
        }
    }

    private void getBundle() {
        try {
            if (getArguments() != null) {
                empId = getArguments().getString("empId", " ");
                from = getArguments().getString("from", " ");
            } else {
                cmn.showAlertDialog("Please Retry", "", false, context);
            }
        } catch (Exception e) {
            Log.d("TAG", "onActivityResult: check 5" + e.toString());
        }
    }

    private void inIt(View view) {
        try {
            preferences = context.getSharedPreferences("loginData", MODE_PRIVATE);
            pathSharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
            expand = view.findViewById(R.id.bank_expand);
            expand2 = view.findViewById(R.id.bank_expand2);
            expand3 = view.findViewById(R.id.bank_expand3);
            expand4 = view.findViewById(R.id.bank_expand4);
            expandable = view.findViewById(R.id.bank_expandable);
            expandable2 = view.findViewById(R.id.bank_expandable2);
            expandable3 = view.findViewById(R.id.bank_expandable3);
            expandable4 = view.findViewById(R.id.bank_expandable4);
            cardView = view.findViewById(R.id.bank_card);
            cardView2 = view.findViewById(R.id.bank_card2);
            cardView3 = view.findViewById(R.id.bank_card3);
            btnIcon = view.findViewById(R.id.bank_btn_icon);
            btnIcon2 = view.findViewById(R.id.bank_btn_icon2);
            btnIcon3 = view.findViewById(R.id.bank_btn_icon3);
            btnIcon4 = view.findViewById(R.id.bank_btn_icon4);
            //family details
            fMName = view.findViewById(R.id.bank_family_member_name_et);
            fMDOB = view.findViewById(R.id.bank_family_member_dob_tv);
            fMRelation = view.findViewById(R.id.family_member_relation_et);
            fMTown = view.findViewById(R.id.family_member_current_city_spinner);
            fMIncome = view.findViewById(R.id.family_member_monthly_income_et);
            fMResidingSpinner = view.findViewById(R.id.residing_with_spinner);
            fMStateSpinner = view.findViewById(R.id.family_member_current_state_spinner);
            fMDisabilitySpinner = view.findViewById(R.id.disability_spinner);
            linearResidence = view.findViewById(R.id.family_member_residence);
            familyMemberLV = view.findViewById(R.id.familyMemberLv);
            familyMemberListViewLayout = view.findViewById(R.id.familyMemberLayout);
            addFamilyLayout = view.findViewById(R.id.addFamilyLayout);
            addNewFamilyMember = view.findViewById(R.id.addNewFamilyBtn);

            //previous pf details
            previousPFNumber = view.findViewById(R.id.previous_insurance_number_et);
            previousEmpCode = view.findViewById(R.id.previous_employee_code_et);
            previousCompanyName = view.findViewById(R.id.company_name_et);
            previousCompanyEmail = view.findViewById(R.id.company_email_address_et);
            previousCompanyAddress = view.findViewById(R.id.company_address_et);

            next = view.findViewById(R.id.next_bank);
            bAccountNumber = view.findViewById(R.id.bank_account_number_et);
            bIFSC = view.findViewById(R.id.bank_ifsc_et);
            nName = view.findViewById(R.id.nominee_name_et);
            nRelation = view.findViewById(R.id.nominee_relation_et);
            nAddress = view.findViewById(R.id.nominee_address_et);
            nUID = view.findViewById(R.id.nominee_uid_et);
            nEmail = view.findViewById(R.id.nominee_email_et);
            nMobile = view.findViewById(R.id.nominee_mobile_et);
            pfUAN = view.findViewById(R.id.uan_number_et);
            passbookPhotoIv = view.findViewById(R.id.bank_passbook_image);
            uploadPassbookBtn = view.findViewById(R.id.upload_passbook_btn);
            passbookPhotoTv = view.findViewById(R.id.passbook_tv);
            bFamilyMember = view.findViewById(R.id.family_member_et);
            storagePath = cmn.getDatabaseStorage(context);
            sharedPreferences = context.getSharedPreferences("path", MODE_PRIVATE);
            rootRef = cmn.getDatabasePath(context);
            mStorageRef = FirebaseStorage.getInstance().getReferenceFromUrl(storagePath);
            familyMemberAdapter = new FamilyMemberAdapter();
            familyMemberLV.setAdapter(familyMemberAdapter);
            getStaticSpinner();
            SetExpandableCardView();
            Log.d("TAG", "inIt: check "+from+"   "+sharedPreferences.getBoolean("Bank", false));
            if (from.equals("edit") || sharedPreferences.getBoolean("Bank", false)) {
                Log.d("TAG", "inIt: check "+from+"   "+sharedPreferences.getBoolean("Bank", false));
                setDefaults();
            } else {
                cmn.closeDialog((Activity) context);
            }
            rootRef.child("Employees/" + empId + "/OtherDetails/isApproved").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue() != null) {
                        if (dataSnapshot.getValue().toString().equalsIgnoreCase("true")) {
                            isApproved = true;
                        } else {
                            isApproved = false;
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
        }
    }

    public void getStaticSpinner() {
        ArrayList<String> disabilityList = new ArrayList<>();
        disabilityList.add("Select");
        disabilityList.add("Yes");
        disabilityList.add("No");
        final ArrayAdapter<String> disabilityAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_dropdown_item, disabilityList) {
            @Override
            public boolean isEnabled(int position) {
                return !(position == 0);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }
        };
        disabilityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fMDisabilitySpinner.setAdapter(disabilityAdapter);
        final ArrayAdapter<String> residenceAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_dropdown_item, disabilityList) {
            @Override
            public boolean isEnabled(int position) {
                return !(position == 0);
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }
        };
        residenceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fMResidingSpinner.setAdapter(residenceAdapter);
        fMResidingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                if (position == 2) {
                    linearResidence.setVisibility(View.VISIBLE);
                } else {
                    linearResidence.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        stateList.add("States");
        stateIdList.add("States");
        try {
            JSONArray jsonArray = new JSONArray(pathSharedPreferences.getString("stateList", ""));
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    String values = jsonArray.getString(i);
                    if (!values.equalsIgnoreCase("null")) {
                        stateList.add(values);
                        stateIdList.add("" + i);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ArrayAdapter<String> stateSpinnerAdapter = new ArrayAdapter<>(context, simple_spinner_item, stateList);
        stateSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fMStateSpinner.setAdapter(stateSpinnerAdapter);
        fMStateSpinner.setSelection(stateIdList.indexOf("22"));

    }

    private void SetExpandableCardView() {
        Log.d("TAG", "SetExpandableCardView: check a");
        try {
            TransitionManager.beginDelayedTransition(cardView, new AutoTransition());
            expand.setOnClickListener(view1 -> {
                Log.d("TAG", "SetExpandableCardView: check A");
                if (expandable.getVisibility() == view1.GONE) {
                    expandable.setVisibility(view1.VISIBLE);
                    expandable2.setVisibility(view1.GONE);
                    expandable3.setVisibility(view1.GONE);
                    expandable4.setVisibility(view1.GONE);
                    btnIcon.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                    btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon4.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                } else {
                    expandable.setVisibility(view1.GONE);
                    btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                }
            });
            expand2.setOnClickListener(view1 -> {
                Log.d("TAG", "SetExpandableCardView: check B");
                if (expandable2.getVisibility() == view1.GONE) {
                    expandable2.setVisibility(view1.VISIBLE);
                    expandable.setVisibility(view1.GONE);
                    expandable3.setVisibility(view1.GONE);
                    expandable4.setVisibility(view1.GONE);
                    btnIcon2.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                    btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon4.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                } else {
                    expandable2.setVisibility(view1.GONE);
                    btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                }
            });
            expand3.setOnClickListener(view1 -> {
                Log.d("TAG", "SetExpandableCardView: check C");
                if (expandable3.getVisibility() == view1.GONE) {
                    expandable3.setVisibility(view1.VISIBLE);
                    expandable.setVisibility(view1.GONE);
                    expandable2.setVisibility(view1.GONE);
                    expandable4.setVisibility(view1.GONE);
                    btnIcon3.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                    btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon4.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                } else {
                    expandable3.setVisibility(view1.GONE);
                    btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                }
            });
            expand4.setOnClickListener(view1 -> {
                Log.d("TAG", "SetExpandableCardView: check D");
                if (expandable4.getVisibility() == view1.GONE) {
                    expandable4.setVisibility(view1.VISIBLE);
                    expandable.setVisibility(view1.GONE);
                    expandable2.setVisibility(view1.GONE);
                    expandable3.setVisibility(view1.GONE);
                    btnIcon4.setBackgroundResource(R.drawable.ic_baseline_remove_circle_outline_24);
                    btnIcon.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon2.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                    btnIcon3.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                } else {
                    expandable4.setVisibility(view1.GONE);
                    btnIcon4.setBackgroundResource(R.drawable.ic_outline_add_circle_outline_24);
                }
            });
        } catch (Exception e) {
            Log.d("TAG", "onActivityResult: check 5" + e.toString());
        }
    }

    private void CameraPermission(Context context) {
        if (isPass) {
            isPass = false;
            new Handler().post(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_CODE);
                    } else {
                        showAlertDialog();
                    }
                }
            });
        }

    }

    private void focusOnTouch(MotionEvent event) {
        if (mCamera != null) {
            Camera.Parameters parameters = mCamera.getParameters();
            if (parameters.getMaxNumMeteringAreas() > 0) {
                Log.i("TAG", "fancy !");
                Rect rect = calculateFocusArea(event.getX(), event.getY());

                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
                meteringAreas.add(new Camera.Area(rect, 800));
                parameters.setFocusAreas(meteringAreas);

                mCamera.setParameters(parameters);
            }
        }
    }

    private Rect calculateFocusArea(float x, float y) {
        int left = clamp(Float.valueOf((x / surfaceView.getWidth()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        int top = clamp(Float.valueOf((y / surfaceView.getHeight()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);

        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private int clamp(int touchCoordinateInCameraReper, int focusAreaSize) {
        int result;
        if (Math.abs(touchCoordinateInCameraReper) + focusAreaSize / 2 > 1000) {
            if (touchCoordinateInCameraReper > 0) {
                result = 1000 - focusAreaSize / 2;
            } else {
                result = -1000 + focusAreaSize / 2;
            }
        } else {
            result = touchCoordinateInCameraReper - focusAreaSize / 2;
        }
        return result;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
        }
    }

    public static void setCameraDisplayOrientation(Activity activity, int cameraId, android.hardware.Camera camera) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = activity.getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    public void showAlertDialog() {
        LayoutInflater inflater = getLayoutInflater();
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        View dialogLayout = inflater.inflate(R.layout.custom_camera_alertbox, null);
        alertDialog.setView(dialogLayout);
        alertDialog.setCancelable(false);
        final AlertDialog dialog = alertDialog.create();
        surfaceView = (SurfaceView) dialogLayout.findViewById(R.id.surfaceViews);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_HARDWARE);
        surfaceViewCallBack = new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    mCamera = Camera.open();
                } catch (RuntimeException e) {
                }
                Camera.Parameters parameters;
                parameters = mCamera.getParameters();
                List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
                parameters.setPictureSize(sizes.get(0).width, sizes.get(0).height);
                mCamera.setParameters(parameters);
                setCameraDisplayOrientation(getActivity(), 0, mCamera);
                try {
                    mCamera.setPreviewDisplay(surfaceHolder);
                    mCamera.startPreview();
                } catch (Exception e) {
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

            }
        };
        surfaceHolder.addCallback(surfaceViewCallBack);
        Button btn = dialogLayout.findViewById(R.id.capture_image_btn);
        btn.setOnClickListener(v -> {
            mCamera.takePicture(null, null, null, pictureCallback);
        });
        Button closeBtn = dialogLayout.findViewById(R.id.close_image_btn);
        closeBtn.setOnClickListener(v -> {
            dialog.cancel();
            isPass = true;
        });
        dialog.show();

        pictureCallback = (bytes, camera) -> {
            Matrix matrix = new Matrix();
            matrix.postRotate(90F);
            thumbnail = Bitmap.createBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length), 0, 0, BitmapFactory.decodeByteArray(bytes, 0, bytes.length).getWidth(), BitmapFactory.decodeByteArray(bytes, 0, bytes.length).getHeight(), matrix, true);
            passbookPhotoTv.setVisibility(View.GONE);
            passbookPhotoIv.setImageBitmap(thumbnail);
            camera.stopPreview();
            if (camera != null) {
                camera.release();
                mCamera = null;
            }
            dialog.cancel();
            isPass = true;
        };

        surfaceView.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                focusOnTouch(motionEvent);
            }
            return false;
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        try {
            new Handler().post(() -> {
                if (requestCode == PERMISSION_CODE) {
                    if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                        showAlertDialog();
                    } else {
                        isPass = true;
                        Toast.makeText(context, "Permission denied...", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            Log.d("TAG", "onActivityResult: check 10" + e.toString());
        }
    }

    public void uploadImage() {
        if (thumbnail != null) {
            getActivity().runOnUiThread(() -> {
                final StorageReference storageReference = mStorageRef.child("/EmployeeImage" + "/" + empId);
                StorageReference mountainImagesRef = storageReference.child("passbook.jpg");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                thumbnail.compress(Bitmap.CompressFormat.JPEG, 20, baos);
                byte[] data = baos.toByteArray();
                UploadTask uploadTask = mountainImagesRef.putBytes(data);
                uploadTask.addOnFailureListener(exception -> {
                }).addOnSuccessListener(taskSnapshot -> mountainImagesRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    if (uri != null) {
                        passbookPhotoUrl = uri.toString();
                        uploadEmpInfo();
                    }
                }).addOnFailureListener(e -> cmn.showAlertDialog("Alert", "Please Retry", false, context)
                ));
            });
        } else {
            uploadEmpInfo();
        }
    }

    public void setDefaults() {
        cmn.setProgressDialog("Please Wait", "PreparingData", context, (Activity) context);
        rootRef.child("Employees").child(empId).child("BankDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("AccountDetails").hasChild("accountNumber")) {
                    uAccountNumber = String.valueOf(dataSnapshot.child("AccountDetails").child("accountNumber").getValue());
                    bAccountNumber.setText(uAccountNumber);
                }
                if (dataSnapshot.child("AccountDetails").hasChild("ifsc")) {
                    uIFSC = String.valueOf(dataSnapshot.child("AccountDetails").child("ifsc").getValue());
                    bIFSC.setText(uIFSC);
                }
                if (dataSnapshot.hasChild("isLock")){
                    isLock = dataSnapshot.child("isLock").getValue().toString();
                    if (isLock.equalsIgnoreCase("1")) {
                        bAccountNumber.setEnabled(false);
                        bIFSC.setEnabled(false);
                    }
                }
                if (dataSnapshot.child("AccountDetails").hasChild("passbookPhotoUrl")) {
                    passbookPhotoUrl = String.valueOf(dataSnapshot.child("AccountDetails").child("passbookPhotoUrl").getValue());
                }
                if (dataSnapshot.child("AccountDetails").hasChild("familyMembers")) {
                    uFamilyMember = String.valueOf(dataSnapshot.child("AccountDetails").child("familyMembers").getValue());
                    bFamilyMember.setText(uFamilyMember);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("name")) {
                    uNName = String.valueOf(dataSnapshot.child("NomineeDetails").child("name").getValue());
                    nName.setText(uNName);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("relation")) {
                    uNRelation = String.valueOf(dataSnapshot.child("NomineeDetails").child("relation").getValue());
                    nRelation.setText(uNRelation);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("address")) {
                    uNAddress = String.valueOf(dataSnapshot.child("NomineeDetails").child("address").getValue());
                    nAddress.setText(uNAddress);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("mobile")) {
                    uNMobile = String.valueOf(dataSnapshot.child("NomineeDetails").child("mobile").getValue());
                    nMobile.setText(uNMobile);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("uidNumber")) {
                    uNUID = String.valueOf(dataSnapshot.child("NomineeDetails").child("uidNumber").getValue());
                    nUID.setText(uNUID);
                }
                if (dataSnapshot.child("NomineeDetails").hasChild("email")) {
                    uNEmail = String.valueOf(dataSnapshot.child("NomineeDetails").child("email").getValue());
                    nEmail.setText(uNEmail);
                }
                if (dataSnapshot.child("ProvidentFundDetails").hasChild("uanNumber")) {
                    upfUAN = String.valueOf(dataSnapshot.child("ProvidentFundDetails").child("uanNumber").getValue());
                    pfUAN.setText(upfUAN);
                }
                if (dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").hasChild("insuranceNumber")) {
                    previousPFNumber.setText(String.valueOf(dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").child("insuranceNumber").getValue()));
                }
                if (dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").hasChild("employeeCode")) {
                    previousEmpCode.setText(String.valueOf(dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").child("employeeCode").getValue()));
                }
                if (dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").hasChild("companyName")) {
                    previousCompanyName.setText(String.valueOf(dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").child("companyName").getValue()));
                }
                if (dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").hasChild("companyEmail")) {
                    previousCompanyEmail.setText(String.valueOf(dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").child("companyEmail").getValue()));
                }
                if (dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").hasChild("companyAddress")) {
                    previousCompanyAddress.setText(String.valueOf(dataSnapshot.child("ProvidentFundDetails/PreviousPFDetails").child("companyAddress").getValue()));
                }
                try {
                    Picasso.get().load(passbookPhotoUrl).error(R.drawable.error_info).into(passbookPhotoIv);
                    passbookPhotoIv.setOnClickListener(view -> {
                        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
                        int width = display.getWidth();
                        int height = display.getWidth();
                        final Dialog dialog = new Dialog(context);
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                        View layout = inflater.inflate(R.layout.custom_fullimage_dialog, (ViewGroup) view.findViewById(R.id.layout_root));
                        ImageView image = layout.findViewById(R.id.fullimage);
                        LinearLayout linearLayout = layout.findViewById(R.id.closeBtn);
                        image.setImageDrawable(passbookPhotoIv.getDrawable());
                        image.getLayoutParams().height = height;
                        image.getLayoutParams().width = width;
                        new PhotoViewAttacher(image);
                        image.requestLayout();
                        linearLayout.setOnClickListener(view1 -> dialog.dismiss());
                        dialog.setContentView(layout);
                        dialog.show();
                    });
                    if (passbookPhotoUrl != null) {
                        passbookPhotoTv.setVisibility(View.GONE);
                    }
                    cmn.closeDialog((Activity) context);

                } catch (Exception e) {
                    cmn.closeDialog((Activity) context);
                    Log.d("TAG", "onActivityResult: check EE" + e.toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private class GetImages extends AsyncTask<Object, Object, Object> {
        Bitmap bitmaps;

        @Override
        protected Object doInBackground(Object... objects) {
            try {
                URL url = new URL(passbookPhotoUrl);
                URLConnection conn = url.openConnection();
                bitmaps = BitmapFactory.decodeStream(conn.getInputStream());
            } catch (Exception ex) {
            }
            return null;
        }

        @SuppressLint("WrongThread")
        @Override
        protected void onPostExecute(Object o) {
            try {
                File root = new File(Environment.getExternalStorageDirectory(), "Employee/" + empId);
                if (!root.exists()) {
                    root.mkdirs();
                }
                File wardFile = new File(root, "Passbook.jpg");
                try {
                    FileOutputStream out = new FileOutputStream(wardFile);
                    bitmaps.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    out.flush();
                    out.close();
                    cmn.showAlertDialog("", "Successfully save.", false, context);
                } catch (Exception e) {
                    e.printStackTrace();
                    cmn.showAlertDialog("Alert", "Please Retry", false, context);
                }
            } catch (Exception e) {
                cmn.showAlertDialog("Alert", "Please Retry", false, context);
            }
            cmn.closeDialog((Activity) context);
        }

    }

    public void uploadEmpInfo() {
        rootRef.child("Employees").child(empId).child("BankDetails").child("AccountDetails").child("accountNumber").setValue(uAccountNumber);
        rootRef.child("Employees").child(empId).child("BankDetails").child("AccountDetails").child("ifsc").setValue(uIFSC.toUpperCase());
        rootRef.child("Employees").child(empId).child("BankDetails").child("AccountDetails").child("passbookPhotoUrl").setValue(passbookPhotoUrl);
        rootRef.child("Employees").child(empId).child("BankDetails").child("AccountDetails").child("familyMembers").setValue(uFamilyMember);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("name").setValue(uNName);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("relation").setValue(uNRelation);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("address").setValue(uNAddress);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("mobile").setValue(uNMobile);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("uidNumber").setValue(uNUID);
        rootRef.child("Employees").child(empId).child("BankDetails").child("NomineeDetails").child("email").setValue(uNEmail);
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails").child("uanNumber").setValue(upfUAN);
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails/PreviousPFDetails").child("insuranceNumber").setValue(previousPFNumber.getText().toString());
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails/PreviousPFDetails").child("employeeCode").setValue(previousEmpCode.getText().toString());
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails/PreviousPFDetails").child("companyName").setValue(previousCompanyName.getText().toString());
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails/PreviousPFDetails").child("companyEmail").setValue(previousCompanyEmail.getText().toString());
        rootRef.child("Employees").child(empId).child("BankDetails").child("ProvidentFundDetails/PreviousPFDetails").child("companyAddress").setValue(previousCompanyAddress.getText().toString());
        if (from.equals("add")) {
            sharedPreferences.edit().putBoolean("Bank", true).apply();
            ((Registration) requireContext()).iconColor();
        } else {
            sharedPreferences.edit().putBoolean("Bank", true).apply();
            ((Registration) context).RemoveBadges();
            cmn.showAlertDialog("Alert", "Changes Saved Successfully", false, context);
        }
        cmn.closeDialog((Activity) context);
    }

    private void setNextBtn() {
        try {
            if (bAccountNumber.getText().toString().trim().length() != 0 && !bAccountNumber.getText().toString().trim().contains(" ")) {
                uAccountNumber = bAccountNumber.getText().toString();
                if (bIFSC.getText().toString().trim().length() != 0 && !bIFSC.getText().toString().trim().contains(" ")) {
                    uIFSC = bIFSC.getText().toString();
                    if (bFamilyMember.getText().toString().trim().length() != 0) {
                        uFamilyMember = bFamilyMember.getText().toString().trim();
                        if (passbookPhotoUrl != null || thumbnail != null) {
                            upfUAN = pfUAN.getText().toString();
                            uNName = nName.getText().toString().trim();
                            uNRelation = nRelation.getText().toString().trim();
                            uNAddress = nAddress.getText().toString().trim();
                            uNMobile = nMobile.getText().toString().trim();
                            uNUID = nUID.getText().toString().trim();
                            uNEmail = nEmail.getText().toString().trim();
                            cmn.setProgressDialog("Please Wait", "Uploading data", context, (Activity) context);
                            uploadImage();
                        } else {
                            cmn.showAlertDialog("Alert", "Click Passbook Photo", false, context);
                        }
                    } else {
                        cmn.showAlertDialog("Alert", "Enter Number of Family Member", false, context);
                    }
                } else {
                    cmn.showAlertDialog("Alert", "Enter Ifsc code", false, context);
                }
            } else {
                cmn.showAlertDialog("Alert", "Enter Account Number", false, context);
            }
        } catch (Exception e) {
            Log.d("TAG", "onActivityResult: check 14" + e.toString());
        }
    }

    public class FamilyMemberAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return familyMemberList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView name, age, relation, reside, residenceTown, residenceState, income, disability, serialNo;
            Button familyEditBtn;
            LinearLayout resideLayout;
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.family_member_list, parent, false);
            }
            try {
                name = (TextView) convertView.findViewById(R.id.familyName);
                age = (TextView) convertView.findViewById(R.id.familyAge);
                relation = (TextView) convertView.findViewById(R.id.familyRelation);
                reside = (TextView) convertView.findViewById(R.id.familyResiding);
                residenceTown = (TextView) convertView.findViewById(R.id.familyTown);
                residenceState = (TextView) convertView.findViewById(R.id.familyState);
                income = (TextView) convertView.findViewById(R.id.familyIncome);
                disability = (TextView) convertView.findViewById(R.id.familyDisability);
                serialNo = (TextView) convertView.findViewById(R.id.familyMemberSerial);
                familyEditBtn = (Button) convertView.findViewById(R.id.editFamilyDetails);
                resideLayout = (LinearLayout) convertView.findViewById(R.id.resideLayout);
                FamilyMemberModel sList = familyMemberList.get(position);
                name.setText(sList.getName());
                age.setText(sList.getAge());
                relation.setText(sList.getRelation());
                reside.setText(sList.getResiding());
                if (sList.getResiding().equals("No")) {
                    resideLayout.setVisibility(View.VISIBLE);
                    residenceTown.setText(sList.getFamilyMemberTown());
                    residenceState.setText(sList.getFamilyMemberState());
                } else {
                    resideLayout.setVisibility(View.GONE);
                }
                income.setText(sList.getIncome());
                disability.setText(sList.getDisability());
                serialNo.setText("" + sList.getSerialNo());

                familyEditBtn.setOnClickListener(v -> {
                    isAddFamily = false;
                    addNewFamilyMember.setText("Changes");
                    familyMemberListViewLayout.setVisibility(View.GONE);
                    familyMemberLV.setVisibility(View.GONE);
                    addFamilyLayout.setVisibility(View.VISIBLE);
                    fMName.setText(sList.getName());
                    fMDOB.setText(sList.getAge());
                    fMRelation.setText(sList.getRelation());
                    if (sList.getResiding().equals("Yes")) {
                        linearResidence.setVisibility(View.GONE);
                        fMResidingSpinner.setSelection(1);
                    } else {
                        linearResidence.setVisibility(View.VISIBLE);
                        fMResidingSpinner.setSelection(2);
                        fMTown.setText(sList.getFamilyMemberTown());
                        fMStateSpinner.setSelection(stateList.indexOf(sList.getFamilyMemberState()));
                    }
                    fMIncome.setText(sList.getIncome());
                    if (sList.getDisability().equals("Yes")) {
                        fMDisabilitySpinner.setSelection(1);
                    } else {
                        fMDisabilitySpinner.setSelection(2);
                    }
                    changesFamilyId = sList.getId();
                });
            } catch (Exception e) {
                Log.d("TAG", "onActivityResult: check 15" + e.toString());
            }

            return convertView;
        }
    }

    private void datePicker() {
        int mYear, mMonth, mDay;
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog((Activity) context,
                (view, year, monthOfYear, dayOfMonth) -> {
                    String date_time;
                    if (monthOfYear + 1 <= 9) {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-0" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    } else {
                        if (dayOfMonth <= 9) {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + "0" + dayOfMonth;
                        } else {
                            date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        }
                    }
                    fMDOB.setText(date_time);
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }
}