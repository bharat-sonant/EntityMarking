package com.wevois.vcarebackoffice.employeeattendance.viewmodel

import android.R
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.wevois.vcarebackoffice.Common.CommonFunctions
import com.wevois.vcarebackoffice.Launcher
import com.wevois.vcarebackoffice.employeeattendance.EmployeeAssignmentActivity
import com.wevois.vcarebackoffice.employeeattendance.NonNavigationEmployeeId
import com.wevois.vcarebackoffice.employeeattendance.model.OtherDetails
import com.wevois.vcarebackoffice.employeeattendance.model.ParentRecyclerviewModel
import com.wevois.vcarebackoffice.employeeattendance.repository.DutyOffKotlinRepository
import com.wevois.vcarebackoffice.employeeattendance.repository.WardSelectKotlinRepository
import com.wevois.vcarebackoffice.employeeattendance.views.DutyOffReview
import java.text.SimpleDateFormat
import java.util.*

class WardSelectKotlinViewModel(var activity: Activity, var spinner: Spinner) : ViewModel() {

    var common = CommonFunctions.getInstance()
    var repository = WardSelectKotlinRepository()
    var repositoryDuty = DutyOffKotlinRepository()
    var databaseReferencePath: DatabaseReference
    var preferences: SharedPreferences
    var loginId: String
    var dustbinPlanSnapshot: DataSnapshot? = null
    var isMoved = true
    var wardList: ArrayList<String> = ArrayList()
    var planIdList: ArrayList<String?> = ArrayList()
    var nonNavigationList: ArrayList<String> = ArrayList()
    var otherDetails: ArrayList<OtherDetails> = ArrayList()
    var userModels: ArrayList<ParentRecyclerviewModel> = ArrayList()
    var offLineData: ArrayList<String> = ArrayList()

    init {
        preferences = activity.getSharedPreferences("path", Context.MODE_PRIVATE)
        databaseReferencePath = common.getDatabasePath(activity)
        loginId = activity.getSharedPreferences("loginData", Context.MODE_PRIVATE).getString("loginId", "101").toString()
        getDustbinPlan()
    }

    private fun getDustbinPlan() {
        common.setProgressDialog("", "Details download हो रही है|", activity, activity)
        repository.getDustbinPlan(common.getDatabasePath(activity)).observe((activity as LifecycleOwner)) { response: DataSnapshot? ->
            if (response != null) {
                if (response.value != null) {
                    dustbinPlanSnapshot = response
                }
            }
            if (!preferences.getString("wardList", "").equals("", ignoreCase = true)) {
                getWardNamesToSpinner()
            } else {
                common.closeDialog(activity)
                Toast.makeText(activity, "No wards found.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getWardNamesToSpinner() {

        common.closeDialog(activity)
        val listAsStringNon = preferences.getString("nonNavigationTaskList", null)
        Log.d("TAG", "getWardNamesToSpinner: check "+listAsStringNon)
        val nonNavigationString = listAsStringNon?.substring(1, listAsStringNon.length - 1)?.split(",")?.toTypedArray()
        for (i in nonNavigationString!!.indices) {
            nonNavigationList.add(nonNavigationString!![i].replace(" ", "").trim { it <= ' ' })
        }
        wardList.add("Select Ward")
        planIdList.add("Select Ward")
        val listAsString = preferences.getString("wardList", null)
        val reasonString = listAsString?.substring(1, listAsString?.length - 1)?.split(",")?.toTypedArray()
        for (i in reasonString!!.indices) {
            val reasonType = reasonString[i].replace(" ", "").trim { it <= ' ' }
            if (reasonType.equals("BinLifting", ignoreCase = true)) {
                if (dustbinPlanSnapshot != null) {
                    if (dustbinPlanSnapshot!!.value != null) {
                        if (dustbinPlanSnapshot!!.hasChildren()) {
                            for (snapshot in dustbinPlanSnapshot!!.children) {
                                if (snapshot.hasChild("planName")) {
                                    wardList.add(reasonType + "(" + snapshot.child("planName").value.toString() + ")")
                                    planIdList.add(snapshot.key)
                                }
                            }
                        }
                    }
                }
            } else {
                wardList.add(reasonType)
                planIdList.add(reasonType)
            }
        }
        bindWardToSpinner()
    }

    private fun bindWardToSpinner() {
        val spinnerArrayAdapter = ArrayAdapter(activity, R.layout.simple_spinner_item, wardList)
        spinnerArrayAdapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
        spinner!!.setAdapter(spinnerArrayAdapter)
    }

    fun continueBtn() {
        if (isMoved) {
            isMoved = false
            if (spinner.selectedItem.toString() == "Select Ward") {
                val selectedView = spinner.selectedView
                if (selectedView != null && selectedView is TextView) {
                    spinner.requestFocus()
                    val selectedTextView = selectedView
                    selectedTextView.error = "error"
                    selectedTextView.setTextColor(Color.RED)
                    selectedTextView.text = "please select ward"
                    spinner.performClick()
                }
                isMoved = true
            } else {
                common.setProgressDialog("Please wait...", "Assignment चेक हो रहा है |", activity, activity)
                saveLocalData();
//                checkAssignment(spinner.selectedItem)
            }
        }
    }

    private fun saveLocalData() {
        Log.d("TAG", "saveLocalData: check "+preferences.getString("dutyOffOtherDetails", "")+"   "+preferences.getString("swipeOtherDetails", ""))
        if (preferences.getString("dutyOffOtherDetails", "") != "") {
            otherDetails = Gson().fromJson(preferences.getString("dutyOffOtherDetails", ""), object : TypeToken<ArrayList<OtherDetails?>?>() {}.type)
            userModels = Gson().fromJson(preferences.getString("dutyOffUserDetails", ""), object : TypeToken<ArrayList<ParentRecyclerviewModel?>?>() {}.type)
            offLineData = otherDetails[0].offlineSave
            if(offLineData.size==0){
                preferences.edit().putString("dutyOffUserDetails", "").apply()
                preferences.edit().putString("dutyOffOtherDetails", "").apply()
                checkAssignment(spinner.selectedItem)
            }else{
                for (a in offLineData) {
                    if(a.equals("emp", ignoreCase = true)){
                        repositoryDuty.setEmployeeData(activity,common,otherDetails,userModels,preferences,otherDetails[0].time,otherDetails[0].wards,otherDetails[0].workPercentage.toInt())?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("emp","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("realTimeCount", ignoreCase = true)){
                        repositoryDuty.realTimeCountDetails(activity,common,userModels)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("realTimeCount","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("vehicle", ignoreCase = true)){
                        repositoryDuty.sendVehicleData(activity,common,otherDetails,"","","","1")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("vehicle","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("realTimeDetails", ignoreCase = true)){
                        repositoryDuty.sendRealTimeDetailData(activity,common,otherDetails,otherDetails[0].wards[otherDetails[0].wards.size-1],"no","completed","notActive")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("realTimeDetails","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("dustbinAssignment", ignoreCase = true)){
                        repositoryDuty.planFree(activity,common,otherDetails)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("dustbinAssignment","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("taskDetails", ignoreCase = true)){
                        repositoryDuty.sendTaskDetailData(activity,common,otherDetails[0].wards[otherDetails[0].wards.size-1],"Available")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("taskDetails","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("WasteCollectionInfo", ignoreCase = true)){
                        repositoryDuty.sendWasteCollectionInfoDetailData(activity,common,otherDetails[0].wards,otherDetails[0].time)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("WasteCollectionInfo","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("TripWasteCollectionInfo", ignoreCase = true)){
                        repositoryDuty.checkTripWasteCollectionInfoComplete(activity,common,otherDetails,preferences,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                            if (response=="success"){
                                offLineData.add("setTripWards")
                                offLineData.add("setTripRealTimeWardsDetails")
                                removedLocal("TripWasteCollectionInfo","dutyOffUserDetails","dutyOffOtherDetails")
                                repositoryDuty.setTripWards(activity,common,otherDetails,preferences)?.observe((activity as LifecycleOwner), { response: String ->
                                    removedLocal("setTripWards","dutyOffUserDetails","dutyOffOtherDetails")
                                })
                                repositoryDuty.setTripRealTimeWardsDetails(activity,common,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                                    removedLocal("setTripRealTimeWardsDetails","dutyOffUserDetails","dutyOffOtherDetails")
                                })
                            }else {
                                removedLocal("TripWasteCollectionInfo","dutyOffUserDetails","dutyOffOtherDetails")
                            }
                        })
                    }
                    if(a.equals("setTripWards", ignoreCase = true)){
                        repositoryDuty.setTripWards(activity,common,otherDetails,preferences)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("setTripWards","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                    if(a.equals("setTripRealTimeWardsDetails", ignoreCase = true)){
                        repositoryDuty.setTripRealTimeWardsDetails(activity,common,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("setTripRealTimeWardsDetails","dutyOffUserDetails","dutyOffOtherDetails")
                        })
                    }
                }
            }
        }else if (preferences.getString("swipeOtherDetails", "") != ""){
            otherDetails = Gson().fromJson(preferences.getString("swipeOtherDetails", ""), object : TypeToken<ArrayList<OtherDetails?>?>() {}.type)
            userModels = Gson().fromJson(preferences.getString("swipeUserDetails", ""), object : TypeToken<ArrayList<ParentRecyclerviewModel?>?>() {}.type)
            offLineData = otherDetails[0].offlineSave
            Log.d("TAG", "saveLocalData: check B "+offLineData+"   "+userModels)
            if(offLineData.size==0){
                preferences.edit().putString("swipeUserDetails", "").apply()
                preferences.edit().putString("swipeOtherDetails", "").apply()
                checkAssignment(spinner.selectedItem)
            }else{
                for (a in offLineData) {
                    if(a.equals("wasteCollectionInfoDutyOff", true)){
                        repositoryDuty.sendWasteCollectionInfoDetailData(activity, common, otherDetails[0].wards, otherDetails[0].time)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("wasteCollectionInfoDutyOff","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("wasteCollectionInfoDutyOnWorker", true)){
                        repositoryDuty.setWasteCollectionInfoDutyOnWorker(activity, common, otherDetails, userModels)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("wasteCollectionInfoDutyOnWorker","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("wasteCollectionInfoDutyOnSummary", true)){
                        repositoryDuty.setWasteCollectionInfoDutyOnSummary(activity, common, otherDetails, userModels)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("wasteCollectionInfoDutyOnSummary","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("empOff", true)){
                        repositoryDuty.setEmployeeSkipDutyOff(activity, common, userModels, loginId , otherDetails[0].time, otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("empOff","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("empOn", true)){
                        repositoryDuty.setEmployeeDutyOn(activity, common, otherDetails, userModels, loginId , otherDetails[0].time)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("empOn","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("vehicle", true)){
                        repositoryDuty.sendVehicleData(activity, common, otherDetails,userModels[0].id,userModels[1].id,otherDetails[0].newWard,"3")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("vehicle","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("realTimeDetailsOff", true)){
                        repositoryDuty.sendRealTimeDetailData(activity, common, otherDetails,otherDetails[0].wards[otherDetails[0].wards.size-1],"no","completed","notActive")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("realTimeDetailsOff","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("realTimeDetailsOn", true)){
                        repositoryDuty.sendRealTimeDetailData(activity, common, otherDetails,otherDetails[0].newWard,"yes","active","notActive")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("realTimeDetailsOn","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("taskDetailsOff", true)){
                        repositoryDuty.sendTaskDetailData(activity, common, otherDetails[0].wards[otherDetails[0].wards.size-1],"Available")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("taskDetailsOff","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("taskDetailsOn", true)){
                        repositoryDuty.sendTaskDetailData(activity, common, otherDetails[0].newWard,"Assigned")?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("taskDetailsOn","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("whoAssignWork", true)){
                        repositoryDuty.saveWhoAssignWork(activity, common, otherDetails,"")?.observe((activity as LifecycleOwner), {
                            removedLocal("whoAssignWork","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("locationHistory", true)){
                        repositoryDuty.saveLocationHistory(activity, common, otherDetails[0].newWard,otherDetails[0].time)?.observe((activity as LifecycleOwner), {
                            removedLocal("locationHistory","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("TripWasteCollectionInfo", true)){
                        repositoryDuty.checkTripWasteCollectionInfoComplete(activity,common,otherDetails,preferences,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                            if (response=="success"){
                                offLineData.add("setTripWards")
                                offLineData.add("setTripRealTimeWardsDetails")
                                removedLocal("TripWasteCollectionInfo","swipeUserDetails","swipeOtherDetails")
                                repositoryDuty.setTripWards(activity,common,otherDetails,preferences)?.observe((activity as LifecycleOwner), { response: String ->
                                    removedLocal("setTripWards","swipeUserDetails","swipeOtherDetails")
                                })
                                repositoryDuty.setTripRealTimeWardsDetails(activity,common,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                                    removedLocal("setTripRealTimeWardsDetails","swipeUserDetails","swipeOtherDetails")
                                })
                            }else {
                                removedLocal("TripWasteCollectionInfo","swipeUserDetails","swipeOtherDetails")
                            }
                        })
                    }
                    if(a.equals("setTripWards", true)){
                        repositoryDuty.setTripWards(activity,common,otherDetails,preferences)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("setTripWards","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                    if(a.equals("setTripRealTimeWardsDetails", true)){
                        repositoryDuty.setTripRealTimeWardsDetails(activity,common,otherDetails[0].wards)?.observe((activity as LifecycleOwner), { response: String ->
                            removedLocal("setTripRealTimeWardsDetails","swipeUserDetails","swipeOtherDetails")
                        })
                    }
                }
            }
        }else {
            checkAssignment(spinner.selectedItem)
        }
    }

    private fun removedLocal(removeData: String,userKey:String,otherKey:String) {
        try {
            Log.d("TAG", "removedLocal: check "+offLineData)
            if (offLineData.contains(removeData)){
                offLineData.remove(removeData)
            }
            Log.d("TAG", "removedLocal: check A "+offLineData+"   "+offLineData.size)
            otherDetails[0].offlineSave = offLineData
            Log.d("TAG", "removedLocal: check B "+otherDetails)
            preferences.edit().putString(userKey, Gson().toJson(userModels)).apply()
            preferences.edit().putString(otherKey, Gson().toJson(otherDetails)).apply()
            if(offLineData.size==0){
                preferences.edit().putString(userKey, "").apply()
                preferences.edit().putString(otherKey, "").apply()
                checkAssignment(spinner.selectedItem)
            }
        } catch (e: Exception) {
        }
    }

    private fun checkAssignment(selectedItem: Any) {
        Log.d("TAG", "checkAssignment: check "+selectedItem+"   "+spinner.selectedItem)
        if (selectedItem.toString().contains("BinLifting")) {
            databaseReferencePath.child("DustbinData/DustbinPickingPlans/" + SimpleDateFormat("yyyy-MM-dd").format(Date()) + "/" + planIdList[spinner.selectedItemPosition]).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value != null) {
                        val i: Intent
                        if (dataSnapshot.child("isAssigned").value.toString().equals("false", ignoreCase = true)) {
                            i = Intent(activity, EmployeeAssignmentActivity::class.java)
                            i.putExtra("ward", spinner.selectedItem.toString())
                            i.putExtra("planName", dataSnapshot.child("planName").value.toString())
                            i.putExtra("planId", planIdList[spinner.selectedItemPosition])
                        } else {
                            i = Intent(activity, DutyOffReview::class.java)
                            val otherDetails = ArrayList<OtherDetails>()
                            val wards = ArrayList<String>()
                            wards.add(spinner.selectedItem.toString())
                            otherDetails.add(OtherDetails(wards, "", dataSnapshot.child("planName").value.toString(), planIdList[spinner.selectedItemPosition], null, null, null, null, null, "", null, "","",""))
                            i.putExtra("otherDetails", Gson().toJson(otherDetails))
                        }
                        common.closeDialog(activity)
                        activity.startActivity(i)
                        isMoved = true
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        } else if (nonNavigationList.contains(selectedItem.toString())) {
            val i = Intent(activity, NonNavigationEmployeeId::class.java)
            i.putExtra("ward", spinner.selectedItem.toString())
            common.closeDialog(activity)
            activity.startActivity(i)
            isMoved = true
        } else {
            databaseReferencePath.child("Tasks/$selectedItem").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value != null) {
                        isMoved = if (dataSnapshot.value.toString().equals("Available", ignoreCase = true)) {
                            val i = Intent(activity, EmployeeAssignmentActivity::class.java)
                            i.putExtra("ward", spinner.selectedItem.toString())
                            common.closeDialog(activity)
                            activity.startActivity(i)
                            true
                        } else {
                            val otherDetails = ArrayList<OtherDetails>()
                            val wards = ArrayList<String>()
                            wards.add(spinner.selectedItem.toString())
                            otherDetails.add(OtherDetails(wards, "", "", "", null, null, null, null, null, "", null, "","",""))
                            val i = Intent(activity, DutyOffReview::class.java)
                            i.putExtra("otherDetails", Gson().toJson(otherDetails))
                            common.closeDialog(activity)
                            activity.startActivity(i)
                            true
                        }
                    } else {
                        isMoved = true
                        common.showAlertDialog("Wrong Assignment!", "Task गलत है | ", false, activity)
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })
        }
    }

    fun onBack() {
        if (isMoved) {
            isMoved = false
            val intent = Intent(activity, Launcher::class.java)
            activity.startActivity(intent)
            activity.finish()
        }
    }
}