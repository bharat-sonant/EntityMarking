package com.wevois.vcarebackoffice.employeeattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.wevois.vcarebackoffice.Common.CommonFunctions;
import com.wevois.vcarebackoffice.Common.CommonUtils;
import com.wevois.vcarebackoffice.R;
import com.wevois.vcarebackoffice.employeeattendance.views.WardSelectKotlin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class EmployeeVehicleKmDriven extends AppCompatActivity {
    EditText startTrip,endTrip;
    String vehicleNo="",date="",time,ward="";
    DatabaseReference databaseReference;
    CommonFunctions common = CommonFunctions.getInstance();
    CommonUtils commonUtils;
    boolean isMoved = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_vehicle_km_driven);
        initPage();
        setAction();
    }

    private void initPage() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView backButton = findViewById(R.id.toolbarback);
        backButton.setOnClickListener(view -> onBackPressed());
        startTrip = findViewById(R.id.vehicleStartMeter);
        endTrip = findViewById(R.id.vehicleEndMeter);
        databaseReference = common.getDatabasePath(this);
        commonUtils = new CommonUtils(EmployeeVehicleKmDriven.this);
        vehicleNo = getIntent().getStringExtra("vehicleNo");
        ward = getIntent().getStringExtra("ward");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        date = dateFormat1.format(new Date());
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        time = dateFormat.format(new Date());
    }

    private void setAction() {
        findViewById(R.id.vehicleSaveBtn).setOnClickListener(view -> {
            if (isMoved) {
                isMoved = false;
                commonUtils.checkDoubleClick(EmployeeVehicleKmDriven.this);
                if (startTrip.getText().toString().length() == 0) {
                    startTrip.setError("Please Enter Start Trip Km.");
                    startTrip.requestFocus();
                    isMoved=true;
                } else if (endTrip.getText().toString().length() == 0) {
                    endTrip.setError("Please Enter End Trip Km.");
                    endTrip.requestFocus();
                    isMoved=true;
                } else {
                    common.setProgressDialog("Please wait...", "Data सेव हो रहा है |", EmployeeVehicleKmDriven.this, EmployeeVehicleKmDriven.this);
                    HashMap<String,String> data = new HashMap<>();
                    data.put("start_meter_reading",startTrip.getText().toString());
                    data.put("end_meter_reading",endTrip.getText().toString());
                    data.put("total_km",""+(Integer.parseInt(endTrip.getText().toString())-Integer.parseInt(startTrip.getText().toString())));
                    data.put("time",time);
                    data.put("vehicle_no",vehicleNo);
                    String path = ward;
                    if (ward.contains("BinLifting")){
                        path = "BinLifting/"+vehicleNo;
                    }
                    databaseReference.child("VehicleKmDriven/" + path + "/" + date).setValue(data).addOnCompleteListener(task -> {
                        if (task.isSuccessful()){
                            Intent intent = new Intent(EmployeeVehicleKmDriven.this, WardSelectKotlin.class);
                            startActivity(intent);
                            finish();
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        commonUtils.showAlertDialog("You can not go back");
    }
}